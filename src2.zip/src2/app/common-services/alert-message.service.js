import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let AlertMessageService = class AlertMessageService {
    constructor() {
        this.cActive = false;
        this.cSlideInDown = false;
        this.cSlideOutUp = false;
    }
    get alertMessage() { return this.cAlertMsg; }
    ;
    get isActive() { return this.cActive; }
    ;
    get isSlideInDown() { return this.cSlideInDown; }
    ;
    get isSlideOutUp() { return this.cSlideOutUp; }
    ;
    popupAlertMsg(pAlertMsg) {
        this.cAlertMsg = pAlertMsg;
        this.cActive = true;
        this.cSlideInDown = true;
        setTimeout(() => {
            this.cSlideInDown = false;
            this.cSlideOutUp = true;
        }, 7000);
        setTimeout(() => {
            this.cActive = false;
            this.cSlideOutUp = false;
        }, 7500);
    }
};
AlertMessageService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], AlertMessageService);
export { AlertMessageService };
//# sourceMappingURL=alert-message.service.js.map