import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let LandingPageMsgService = class LandingPageMsgService {
    constructor() {
        /**Css classes*/
        // Transaction module css class
        this._transactions = 'no-transaction';
        this._bulkUpdate = 'no-bulk-update';
        this._disputes = 'no-disputes';
        this._refundChecker = 'no-refund-checker';
        // Invoice module css class
        this._invoice = 'no-invoice';
        this._recurringProfile = 'no-recurring-profile';
        this._invoiceSetting = 'no-invoice-setting';
        this._taskItem = 'no-task-items';
        // Recurring payments module css class
        this._recurringPayments = 'no-recurring-payment';
        //Product module css class
        this._products = 'no-product';
        this._editProducts = 'no-product';
        this._shipping = 'no-shipping';
        this._pendingOrder = 'no-pending-order';
        //Product module css class
        //Marketing tools module css class
        this._qrCode = 'no-discount';
        this._discountCoupons = 'no-discount';
        this._promotions = 'no-promotion';
        this._ccavenueSnip = 'no-snip';
        //Brand360 module css class
        //Reports module css class
        this._salesReport = 'no-sales-report';
        this._report = 'no-reports';
        //Setting module css class
        this._gatewaySettings = 'no-gateway-setting';
        this._apiKeys = 'no-black-list-controls';
        this._velocityChecks = 'no-velocity-checker';
        this._blackListControls = 'no-black-list-controls';
        this._dynamicEventNotification = 'no-dynamic-event-notification';
        this._manageTax = 'no-manage-tax';
        // Other css class
        this._links = 'no-links';
        this._subAccount = 'no-sub-account';
        this._error = 'no-error';
        this._pages = 'no-pages';
        this._tokenExpired = 'no-error';
        this._forbiddenError = 'no-error';
        this._commonError = 'no-error';
        // Customer module css class
        this._customer = "no-invoice";
        /**Message*/
        // Transaction module messages 
        this._noTransactionYetMsg = "You haven't received any orders yet!";
        this._noTransactionMsg = "No transaction found";
        this._noRefundRaisedYetMsg = "You haven't raised any refund request yet!";
        this._noRefundChkMsg = "No record found";
        this._noDisputesRaisedYetMsg = "You haven't raised any disputes yet!";
        this._noDisputesFoundMsg = "No disputes found";
        this._noBulkUpdateYetMsg = "You haven't uploaded any file yet!";
        // Invoice module messages
        this._noInvoiceCreateMsg = "You haven't raised any invoices yet!";
        this._invoiceNoRecMsg = "No record found";
        this._noRecurringProfCreatedYetMsg = "You haven't created any recurring profile(s) yet!";
        this._noRecurringProfMsg = "No recurring profile(s) found.";
        this._noTaskMsg = "No record found";
        // Recurring payments module messages
        this._noRecurringPayCreatedYetMsg = "You haven't created any recurring payment yet!";
        this._noRecurringPayFoundMsg = "No Record Found";
        // Marketing Tools messages
        this._noDiscountCouponYetMsg = "You haven't created any discount coupon yet!";
        this._noDiscountCouponMsg = "No discount coupon found";
        this._noPromoCreatedYetMsg = "You haven't created any promotions yet!";
        this._noPromoMsg = "No promotion found";
        this._noSnipRaisedYetMsg = "You haven't created any SNIP yet!";
        this._noSnipMsg = "No campaign found";
        //Product module messages
        //Brand360 module messages
        //Reports module messages
        this._noReportsMsg = "You haven't received any orders yet!";
        //Setting module messages
        this._velocityChkNoCurrAdded = 'No velocity checks have been set';
        this._noTaxationFound = 'You havent added any tax rates yet!';
        this._noBlackListRecordFoundMsg = "You haven't added any control type yet!";
        // Account Admin messages 
        this._noManageUserMsg = "Sorry! No Records Found";
        this._noLinkedAccountYetMsg = "You haven't added any linked account yet!";
        this._noLinkedAccountFoundMsg = "Sorry! No Records Found";
        // Other messages 
        this._tokenExpiredMsg = 'Session expired';
        this._forbiddenErrorMsg = 'You are not authorized to view this page';
        this._commonErrorMsg = 'Something went wrong';
        this._noCustomerCreateMsg = "You haven't added customer yet!";
    }
    get transactions() { return this._transactions; }
    ;
    get bulkUpdate() { return this._bulkUpdate; }
    ;
    get disputes() { return this._disputes; }
    ;
    get refundChecker() { return this._refundChecker; }
    ;
    get invoice() { return this._invoice; }
    ;
    get recurringProfile() { return this._recurringProfile; }
    ;
    get invoiceSetting() { return this._invoiceSetting; }
    ;
    get taskItem() { return this._taskItem; }
    ;
    get recurringPayments() { return this._recurringPayments; }
    ;
    get products() { return this._products; }
    ;
    get editProducts() { return this._editProducts; }
    ;
    get shipping() { return this._shipping; }
    ;
    get pendingOrder() { return this._pendingOrder; }
    ;
    get qrCode() { return this._qrCode; }
    ;
    get discountCoupons() { return this._discountCoupons; }
    ;
    get promotions() { return this._promotions; }
    ;
    get ccavenueSnip() { return this._ccavenueSnip; }
    ;
    get salesReport() { return this._salesReport; }
    ;
    get report() { return this._report; }
    ;
    get gatewaySettings() { return this._gatewaySettings; }
    ;
    get apiKeys() { return this._apiKeys; }
    ;
    get velocityChecks() { return this._velocityChecks; }
    ;
    get blackListControls() { return this._blackListControls; }
    ;
    get dynamicEventNotification() { return this._dynamicEventNotification; }
    ;
    get manageTax() { return this._manageTax; }
    ;
    get links() { return this._links; }
    ;
    get subAccount() { return this._subAccount; }
    ;
    get error() { return this._error; }
    ;
    get pages() { return this._pages; }
    ;
    get tokenExired() { return this._tokenExpired; }
    ;
    get forbiddenError() { return this._forbiddenError; }
    ;
    get commonError() { return this.commonError; }
    ;
    get customer() { return this._customer; }
    ;
    get noTransactionYetMsg() { return this._noTransactionYetMsg; }
    ;
    get noTransactionMsg() { return this._noTransactionMsg; }
    ;
    get noRefundRaisedYetMsg() { return this._noRefundRaisedYetMsg; }
    ;
    get noRefundChkMsg() { return this._noRefundChkMsg; }
    ;
    get noDisputesRaisedYetMsg() { return this._noDisputesRaisedYetMsg; }
    ;
    get noDisputesFoundMsg() { return this._noDisputesFoundMsg; }
    ;
    get noBulkUpdateYetMsg() { return this._noBulkUpdateYetMsg; }
    get noInvoiceCreateMsg() { return this._noInvoiceCreateMsg; }
    ;
    get invoiceNoRecMsg() { return this._invoiceNoRecMsg; }
    ;
    get noRecurringProfCreatedYetMsg() { return this._noRecurringProfCreatedYetMsg; }
    ;
    get noRecurringProfMsg() { return this._noRecurringProfMsg; }
    ;
    get noTaskMsg() { return this._noTaskMsg; }
    ;
    get noRecurringPayCreatedYetMsg() { return this._noRecurringPayCreatedYetMsg; }
    ;
    get noRecurringPayFoundMsg() { return this._noRecurringPayFoundMsg; }
    ;
    get noDiscountCouponYetMsg() { return this._noDiscountCouponYetMsg; }
    ;
    get noDiscountCouponMsg() { return this._noDiscountCouponMsg; }
    ;
    get noPromoCreatedYetMsg() { return this._noPromoCreatedYetMsg; }
    ;
    get noPromoMsg() { return this._noPromoMsg; }
    ;
    get noSnipRaisedYetMsg() { return this._noSnipRaisedYetMsg; }
    ;
    get noSnipMsg() { return this._noSnipMsg; }
    ;
    get noReportsMsg() { return this._noReportsMsg; }
    ;
    get velocityChkNoCurrAdded() { return this._velocityChkNoCurrAdded; }
    ;
    get noTaxationFound() { return this._noTaxationFound; }
    ;
    get noBlackListRecordFoundMsg() { return this._noBlackListRecordFoundMsg; }
    ;
    get noManageUserMsg() { return this._noManageUserMsg; }
    ;
    get noLinkedAccountYetMsg() { return this._noLinkedAccountYetMsg; }
    ;
    get noLinkedAccountFoundMsg() { return this._noLinkedAccountFoundMsg; }
    ;
    get tokenExiredMsg() { return this._tokenExpiredMsg; }
    ;
    get forbiddenErrorMsg() { return this._forbiddenErrorMsg; }
    ;
    get commonErrorMsg() { return this.commonErrorMsg; }
    ;
    get noCustomerCreateMsg() { return this._noCustomerCreateMsg; }
    ;
};
LandingPageMsgService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], LandingPageMsgService);
export { LandingPageMsgService };
//# sourceMappingURL=landing-page-msg.service.js.map