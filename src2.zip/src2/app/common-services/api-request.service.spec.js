import { TestBed, inject } from '@angular/core/testing';
import { ApiRequestService } from './api-request.service';
describe('ApiRequestService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ApiRequestService]
        });
    });
    it('should be created', inject([ApiRequestService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=api-request.service.spec.js.map