import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let ErrorMessagesService = class ErrorMessagesService {
    constructor() {
        //Common message if response get null
        this._responseNull = 'Something went wrong.';
        //Common message for error response
        this._errorResponse = 'Something went wrong.';
        //Invalid Data
        this._invalidData = 'Invalid Data.';
        /* ---------------------------Angular inbuilt validation---------------------------------------- */
        this._required = 'This information is required.';
        this._number = 'Only numbers are allowed.';
        this._min = 'Please enter a greater value.';
        this._minAmount = 'Please enter a greater value.';
        this._max = 'Please enter a lower value.';
        this._minlength = 'Characters length insufficient.';
        this._maxlength = 'Characters length exceeded.';
        this._disputeMessages = 'Only letters,numbers,hyphens,dots and circular brackets and symbol & are allowed.';
        /* -------------------------End Angular inbuilt validation-------------------------------------- */
        this._letterswithbasicpunc = 'Only letters and punctuations are allowed.';
        this._alphanumericwithbasicpunc = 'Only letters and punctuations are allowed.';
        this._alphanumeric = 'Only letters,numbers,spaces or underscores.';
        this._lettersonly = 'Only letters are allowed.';
        this._nowhitespace = 'Only spaces are allowed.';
        this._ziprange = 'Pincode must be between 902xx-xxxx to 905-xx-xxxx.';
        this._integer = 'Only positive or negative non-decimal numbers are allowed. ';
        this._vinUS = 'Invalid vehicle identification number(VIN).';
        this._dateITA = 'Please enter a correct date.';
        this._dateNL = 'Please enter a valid time between 00:00 and 23:59.';
        this._phoneUS = 'Please specify a valid phone number.';
        this._phoneUK = 'Please specify a valid phone number.';
        this._mobileUK = 'Please specify a valid mobile number.';
        this._strippedminlength = 'Please enter at least {0} characters.';
        this._email2 = 'Only Letters, @,numbers, hyphens,dots and underscores are allowed.';
        this._url2 = 'ErrorMessage';
        this._creditcardtypes = 'Please enter a valid credit card number.';
        this._customDate = 'Please enter a correct date.';
        this._mobile = 'Please enter 10 digit mobile number.';
        /* ****************************** Custom Methods Starts ********************************************* */
        /* *******************************   Common Methods  ************************************************ */
        this._numbersOnly = 'Only numbers are allowed.';
        this._numbersAndDotOnly = 'Only numbers and dot are allowed.';
        this._lettersOnly = 'Only letters are allowed.';
        this._letterAndSpaceOnly = 'Only letters and space between are allowed.';
        this._letterAndNumberOnly = 'Only letters and numbers  are allowed.';
        this._letterSpaceAndDotOnly = 'Only letters,spaces and dots are allowed.';
        this._letterSpaceDotAndApostropheOnly = 'Only letters,space,dot and single apostrophe are allowed.';
        this._letterSpaceDotAndHyphenOnly = 'Only letters,hyphen,dot and space are allowed.';
        this._firstName = 'Only letters and space between words are allowed.';
        this._lastName = 'Only letters, spaces and apostrophe are allowed.';
        this._fullName = 'Only letters,spaces,one appostrophe and dots are allowed.';
        this._email = 'Please enter valid email.';
        this._email3 = 'Please enter valid email address.';
        this._invalidEmailDesc = 'Please enter valid email desc.';
        this._isBeginSpecialChar = 'This information must not begin with a special character.';
        this._isEndSpecialChar = 'This information must not end  with a special character.';
        this._isBeginSpecialCharEmailSub = 'This information must not begin with a special character.';
        this._isEndSpecialCharEmailSub = 'This information must not end with a special character.';
        /* //////////////////for description/////////////////////////////////////////// */
        this._isBeginSpecialCharDesc = 'This information must not begin with a special character.';
        this._isEndSpecialCharDesc = 'This information must not end with a special character.';
        this._isConsecuSpecialCharDesc = 'This information must not have two special characters next to each other.';
        this._isBlankSpace = 'This information is required.';
        /* ///////////////////////////////////////////////////////////////////////////// */
        this._isEndSpecialCharUrl = 'This information must not end with a special character.';
        this._isConsecuSpecialCharUrl = 'This information must not have two special characters next to each other.';
        this._customURL = 'Only letters, numbers, dot slash and colon are allowed.';
        this._invalidURL = 'Please enter a valid url.';
        this._isEndSpecialCharForAddr = 'This information must not end with a special character.';
        this._isConsecuSpecialChar = 'This information must not have two special characters next to each other.';
        this._loginId = 'Invalid User Id.';
        this._checkeUserIdAvailability = 'User Id already exist.';
        this._checkeTaskAvailability = 'Task/Item Name already exists.';
        this._password = 'Invalid Password.';
        this._passwordMin = 'Invalid Password.';
        this._matchPassword = 'Password and Confirm Password do not match.';
        this._passwordMatchUserInfo = 'Password should not be same as Name,Email and/or User Id.';
        this._isConsecuSpecialCharPassword = 'This information must not have two special characters next to each other.';
        this._textArea = 'Only letters , numbers, space between words,hyphen,comma,ampersand (&) ,hash (#),circular brackets and dot are allowed.';
        this._termsCondition = 'Only letters , numbers,space between words , hyphen , comma , ampersand (&) , hash (#), circular brackets and dot are allowed.';
        this._termsConditionInv = 'Only letters,numbers,hyphen,comma, ampersand,hash,slash(/),circular brackets and dot are allowed.';
        this._address = 'Only letters,numbers,hash,comma and hyphen are allowed';
        this._customAddress = 'Only letters,numbers,hash,comma,apostrophe,ciruclar brackets,slash(/) and hyphen are allowed.';
        this._city = 'Only numbers,letters,comma,hyphen and dot are allowed.';
        this._orderid = 'Only letters,hash and hyphen are allowed.';
        this._isBeginSpecialCharfororderid = 'This information must not begin with a special character.';
        this._zipCode = 'Only letters,numbers,hyphens and space are allowed.';
        this._linkName = 'Only letters,numbers,space,hyphen and dot should be allowed.';
        this._state = 'Letters,space between words, hyphen and dots allowed.';
        this._country = 'Only letters,space,comma,dot and circular brackets are allowed.';
        this._keyValuePair = 'Invalid Value.';
        this._phone = 'Only numbers,hyphen and space are allowed.';
        this._customPANCard = 'This information is required.Only letters and numbers are allowed.';
        this._customSaleTaxNo = 'Only numbers,letters and hyphen are allowed.';
        this._customServiceTaxNo = 'It should be combination of alphabets and numbers.';
        /* ******************************* End Common Methods *********************************************** */
        /* ****************************  Start Gateway Settings ********************************************* */
        this._webStoreName = 'Only letters,numbers,hyphen,and symbol &,spaces between words  are allowed.';
        this._customerCareMailSignature = 'Only letters, numbers ,underscore, @, hypen, colon(:) and spaces are allowed.';
        this._letterSpaceUnderscoreColon = 'Only letters, numbers ,underscore, @, hypen, colon(:) and spaces are allowed.';
        this._isEndSpecialCharForWebStore = 'This information must not end with a special character.';
        this._isOrderEmailSignature = 'Enter a valid order email signature.';
        this._isEndOrderEmailSignature = 'Please enter a valid email signature.';
        this._fileError = 'Image width should not be greater than 250 pixels.';
        /* *****************************  End Gateway Settings ********************************************** */
        /* ********************************* Start Invoice ************************************************** */
        this._customerNameMinMax = 'Please enter a valid customer name with min. 1 & max. 60 characters.';
        this._customerNameInvalid = 'Only letters,Numbers,space,apostrophe and dot are allowed.';
        this._leastOneChar = 'Enter a valid customer name.';
        this._amount = 'Please enter a valid amount.';
        this._customerEmailInvalid = 'Please enter a valid email.';
        this._customerEmailSubInvalid = 'Please enter valid Email Subject Line.';
        this._customerEmailMax = 'Email should not exceed 70 characters.';
        this._customerEmailSubMax = 'Email subject line should not exceed 100 characters.';
        this._customerMobileInvalid = 'Please enter valid customer mobile number.';
        this._validateAmount = 'Please enter a higher value.';
        this._nonZeroNumber = 'Only numbers are allowed.';
        this._invoiceMerRefNum = 'Please enter valid Unique Reference #.';
        this._invoiceMerRefNumMinMax = 'Unique Reference # should be between 3 to 50 characters.';
        this._recurringMerRefNum = 'Only letters,space,numbers,hyphen and underscore are allowed.';
        this._legalEntity = 'Only letters,numbers,hyphens,dots,circular brackets and symbol & are allowed.';
        this._NumbersAndDot = 'Only numbers and dot are allowed.';
        this._emailSub = 'Only letters,numbers,underscore,hypen,dots and spaces between words are allowed.';
        this._smsContent = 'Only letters,numbers,underscore, hypen,hash and spaces between words are allowed.';
        this._invoiceEmailSub = 'Only letters,numbers,underscore,hypen,and spaces between words are allowed.';
        this._isEndSpecialCharForSMS = 'This information must not end with a special character.';
        this._isEndSpecialCharForTerms = 'This information must not end with a special character.';
        this._dueDate = 'Only numbers,hyphen are allowed.';
        this._frequency = 'Only letters,hyphen are allowed.';
        this._isConsecuSpecialCharInvoice = 'This information must not have two special characters next to each other.';
        this._invalidLateFeeValue = 'Late Payment Fees value must be less than invoice amount.';
        this._invalidDiscountIfValue = 'Discount if Paid Within must not be greater than Due Upto.';
        this._invalidDiscountValue = 'Discount value must be less than invoice amount.';
        this._invalidMinInvoiceAmt = 'Min. invoice amount must not be greater than invoice amount.';
        this._zeroMinInvoiceAmt = 'Min. invoice Amount must be greater than 0.';
        this._zeroInvoiceValidFor = 'Please enter a value greater than or equal to 1.';
        this._nonZeroAmountForDueUpto = 'Due upto must be greater than 0.';
        this._nonZeroQuantity = 'Quantity must be greater than 0.';
        this._hours = 'Validity must be between 1 to 24 hours.';
        this._minutes = 'Validity must be between 1 to 60 minutes.';
        this._days = 'Validity must be between 1 to 365 days.';
        /* ********************************** End Invoice *************************************************** */
        /* ******************************* Marketing Coupans ************************************************ */
        this._couponName = 'Only letters,numbers,underscore,hyphen and spaces between words are allowed.';
        this._invalidAmount = "Please enter a value less than or equal to 999999.99.";
        this._invalidPercentageRange = "Please enter a value less than or equal to 99.99.";
        this._couponCodeAvaibility = 'Discount Code already exists.';
        /* ***************************** End Marketing Coupens ********************************************** */
        /* ********************************** Marketing Promotion *********************************************** */
        this._promotionName = 'Only letters, numbers, underscore, hyphen and spaces between words are allowed.';
        this._gaCode = 'Please enter valid Analytics Code (ex: UA-1234567-12).';
        this._promotionDescription = 'Only letters,numbers,hyphen,underscore,dot,circular brackets,space,comma,hash (#),colon(:),symbol @ and symbol & are allowed.';
        this._promotionBins = 'Promotion Bins should be six digits each.';
        this._isEndSpecialCharPromotionBins = 'This information must not end with a special character.';
        this._promoTermsAndConditions = 'Only letters, numbers, hyphen, dot, circular brackets, space, comma, hash (#) and symbol & are allowed.';
        this._promoMinMax = 'Promotion Name must be between 3 to 100 characters.';
        this._snipName = 'Only letters,space,numbers,underscore,hyphen,and symbol & and / are allowed.';
        /* **************************** End Marketing Promotion ********************************************* */
        /* ****************************** Product Management************************************************* */
        this._productName = 'Only letters,numbers,underscore,hypen,and spaces between are allowed.';
        this._productDesc = 'Only letters,numbers,underscore,hypen,and spaces between are allowed.';
        this._productPrice = 'Only numbers are allowed.';
        this._productcurrencyPrice = 'Only numbers,dot,pipe between are allowed.';
        this._optionValue = 'Only letters,numbers,dot,comma,plus,hypen,and spaces between are allowed.';
        this._productSku = 'Only letters,numbers,underscore,hypen are allowed.';
        this._productPricePair = 'Invalid Price.';
        /* **************************** End Product Management ********************************************** */
        this._NumberAndDot = 'Only numbers,hyphen are allowed.';
        /* ***************************** StartPending Orders ************************************************ */
        this._notes = 'Only letters,numbers,space,dot and hyphens are allowed.';
        this._isEndSpecialCharForNotes = 'This information must not end with a special character.';
        /* ***************************** End Pending Orders ************************************************* */
        this._collectionTitle = 'Only letters,space,comma,dot and circular brackets are allowed.';
        this._letterNumberAndSpaceOnly = 'Only letters,numbers and space are allowed.';
        /* ******************************** Store Settings ************************************************** */
        this._storeNameTitle = 'Only numbers, letters,hyphen,apostrophe and dot are allowed.';
        this._ccavenuedomain = 'Only letters,numbers,apostrophe and dot are allowed.';
        this._customedomain = 'Only letters,numbers,apostrophe and dot are allowed.';
        /* ****************************** End Store Settings ************************************************ */
        this._colorCode = 'Please enter valid color code.';
        this._altTag = 'Please enter valid Alt Tag.';
        this._storePageUrl = 'Only letters, numbers, space, dot and hyphens are allowed.';
        this._ipAddress = 'Please enter a valid IP.';
        this._percentages = 'Please enter valid percentages value.';
        /* ******************************* Custom validation message ************************************** */
        this._acceptValues = 'Please enter a correct value.';
        /* ******************************* Custom validation message of BlackList Controller ************************************** */
        this._isValidCountry = 'Please enter a valid country.';
        this._isValidValue = 'Please enter a valid amount.';
        /* ******************************* Custom validation message For Tax************************************** */
        this._maxTaxValue = 'Tax Rate should be less than 100.';
        this._minTaxValue = 'Invalid Tax Rate.';
        this._decimalTaxValue = 'Only two decimal value is allowed.';
        //***********************************Account Information**************************************//  
        this._customPANCard2 = 'Enter valid PAN number.';
        this._customGSTNum = 'Please enter valid GSTIN number.';
        this._GSTNumMaxLen = 'GSTIN number must be equal to 15 digits.';
        this.isDuplicateGSTN = 'GSTN # already exists.';
        //***********************************Refund Checker**************************************//  
        this._validDateRange = 'Select valid date range.';
        //*****************************Transactions **********************************************//
        this._orderNo = 'Only letters, numbers and hyphen are allowed.';
        this._billAddress = 'Only letters, numbers, space, hyphen, comma, ampersand(&), hash(#), circular brackets and dot are allowed.';
        this._billCity = 'Only numbers,letters,space,comma,hyphen and dot are allowed.';
        this._billZip = 'Only letters,numbers,hyphen and space are allowed.';
        //*******************************Dashboard********************************************//
        this._gstNo = 'Please enter valid GSTIN number.';
        //************************Snip************************//
        this._customerCity = 'Please enter valid city.';
        this._customerPhone = 'Please enter valid mobile no.';
        this._customerPin = 'Please enter valid pin code.';
        this._customerState = 'Please enter valid state.';
        this._customerCountry = 'Please enter valid country.';
        this._customerAddress = 'Only letters,numbers,hash,comma and hyphen are allowed.';
        this._checkEmailAvailability = 'EmailId already exists.';
        this._checkMobileAvailability = 'Mobile# already exists.';
        //**********************************BulkUpload********************************************* */
        this._batchfileName = 'Only letters,space,numbers,hyphen and underscore are allowed.';
    }
    get responseNull() { return this._responseNull; }
    ;
    get errorResponse() { return this._errorResponse; }
    ;
    get invalidData() { return this._invalidData; }
    ;
    get required() { return this._required; }
    ;
    get number() { return this._number; }
    ;
    get min() { return this._min; }
    ;
    getMin(pMin) {
        return 'Please enter a value greater than or equal to ' + pMin + '.';
    }
    get minAmount() { return this._minAmount; }
    ;
    getMinAmount(pMin) {
        return ' Please enter a value greater than ' + (pMin - 1) + '.';
    }
    get max() { return this._max; }
    ;
    getMax(pMax) {
        return 'Please enter a value less than or equal to ' + pMax + '.';
    }
    get minlength() { return this._minlength; }
    ;
    getMinlength(pMinlength) {
        return 'Characters length must be greater than or equal to ' + pMinlength + '.';
    }
    get maxlength() { return this._maxlength; }
    ;
    getMaxlength(pMaxlength) {
        return ' Characters length must be less than or equal to ' + pMaxlength + '.';
    }
    /* private _maxlengthNum: string = 'Characters length exceeded.';
     get maxlengthNum():string {return this._maxlengthNum};*/
    getMaxlengthNum(pMaxlength) {
        return ' Enter max ' + pMaxlength + ' digits.';
    }
    /*-----------------disputes-------------------------------------------------- */
    getMaxlengthForDisputes(pMaxlength) {
        return ' Message should not exceed ' + pMaxlength + ' characters. ';
    }
    get disputeMessages() { return this._disputeMessages; }
    ;
    get letterswithbasicpunc() { return this._letterswithbasicpunc; }
    ;
    get alphanumericwithbasicpunc() { return this._alphanumericwithbasicpunc; }
    ;
    get alphanumeric() { return this._alphanumeric; }
    ;
    get lettersonly() { return this._lettersonly; }
    ;
    get nowhitespace() { return this._nowhitespace; }
    ;
    get ziprange() { return this._ziprange; }
    ;
    get integer() { return this._integer; }
    ;
    get vinUS() { return this._vinUS; }
    ;
    get dateITA() { return this._dateITA; }
    ;
    get dateNL() { return this._dateNL; }
    ;
    get phoneUS() { return this._phoneUS; }
    ;
    get phoneUK() { return this._phoneUK; }
    ;
    get mobileUK() { return this._mobileUK; }
    ;
    get strippedminlength() { return this._strippedminlength; }
    ;
    get email2() { return this._email2; }
    ;
    get url2() { return this._url2; }
    ;
    get creditcardtypes() { return this._creditcardtypes; }
    ;
    get customDate() { return this._customDate; }
    ;
    get mobile() { return this._mobile; }
    ;
    get numbersOnly() { return this._numbersOnly; }
    ;
    get numbersAndDotOnly() { return this._numbersAndDotOnly; }
    ;
    get lettersOnly() { return this._lettersOnly; }
    ;
    get letterAndSpaceOnly() { return this._letterAndSpaceOnly; }
    ;
    get letterAndNumberOnly() { return this._letterAndNumberOnly; }
    ;
    get letterSpaceAndDotOnly() { return this._letterSpaceAndDotOnly; }
    ;
    get letterSpaceDotAndApostropheOnly() { return this._letterSpaceDotAndApostropheOnly; }
    ;
    get letterSpaceDotAndHyphenOnly() { return this._letterSpaceDotAndHyphenOnly; }
    ;
    get firstName() { return this._firstName; }
    ;
    get lastName() { return this._lastName; }
    ;
    get fullName() { return this._fullName; }
    ;
    get email() { return this._email; }
    ;
    get email3() { return this._email3; }
    ;
    get invalidEmailDesc() { return this._invalidEmailDesc; }
    ;
    get isBeginSpecialChar() { return this._isBeginSpecialChar; }
    ;
    get isEndSpecialChar() { return this._isEndSpecialChar; }
    ;
    get isBeginSpecialCharEmailSub() { return this._isBeginSpecialCharEmailSub; }
    ;
    get isEndSpecialCharEmailSub() { return this._isEndSpecialCharEmailSub; }
    ;
    get isBeginSpecialCharDesc() { return this._isBeginSpecialCharDesc; }
    ;
    get isEndSpecialCharDesc() { return this._isEndSpecialCharDesc; }
    ;
    get isConsecuSpecialCharDesc() { return this._isConsecuSpecialCharDesc; }
    ;
    get isBlankSpace() { return this._isBlankSpace; }
    ;
    get isEndSpecialCharUrl() { return this._isEndSpecialCharUrl; }
    ;
    get isConsecuSpecialCharUrl() { return this._isConsecuSpecialCharUrl; }
    ;
    get customURL() { return this._customURL; }
    ;
    get invalidURL() { return this._invalidURL; }
    ;
    get isEndSpecialCharForAddr() { return this._isEndSpecialCharForAddr; }
    ;
    get isConsecuSpecialChar() { return this._isConsecuSpecialChar; }
    ;
    get loginId() { return this._loginId; }
    ;
    get checkeUserIdAvailability() { return this._checkeUserIdAvailability; }
    ;
    get checkeTaskAvailability() { return this._checkeTaskAvailability; }
    ;
    get password() { return this._password; }
    ;
    get passwordMin() { return this._passwordMin; }
    ;
    get matchPassword() { return this._matchPassword; }
    ;
    get passwordMatchUserInfo() { return this._passwordMatchUserInfo; }
    ;
    get isConsecuSpecialCharPassword() { return this._isConsecuSpecialCharPassword; }
    ;
    get textArea() { return this._textArea; }
    ;
    get termsCondition() { return this._termsCondition; }
    ;
    get termsConditionInv() { return this._termsConditionInv; }
    ;
    get address() { return this._address; }
    ;
    get customAddress() { return this._customAddress; }
    ;
    get city() { return this._city; }
    ;
    get orderid() { return this._orderid; }
    ;
    get isBeginSpecialCharfororderid() { return this._isBeginSpecialCharfororderid; }
    ;
    get zipCode() { return this._zipCode; }
    ;
    get linkName() { return this._linkName; }
    ;
    get state() { return this._state; }
    ;
    get country() { return this._country; }
    ;
    get keyValuePair() { return this._keyValuePair; }
    ;
    get phone() { return this._phone; }
    ;
    get customPANCard() { return this._customPANCard; }
    ;
    get customSaleTaxNo() { return this._customSaleTaxNo; }
    ;
    get customServiceTaxNo() { return this._customServiceTaxNo; }
    ;
    get webStoreName() { return this._webStoreName; }
    ;
    get customerCareMailSignature() { return this._customerCareMailSignature; }
    ;
    get letterSpaceUnderscoreColon() { return this._letterSpaceUnderscoreColon; }
    ;
    get isEndSpecialCharForWebStore() { return this._isEndSpecialCharForWebStore; }
    ;
    get isOrderEmailSignature() { return this._isOrderEmailSignature; }
    ;
    get isEndOrderEmailSignature() { return this._isEndOrderEmailSignature; }
    ;
    get fileError() { return this._fileError; }
    ;
    get customerNameMinMax() { return this._customerNameMinMax; }
    ;
    get customerNameInvalid() { return this._customerNameInvalid; }
    ;
    get leastOneChar() { return this._leastOneChar; }
    ;
    get amount() { return this._amount; }
    ;
    get customerEmailInvalid() { return this._customerEmailInvalid; }
    ;
    get customerEmailSubInvalid() { return this._customerEmailSubInvalid; }
    ;
    get customerEmailMax() { return this._customerEmailMax; }
    ;
    get customerEmailSubMax() { return this._customerEmailSubMax; }
    ;
    get customerMobileInvalid() { return this._customerMobileInvalid; }
    ;
    getValidateAmount(pAmount) {
        return 'Amount should be greater than ' + pAmount;
    }
    get nonZeroNumber() { return this._nonZeroNumber; }
    ;
    get invoiceMerRefNum() { return this._invoiceMerRefNum; }
    ;
    get invoiceMerRefNumMinMax() { return this._invoiceMerRefNumMinMax; }
    ;
    get recurringMerRefNum() { return this._recurringMerRefNum; }
    ;
    get legalEntity() { return this._legalEntity; }
    ;
    get NumbersAndDot() { return this._NumbersAndDot; }
    ;
    get emailSub() { return this._emailSub; }
    ;
    get smsContent() { return this._smsContent; }
    ;
    get invoiceEmailSub() { return this._invoiceEmailSub; }
    ;
    get isEndSpecialCharForSMS() { return this._isEndSpecialCharForSMS; }
    ;
    get isEndSpecialCharForTerms() { return this._isEndSpecialCharForTerms; }
    ;
    get dueDate() { return this._dueDate; }
    ;
    get frequency() { return this._frequency; }
    ;
    get isConsecuSpecialCharInvoice() { return this._isConsecuSpecialCharInvoice; }
    ;
    get invalidLateFeeValue() { return this._invalidLateFeeValue; }
    ;
    get invalidDiscountIfValue() { return this._invalidDiscountIfValue; }
    ;
    get invalidDiscountValue() { return this._invalidDiscountValue; }
    ;
    get invalidMinInvoiceAmt() { return this._invalidMinInvoiceAmt; }
    ;
    get zeroMinInvoiceAmt() { return this._zeroMinInvoiceAmt; }
    ;
    get zeroInvoiceValidFor() { return this._zeroInvoiceValidFor; }
    ;
    get nonZeroAmountForDueUpto() { return this._nonZeroAmountForDueUpto; }
    ;
    get nonZeroQuantity() { return this._nonZeroQuantity; }
    ;
    get hours() { return this._hours; }
    ;
    get minutes() { return this._minutes; }
    ;
    get days() { return this._days; }
    ;
    get couponName() { return this._couponName; }
    ;
    get invalidAmount() { return this._invalidAmount; }
    ;
    get invalidPercentageRange() { return this._invalidPercentageRange; }
    ;
    get couponCodeAvaibility() { return this._couponCodeAvaibility; }
    ;
    get promotionName() { return this._promotionName; }
    ;
    get gaCode() { return this._gaCode; }
    ;
    get promotionDescription() { return this._promotionDescription; }
    ;
    get promotionBins() { return this._promotionBins; }
    ;
    get isEndSpecialCharPromotionBins() { return this._isEndSpecialCharPromotionBins; }
    ;
    get promoTermsAndConditions() { return this._promoTermsAndConditions; }
    ;
    get promoMinMax() { return this._promoMinMax; }
    ;
    getMaxlengthForNum(pMaxlength) {
        return 'Number must be less than or equal to ' + pMaxlength + ' digits.';
    }
    getMaxLengthForPromoBins(pMaxlength) {
        return 'Promotion Bins must not exceed ' + pMaxlength + ' characters.';
    }
    get snipName() { return this._snipName; }
    ;
    get productName() { return this._productName; }
    ;
    get productDesc() { return this._productDesc; }
    ;
    get productPrice() { return this._productPrice; }
    ;
    get productcurrencyPrice() { return this._productcurrencyPrice; }
    ;
    get optionValue() { return this._optionValue; }
    ;
    get productSku() { return this._productSku; }
    ;
    get productPricePair() { return this._productPricePair; }
    ;
    get NumberAndDot() { return this._NumberAndDot; }
    ;
    get notes() { return this._notes; }
    ;
    get isEndSpecialCharForNotes() { return this._isEndSpecialCharForNotes; }
    ;
    get collectionTitle() { return this._collectionTitle; }
    ;
    get letterNumberAndSpaceOnly() { return this._letterNumberAndSpaceOnly; }
    ;
    get storeNameTitle() { return this._storeNameTitle; }
    ;
    get ccavenuedomain() { return this._ccavenuedomain; }
    ;
    get customedomain() { return this._customedomain; }
    ;
    get colorCode() { return this._colorCode; }
    ;
    get altTag() { return this._altTag; }
    ;
    get storePageUrl() { return this._storePageUrl; }
    ;
    get ipAddress() { return this._ipAddress; }
    ;
    get percentages() { return this._percentages; }
    ;
    get acceptValues() { return this._acceptValues; }
    ;
    get isValidCountry() { return this._isValidCountry; }
    ;
    get isValidValue() { return this._isValidValue; }
    ;
    get maxTaxValue() { return this._maxTaxValue; }
    ;
    getMaxTaxValue() {
        return this._maxTaxValue;
    }
    get minTaxValue() { return this._minTaxValue; }
    ;
    getMinTaxValue() {
        return this._minTaxValue;
    }
    get decimalTaxValue() { return this._decimalTaxValue; }
    ;
    getDecimalTaxValue() {
        return this._decimalTaxValue;
    }
    get customPANCard2() { return this._customPANCard2; }
    ;
    get customGSTNum() { return this._customGSTNum; }
    ;
    get GSTNumMaxLen() { return this._GSTNumMaxLen; }
    ;
    get _isDuplicateGSTN() { return this.isDuplicateGSTN; }
    ;
    getMinLengthForPhoneNo(pMaxlength) {
        return 'Phone number should be minimum ' + pMaxlength + ' characters.';
    }
    ;
    get validDateRange() { return this._validDateRange; }
    ;
    get orderNo() { return this._orderNo; }
    ;
    get billAddress() { return this._billAddress; }
    ;
    get billCity() { return this._billCity; }
    ;
    get billZip() { return this._billZip; }
    ;
    get gstNo() { return this._gstNo; }
    ;
    get customerCity() { return this._customerCity; }
    ;
    get customerPhone() { return this._customerPhone; }
    ;
    get customerPin() { return this._customerPin; }
    ;
    get customerState() { return this._customerState; }
    ;
    get customerCountry() { return this._customerCountry; }
    ;
    get customerAddress() { return this._customerAddress; }
    ;
    get checkEmailAvailability() { return this._checkEmailAvailability; }
    ;
    get checkMobileAvailability() { return this._checkMobileAvailability; }
    ;
    get batchfileName() { return this._batchfileName; }
    ;
};
ErrorMessagesService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], ErrorMessagesService);
export { ErrorMessagesService };
//# sourceMappingURL=error-messages.service.js.map