import * as tslib_1 from "tslib";
import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from "@angular/common";
import { ConditionalCheckService } from '../common-services/conditional-check.service';
let ResponsiveService = class ResponsiveService {
    constructor(sCheck, sDocument) {
        this.sCheck = sCheck;
        this.sDocument = sDocument;
    }
    isMaxWidth767Device() {
        return window.matchMedia('(max-width:767px)').matches;
    }
    isMaxWidth1024Device() {
        return window.matchMedia('(max-width:1024px)').matches;
    }
    isMenuResponsive() {
        if (window.matchMedia('(max-width:767px)').matches) {
            if (document.getElementsByClassName('wrapper')[0].classList.contains('toggle-close')) {
                document.getElementsByClassName('wrapper')[0].classList.remove('toggle-close');
                document.getElementsByClassName('header')[0].classList.remove('toggle-close');
                document.getElementsByClassName('footer')[0].classList.remove('toggle-close');
                return false;
            }
            else {
                document.getElementsByClassName('wrapper')[0].classList.add('toggle-close');
                document.getElementsByClassName('header')[0].classList.add('toggle-close');
                document.getElementsByClassName('footer')[0].classList.add('toggle-close');
                return true;
            }
        }
        return null;
    }
    hoverMenu(pStatus) {
        if (window.matchMedia('(min-width:767px)').matches) {
            if (document.getElementsByClassName('wrapper')[0].classList.contains('toggle-close') && pStatus === 'add') {
                document.getElementsByClassName('header')[0].classList.add('toggle-close-hover');
                document.getElementsByClassName('wrapper')[0].classList.add('toggle-close-hover');
                document.getElementsByClassName('footer')[0].classList.add('toggle-close-hover');
            }
            else if (document.getElementsByClassName('wrapper')[0].classList.contains('toggle-close-hover') && pStatus === 'remove') {
                document.getElementsByClassName('header')[0].classList.add('toggle-close-hover');
                document.getElementsByClassName('wrapper')[0].classList.remove('toggle-close-hover');
                document.getElementsByClassName('footer')[0].classList.add('toggle-close-hover');
            }
        }
    }
    isSearchResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.add('absolute');
            this.sDocument.getElementsByClassName('header')[0].classList.add('toggle-close');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.sDocument.body.classList.add('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.add('display-none');
            this.sDocument.getElementsByClassName('footer')[0].classList.add('toggle-close');
            // this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
            // if(this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')){
            //     this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            // }
            // if(this.sDocument.getElementsByClassName('daterangepicker').length > 0){
            //     this.sDocument.getElementsByClassName('slideL')[0].appendChild(this.sDocument.getElementsByClassName('daterangepicker')[0]);
            // }
            // if (window.matchMedia('(max-width:990px)').matches) {
            //   this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
            //   if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
            //     this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            //   }
            // }
            return true;
        }
        else {
            return false;
        }
    }
    isCancelResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.remove('absolute');
            this.sDocument.body.classList.remove('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.sDocument.getElementsByClassName('custom-search')[0].classList.remove('slideL');
            if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.remove('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    isCustomizeResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.add('absolute');
            this.sDocument.body.classList.add('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.add('display-none');
            this.sDocument.getElementsByName('customize-search')[0].classList.add('slideL');
            if (this.sDocument.getElementsByName('customize-search')[0].parentElement.classList.contains('row')) {
                this.sDocument.getElementsByName('customize-search')[0].parentElement.classList.add('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    isCancelCustomizeResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.remove('absolute');
            this.sDocument.body.classList.remove('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.sDocument.getElementsByName('customize-search')[0].classList.remove('slideL');
            if (this.sDocument.getElementsByName('customize-search')[0].parentElement.classList.contains('row')) {
                this.sDocument.getElementsByName('customize-search')[0].parentElement.classList.remove('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    removeLoader() {
        if (this.sCheck.isNotNullObject(this.sDocument.getElementById('loader-bar')) && this.sDocument.getElementById('loader-bar').classList.contains('loader')) {
            this.sDocument.getElementById('loader-bar').classList.remove('loader');
        }
    }
    addLoader() {
        if (this.sCheck.isNotNullObject(this.sDocument.getElementById('loader-bar')) && !this.sDocument.getElementById('loader-bar').classList.contains('loader')) {
            this.sDocument.getElementById('loader-bar').classList.add('loader');
        }
    }
    openSearch() {
        if (window.matchMedia('(min-width:1025px)').matches) {
            if (!this.sDocument.getElementsByClassName('custom-search')[0].classList.contains('custom-search-show')) {
                this.sDocument.getElementsByClassName('custom-search')[0].classList.add('custom-search-show');
            }
            else {
                this.sDocument.getElementsByClassName('custom-search')[0].classList.remove('custom-search-show');
            }
            if (!this.sDocument.getElementsByClassName('BtnSlide')[0].classList.contains('active')) {
                this.sDocument.getElementsByClassName('BtnSlide')[0].classList.add('active');
            }
            else {
                this.sDocument.getElementsByClassName('BtnSlide')[0].classList.remove('active');
            }
        }
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.add('absolute');
            this.sDocument.body.classList.add('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.add('display-none');
            this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
            if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            }
            if (this.sDocument.getElementsByClassName('daterangepicker').length > 0) {
                this.sDocument.getElementsByClassName('slideL')[0].appendChild(this.sDocument.getElementsByClassName('daterangepicker')[0]);
            }
            return true;
        }
    }
    closeSearch() {
        if (window.matchMedia('(min-width:1025px)').matches) {
            if (this.sDocument.getElementsByClassName('custom-search')[0].classList.contains('custom-search-show')) {
                this.sDocument.getElementsByClassName('custom-search')[0].classList.remove('custom-search-show');
            }
            if (this.sDocument.getElementsByClassName('BtnSlide')[0].classList.contains('active')) {
                this.sDocument.getElementsByClassName('BtnSlide')[0].classList.remove('active');
            }
        }
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.sDocument.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.sDocument.getElementsByClassName('header')[0].classList.remove('absolute');
            this.sDocument.body.classList.remove('overflow-y-hidden');
            this.sDocument.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.sDocument.getElementsByClassName('custom-search')[0].classList.remove('slideL');
            if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.remove('slidepop');
            }
        }
    }
    openDetails() {
        if (this.sDocument.getElementsByClassName('content-header') != null && this.sDocument.getElementsByClassName('content-header').length > 0 && (!this.sDocument.getElementsByClassName('content-header')[0].classList.contains('details'))) {
            this.sDocument.getElementsByClassName('content-header')[0].classList.add('details');
        }
        if (this.sDocument.getElementsByClassName('content') != null && this.sDocument.getElementsByClassName('content').length > 0) {
            if (this.sDocument.getElementsByClassName('content')[0].classList.contains('main-open')) {
                this.sDocument.getElementsByClassName('content')[0].classList.remove('main-open');
                this.sDocument.getElementsByClassName('content')[0].classList.add('detail-open');
            }
        }
    }
    closeDetails() {
        if (this.sDocument.getElementsByClassName('content-header') != null && this.sDocument.getElementsByClassName('content-header').length > 0 && this.sDocument.getElementsByClassName('content-header')[0].classList.contains('details')) {
            this.sDocument.getElementsByClassName('content-header')[0].classList.remove('details');
        }
        if (this.sDocument.getElementsByClassName('content') != null && this.sDocument.getElementsByClassName('content').length > 0) {
            if (this.sDocument.getElementsByClassName('content')[0].classList.contains('detail-open')) {
                this.sDocument.getElementsByClassName('content')[0].classList.remove('detail-open');
                this.sDocument.getElementsByClassName('content')[0].classList.add('main-open');
            }
        }
    }
    removeBodyClass(pClassName) {
        if (this.sDocument.body.classList.contains(pClassName)) {
            this.sDocument.body.classList.remove(pClassName);
        }
    }
    addBodyClass(pClassName) {
        if (!this.sDocument.body.classList.contains(pClassName)) {
            this.sDocument.body.classList.add(pClassName);
        }
    }
};
ResponsiveService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__param(1, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [ConditionalCheckService,
        Document])
], ResponsiveService);
export { ResponsiveService };
//# sourceMappingURL=responsive.service.js.map