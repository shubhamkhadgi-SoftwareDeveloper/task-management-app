import { TestBed, inject } from '@angular/core/testing';
import { CustomFacebookService } from './custom-facebook.service';
describe('CustomFacebookService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CustomFacebookService]
        });
    });
    it('should be created', inject([CustomFacebookService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=custom-facebook.service.spec.js.map