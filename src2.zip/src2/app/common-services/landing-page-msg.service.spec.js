import { TestBed, inject } from '@angular/core/testing';
import { LandingPageMsgService } from './landing-page-msg.service';
describe('LandingPageMsgService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [LandingPageMsgService]
        });
    });
    it('should be created', inject([LandingPageMsgService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=landing-page-msg.service.spec.js.map