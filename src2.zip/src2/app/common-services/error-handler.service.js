import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ConditionalCheckService } from './conditional-check.service';
import { AlertMessageService } from '../common-services/alert-message.service';
import { ErrorMessagesService } from '../common-services/error-messages.service';
let ErrorHandlerService = class ErrorHandlerService {
    constructor(sCheck, sAlertMessageService, sErrorMessagesService) {
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
    }
    setServerError(pErrorFieldList, pFormControl) {
        if (this.sCheck.isNotNullObject(pErrorFieldList) && this.sCheck.isNotNullObject(pFormControl)) {
            for (var mFieldName in pErrorFieldList) {
                const mFieldControl = pFormControl.get(mFieldName);
                if (this.sCheck.isNotNullObject(mFieldControl) && (mFieldControl.constructor.name === 'FormControl')) { //show message below corresponding field-control
                    for (var mError in pErrorFieldList[mFieldName]) {
                        const mUpdatedErrors = Object.assign({}, mFieldControl.errors, { 'server': pErrorFieldList[mFieldName][mError] });
                        mFieldControl.setErrors(mUpdatedErrors);
                        mFieldControl.markAsDirty({ onlySelf: true });
                        mFieldControl.markAsTouched({ onlySelf: true });
                        this.sAlertMessageService.popupAlertMsg(pErrorFieldList[mFieldName][mError]);
                        break; //At a time only one error message per field
                    }
                }
                else { //Pop-up message if corresponding field-control is not available
                    for (var mError in pErrorFieldList[mFieldName]) {
                        console.log(pErrorFieldList[mFieldName][mError]);
                        break; //At a time only one error message pop-up
                    }
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.invalidData);
        }
    }
    setSingleServerError(pErrorFieldList, pFormControl) {
        if (this.sCheck.isNotNullObject(pErrorFieldList) && this.sCheck.isNotNullObject(pFormControl)) {
            for (var mFieldName in pErrorFieldList) {
                const mFieldControl = pFormControl.get(mFieldName);
                if (this.sCheck.isNotNullObject(mFieldControl) && (mFieldControl.constructor.name === 'FormControl')) { //show message below corresponding field-control
                    for (var mError in pErrorFieldList[mFieldName]) {
                        const mUpdatedErrors = Object.assign({}, mFieldControl.errors, { 'server': pErrorFieldList[mFieldName] });
                        mFieldControl.setErrors(mUpdatedErrors);
                        mFieldControl.markAsDirty({ onlySelf: true });
                        mFieldControl.markAsTouched({ onlySelf: true });
                        break; //At a time only one error message per field
                    }
                }
                else { //Pop-up message if corresponding field-control is not available
                    for (var mError in pErrorFieldList[mFieldName]) {
                        console.log(pErrorFieldList[mFieldName]);
                        break; //At a time only one error message per field
                    }
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.invalidData);
        }
    }
    isShowError(pFieldControl) {
        if (this.sCheck.isNotNullObject(pFieldControl)) {
            if (pFieldControl.invalid && pFieldControl.errors) {
                return ((pFieldControl.dirty || pFieldControl.touched));
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
};
ErrorHandlerService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService])
], ErrorHandlerService);
export { ErrorHandlerService };
//# sourceMappingURL=error-handler.service.js.map