import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { AlertMessageService } from './alert-message.service';
let PdfPrintService = class PdfPrintService {
    constructor(sAlertMessageService) {
        this.sAlertMessageService = sAlertMessageService;
    }
    pdfPrint(pDivId) {
        let mBrowserName = this.getBrowserName();
        let printPreview = window.open('about:blank', 'print_preview');
        let printDocument = printPreview.document;
        printDocument.open();
        printDocument.write("<html>" + document.documentElement.innerHTML + "</html>");
        printDocument.getElementsByClassName('pdf-list-table')[0].setAttribute('border', "1px solid #000");
        let parasCol = printDocument.getElementsByClassName('pdf-remove-col');
        while (parasCol[0]) {
            parasCol[0].parentNode.removeChild(parasCol[0]);
        }
        printDocument.body.innerHTML = "<html><head><title>MyPdf</title></head><body>" + printDocument.getElementById(pDivId).innerHTML + "</body> </html>";
        if (mBrowserName.indexOf('Chrome') != -1) {
            setTimeout(function () {
                printPreview.print();
                printPreview.close();
            }, 500);
        }
        else {
            printPreview.print();
            printPreview.close();
        }
    }
    print(pPrintData) {
        let printWindow = window.open('about:blank', 'print_preview');
        if (printWindow != null) {
            printWindow.document.open();
            printWindow.document.write(pPrintData);
            printWindow.print();
            printWindow.document.close();
            printWindow.close();
        }
        else {
            console.log("Setting is BLOCKED from your Browser");
        }
    }
    getBrowserName() {
        let ua = navigator.userAgent, tem, M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
        if (/trident/i.test(M[1])) {
            tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
            return 'IE ' + (tem[1] || '');
        }
        if (M[1] === 'Chrome') {
            tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
            if (tem != null)
                return tem.slice(1).join(' ').replace('OPR', 'Opera');
        }
        M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
        if ((tem = ua.match(/version\/(\d+)/i)) != null)
            M.splice(1, 1, tem[1]);
        return M.join(' ');
    }
};
PdfPrintService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [AlertMessageService])
], PdfPrintService);
export { PdfPrintService };
//# sourceMappingURL=pdf-print.service.js.map