import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let ConditionalCheckService = class ConditionalCheckService {
    constructor() { }
    isNotNullObject(pCheckObject) {
        return ((pCheckObject != undefined) && (pCheckObject != null));
    }
    isNotNullNumber(pCheckObject) {
        return ((pCheckObject != null) && (pCheckObject != undefined) && (pCheckObject != 0));
    }
    isNotNullString(pCheckObject) {
        return ((pCheckObject != null) && (pCheckObject != undefined) && (pCheckObject != '') && (pCheckObject != ' '));
    }
    isNullString(pCheckObject) {
        return ((pCheckObject == null) || (pCheckObject == undefined) || (pCheckObject == '') || (pCheckObject.trim() == ''));
    }
    isNotNullList(pCheckObject) {
        return ((pCheckObject != null) && (pCheckObject != undefined) && (pCheckObject.length > 0));
    }
    isNullList(pCheckObject) {
        return ((pCheckObject == null) || (pCheckObject == undefined) || (pCheckObject.length == 0));
    }
    isNotNullObjList(pCheckObject) {
        return ((pCheckObject != null) && (pCheckObject != undefined) && (pCheckObject.size() > 0));
    }
};
ConditionalCheckService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], ConditionalCheckService);
export { ConditionalCheckService };
//# sourceMappingURL=conditional-check.service.js.map