import { TestBed, inject } from '@angular/core/testing';
import { CurrentLoginMerchantService } from './current-login-merchant.service';
describe('CurrentLoginMerchantService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CurrentLoginMerchantService]
        });
    });
    it('should be created', inject([CurrentLoginMerchantService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=current-login-merchant.service.spec.js.map