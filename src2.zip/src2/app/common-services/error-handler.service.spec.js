import { TestBed, inject } from '@angular/core/testing';
import { ErrorHandlerService } from './error-handler.service';
describe('ErrorHandlerService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ErrorHandlerService]
        });
    });
    it('should be created', inject([ErrorHandlerService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=error-handler.service.spec.js.map