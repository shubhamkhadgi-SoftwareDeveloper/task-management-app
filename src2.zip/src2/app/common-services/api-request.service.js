import * as tslib_1 from "tslib";
import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { map, catchError, finalize } from 'rxjs/operators';
import 'rxjs/Rx';
import { CurrentLoginMerchantService } from './current-login-merchant.service';
import { Router } from '@angular/router';
import * as sha256 from 'crypto-js/sha256';
let ApiRequestService = class ApiRequestService {
    constructor(http, pApiEndpoint, pLoadingBarService, sCurrentLoginMerchantService, pRouter) {
        this.http = http;
        this.pApiEndpoint = pApiEndpoint;
        this.pLoadingBarService = pLoadingBarService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.pRouter = pRouter;
    }
    asyncHttpPostRequest(pRequestObject, pRequestUrl) {
        let accessToken = '';
        let userId = '';
        if (this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '' && this.sCurrentLoginMerchantService.accessToken != null && this.sCurrentLoginMerchantService.accessToken != '') {
            accessToken = this.addCheckSumToUserToken(this.sCurrentLoginMerchantService.accessToken);
            userId = this.sCurrentLoginMerchantService.userId;
        }
        let mHeaders = new HttpHeaders().set('Content-Type', 'application/json').set('accessToken', accessToken).set('userId', userId);
        return this.http.post(this.getApiBaseUrl(pRequestUrl), pRequestObject, { headers: mHeaders, observe: 'response' }).pipe(map((res) => this.httpPostRequestSuccess(res)), catchError((res) => this.handleError(res)));
    }
    httpPostRequest(pRequestObject, pRequestUrl) {
        this.pLoadingBarService.reset();
        this.pLoadingBarService.start();
        let accessToken = '';
        let userId = '';
        if (this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '' && this.sCurrentLoginMerchantService.accessToken != null && this.sCurrentLoginMerchantService.accessToken != '') {
            accessToken = this.addCheckSumToUserToken(this.sCurrentLoginMerchantService.accessToken);
            userId = this.sCurrentLoginMerchantService.userId;
        }
        let mHeaders = new HttpHeaders().set('Content-Type', 'application/json').set('accessToken', accessToken).set('userId', userId);
        return this.http.post(this.getApiBaseUrl(pRequestUrl), pRequestObject, { headers: mHeaders, observe: 'response' }).pipe(map((res) => this.httpPostRequestSuccess(res)), catchError((res) => this.handleError(res)), finalize(() => this.pLoadingBarService.complete()));
    }
    exportFileRequest(pRequestObject, pRequestUrl, pFileName) {
        this.pLoadingBarService.reset();
        this.pLoadingBarService.start();
        let accessToken = '';
        let userId = '';
        if (this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '' && this.sCurrentLoginMerchantService.accessToken != null && this.sCurrentLoginMerchantService.accessToken != '') {
            accessToken = this.addCheckSumToUserToken(this.sCurrentLoginMerchantService.accessToken);
            userId = this.sCurrentLoginMerchantService.userId;
        }
        let mHeaders = new HttpHeaders().set('Content-Type', 'application/json').set('accessToken', accessToken).set('userId', userId);
        return this.http.post(this.getApiBaseUrl(pRequestUrl), pRequestObject, { headers: mHeaders, responseType: 'arraybuffer', observe: 'response' })
            .pipe(map(pResponse => this.exportFileRequestSuccess(pResponse, pFileName)), catchError((pResponse) => this.handleError(pResponse)), finalize(() => this.pLoadingBarService.complete()));
    }
    uploadFiledownloadFileRequest(pFile, pRequestObject, pRequestUrl, pFileName) {
        this.pLoadingBarService.reset();
        this.pLoadingBarService.start();
        const mFormData = new FormData();
        mFormData.append('jsonData', JSON.stringify(pRequestObject));
        mFormData.append('file', pFile);
        let accessToken = '';
        let userId = '';
        if (this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '' && this.sCurrentLoginMerchantService.accessToken != null && this.sCurrentLoginMerchantService.accessToken != '') {
            accessToken = this.addCheckSumToUserToken(this.sCurrentLoginMerchantService.accessToken);
            userId = this.sCurrentLoginMerchantService.userId;
        }
        let mHeaders = new HttpHeaders().set('accessToken', accessToken).set('userId', userId);
        return this.http.post(this.getApiBaseUrl(pRequestUrl), mFormData, { headers: mHeaders, observe: 'response' })
            .map(pResponse => this.exportFileRequestSuccess(pResponse, pFileName))
            .catch((pResponse) => this.handleError(pResponse))
            .finally(() => this.pLoadingBarService.complete());
    }
    fileUploadRequest(pFile, pRequestObject, pRequestUrl) {
        this.pLoadingBarService.reset();
        this.pLoadingBarService.start();
        const mFormData = new FormData();
        mFormData.append('jsonData', JSON.stringify(pRequestObject));
        mFormData.append('file', pFile);
        let accessToken = '';
        let userId = '';
        if (this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '' && this.sCurrentLoginMerchantService.accessToken != null && this.sCurrentLoginMerchantService.accessToken != '') {
            accessToken = this.addCheckSumToUserToken(this.sCurrentLoginMerchantService.accessToken);
            userId = this.sCurrentLoginMerchantService.userId;
        }
        let mHeaders = new HttpHeaders().set('accessToken', accessToken).set('userId', userId);
        return this.http.post(this.getApiBaseUrl(pRequestUrl), mFormData, { headers: mHeaders, observe: 'response' })
            .pipe(map((res) => this.httpPostRequestSuccess(res)), catchError((res) => this.handleError(res)), finalize(() => this.pLoadingBarService.complete()));
    }
    httpPostRequestSuccess(pResponse) {
        if (pResponse.headers.get("accessToken") != undefined && pResponse.headers.get("accessToken") != null && pResponse.headers.get("accessToken") != '') {
            localStorage.setItem("accessToken", pResponse.headers.get("accessToken"));
        }
        let mBody = pResponse.body;
        return mBody || {};
    }
    ;
    exportFileRequestSuccess(pResponse, pFileName) {
        if (pResponse.headers.get("accessToken") != undefined && pResponse.headers.get("accessToken") != null && pResponse.headers.get("accessToken") != '') {
            localStorage.setItem("accessToken", pResponse.headers.get("accessToken"));
        }
        var mBlob = new Blob([pResponse.body]);
        let excelEle = document.createElement("a");
        excelEle.href = URL.createObjectURL(mBlob);
        excelEle.download = pFileName;
        document.body.appendChild(excelEle);
        excelEle.click();
        excelEle.remove();
    }
    ;
    handleError(pError) {
        if (pError.status == 401) {
            this.unAuthorizedResponseHandler(pError.status);
        }
        else if (pError.status == 403) {
            this.forbiddenResponseHandler(pError.status);
        }
        else if (pError.status == 400 ||
            pError.status == 404 ||
            pError.status == 500 ||
            pError.status == 502 ||
            pError.status == 503 ||
            pError.status == 504) {
            this.commonErrorResponseHandler(pError.status);
        }
        return null;
    }
    ;
    getApiBaseUrl(pRequestUrl) {
        return this.pApiEndpoint + pRequestUrl;
    }
    ;
    addCheckSumToUserToken(userToken) {
        let secureHash = sha256(userToken.substring(0, 10));
        return secureHash + userToken;
    }
    unAuthorizedResponseHandler(pErrorCode) {
        this.pRouter.navigate(['home/menu/errorHandler', pErrorCode]);
        setTimeout(() => {
            sessionStorage.clear();
            localStorage.clear();
            location.reload();
        }, 3000);
    }
    forbiddenResponseHandler(pErrorCode) {
        this.pRouter.navigate(['home/menu/errorHandler', pErrorCode]);
    }
    commonErrorResponseHandler(pErrorCode) {
        this.pRouter.navigate(['home/menu/errorHandler', pErrorCode]);
    }
};
ApiRequestService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__param(1, Inject('APP_CONFIG')),
    tslib_1.__metadata("design:paramtypes", [HttpClient, String, SlimLoadingBarService,
        CurrentLoginMerchantService,
        Router])
], ApiRequestService);
export { ApiRequestService };
//# sourceMappingURL=api-request.service.js.map