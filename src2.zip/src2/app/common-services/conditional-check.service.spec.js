import { TestBed, inject } from '@angular/core/testing';
import { ConditionalCheckService } from './conditional-check.service';
describe('ConditionalCheckService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ConditionalCheckService]
        });
    });
    it('should be created', inject([ConditionalCheckService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=conditional-check.service.spec.js.map