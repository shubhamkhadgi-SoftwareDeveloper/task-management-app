import { TestBed, inject } from '@angular/core/testing';
import { AlertMessageService } from './alert-message.service';
describe('AlertMessageService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AlertMessageService]
        });
    });
    it('should be created', inject([AlertMessageService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=alert-message.service.spec.js.map