import { TestBed, inject } from '@angular/core/testing';
import { MerchInfoService } from './merch-info.service';
describe('MerchInfoService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [MerchInfoService]
        });
    });
    it('should be created', inject([MerchInfoService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=merch-info.service.spec.js.map