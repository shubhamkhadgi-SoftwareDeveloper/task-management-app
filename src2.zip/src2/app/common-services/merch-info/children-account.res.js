export class ChildrenAccount {
}
//# sourceMappingURL=children-account.res.js.map