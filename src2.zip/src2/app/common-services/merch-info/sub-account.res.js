export class SubAccount {
}
//# sourceMappingURL=sub-account.res.js.map