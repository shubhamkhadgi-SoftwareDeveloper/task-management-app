import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../api-request.service';
import { ConditionalCheckService } from '../conditional-check.service';
import { AlertMessageService } from '../alert-message.service';
import { ErrorMessagesService } from '../error-messages.service';
import { ErrorHandlerService } from '../error-handler.service';
import { CommonResponse } from '../../common-response/common-response.res';
import { CurrentLoginMerchantService } from '../../common-services/current-login-merchant.service';
let MerchInfoService = class MerchInfoService {
    constructor(pApiRequestService, sCheck, sErrorHandler, sAlertMessageService, sErrorMessagesService, sCurrentLoginMerchantService) {
        this.pApiRequestService = pApiRequestService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.cOrderStatusList = [];
        this.cOrdersStatusList = [];
        this.cOrderTypeList = [];
        this.cPaymentModeList = [];
        this.cDisputesStatusList = [];
        this.cDisputesReasonList = [];
        this.cRegId = null;
        this.cBizWebsite = null;
        this.cChildrenAccount = [];
        this.cSubAccount = [];
        this.cCurrency = [];
        this.cOrderStatus = [];
        this.cOrderType = [];
        this.cPaymentMode = [];
        this.cDisputesStatus = [];
        this.cDisputesReason = [];
        this.cChildrenAccountList = [];
        this.cCurrencyList = [];
        this.cSubAccountList = [];
        this.cOrderStatusList = [];
        this.cOrdersStatusList = [];
        this.cOrderTypeList = [];
        this.cPaymentModeList = [];
        this.cDisputesStatusList = [];
        this.cDisputesReasonList = [];
        this.cIsChildrenAccount = false;
        this.cIsSubAccount = false;
        //Set stored data into service
        this.setDataFromStorage();
        //fetch remening data from API
        this.fetchAllMerchInfo();
    }
    fetchAllMerchInfo() {
        if (this.sCurrentLoginMerchantService.regId != undefined && this.sCurrentLoginMerchantService.regId != null && this.sCurrentLoginMerchantService.regId != '') {
            this.pApiRequestService.httpPostRequest({ "regId": Number(this.sCurrentLoginMerchantService.regId) }, 'common/fetchAllMerchInfo')
                .subscribe(pResponse => this.fetchAllMerchInfoSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    setDataFromStorage() {
        try {
            if (this.sCheck.isNotNullString(sessionStorage.getItem("regId"))) {
                this.cRegId = Number(sessionStorage.getItem("regId"));
            }
            if (this.sCheck.isNotNullString(sessionStorage.getItem("bizWebsite"))) {
                this.cBizWebsite = sessionStorage.getItem("bizWebsite");
            }
            if (this.sCheck.isNotNullString(sessionStorage.getItem("childrenAccounts"))) {
                this.cChildrenAccount = JSON.parse(sessionStorage.getItem("childrenAccounts"));
            }
            if (this.sCheck.isNotNullString(sessionStorage.getItem("subAccounts"))) {
                this.cSubAccount = JSON.parse(sessionStorage.getItem("subAccounts"));
            }
            if (this.sCheck.isNotNullString(sessionStorage.getItem("currency"))) {
                this.cCurrency = JSON.parse(sessionStorage.getItem("currency"));
            }
            //child-Merchants
            if (this.sCheck.isNotNullList(this.cChildrenAccount)) {
                this.cIsChildrenAccount = true;
                this.cChildrenAccountList.push({ label: this.getRegId() + "-" + this.getBizWebsite(), value: this.getRegId() });
                for (let pChildrenAccount of this.cChildrenAccount) {
                    this.cChildrenAccountList.push({ label: pChildrenAccount.regId + "-" + pChildrenAccount.bizWebsite, value: pChildrenAccount.regId });
                }
            }
            //Sub-accounts
            if (this.sCheck.isNotNullList(this.cSubAccount)) {
                this.cIsSubAccount = true;
                for (let pSubAccount of this.cSubAccount) {
                    this.cSubAccountList.push({ label: pSubAccount.subAccountId, value: pSubAccount.subAccountId });
                }
            }
            //Currency
            if (this.sCheck.isNotNullList(this.cCurrency)) {
                for (let pCurrency of this.cCurrency) {
                    this.cCurrencyList.push({ label: pCurrency.currencyId, value: pCurrency.currencyId });
                }
            }
        }
        catch (e) {
        }
    }
    fetchAllMerchInfoSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess && this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cOrderStatus = mCommonResponse.data['orderStatus'];
                this.cOrderType = mCommonResponse.data['orderType'];
                this.cPaymentMode = mCommonResponse.data['paymentOption'];
                this.cDisputesStatus = mCommonResponse.data['disputesStatus'];
                this.cDisputesReason = mCommonResponse.data['disputeReason'];
                //Order Status
                if (this.sCheck.isNotNullList(this.cOrderStatus)) {
                    for (let pOrderStatus of this.cOrderStatus) {
                        this.cOrderStatusList.push({ label: pOrderStatus.status, value: pOrderStatus.statusId });
                    }
                }
                //Orders Status
                if (this.sCheck.isNotNullList(this.cOrderStatus)) {
                    for (let pOrderStatus of this.cOrderStatus) {
                        if (pOrderStatus.status != 'Successful') {
                            this.cOrdersStatusList.push({ label: pOrderStatus.status, value: pOrderStatus.statusId });
                        }
                    }
                }
                //Order Type
                if (this.sCheck.isNotNullList(this.cOrderType)) {
                    for (let pOrderType of this.cOrderType) {
                        this.cOrderTypeList.push({ label: pOrderType.status, value: pOrderType.statusId });
                    }
                }
                //Payment modes
                if (this.sCheck.isNotNullList(this.cPaymentMode)) {
                    for (let pPaymentMode of this.cPaymentMode) {
                        this.cPaymentModeList.push({ label: pPaymentMode.paymentOptionDescription, value: pPaymentMode.paymentOptionType });
                    }
                }
                //Disputes Status
                if (this.sCheck.isNotNullList(this.cDisputesStatus)) {
                    for (let pDisputesStatus of this.cDisputesStatus) {
                        this.cDisputesStatusList.push({ label: pDisputesStatus.status, value: pDisputesStatus.statusId });
                    }
                }
                //Disputes reason
                if (this.sCheck.isNotNullList(this.cDisputesReason)) {
                    for (let pDisputesReason of this.cDisputesReason) {
                        this.cDisputesReasonList.push({ label: pDisputesReason.status, value: pDisputesReason.statusId });
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
    getRegId() {
        return this.cRegId;
    }
    getBizWebsite() {
        return this.cBizWebsite;
    }
    getChildrenAccount() {
        return this.cChildrenAccount;
    }
    getSubAccount() {
        return this.cSubAccount;
    }
    getCurrency() {
        return this.cCurrency;
    }
    getChildrenAccountList() {
        return this.cChildrenAccountList;
    }
    getSubAccountList() {
        return this.cSubAccountList;
    }
    getCurrencyList() {
        return this.cCurrencyList;
    }
    isChildrenAccount() {
        return this.cIsChildrenAccount;
    }
    isSubAccount() {
        return this.cIsSubAccount;
    }
    getOrderStatus() {
        return this.cOrderStatus;
    }
    getOrderType() {
        return this.cOrderType;
    }
    getPaymentMode() {
        return this.cPaymentMode;
    }
    //  public getOrderStatusList(){
    //      return this.cOrderStatusList;
    //  }
    getOrdersStatusList() {
        return this.cOrdersStatusList;
    }
    getOrderTypeList() {
        return this.cOrderTypeList;
    }
    getPaymentModeList() {
        return this.cPaymentModeList;
    }
    getDisputesStatusList() {
        return this.cDisputesStatusList;
    }
    getDisputesReasonList() {
        return this.cDisputesReasonList;
    }
};
MerchInfoService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService,
        ConditionalCheckService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        CurrentLoginMerchantService])
], MerchInfoService);
export { MerchInfoService };
//# sourceMappingURL=merch-info.service.js.map