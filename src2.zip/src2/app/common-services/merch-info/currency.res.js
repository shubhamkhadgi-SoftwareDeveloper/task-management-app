export class Currency {
}
//# sourceMappingURL=currency.res.js.map