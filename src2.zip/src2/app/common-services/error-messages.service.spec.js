import { TestBed, inject } from '@angular/core/testing';
import { ErrorMessagesService } from './error-messages.service';
describe('ErrorMessagesService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ErrorMessagesService]
        });
    });
    it('should be created', inject([ErrorMessagesService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=error-messages.service.spec.js.map