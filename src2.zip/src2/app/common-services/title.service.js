import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ConditionalCheckService } from './conditional-check.service';
let TitleService = class TitleService {
    constructor(sTitle, sCheck) {
        this.sTitle = sTitle;
        this.sCheck = sCheck;
        this.CommonTitle = 'CCAvenue';
        //Account Admin
        this.AccountInformation = 'CCAvenue - Merchant Accounting & Reporting System : Account Information';
        this.UpgradeAccount = 'CCAvenue - Merchant Accounting & Reporting System : Upgrade Account';
        this.ManageUsers = 'CCAvenue - Merchant Accounting & Reporting System : Manage Users';
        //Dashboard
        this.Dashboard = 'CCAvenue - Dashboard';
        //Transactions
        this.Unconfirmed = 'CCAvenue - Transactions : Unconfirmed';
        this.Orders = 'CCAvenue - Transactions : Orders';
        this.BulkUpdate = 'CCAvenue - Transactions : Bulk Update';
        this.Disputes = 'CCAvenue - Transactions : Disputes';
        this.Refunds = 'CCAvenue - Transactions : Refunds to be Confirmed';
        //Invoice
        this.Invoice = 'CCAvenue - Invoice : Invoice List';
        this.RecurringProfile = 'CCAvenue - Invoice : Recurring Profile List';
        this.BulkUpload = 'CCAvenue - Invoice : Bulk Upload';
        this.InvoiceSettings = 'CCAvenue - Invoice : Invoice Settings';
        this.TasksItems = 'CCAvenue - Invoice :  Invoice Task/Items List';
        //RecurringPayments
        this.RecurringPayments = 'Recurring Payments';
        this.StandingInstructionsList = 'CCAvenue - Recurring Payments :  Standing Instructions List ';
        this.RecurringPaymentsSettings = 'CCAvenue - Recurring Payments :  Settings';
        this.ProgressBars = 'CCAvenue - Recurring Payments :  Progress Bars';
        this.SISuccessfulReport = 'CCAvenue - Recurring Payments :  SI Successful Report';
        this.SIUnsuccessfulReport = 'CCAvenue - Recurring Payments :  SI Unsuccessful Report';
        //Products
        this.Products = 'CCAvenue - Products : Product List';
        this.EditProducts = 'CCAvenue - Products : Edit Products';
        this.Shipping = 'CCAvenue - Products:  Shipping';
        //Store
        this.Store = 'Store';
        this.StoreSettings = 'Store Settings';
        this.ThemeSettings = 'Theme Settings';
        this.ManageThemes = 'Manage Themes';
        this.ProductCategories = 'Product Categories';
        this.Pages = 'Pages';
        this.Links = 'Links';
        //MarketingTools
        this.MarketingTools = 'Marketing Tools';
        this.QRCode = 'CCAvenue - Marketting Tools : QR Code';
        this.DiscountCoupons = 'CCAvenue - Marketting Tools : Discount Coupons';
        this.Promotions = 'CCAvenue - Marketting Tools : Promotions';
        this.CCAvenueSNIP = 'CCAvenue - Marketting Tools : CCAvenue S.N.I.P';
        //Brand360
        this.Brand360 = 'Brand 360';
        this.MarketingDashboard = 'Marketing Dashboard';
        this.SEOAudit = 'SEO Audit';
        this.WebsiteUptime = 'Website Uptime';
        this.ReputationMonitoring = 'Reputation Monitoring';
        this.FacebookManagement = 'Facebook Management';
        this.TwitterManagement = 'Twitter Management';
        this.FacebookApps = 'Facebook Apps';
        this.SocialAnalytics = 'Social Analytics';
        this.Brand360Settings = 'Settings';
        //Reports
        this.Reports = 'Reports';
        this.UnsettledTransactionReport = 'CCAvenue - Report : Unsettled Transaction Summary';
        this.PayoutSummary = 'CCAvenue - Report : Payout Summary';
        this.SalesReport = 'CCAvenue - Report : Sales Report';
        this.SalesReportbyPaymentType = 'CCAvenue - Report : Sales Report by Payment Type';
        this.DirectBankSettlements = 'CCAvenue - Report : Direct Bank Settlements';
        this.CCAvenueServiceInvoice = 'CCAvenue - Report : CCavenue Service Invoice';
        this.ReconciliationReport = 'CCAvenue - Report : Reconciliation Report';
        this.AbortedTransactionReport = 'CCAvenue - Report : Aborted Transaction Summary';
        this.InvalidRequestReport = 'CCAvenue - Report : Invalid Request Report';
        this.FailureAnalysisReport = 'CCAvenue - Report : Failure Analysis Report';
        this.RefundAnalysisReport = 'CCAvenue - Report : Refund Analysis Report';
        this.UserAuditLogs = 'CCAvenue - Report : User Audit Logs';
        this.GatewayPerformanceReport = 'CCAvenue - Report : Gateway Performance Report';
        this.RetriedTransactionReport = 'CCAvenue - Report : Retried Transaction Report';
        this.SubAccountReport = 'CCAvenue - Report : Subaccount Report';
        //Setting - module
        this.Settings = 'Settings';
        this.GatewaySettings = 'CCAvenue - Settings : Gateway Settings';
        this.ManageTax = 'CCAvenue - Settings : Manage Tax';
        this.APIKeys = 'CCAvenue - Settings : API Keys';
        this.VelocityChecks = 'CCAvenue - Settings : Velocity Checks';
        this.BlackListControls = 'CCAvenue - Settings : Black List Controls';
        this.DynamicEventNotification = 'CCAvenue - Settings : Dynamic Event Notification';
        this.SocialStreams = 'CCAvenue - Settings : Social Streams';
        this.LookFeel = 'CCAvenue - Settings : Look & Feel';
        //Resources
        this.Resources = 'Resources';
        this.WebIntegrationKit = 'CCAvenue - Resources : Web Integration Kit';
        this.MobileIntegrationKit = 'CCAvenue - Resources : Mobile Integration Kit';
        this.APIImplementationGuide = 'CCAvenue - Resources : API Implementation Guide';
        this.ThirdPartyShoppingCart = 'CCAvenue - Resources : Third Party Shopping Cart';
    }
    setTitle(pTitle) {
        if (this.sCheck.isNotNullString) {
            this.sTitle.setTitle(pTitle);
        }
        else {
            this.sTitle.setTitle(this.CommonTitle);
        }
    }
};
TitleService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Title,
        ConditionalCheckService])
], TitleService);
export { TitleService };
//# sourceMappingURL=title.service.js.map