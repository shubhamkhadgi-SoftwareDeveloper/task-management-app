import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ConditionalCheckService } from './conditional-check.service';
import { CommonResponse } from './../common-response/common-response.res';
import { AlertMessageService } from './alert-message.service';
import { ErrorMessagesService } from './error-messages.service';
import { PrivilegeService } from './privilege.service';
import { FacebookService } from 'ngx-facebook';
import { SocialStreamsService } from '../home/menu/settings/social-streams/social-streams.service';
import { HttpClient } from '@angular/common/http';
let CustomFacebookService = class CustomFacebookService {
    constructor(sCheck, sAlertMessageService, sPrivilegeService, sErrorMessagesService, sFacebook, sSocialStreamsService, http) {
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sPrivilegeService = sPrivilegeService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sFacebook = sFacebook;
        this.sSocialStreamsService = sSocialStreamsService;
        this.http = http;
        //Facebook App Info
        this.cAppId = '1603075549908137'; // '1635381893351662';
        this.cAppSecret = 'aa2bd02917750e3eb43c1fa3ef766e81'; //'c8f17d5b8c595c9baafe3c90fc2fa13e';
        this.cAppVersion = 'v2.12';
        //Facebook Profile Param
        this.cFbProfileId = null;
        this.cFbProfileName = null;
        this.cFbProfilePic = null;
        //Facebook Page Param
        this.cFbPageId = null;
        this.cFbPageName = null;
        this.cFbPageCategory = null;
        this.cFbPageToken = null;
        this.cFbPagePic = null;
        this.cFbLoginFor = null;
        this.initiateFbApp();
    }
    /***************************************initiate FaceBook App*********************************************************/
    initiateFbApp() {
        let initParams = {
            appId: this.cAppId,
            xfbml: true,
            version: this.cAppVersion,
            status: true,
            cookie: false
        };
        this.sFacebook.init(initParams);
    }
    /******************************Check Active FaceBook connection*********************************************************/
    onFbConnClick(pFbProfileId) {
        this.cFbLoginFor = pFbProfileId;
        this.sFacebook.getLoginStatus()
            .then(response => this.checkLogin(response))
            .catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    checkLogin(response) {
        if (response.status == 'connected') {
            this.sFacebook.logout()
                .then((response) => {
                if (this.cFbLoginFor === 'fbProfile') {
                    this.loginToFacebookProfile();
                }
                else if (this.cFbLoginFor === 'fbPage') {
                    this.loginToFacebookPage();
                }
            }).catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        else {
            if (this.cFbLoginFor === 'fbProfile') {
                this.loginToFacebookProfile();
            }
            else if (this.cFbLoginFor === 'fbPage') {
                this.loginToFacebookPage();
            }
        }
    }
    /******************************FaceBook profile connection*********************************************************/
    loginToFacebookProfile() {
        this.sFacebook.login({ auth_type: 'reauthenticate', scope: 'email, publish_pages, manage_pages' }) //publish_actions,read_stream,offline_access,publish_stream  // read_stream,offline_access,publish_stream, //email,publish_actions,publish_pages,manage_pages,read_stream,offline_access,publish_stream
            .then((response) => {
            if (response.status == "connected" && response.authResponse) {
                this.getFbUserInfo(response);
            }
        }).catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    getFbUserInfo(pResponse) {
        this.sFacebook.api('/me', 'get')
            .then((response) => {
            this.addFbProfile(response.id, response.name);
        }).catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    addFbProfile(pProfileId, pProfileName) {
        this.sSocialStreamsService.addFbProfile({ 'profileId': pProfileId, 'profileName': pProfileName })
            .subscribe(pResponse => this.addFbProfileSuccess(pResponse, pProfileId, pProfileName), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    addFbProfileSuccess(pResponse, pProfileId, pProfileName) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cFbProfilePic = 'https://graph.facebook.com/' + pProfileId + '/picture/' + pProfileName;
                this.cFbProfileName = pProfileName;
                console.log(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.cFbProfileName = null;
                this.cFbProfilePic = null;
                console.log(mCommonResponse.messageDesc);
            }
            else {
                this.cFbProfileName = null;
                this.cFbProfilePic = null;
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cFbProfileName = null;
            this.cFbProfilePic = null;
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
    /******************************FaceBook page connection*********************************************************/
    loginToFacebookPage() {
        this.sFacebook.login({ auth_type: 'reauthenticate', scope: 'email,publish_pages,manage_pages' }) //publish_actions,read_stream,offline_access,publish_stream  
            .then((response) => {
            if (response.status == "connected" && response.authResponse) {
                this.getPageLivedToken(response);
            }
        }).catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    /* public getPageLivedToken(pResponse: LoginResponse){
         let pUserId: string = pResponse.authResponse.userID;
         this.sSocialStreamsService.getPageLivedToken({'fbExchangeToken':pResponse.authResponse.accessToken})
         .subscribe(pResponse => this.getPageLivedTokenSuccess(pResponse, pUserId) ,error => {console.log(this.sErrorMessagesService.errorResponse);});
     }
     
     private getPageLivedTokenSuccess(pResponse, pUserId){
         if(this.sCheck.isNotNullObject(pResponse)){
             let mCommonResponse:CommonResponse  = new CommonResponse(pResponse);
             if(mCommonResponse.isSuccess){
                 if(this.sCheck.isNotNullObject(mCommonResponse.data)){
                     if(this.sCheck.isNotNullString(mCommonResponse.data)){
                         let mAccesstoken: string = mCommonResponse.data.livePageToken as string;
                         this.getPageInfo(mAccesstoken, pUserId)
                     }
                 }
             }else if(mCommonResponse.isFail){
                 console.log(mCommonResponse.messageDesc);
             }else{
                 console.log(this.sErrorMessagesService.responseNull);
             }
         }else{
             console.log(this.sErrorMessagesService.responseNull);
         }
     }*/
    getPageLivedToken(pResponse) {
        let pUserId = pResponse.authResponse.userID;
        let pFbExchangeToken = pResponse.authResponse.accessToken;
        let getPageLivedTokenUrl = 'https://graph.facebook.com/' + this.cAppVersion + '/oauth/access_token?grant_type=fb_exchange_token&client_id=' + this.cAppId + '&client_secret=' + this.cAppSecret + '&fb_exchange_token=' + pFbExchangeToken;
        // this.http.get(getPageLivedTokenUrl).subscribe(data => {
        //     let mBody = data.json();
        //     this.getPageInfo(mBody.access_token, pUserId)
        //   });
    }
    getPageInfo(pAccesstoken, pUserId) {
        let mGetPageInfoUrl = '/' + pUserId + '/accounts';
        this.sFacebook.api(mGetPageInfoUrl, 'get', { access_token: pAccesstoken })
            .then((response) => {
            if (this.sCheck.isNotNullList(response.data)) {
                this.addFbPage(response.data[0].id, response.data[0].name, response.data[0].category, response.data[0].access_token);
            }
            else {
                console.log("This is not a valid facebook page.");
            }
        }).catch((error) => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    addFbPage(pFbPageId, pFbPageName, pFbPageCategory, pFbPageToken) {
        this.sSocialStreamsService.addFbPage({ 'fbPageId': pFbPageId, 'fbPageName': pFbPageName, 'fbPageCategory': pFbPageCategory, 'fbPageToken': pFbPageToken })
            .subscribe(pResponse => this.addFbPageSuccess(pResponse, pFbPageId, pFbPageName, pFbPageCategory, pFbPageToken), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    addFbPageSuccess(pResponse, pFbPageId, pFbPageName, pFbPageCategory, pFbPageToken) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cFbPageId = pFbPageId;
                this.cFbPageName = pFbPageName;
                this.cFbPageCategory = pFbPageCategory;
                this.cFbPageToken = pFbPageToken;
                this.cFbPagePic = 'http://graph.facebook.com/' + this.cFbPageId + '/picture?access_token=' + this.cFbPageToken;
                console.log(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.cFbPageId = null;
                this.cFbPageName = null;
                this.cFbPageCategory = null;
                this.cFbPageToken = null;
                console.log(mCommonResponse.messageDesc);
            }
            else {
                this.cFbPageId = null;
                this.cFbPageName = null;
                this.cFbPageCategory = null;
                this.cFbPageToken = null;
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cFbPageId = null;
            this.cFbPageName = null;
            this.cFbPageCategory = null;
            this.cFbPageToken = null;
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
    /******************************Profile Deactivation*********************************************************/
    onProfileDisConnClick(pProfileType) {
        this.sSocialStreamsService.deleteProfile({ 'profileType': pProfileType })
            .subscribe(pResponse => this.deleteProfileSuccess(pResponse, pProfileType), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    deleteProfileSuccess(pResponse, pProfileType) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (pProfileType == 'Facebook') {
                    this.cFbProfileId = null;
                    this.cFbProfilePic = null;
                    this.cFbProfileName = null;
                }
                else if (pProfileType == 'FacebookPage') {
                    this.cFbPageId = null;
                    this.cFbPageName = null;
                    this.cFbPageCategory = null;
                    this.cFbPageToken = null;
                }
                console.log(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
};
CustomFacebookService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ConditionalCheckService,
        AlertMessageService,
        PrivilegeService,
        ErrorMessagesService,
        FacebookService,
        SocialStreamsService,
        HttpClient])
], CustomFacebookService);
export { CustomFacebookService };
//# sourceMappingURL=custom-facebook.service.js.map