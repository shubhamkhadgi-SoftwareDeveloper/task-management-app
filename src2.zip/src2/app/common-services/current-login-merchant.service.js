import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
let CurrentLoginMerchantService = class CurrentLoginMerchantService {
    constructor(sRouter) {
        this.sRouter = sRouter;
        this._regId = sessionStorage.getItem("regId");
        this._accessToken = localStorage.getItem("accessToken");
        this._userName = sessionStorage.getItem("userName");
        this._userId = sessionStorage.getItem("userId");
        this._userEmail = sessionStorage.getItem("userEmail");
        this._isUserPrimary = sessionStorage.getItem("isUserPrimary");
        this._resellerCode = sessionStorage.getItem("resellerCode");
    }
    set regId(pRegId) {
        this._regId = pRegId;
    }
    get regId() {
        return sessionStorage.getItem("regId");
    }
    set userId(pUserId) {
        this._userId = pUserId;
    }
    get userId() {
        return sessionStorage.getItem("userId");
    }
    set userEmail(pUserEmail) {
        this._userEmail = pUserEmail;
    }
    get userEmail() {
        return sessionStorage.getItem("userEmail");
    }
    set userName(pUserName) {
        this._userName = pUserName;
    }
    get userName() {
        return sessionStorage.getItem("userName");
    }
    set accessToken(pAccessToken) {
        this._accessToken = pAccessToken;
    }
    get accessToken() {
        return localStorage.getItem("accessToken");
    }
    get isUserPrimary() {
        this._isUserPrimary = sessionStorage.getItem("isUserPrimary");
        if (this._isUserPrimary != null) {
            if (this._isUserPrimary === 'Y' || this._isUserPrimary === 'y') {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return null;
        }
    }
    get resellerCode() {
        if (sessionStorage.getItem("resellerCode") != undefined && sessionStorage.getItem("resellerCode") != null) {
            return sessionStorage.getItem("resellerCode");
        }
        else {
            return "";
        }
    }
};
CurrentLoginMerchantService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router])
], CurrentLoginMerchantService);
export { CurrentLoginMerchantService };
//# sourceMappingURL=current-login-merchant.service.js.map