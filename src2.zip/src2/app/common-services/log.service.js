import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let LogService = class LogService {
    constructor() { }
    log(pLog) {
        console.log(pLog);
    }
    logWithMsg(pLogMsg, pLog) {
        console.log(pLogMsg + '-->' + pLog);
    }
    jsonLog(pJsonLog) {
        console.log(JSON.stringify(pJsonLog));
    }
    jsonLogWithMsg(pJsonLogMsg, pJsonLog) {
        console.log(pJsonLogMsg + '-->' + JSON.stringify(pJsonLog));
    }
};
LogService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], LogService);
export { LogService };
//# sourceMappingURL=log.service.js.map