import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let PrivilegeService = class PrivilegeService {
    constructor() {
        /*****************Privilege Rights*************/
        this.MAIN = "MAIN";
        this.WRITE = "WRITE";
        this.READ = "READ";
        this.NR = "NR";
        /*****************Menus By Rights*************/
        this.mainMenus = [];
        this.writeRightMenus = [];
        this.readRightMenus = [];
        this.noRightMenus = [];
        /*****************NO Privilege menu******************/
        this.fullPrivilegeMenu = [];
        this.onlyReadPrivilegeMenu = [];
        /*****************Menu*************/
        //Account Admin
        this.AccountInformation = 'Account Information';
        this.UpgradeAccount = 'Upgrade Account';
        this.ManageUsers = 'Manage Users';
        //Dashboard
        this.Dashboard = 'Dashboard';
        //Transactions
        this.Unconfirmed = 'Unconfirmed';
        this.Orders = 'Orders';
        this.BulkUpdate = 'Bulk Update';
        this.Disputes = 'Disputes';
        this.Refunds = 'Refunds';
        //Invoice
        this.Invoice = 'Invoice';
        this.RecurringProfile = 'Recurring Profile';
        this.BulkUpload = "Bulk Upload";
        this.InvoiceSettings = 'Invoice Settings';
        this.TasksItems = 'Tasks / Items';
        //RecurringPayments
        this.RecurringPayments = 'Recurring Payments';
        this.StandingInstructionsList = 'Standing Instructions List';
        this.RecurringPaymentsSettings = 'Settings';
        this.ProgressBars = 'Progress Bars';
        this.SISuccessfulReport = 'SI Successful Report';
        this.SIUnsuccessfulReport = 'SI Unsuccessful Report';
        //Products
        this.Products = 'Products';
        this.EditProducts = 'Edit Products';
        this.Shipping = 'Shipping';
        //Store
        this.Store = 'Store';
        this.StoreSettings = 'Store Settings';
        this.ThemeSettings = 'Theme Settings';
        this.ManageThemes = 'Manage Themes';
        this.ProductCategories = 'Product Categories';
        this.Pages = 'Pages';
        this.Links = 'Links';
        //MarketingTools
        this.MarketingTools = 'Marketing Tools';
        this.QRCode = 'QR Code';
        this.DiscountCoupons = 'Discount Coupons';
        this.Promotions = 'Promotions';
        this.CCAvenueSNIP = 'CCAvenue S.N.I.P';
        //Reports
        this.Reports = 'Reports';
        this.UnsettledTransactionReport = 'Unsettled Transaction Report';
        this.PayoutSummary = 'Payout Summary';
        this.SalesReport = 'Sales Report';
        this.SalesReportbyPaymentType = 'Sales Report by Payment Type';
        this.DirectBankSettlements = 'Direct Bank Settlements';
        this.CCAvenueServiceInvoice = 'CCAvenue Service Invoice';
        this.ReconciliationReport = 'Reconciliation Report';
        this.AbortedTransactionReport = 'Aborted Transaction Report';
        this.InvalidRequestReport = 'Invalid Request Report';
        this.FailureAnalysisReport = 'Failure Analysis Report';
        this.RefundAnalysisReport = 'Refund Analysis Report';
        this.UserAuditLogs = 'User Audit Logs';
        this.GatewayPerformanceReport = 'Gateway Performance Report';
        this.RetriedTransactionReport = 'Retried Transaction Report';
        this.SubAccountReport = 'Sub Account Report';
        //Setting - module
        this.Settings = 'Settings';
        this.GatewaySettings = 'Gateway Settings';
        this.ManageTax = 'Manage Tax';
        this.APIKeys = 'API Keys';
        this.VelocityChecks = 'Velocity Checks';
        this.BlackListControls = 'Black List Controls';
        this.Webhooks = 'Webhooks';
        this.SocialStreams = 'Social Streams';
        this.LookFeel = 'Look & Feel';
        //Resources
        this.Resources = 'Resources';
        //Customer
        this.Customer = 'Customers';
        //Quick Invoice
        this.QuickInvoice = 'Quick Invoice';
        //full Privilege Menu (i.e. No relation with right)
        this.fullPrivilegeMenu.push(this.Dashboard);
        //Only read privilege menu
        this.onlyReadPrivilegeMenu.push(this.Reports);
        this.onlyReadPrivilegeMenu.push(this.UnsettledTransactionReport);
        this.onlyReadPrivilegeMenu.push(this.PayoutSummary);
        this.onlyReadPrivilegeMenu.push(this.SalesReport);
        this.onlyReadPrivilegeMenu.push(this.SalesReportbyPaymentType);
        this.onlyReadPrivilegeMenu.push(this.DirectBankSettlements);
        this.onlyReadPrivilegeMenu.push(this.CCAvenueServiceInvoice);
        this.onlyReadPrivilegeMenu.push(this.ReconciliationReport);
        this.onlyReadPrivilegeMenu.push(this.AbortedTransactionReport);
        this.onlyReadPrivilegeMenu.push(this.InvalidRequestReport);
        this.onlyReadPrivilegeMenu.push(this.FailureAnalysisReport);
        this.onlyReadPrivilegeMenu.push(this.RefundAnalysisReport);
        this.onlyReadPrivilegeMenu.push(this.UserAuditLogs);
        this.onlyReadPrivilegeMenu.push(this.GatewayPerformanceReport);
        this.onlyReadPrivilegeMenu.push(this.RetriedTransactionReport);
        this.onlyReadPrivilegeMenu.push(this.SubAccountReport);
        //Account Admin Menu privilege
        let cAdminMenuList = JSON.parse(sessionStorage.getItem("adminMenuList"));
        if (cAdminMenuList != undefined && cAdminMenuList != null) {
            for (let mChild of cAdminMenuList) {
                let mChildMenu = mChild;
                if (mChildMenu.privilegeRight === this.WRITE) {
                    this.writeRightMenus.push(mChildMenu.menuName);
                }
                else if (mChildMenu.privilegeRight === this.READ) {
                    this.readRightMenus.push(mChildMenu.menuName);
                }
                else if (mChildMenu.privilegeRight === this.NR) {
                    this.noRightMenus.push(mChildMenu.menuName);
                }
                else if (mChildMenu.privilegeRight === this.MAIN) {
                    if (!(this.mainMenus.indexOf(mChildMenu.menuName) >= 0)) {
                        this.mainMenus.push(mChildMenu.menuName);
                    }
                }
            }
        }
        //Main Menu privilege
        let cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        if (cMenuList != undefined && cMenuList != null) {
            for (let mParentMenu in cMenuList) {
                this.mainMenus.push(mParentMenu);
                for (let mChild of cMenuList[mParentMenu]) {
                    let mChildMenu = mChild;
                    if (mChildMenu.privilegeRight === this.WRITE) {
                        this.writeRightMenus.push(mChildMenu.menuName);
                    }
                    else if (mChildMenu.privilegeRight === this.READ) {
                        this.readRightMenus.push(mChildMenu.menuName);
                    }
                    else if (mChildMenu.privilegeRight === this.NR) {
                        this.noRightMenus.push(mChildMenu.menuName);
                    }
                    else if (mChildMenu.privilegeRight === this.MAIN) {
                        if (!(this.mainMenus.indexOf(mChildMenu.menuName) >= 0)) {
                            this.mainMenus.push(mChildMenu.menuName);
                        }
                    }
                }
            }
        }
    }
    get isUserPrimary() {
        let isUserPrimary = sessionStorage.getItem("isUserPrimary");
        if (isUserPrimary != undefined && isUserPrimary != null && isUserPrimary == 'Y') {
            return true;
        }
        else {
            return false;
        }
    }
    isWritePrivilege(mMenuName) {
        if (this.writeRightMenus != null && this.writeRightMenus.length > 0 && mMenuName != null) {
            return (this.writeRightMenus.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
    isReadPrivilege(mMenuName) {
        if (this.readRightMenus != null && this.readRightMenus.length > 0 && mMenuName != null) {
            return (this.readRightMenus.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
    isMainPrivilege(mMenuName) {
        if (this.mainMenus != null && this.mainMenus.length > 0 && mMenuName != null) {
            return (this.mainMenus.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
    isNoPrivilege(mMenuName) {
        if (this.noRightMenus != null && this.noRightMenus.length > 0 && mMenuName != null) {
            return (this.noRightMenus.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
    isFullPrivilegeMenu(mMenuName) {
        if (mMenuName != null) {
            return (this.fullPrivilegeMenu.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
    isOnlyReadPrivilegeMenu(mMenuName) {
        if (mMenuName != null) {
            return (this.onlyReadPrivilegeMenu.indexOf(mMenuName) >= 0);
        }
        else {
            false;
        }
    }
};
PrivilegeService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], PrivilegeService);
export { PrivilegeService };
//# sourceMappingURL=privilege.service.js.map