import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UploadDocumentComponent } from './upload-document/upload-document.component';
let FormComponentModule = class FormComponentModule {
};
FormComponentModule = tslib_1.__decorate([
    NgModule({
        imports: [CommonModule],
        exports: [UploadDocumentComponent],
        declarations: [UploadDocumentComponent]
    })
], FormComponentModule);
export { FormComponentModule };
//# sourceMappingURL=form-component.module.js.map