export class DocumentUploadRequest {
}
//# sourceMappingURL=document-upload.request.js.map