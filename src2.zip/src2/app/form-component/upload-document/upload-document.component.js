import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { DocumentUploadRequest } from './document-upload.request';
import { BsModalService } from 'ngx-bootstrap/modal';
let UploadDocumentComponent = class UploadDocumentComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.fileName = '';
        this.allowedToProceed = false;
        this.errorMessage = '';
    }
    ngOnInit() {
    }
    openUploadModal(pTemplate) {
        this.modalRef = this.modalService.show(pTemplate, { class: 'batch-details-model modal-md', ignoreBackdropClick: true });
    }
    onChange(event) {
        let fileList = event.target.files;
        if (fileList.length > 0) {
            this.document = fileList[0];
            this.fileName = fileList[0].name;
            let validExts = [];
            validExts = ['.jpg', '.jpeg', '.png', '.doc', '.pdf'];
            var fileExt = this.fileName.substring(this.fileName.lastIndexOf('.'));
            if (validExts.indexOf(fileExt) >= 0) {
                if (this.document.size <= 500000) {
                    this.allowedToProceed = true;
                }
                else {
                    this.errorMessage = "File size upto 500 KB allowed.";
                    this.allowedToProceed = false;
                }
            }
            else {
                this.errorMessage = "Only doc, pdf, jpg, jpeg & png files upto 500 KB allowed.";
                this.allowedToProceed = false;
            }
        }
    }
    onUploadClick() {
        this.documentUploadRequest = new DocumentUploadRequest();
        this.documentUploadRequest.isDocumentPresent = this.isDocumentPresent,
            this.documentUploadRequest.uploadDescription = this.uploadDescription,
            this.documentUploadRequest.uploadId = this.uploadId;
        this.uploadFileCallback(this.documentUploadRequest, this.document);
        this.modalRef.hide();
    }
    closeModal() {
        this.modalRef.hide();
        this.document = null;
        this.fileName = '';
        this.errorMessage = '';
    }
};
tslib_1.__decorate([
    Input('uploadDescription'),
    tslib_1.__metadata("design:type", String)
], UploadDocumentComponent.prototype, "uploadDescription", void 0);
tslib_1.__decorate([
    Input('uploadId'),
    tslib_1.__metadata("design:type", String)
], UploadDocumentComponent.prototype, "uploadId", void 0);
tslib_1.__decorate([
    Input('isDocumentPresent'),
    tslib_1.__metadata("design:type", String)
], UploadDocumentComponent.prototype, "isDocumentPresent", void 0);
tslib_1.__decorate([
    Input('disableUpload'),
    tslib_1.__metadata("design:type", String)
], UploadDocumentComponent.prototype, "disableUpload", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Function)
], UploadDocumentComponent.prototype, "uploadFileCallback", void 0);
UploadDocumentComponent = tslib_1.__decorate([
    Component({
        selector: 'upload-document',
        templateUrl: './upload-document.template.html',
        styleUrls: ['./upload-document.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [BsModalService])
], UploadDocumentComponent);
export { UploadDocumentComponent };
//# sourceMappingURL=upload-document.component.js.map