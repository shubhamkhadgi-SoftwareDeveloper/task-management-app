import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app.routing';
import { LoginModule } from './login/login.module';
import { HomeModule } from './home/home.module';
import { ApiRequestService } from './common-services/api-request.service';
import { MerchInfoService } from './common-services/merch-info/merch-info.service';
import { PdfPrintService } from './common-services/pdf-print.service';
import { LogService } from './common-services/log.service';
import { ConditionalCheckService } from './common-services/conditional-check.service';
import { AlertMessageService } from './common-services/alert-message.service';
import { ErrorHandlerService } from './common-services/error-handler.service';
import { ErrorMessagesService } from './common-services/error-messages.service';
import { CurrentLoginMerchantService } from './common-services/current-login-merchant.service';
import { ResponsiveService } from './common-services/responsive.service';
import { LandingPageMsgService } from './common-services/landing-page-msg.service';
import { PrivilegeService } from './common-services/privilege.service';
import { CanActivateRouteGuard } from './common-guard-services/can-activate-route.guard';
import { TitleService } from './common-services/title.service';
import { WINDOW_PROVIDERS } from './common-services/window.service';
import { DatePipe, CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { ColorPickerModule } from 'ngx-color-picker';
let AppModule = class AppModule {
};
AppModule = tslib_1.__decorate([
    NgModule({
        imports: [
            CommonModule,
            BrowserModule,
            BrowserAnimationsModule,
            FormsModule,
            HttpClientModule,
            ColorPickerModule,
            AppRoutingModule,
            LoginModule,
            HomeModule
        ],
        declarations: [AppComponent],
        providers: [
            //API base url
            { provide: 'APP_CONFIG', useValue: "http://localhost:8080/" },
            //API request http service
            ApiRequestService,
            //Merchant common information service
            MerchInfoService,
            //To print Pdf
            PdfPrintService,
            //To print console
            LogService,
            //To Check various condition on object
            ConditionalCheckService,
            //To show alert message
            AlertMessageService,
            ColorPickerModule,
            //To handle client/server side error
            ErrorHandlerService,
            //To error messages from common location
            ErrorMessagesService,
            //To identify current user and its AccessToken
            CurrentLoginMerchantService,
            //To resolve responsive design issue
            ResponsiveService,
            //To handling landing pages css classes and error messages
            LandingPageMsgService,
            //To provide privilege to module
            PrivilegeService,
            //Guard
            CanActivateRouteGuard,
            //To set title for window
            TitleService,
            DatePipe,
            HttpClientModule,
            WINDOW_PROVIDERS
        ],
        bootstrap: [AppComponent]
    })
], AppModule);
export { AppModule };
//# sourceMappingURL=app.module.js.map