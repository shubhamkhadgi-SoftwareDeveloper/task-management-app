import * as tslib_1 from "tslib";
import { Directive, HostListener } from '@angular/core';
let BlockCopyPasteDirective = class BlockCopyPasteDirective {
    constructor() { }
    blockPaste(e) {
        e.preventDefault();
    }
    blockCopy(e) {
        e.preventDefault();
    }
    blockCut(e) {
        e.preventDefault();
    }
};
tslib_1.__decorate([
    HostListener('paste', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], BlockCopyPasteDirective.prototype, "blockPaste", null);
tslib_1.__decorate([
    HostListener('copy', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], BlockCopyPasteDirective.prototype, "blockCopy", null);
tslib_1.__decorate([
    HostListener('cut', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], BlockCopyPasteDirective.prototype, "blockCut", null);
BlockCopyPasteDirective = tslib_1.__decorate([
    Directive({
        selector: '[appBlockCopyPaste]'
    }),
    tslib_1.__metadata("design:paramtypes", [])
], BlockCopyPasteDirective);
export { BlockCopyPasteDirective };
//# sourceMappingURL=block-copy-paste.directive.js.map