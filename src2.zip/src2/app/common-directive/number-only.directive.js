import * as tslib_1 from "tslib";
import { Directive, ElementRef, HostListener } from '@angular/core';
let NumberDirective = class NumberDirective {
    constructor(_el) {
        this._el = _el;
    }
    onInputChange(event) {
        const initalValue = this._el.nativeElement.value;
        this._el.nativeElement.value = initalValue.replace(/[^0-9]*/g, '');
        if (initalValue !== this._el.nativeElement.value) {
            event.stopPropagation();
        }
    }
};
tslib_1.__decorate([
    HostListener('input', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", void 0)
], NumberDirective.prototype, "onInputChange", null);
NumberDirective = tslib_1.__decorate([
    Directive({
        selector: 'input[numbersOnly]'
    }),
    tslib_1.__metadata("design:paramtypes", [ElementRef])
], NumberDirective);
export { NumberDirective };
//# sourceMappingURL=number-only.directive.js.map