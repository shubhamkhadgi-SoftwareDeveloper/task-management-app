import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DashboardComponent } from './menu/dashboard/dashboard.component';
import { CustomerComponent } from './menu/customer/customer.component';
import { AppControlsComponent } from '../common-components/app-controls/app-controls.component';
import { ServerErrorLandingPageComponent } from '../common-components/server-error-landing-page/server-error-landing-page.component';
//Resolver - services
import { DashboardResolverService } from './menu/dashboard/dashboard-resolver.service';
import { CustomerResolverService } from './menu/customer/customer-resolver.service';
//API - services
import { DashboardService } from './menu/dashboard/dashboard.service';
import { CustomerService } from './menu/customer/customer.service';
//Guard services
import { CanActivateRouteGuard } from './../common-guard-services/can-activate-route.guard';
import { SettingsComponent } from './menu/settings/settings.component';
const routes = [
    {
        path: 'menu',
        component: HomeComponent,
        canActivate: [CanActivateRouteGuard],
        children: [
            {
                path: 'accountSetting',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/account-setting/account-setting.module').then(m => m.AccountSettingModule)
            },
            {
                path: 'dashboard',
                canActivate: [CanActivateRouteGuard],
                component: DashboardComponent,
                resolve: { commonResponse: DashboardResolverService }
            },
            {
                path: 'transactions',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/transactions/transactions.module').then(m => m.TransactionsModule)
            },
            {
                path: 'invoice',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/invoice/invoice.module').then(m => m.InvoiceModule)
            },
            {
                path: 'recurringPayments',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/recurring-payments/recurring-payments.module').then(m => m.RecurringPaymentsModule)
            },
            {
                path: 'marketingTools',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/marketing-tools/marketing-tools.module').then(m => m.MarketingToolsModule)
            },
            {
                path: 'reports',
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/reports/reports.module').then(m => m.ReportsModule)
            },
            {
                path: 'settings',
                component: SettingsComponent,
                canActivate: [CanActivateRouteGuard],
                loadChildren: () => import('app/home/menu/settings/settings.module').then(m => m.SettingsModule),
            },
            {
                path: 'errorHandler/:errorCode',
                canActivate: [CanActivateRouteGuard],
                component: ServerErrorLandingPageComponent,
            },
            {
                path: 'customers',
                canActivate: [CanActivateRouteGuard],
                component: CustomerComponent,
                resolve: { commonResponse: CustomerResolverService }
            },
            { path: '', redirectTo: 'dashboard', pathMatch: 'full', canActivate: [CanActivateRouteGuard], resolve: { commonResponse: DashboardResolverService } },
            { path: '**', component: DashboardComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: DashboardResolverService } }
        ],
    },
    { path: '', redirectTo: 'dashboard', pathMatch: 'full', canActivate: [CanActivateRouteGuard], resolve: { commonResponse: DashboardResolverService } },
    { path: '**', component: DashboardComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: DashboardResolverService } }
];
let HomeRoutingModule = class HomeRoutingModule {
};
HomeRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [DashboardService, DashboardResolverService, CustomerService, CustomerResolverService]
    })
], HomeRoutingModule);
export { HomeRoutingModule };
export const HomeRoutedComponents = [HomeComponent, MenuComponent, HeaderComponent, FooterComponent, AppControlsComponent];
//# sourceMappingURL=home.routing.js.map