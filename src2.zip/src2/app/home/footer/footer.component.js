import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
        let currDate = new Date();
        this.cYear = currDate.getFullYear();
    }
};
tslib_1.__decorate([
    Input('isMinView'),
    tslib_1.__metadata("design:type", Boolean)
], FooterComponent.prototype, "cIsMinView", void 0);
FooterComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-footer',
        templateUrl: './footer.component.html',
        styleUrls: ['./footer.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [])
], FooterComponent);
export { FooterComponent };
//# sourceMappingURL=footer.component.js.map