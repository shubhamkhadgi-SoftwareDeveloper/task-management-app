import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { CommonResponse } from './../../../../common-response/common-response.res';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ErrorHandlerService } from './../../../../common-services/error-handler.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ManageUsers } from './manage-users.class';
import { ManageUsersService } from './manage-users.service';
import { PrivilegeService } from './../../../../common-services/privilege.service';
import { CurrentLoginMerchantService } from './../../../../common-services/current-login-merchant.service';
let ManageUsersComponent = class ManageUsersComponent {
    constructor(sActivatedRoute, sFormBuilder, sCheck, sResponsiveService, sErrorHandler, sAlertMessageService, sErrorMessagesService, sCurrentLoginMerchantService, sLandingPageMsgService, sModalService, sManageUsersService, sPrivilegeService) {
        this.sActivatedRoute = sActivatedRoute;
        this.sFormBuilder = sFormBuilder;
        this.sCheck = sCheck;
        this.sResponsiveService = sResponsiveService;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sModalService = sModalService;
        this.sManageUsersService = sManageUsersService;
        this.sPrivilegeService = sPrivilegeService;
        this.cIsWritePrivilege = false;
        this.cManageUsers = new ManageUsers();
        this.createFormGroup();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.ManageUsers);
        this.cMenuList = JSON.parse(sessionStorage.getItem('menuList'));
    }
    ngOnInit() {
        this.cFetchUserListForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.fetchUserListSuccess(data.commonResponse);
        });
    }
    createFormGroup() {
        this.cFetchUserListForm = this.sFormBuilder.group({
            searchBy: [''],
            searchByValue: [''],
            searchStatus: [''],
            searchPageNo: [1],
            searchPageSize: [25]
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchPanelClick() {
        this.sResponsiveService.openSearch();
    }
    onCancelPanelClick() {
        this.sResponsiveService.closeSearch();
        this.cManageUsers.searchByLabel = 'Search by';
        this.cFetchUserListForm.reset();
        this.cFetchUserListForm.setValue({
            searchBy: '',
            searchByValue: '',
            searchStatus: '',
            searchPageNo: 1,
            searchPageSize: 25
        });
        this.cFetchUserListForm.controls['searchByValue'].disable();
        this.onSearchClick();
    }
    onSearchByClick() {
        this.cManageUsers.isSearchByClick = !this.cManageUsers.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cManageUsers.isSearchByClick = !this.cManageUsers.isSearchByClick;
        // if(this.sCheck.isNotNullObject(pOption.value)){
        this.cManageUsers.searchByLabel = pOption.label;
        this.cFetchUserListForm.get('searchBy').setValue(pOption.value);
        // }
        // console.log(this.cManageUsers.searchByLabel);
        if (this.cManageUsers.searchByLabel == "User ID"
            || this.cManageUsers.searchByLabel == "Email ID"
            || this.cManageUsers.searchByLabel == "Name") {
            this.cFetchUserListForm.controls['searchByValue'].enable();
            this.cFetchUserListForm.controls['searchByValue'].setValue(null);
            this.cFetchUserListForm.controls['searchByValue'].dirty;
            this.cFetchUserListForm.controls['searchByValue'].markAsDirty({ onlySelf: true });
            this.cFetchUserListForm.controls['searchByValue'].setValidators(Validators.required);
            this.cFetchUserListForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cManageUsers.searchByLabel == "Search by") {
            this.cFetchUserListForm.controls['searchByValue'].setValue(null);
            this.cFetchUserListForm.controls['searchByValue'].disable();
            this.cFetchUserListForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchClick() {
        this.sManageUsersService.fetchUserList(this.cFetchUserListForm.value)
            .subscribe(pResponse => this.fetchUserListSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onViewPrivilegesClick(pUser) {
        this.cUser = pUser;
        this.sManageUsersService.viewPrivileges(pUser)
            .subscribe(pResponse => this.viewPrivilegesSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onBackClick() {
        this.cUser = null;
        this.sResponsiveService.closeDetails();
    }
    onStatusChange(pEvent, pUser, pTemplate) {
        this.cBsModalRef = this.sModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cUser = pUser;
        if (pEvent.target.checked) {
            if (pUser.userStatus == 'INAC') {
                this.cUser.userStatus = 'ACTI';
            }
        }
        else {
            if (pUser.userStatus == 'ACTI') {
                this.cUser.userStatus = 'INAC';
            }
        }
    }
    confirmChangeStatus() {
        console.log(this.cUser);
        this.cBsModalRef.hide();
    }
    declineChangeStatus() {
        if (this.cUser.userStatus == 'INAC') {
            this.cUser.userStatus = 'ACTI';
        }
        else if (this.cUser.userStatus == 'ACTI') {
            this.cUser.userStatus = 'INAC';
        }
        this.cUser = null;
        this.cBsModalRef.hide();
    }
    onPageChange(event) {
        this.cFetchUserListForm.get('searchPageNo').setValue(event.cPageNo);
        this.cFetchUserListForm.get('searchPageSize').setValue(event.cPageSize);
        this.onSearchClick();
    }
    fetchUserListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cUserListProcEntity = mCommonResponse.data['userList'];
                this.cPageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.sResponsiveService.closeSearch();
            }
            else if (mCommonResponse.isFail) {
                this.cUserListProcEntity = null;
                this.cPageTotalCount = null;
                this.sResponsiveService.closeSearch();
                console.log(mCommonResponse.messageDesc);
            }
            else {
                this.cUserListProcEntity = null;
                this.cPageTotalCount = null;
                this.sResponsiveService.closeSearch();
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cUserListProcEntity = null;
            this.cPageTotalCount = null;
            this.sResponsiveService.closeSearch();
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
    viewPrivilegesSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPrivileges = mCommonResponse.data['privilegesList'];
                this.sResponsiveService.openDetails();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
};
ManageUsersComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-manage-users',
        templateUrl: './manage-users.component.html',
        styleUrls: ['./manage-users.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        FormBuilder,
        ConditionalCheckService,
        ResponsiveService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        CurrentLoginMerchantService,
        LandingPageMsgService,
        BsModalService,
        ManageUsersService,
        PrivilegeService])
], ManageUsersComponent);
export { ManageUsersComponent };
//# sourceMappingURL=manage-users.component.js.map