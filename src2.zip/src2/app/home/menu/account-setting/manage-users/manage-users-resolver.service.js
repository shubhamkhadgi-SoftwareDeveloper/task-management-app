import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { ManageUsersService } from './manage-users.service';
let ManageUsersResolverService = class ManageUsersResolverService {
    constructor(sManageUsersService) {
        this.sManageUsersService = sManageUsersService;
    }
    resolve(route, state) {
        return this.sManageUsersService.fetchUserList({ 'searchPageNo': 1, 'searchPageSize': 25 }).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
ManageUsersResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ManageUsersService])
], ManageUsersResolverService);
export { ManageUsersResolverService };
//# sourceMappingURL=manage-users-resolver.service.js.map