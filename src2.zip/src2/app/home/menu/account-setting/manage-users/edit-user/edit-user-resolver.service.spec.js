import { TestBed, inject } from '@angular/core/testing';
import { EditUserResolverService } from './edit-user-resolver.service';
describe('EditUserResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [EditUserResolverService]
        });
    });
    it('should be created', inject([EditUserResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=edit-user-resolver.service.spec.js.map