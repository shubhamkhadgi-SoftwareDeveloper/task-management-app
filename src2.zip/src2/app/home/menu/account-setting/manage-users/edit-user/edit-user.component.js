import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '.././../../../../common-services/error-handler.service';
import { LandingPageMsgService } from '.././../../../../common-services/landing-page-msg.service';
import { PrivilegeService } from '../../../../../common-services/privilege.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { ManageUsersService } from '../manage-users.service';
import * as sha256 from 'crypto-js/sha256';
let EditUserComponent = class EditUserComponent {
    constructor(sFormBuilder, sActivatedRoute, sCheck, sErrorHandler, sAlertMessageService, sErrorMessagesService, sLandingPageMsgService, pMerchInfoService, sPrivilegeService, sManageUsersService, sLocation) {
        this.sFormBuilder = sFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.pMerchInfoService = pMerchInfoService;
        this.sPrivilegeService = sPrivilegeService;
        this.sManageUsersService = sManageUsersService;
        this.sLocation = sLocation;
        this.cIpValidator = [CustomValidator.ipAddress];
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            if (this.sCheck.isNotNullObject(data.commonResponse)) {
                let mCommonResponse = new CommonResponse(data.commonResponse);
                if (mCommonResponse.isSuccess) {
                    this.cPrivileges = mCommonResponse.data['privilegesList'];
                    //this.cOrignalPrivileges = Object.assign({}, mCommonResponse.data['privilegesList']);
                    this.cOrignalPrivileges = this.deepcopy(this.cPrivileges);
                    let userId = mCommonResponse.data['userId'];
                    let userEmail = mCommonResponse.data['userEmail'];
                    let userName = mCommonResponse.data['userName'];
                    let subAccId = mCommonResponse.data['subAccId'];
                    let userLoginIpStatus = mCommonResponse.data['userLoginIpStatus'];
                    let userLoginIp = mCommonResponse.data['userLoginIp'];
                    let userStatus = mCommonResponse.data['userStatus'];
                    this.cEditUserPrimary = mCommonResponse.data['userPrimary'];
                    this.createEditUserForm(userId, userEmail, userName, subAccId, userLoginIpStatus, userLoginIp, userStatus);
                    // Validation apply only if Login ip is true
                    this.cEditUserForm.get('userLoginIpStatus').valueChanges.subscribe((userLoginIpStatus) => {
                        if (userLoginIpStatus) {
                            this.cEditUserForm.get('userLoginIp').setValidators([Validators.required]);
                        }
                        else {
                            this.cEditUserForm.get('userLoginIp').setValidators([]);
                        }
                        this.cEditUserForm.get('userLoginIp').updateValueAndValidity();
                    });
                    // Validation apply only if reset password is true
                    this.cEditUserForm.get('resetPasswordStatus').valueChanges.subscribe((resetPasswordStatus) => {
                        if (resetPasswordStatus) {
                            if ((this.cEditUserPrimary == this.sPrivilegeService.isUserPrimary) || !this.sPrivilegeService.isUserPrimary) {
                                this.cEditUserForm.get('currentPassword').setValidators([Validators.required]);
                            }
                            this.cEditUserForm.get('userPassword').setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(22), CustomValidator.password, CustomValidator.passwordMin, CustomValidator.isConsecuSpecialCharPassword]);
                            this.cEditUserForm.get('confirmUserPassword').setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(22), CustomValidator.password, CustomValidator.passwordMin, CustomValidator.isConsecuSpecialCharPassword]);
                        }
                        else {
                            this.cEditUserForm.get('currentPassword').setValidators([]);
                            this.cEditUserForm.get('userPassword').setValidators([]);
                            this.cEditUserForm.get('confirmUserPassword').setValidators([]);
                        }
                        this.cEditUserForm.get('currentPassword').updateValueAndValidity();
                        this.cEditUserForm.get('userPassword').updateValueAndValidity();
                        this.cEditUserForm.get('confirmUserPassword').updateValueAndValidity();
                    });
                }
                else if (mCommonResponse.isFail) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                    this.sLocation.back();
                }
                else {
                    this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                    this.sLocation.back();
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                this.sLocation.back();
            }
        });
    }
    onCancelCLick() {
        this.sLocation.back();
    }
    createEditUserForm(pUserId, pUserEmail, pUserName, pSubAccId, pUserLoginIpStatus, pUserLoginIp, pUserStatus) {
        this.cEditUserForm = this.sFormBuilder.group({
            userId: [{ value: pUserId, disabled: true }, [Validators.required, Validators.minLength(5), Validators.maxLength(50), CustomValidator.loginId, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar]],
            userEmail: [{ value: pUserEmail, disabled: true }, [Validators.required, Validators.maxLength(70), CustomValidator.email, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar]],
            userName: [{ value: pUserName, disabled: true }, [Validators.required, Validators.maxLength(60), CustomValidator.fullName, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar]],
            subAccId: [pSubAccId],
            resetPasswordStatus: [false],
            currentPassword: [],
            userPassword: [],
            confirmUserPassword: [],
            userLoginIpStatus: [pUserLoginIpStatus, [Validators.required]],
            userLoginIp: [pUserLoginIp],
            menuPrivilege: [],
            userStatus: [pUserStatus, [Validators.required]],
        }, {
            validator: this.matchPassword
        });
    }
    /***********************Password Confirmation *******************/
    matchPassword(AC) {
        if (AC.get('userPassword') == undefined || AC.get('userPassword') == null || AC.get('userPassword').value === '') {
            return null;
        }
        let password = AC.get('userPassword').value; // to get value in input tag
        let confirmPassword = AC.get('confirmUserPassword').value; // to get value in input tag
        if (password != confirmPassword) {
            AC.get('confirmUserPassword').setErrors({ 'matchPassword': true });
        }
        else {
            return null;
        }
        if (AC.get('userPassword') == undefined || AC.get('userPassword') == null || AC.get('userPassword').value === '') {
            return null;
        }
        let userId = AC.get('userId').value;
        let userEmail = AC.get('userEmail').value;
        let userName = AC.get('userName').value;
        if ((userId != null && userId.toLowerCase() == password.toLocaleLowerCase()) || (userEmail != null && userEmail.toLowerCase() == password.toLocaleLowerCase()) || (userName != null && userName.toLowerCase() == password.toLocaleLowerCase())) {
            AC.get('userPassword').setErrors({ 'passwordMatchUserInfo': true });
        }
        else {
            return null;
        }
    }
    onSaveUserCLick() {
        if (this.cEditUserForm.valid) {
            let mMenuPrivilege = [];
            for (let mParentMenu in this.cPrivileges) {
                for (let mChild in this.cPrivileges[mParentMenu]) {
                    let mOrignalChildMenu = this.cOrignalPrivileges[mParentMenu][mChild];
                    ;
                    let mChildMenu = this.cPrivileges[mParentMenu][mChild];
                    if (mOrignalChildMenu.privilegeRight != mChildMenu.privilegeRight) {
                        if (!this.sPrivilegeService.isFullPrivilegeMenu(mChildMenu.menuName)) {
                            if (mChildMenu.privilegeRight == this.sPrivilegeService.NR || mChildMenu.privilegeRight == this.sPrivilegeService.READ) {
                                mMenuPrivilege.push(mChildMenu);
                            }
                            else if (mChildMenu.privilegeRight == this.sPrivilegeService.WRITE) {
                                if (!this.sPrivilegeService.isOnlyReadPrivilegeMenu(mChildMenu.menuName)) {
                                    mMenuPrivilege.push(mChildMenu);
                                }
                            }
                        }
                    }
                }
            }
            this.cEditUserForm.patchValue({ menuPrivilege: mMenuPrivilege });
            if (this.sCheck.isNotNullString(this.cEditUserForm.get('currentPassword').value)) {
                let mSha2Pwd = sha256(this.cEditUserForm.get('currentPassword').value);
                this.cEditUserForm.patchValue({ currentPassword: mSha2Pwd.toString() });
            }
            this.sManageUsersService.updateUser(this.cEditUserForm.getRawValue())
                .subscribe(pResponse => this.updateUserSuccess(pResponse), pError => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
        }
        else {
            CustomValidator.validateAllFields(this.cEditUserForm);
        }
    }
    updateUserSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.sLocation.back();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.cEditUserForm);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    deepcopy(o) {
        return JSON.parse(JSON.stringify(o));
    }
};
EditUserComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-edit-user',
        templateUrl: './edit-user.component.html',
        styleUrls: ['./edit-user.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        ActivatedRoute,
        ConditionalCheckService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        LandingPageMsgService,
        MerchInfoService,
        PrivilegeService,
        ManageUsersService,
        Location])
], EditUserComponent);
export { EditUserComponent };
//# sourceMappingURL=edit-user.component.js.map