import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { ManageUsersService } from '../manage-users.service';
let EditUserResolverService = class EditUserResolverService {
    constructor(sManageUsersService) {
        this.sManageUsersService = sManageUsersService;
    }
    resolve(route, state) {
        return this.sManageUsersService.fetchUpdateInfo({ 'userId': route.paramMap.get('userId') }).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                //this.sRouter.navigate(['']);
                return null;
            }
        });
    }
};
EditUserResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ManageUsersService])
], EditUserResolverService);
export { EditUserResolverService };
//# sourceMappingURL=edit-user-resolver.service.js.map