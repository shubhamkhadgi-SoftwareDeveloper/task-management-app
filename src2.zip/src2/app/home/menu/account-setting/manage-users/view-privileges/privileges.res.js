export class Privileges {
}
//# sourceMappingURL=privileges.res.js.map