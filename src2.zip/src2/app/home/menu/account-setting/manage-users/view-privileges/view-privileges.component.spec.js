import { async, TestBed } from '@angular/core/testing';
import { ViewPrivilegesComponent } from './view-privileges.component';
describe('ViewPrivilegesComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ViewPrivilegesComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(ViewPrivilegesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=view-privileges.component.spec.js.map