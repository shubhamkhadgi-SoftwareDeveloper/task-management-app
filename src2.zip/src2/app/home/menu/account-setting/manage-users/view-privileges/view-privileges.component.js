import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { UserListProcEntity } from '../../../../../proc-entities/user-list-proc-entity';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { PrivilegeService } from '../../../../../common-services/privilege.service';
let ViewPrivilegesComponent = class ViewPrivilegesComponent {
    constructor(sPrivilegeService, sCheck) {
        this.sPrivilegeService = sPrivilegeService;
        this.sCheck = sCheck;
    }
    ngOnInit() {
    }
};
tslib_1.__decorate([
    Input('privileges'),
    tslib_1.__metadata("design:type", Map)
], ViewPrivilegesComponent.prototype, "cPrivileges", void 0);
tslib_1.__decorate([
    Input('user'),
    tslib_1.__metadata("design:type", UserListProcEntity)
], ViewPrivilegesComponent.prototype, "cUser", void 0);
ViewPrivilegesComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-view-privileges',
        templateUrl: './view-privileges.component.html',
        styleUrls: ['./view-privileges.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [PrivilegeService,
        ConditionalCheckService])
], ViewPrivilegesComponent);
export { ViewPrivilegesComponent };
//# sourceMappingURL=view-privileges.component.js.map