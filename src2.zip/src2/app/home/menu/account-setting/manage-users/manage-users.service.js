import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let ManageUsersService = class ManageUsersService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseManageUsersUrl = 'manageUsers/';
        this.cFetchUserListUrl = this.cBaseManageUsersUrl + 'fetchUserList';
        this.cViewPrivilegesUrl = this.cBaseManageUsersUrl + 'viewPrivileges';
        this.cFetchMenuUrl = this.cBaseManageUsersUrl + 'fetchMenu';
        this.cAddUserUrl = this.cBaseManageUsersUrl + 'addUser';
        this.cUpdateUserUrl = this.cBaseManageUsersUrl + 'updateUser';
        this.cCheckeUserIdAvailabilityUrl = this.cBaseManageUsersUrl + 'checkeUserIdAvailability';
        this.cFetchUpdateInfoUrl = this.cBaseManageUsersUrl + 'fetchUpdateInfo';
    }
    fetchUserList(pFetchUserListReq) {
        return this.pApiRequestService.httpPostRequest(pFetchUserListReq, this.cFetchUserListUrl);
    }
    viewPrivileges(pViewPrivilegesReq) {
        return this.pApiRequestService.httpPostRequest(pViewPrivilegesReq, this.cViewPrivilegesUrl);
    }
    fetchMenu() {
        return this.pApiRequestService.httpPostRequest(null, this.cFetchMenuUrl);
    }
    checkeUserIdAvailability(pCheckeUserIdAvailabilityReq) {
        return this.pApiRequestService.asyncHttpPostRequest(pCheckeUserIdAvailabilityReq, this.cCheckeUserIdAvailabilityUrl);
    }
    addUser(pAddUserReq) {
        return this.pApiRequestService.httpPostRequest(pAddUserReq, this.cAddUserUrl);
    }
    fetchUpdateInfo(pFetchUpdateInfoReq) {
        return this.pApiRequestService.httpPostRequest(pFetchUpdateInfoReq, this.cFetchUpdateInfoUrl);
    }
    updateUser(pUpdateUserReq) {
        return this.pApiRequestService.httpPostRequest(pUpdateUserReq, this.cUpdateUserUrl);
    }
};
ManageUsersService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], ManageUsersService);
export { ManageUsersService };
//# sourceMappingURL=manage-users.service.js.map