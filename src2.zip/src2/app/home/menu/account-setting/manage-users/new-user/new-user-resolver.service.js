import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { ManageUsersService } from '../manage-users.service';
let NewUserResolverService = class NewUserResolverService {
    constructor(sManageUsersService) {
        this.sManageUsersService = sManageUsersService;
    }
    resolve(route, state) {
        return this.sManageUsersService.fetchMenu().take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                //this.sRouter.navigate(['']);
                return null;
            }
        });
    }
};
NewUserResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ManageUsersService])
], NewUserResolverService);
export { NewUserResolverService };
//# sourceMappingURL=new-user-resolver.service.js.map