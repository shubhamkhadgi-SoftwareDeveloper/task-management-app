import { TestBed, inject } from '@angular/core/testing';
import { NewUserResolverService } from './new-user-resolver.service';
describe('NewUserResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [NewUserResolverService]
        });
    });
    it('should be created', inject([NewUserResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=new-user-resolver.service.spec.js.map