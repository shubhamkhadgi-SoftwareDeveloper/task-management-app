import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { CommonResponse, CustomResponseCode } from '../../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '.././../../../../common-services/error-handler.service';
import { LandingPageMsgService } from '.././../../../../common-services/landing-page-msg.service';
import { ManageUsersService } from '../manage-users.service';
import { PrivilegeService } from '../../../../../common-services/privilege.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
let NewUserComponent = class NewUserComponent {
    constructor(sFormBuilder, sActivatedRoute, sCheck, sErrorHandler, sAlertMessageService, sErrorMessagesService, sLandingPageMsgService, sManageUsersService, pMerchInfoService, sPrivilegeService, sRef, sRouter, sLocation) {
        this.sFormBuilder = sFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sManageUsersService = sManageUsersService;
        this.pMerchInfoService = pMerchInfoService;
        this.sPrivilegeService = sPrivilegeService;
        this.sRef = sRef;
        this.sRouter = sRouter;
        this.sLocation = sLocation;
        this.cIpValidator = [CustomValidator.ipAddress];
    }
    ngOnInit() {
        this.createAddUserForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.menuListSuccess(data.commonResponse);
        });
        // Validation apply only if Login ip is true
        this.cAddUserForm.get('userLoginIpStatus').valueChanges.subscribe((userLoginIpStatus) => {
            if (userLoginIpStatus) {
                this.cAddUserForm.get('userLoginIp').setValidators([Validators.required]);
            }
            else {
                this.cAddUserForm.get('userLoginIp').setValidators([]);
            }
            this.cAddUserForm.get('userLoginIp').updateValueAndValidity();
        });
    }
    ngAfterViewChecked() {
        this.sRef.detectChanges();
    }
    createAddUserForm() {
        this.cAddUserForm = this.sFormBuilder.group({
            userId: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50), CustomValidator.loginId, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar], this.checkeUserIdAvailability.bind(this)],
            userEmail: ['', [Validators.required, Validators.maxLength(70), CustomValidator.email, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar]],
            userName: ['', [Validators.required, Validators.maxLength(60), CustomValidator.fullName, CustomValidator.isBeginSpecialChar, CustomValidator.isConsecuSpecialChar, CustomValidator.isEndSpecialChar]],
            subAccId: [],
            userPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(22), CustomValidator.password, CustomValidator.passwordMin, CustomValidator.isConsecuSpecialCharPassword]],
            confirmUserPassword: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(22), CustomValidator.password, CustomValidator.passwordMin, CustomValidator.isConsecuSpecialCharPassword]],
            userLoginIpStatus: [false, [Validators.required]],
            userLoginIp: [],
            menuPrivilege: [],
            userStatus: [true, [Validators.required]],
        }, {
            validator: this.matchPassword
        });
    }
    /***********************Asynchronous validator for user name checking *******************/
    checkeUserIdAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.sManageUsersService.checkeUserIdAvailability({ 'userId': control.value })
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkeUserIdAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkeUserIdAvailability': true };
                }
            }
            else {
                return { 'checkeUserIdAvailability': true };
            }
        });
    }
    /***********************Password Confirmation *******************/
    matchPassword(AC) {
        if (AC.get('userPassword') == undefined || AC.get('userPassword') == null || AC.get('userPassword').value === '') {
            return null;
        }
        let password = AC.get('userPassword').value; // to get value in input tag
        let confirmPassword = AC.get('confirmUserPassword').value; // to get value in input tag
        let userId = AC.get('userId').value;
        let userEmail = AC.get('userEmail').value;
        let userName = AC.get('userName').value;
        if (password != confirmPassword) {
            AC.get('confirmUserPassword').setErrors({ 'matchPassword': true });
        }
        else if ((userId.toLowerCase() == password.toLocaleLowerCase()) || (userEmail.toLowerCase() == password.toLocaleLowerCase()) || (userName.toLowerCase() == password.toLocaleLowerCase())) {
            AC.get('userPassword').setErrors({ 'passwordMatchUserInfo': true });
        }
        else {
            return null;
        }
    }
    onAddUserCLick() {
        if (this.cAddUserForm.valid) {
            let mMenuPrivilege = [];
            for (let mParentMenu in this.cMenuList) {
                for (let mChild of this.cMenuList[mParentMenu]) {
                    let mChildMenu = mChild;
                    if (!this.sPrivilegeService.isFullPrivilegeMenu(mChildMenu.menuName)) {
                        //mMenuPrivilege.push(mChildMenu);
                        if (mChildMenu.privilegeRight == this.sPrivilegeService.NR || mChildMenu.privilegeRight == this.sPrivilegeService.READ) {
                            mMenuPrivilege.push(mChildMenu);
                        }
                        else if (mChildMenu.privilegeRight == this.sPrivilegeService.WRITE) {
                            if (this.sPrivilegeService.isOnlyReadPrivilegeMenu(mChildMenu.menuName)) {
                                mChildMenu.privilegeRight = this.sPrivilegeService.NR;
                            }
                            mMenuPrivilege.push(mChildMenu);
                        }
                        else {
                            mChildMenu.privilegeRight = this.sPrivilegeService.NR;
                            mMenuPrivilege.push(mChildMenu);
                        }
                    }
                }
            }
            this.cAddUserForm.patchValue({ menuPrivilege: mMenuPrivilege });
            this.sManageUsersService.addUser(this.cAddUserForm.value)
                .subscribe(pResponse => this.addUserSuccess(pResponse), pError => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        else {
            CustomValidator.validateAllFields(this.cAddUserForm);
        }
    }
    onCancelCLick() {
        this.sLocation.back();
    }
    menuListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                let mMenuList = mCommonResponse.data['menuList'];
                for (let mParentMenu in mMenuList) {
                    for (let mChild of mMenuList[mParentMenu]) {
                        let mChildMenu = mChild;
                        mChildMenu.privilegeRight = this.sPrivilegeService.NR;
                    }
                }
                this.cMenuList = mMenuList;
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    addUserSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.sLocation.back();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.cAddUserForm);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
};
NewUserComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-new-user',
        templateUrl: './new-user.component.html',
        styleUrls: ['./new-user.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        ActivatedRoute,
        ConditionalCheckService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        LandingPageMsgService,
        ManageUsersService,
        MerchInfoService,
        PrivilegeService,
        ChangeDetectorRef,
        Router,
        Location])
], NewUserComponent);
export { NewUserComponent };
//# sourceMappingURL=new-user.component.js.map