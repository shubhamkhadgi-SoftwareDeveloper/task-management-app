export class ManageUsers {
    constructor() {
        this.recordsFrom = 1;
        this.recordsTo = 25;
        this.searchByLabel = 'Search by';
        this.searchBy = [];
        this.searchBy.push({ label: 'User ID', value: 'userId' });
        this.searchBy.push({ label: 'Email ID', value: 'userEmail' });
        this.searchBy.push({ label: 'Name', value: 'userName' });
        this.isSearchByClick = false;
        this.status = [];
        // this.status.push({label: 'Select' , value: '' });
        this.status.push({ label: 'Active', value: 'ACTI' });
        this.status.push({ label: 'Inactive', value: 'INAC' });
    }
}
//# sourceMappingURL=manage-users.class.js.map