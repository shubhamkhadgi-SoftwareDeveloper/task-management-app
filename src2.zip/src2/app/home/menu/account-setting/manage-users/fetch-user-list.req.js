export class FetchUserListReq {
}
//# sourceMappingURL=fetch-user-list.req.js.map