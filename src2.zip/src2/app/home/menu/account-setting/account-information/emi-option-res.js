export class EMIOptionRes {
}
//# sourceMappingURL=emi-option-res.js.map