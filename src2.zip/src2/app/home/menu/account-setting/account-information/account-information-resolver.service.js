import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { AccountInformationService } from './account-information.service';
import { AccountInfoReq } from './account-info-req';
let AccountInformationResolverService = class AccountInformationResolverService {
    constructor(pAccountInformationService, pMerchInfoService) {
        this.pAccountInformationService = pAccountInformationService;
        this.pMerchInfoService = pMerchInfoService;
    }
    resolve(route, state) {
        let mAccountInfoReq = new AccountInfoReq();
        return this.pAccountInformationService.fetchAccountInfo(mAccountInfoReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
AccountInformationResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [AccountInformationService,
        MerchInfoService])
], AccountInformationResolverService);
export { AccountInformationResolverService };
//# sourceMappingURL=account-information-resolver.service.js.map