import * as tslib_1 from "tslib";
import { CurrentLoginMerchantService } from './../../../../common-services/current-login-merchant.service';
import { Component, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { InvoiceSettingsValidator } from '../../invoice/invoice-settings/invoice-settings-validator';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../common-response/common-response.res';
import { AccountInformationService } from './account-information.service';
import { AccountInfoReq } from './account-info-req';
import { UpdAccountInfoReq } from './upd-account-info-req';
import { SettlementBankDetailResultEntity } from '../../../../entities/settlement-bank-detail-result-entity';
import { AccountInformation } from './account-information.class';
import { SettlementBankRes } from './set-bank-res';
import { DOCUMENT } from "@angular/common";
let AccountInformationComponent = class AccountInformationComponent {
    //***********************************************Constructor*******************************************//
    constructor(pLocation, sActivatedRoute, pApiRequestService, pMerchInfoService, sCheck, pAccountInformationService, sAlertMessageService, sErrorMessagesService, sErrorHandler, pFormBuilder, sResponsiveService, sPrivilegeService, sLandingPageMsgService, sCurrentLoginMerchantService, sDocument) {
        this.pLocation = pLocation;
        this.sActivatedRoute = sActivatedRoute;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.sCheck = sCheck;
        this.pAccountInformationService = pAccountInformationService;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sErrorHandler = sErrorHandler;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sPrivilegeService = sPrivilegeService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.sDocument = sDocument;
        this.cCurrencyDropDownList = [];
        this.cIsWritePrivilege = false;
        this.cAccInfoName = '';
        this.cActiveTabName = 'tabBankDetails';
        this.cCommonResponse = new CommonResponse();
        this.cAccountInfoReq = new AccountInfoReq();
        this.cUpdAccountInfoReq = new UpdAccountInfoReq();
        this.cEmiPlansWrapperResList = [];
        this.cPaymentOptionWrapperResList = [];
        this.cAccountInformation = new AccountInformation();
        this.cSettlementBankRes = new SettlementBankRes();
        this.cSettlementBankDetailResultEntity = new SettlementBankDetailResultEntity();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.AccountInformation);
        this.cMenuList = JSON.parse(sessionStorage.getItem('menuList'));
        this.createForm();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (mCommonResponse.data != null) {
                    this.cRegistrationEntity = mCommonResponse.data.regData;
                    this.cUpdAccountInfoReq.bizPanCard = this.cRegistrationEntity.registeredBizPanCard;
                    this.cUpdAccountInfoReq.regMobile = this.cRegistrationEntity.registeredMobile;
                    let mPhoneNum = this.cRegistrationEntity.registeredPhone;
                    if (this.sCheck.isNotNullObject(mPhoneNum)) {
                        var arr = new Array();
                        arr = mPhoneNum.split("-");
                        this.cUpdAccountInfoReq.regPhonePinNum = arr[0];
                        this.cUpdAccountInfoReq.regPhoneNum = arr[1];
                    }
                    this.cUpdAccountInfoReq.regEmail = this.cRegistrationEntity.registeredEmail;
                    if (this.cRegistrationEntity.regGstNo != 'N')
                        this.cUpdAccountInfoReq.regGSTNum = this.cRegistrationEntity.regGstNo;
                    else
                        this.cUpdAccountInfoReq.regGSTNum = this.cRegistrationEntity.regGstNo;
                    //resultSet for Active currency
                    this.cActivationCurrencySelResultEntity = mCommonResponse.data.ActiveCurrencyList;
                    if (this.sCheck.isNotNullList(this.cActivationCurrencySelResultEntity)) {
                        for (let pCurrency of this.cActivationCurrencySelResultEntity) {
                            this.cCurrencyDropDownList.push({ label: pCurrency.currName, value: pCurrency.currId });
                        }
                    }
                }
                else {
                    console.log(this.sErrorMessagesService.responseNull);
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
            }
        });
        if (!this.cIsWritePrivilege) {
            this.disableFields();
        }
    }
    //*********************************************** Validation ********************************************//
    disableFields() {
        this.mContactInfoForm.controls['regEmail'].disable();
        this.mContactInfoForm.controls['regPhonePinNum'].disable();
        this.mContactInfoForm.controls['regPhoneNum'].disable();
        this.mContactInfoForm.controls['regMobile'].disable();
        this.mBussinessInfoForm.controls['bizPanCard'].disable();
        this.mBussinessInfoForm.controls['regGSTNum'].disable();
    }
    createForm() {
        this.mContactInfoForm = this.pFormBuilder.group({
            regEmail: ['', [
                    Validators.required,
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.email,
                ]],
            regPhonePinNum: ['', [
                    Validators.required,
                    InvoiceSettingsValidator.integerNumberOnly,
                ]],
            regPhoneNum: ['', [
                    Validators.required,
                    InvoiceSettingsValidator.integerNumberOnly,
                    Validators.minLength(3),
                    Validators.maxLength(10),
                ]],
            regMobile: ['', [
                    InvoiceSettingsValidator.mobile,
                ]],
        });
        //bussiness Info Form
        this.mBussinessInfoForm = this.pFormBuilder.group({
            bizPanCard: ['', [
                    InvoiceSettingsValidator.customPANCard,
                ]],
            regGSTNum: ['', [
                    Validators.maxLength(15),
                    InvoiceSettingsValidator.customGSTNum,
                ]],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    getContactInfoFormValidationErrors() {
        Object.keys(this.mContactInfoForm.controls).forEach(key => {
            const controlErrors = this.mContactInfoForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    //console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    getBussinessInfoFormValidationErrors() {
        Object.keys(this.mBussinessInfoForm.controls).forEach(key => {
            const controlErrors = this.mBussinessInfoForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    //console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    //***********************************************Submit form ********************************************//
    updContactInfoForm() {
        if (this.mContactInfoForm.valid) {
            this.cUpdAccountInfoReq.divName = 'contactInfo';
            this.pAccountInformationService.updAccountInfo(this.cUpdAccountInfoReq)
                .subscribe(pResponse => this.updAccountInfoSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mContactInfoForm);
            this.getContactInfoFormValidationErrors();
        }
    }
    updBussinessInfoForm() {
        if (this.mBussinessInfoForm.valid) {
            this.cUpdAccountInfoReq.divName = 'bussinessInfo';
            this.pAccountInformationService.updAccountInfo(this.cUpdAccountInfoReq)
                .subscribe(pResponse => this.updAccountInfoSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mBussinessInfoForm);
            this.getBussinessInfoFormValidationErrors();
        }
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.sResponsiveService.closeDetails();
    }
    onCurrencyChange(pEvent) {
        this.cAccountInfoReq.currId = pEvent.currId;
    }
    fetchAccountCurrwiseDetail(pCurrId, pModuleName) {
        if (pModuleName == 'initialdetails') {
            this.cAccountInfoReq.currId = pCurrId;
            this.pAccountInformationService.fetchAccountCurrwiseDetail(this.cAccountInfoReq)
                .subscribe(pResponse => this.fetchAccountCurrwiseDetailSuccess(pResponse), error => { console.log('error'); });
        }
    }
    updateDetails(pEvent, pModuleName) {
        if (pModuleName == 'onUpdateDetails') {
            this.cAccountInfoReq.currId = pEvent.value;
            this.pAccountInformationService.fetchAccountCurrwiseDetail(this.cAccountInfoReq)
                .subscribe(pResponse => this.fetchAccountCurrwiseDetailSuccess(pResponse), error => { console.log('error'); });
        }
    }
    onTabHeadingClick(pAccInfoName) {
        this.cAccInfoName = pAccInfoName;
        if (this.sResponsiveService.isMaxWidth767Device()) {
            if (document.getElementsByClassName('tab-link')[0].classList.contains('slideright')) {
                document.getElementsByClassName('tab-link')[0].classList.remove('slideright');
                document.getElementsByClassName('tab-link')[0].classList.add('slideleft');
                document.getElementsByClassName('footer')[0].classList.add('setting-footer-h');
            }
            else {
                document.getElementsByClassName('tab-link')[0].classList.add('slideleft');
                document.getElementsByClassName('footer')[0].classList.add('setting-footer-h');
            }
        }
    }
    onTabClick(pActiveTabName) {
        this.cActiveTabName = pActiveTabName;
    }
    //***********************************************Server Call Event**********************************************//
    updAccountInfoSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.pAccountInformationService.fetchAccountInfo(this.cAccountInfoReq)
                    .subscribe(pResponse => this.fetchAccountInfoSuccess(pResponse), error => { console.log('error'); });
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                //this.sErrorHandler.setServerError( mCommonResponse.fieldErrors, this.mForm );
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    fetchAccountCurrwiseDetailSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (mCommonResponse.isSuccess) {
            //first result set
            if (this.sCheck.isNotNullObject(mCommonResponse.data.settlementBankDetailsList)) {
                this.cSettlementBankDetailResultEntity = mCommonResponse.data.settlementBankDetailsList;
            }
            //second result set
            if (this.sCheck.isNotNullObject(mCommonResponse.data.EMIPlansWrapperList)) {
                this.cEmiPlansWrapperResList = mCommonResponse.data.EMIPlansWrapperList;
            }
            //third result set
            if (this.sCheck.isNotNullObject(mCommonResponse.data.PaymentOptionWrapperList)) {
                this.cPaymentOptionWrapperResList = mCommonResponse.data.PaymentOptionWrapperList;
            }
            this.cAccountInformation.noRecordFound = "Sorry! No Records Found";
            // this.sResponsiveService.openDetails();
            window.scrollTo(0, 0);
        }
        else if (mCommonResponse.isFail) {
            console.log(mCommonResponse.messageDesc);
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
    getEmiOption(EMIOPtion, index) {
        let arr = EMIOPtion.toString().split('|');
        return arr[index];
    }
    getPayOption(payOPtion, index) {
        let arr = payOPtion.toString().split('|');
        return arr[index];
    }
    fetchAccountInfoSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (mCommonResponse.isSuccess) {
            if (mCommonResponse.data != null) {
                this.cRegistrationEntity = mCommonResponse.data.regData;
                this.cUpdAccountInfoReq.bizPanCard = this.cRegistrationEntity.registeredBizPanCard;
                this.cUpdAccountInfoReq.regMobile = this.cRegistrationEntity.registeredMobile;
                let mPhoneNum = this.cRegistrationEntity.registeredPhone;
                if (this.sCheck.isNotNullObject(mPhoneNum)) {
                    var arr = new Array();
                    arr = mPhoneNum.split("-");
                    this.cUpdAccountInfoReq.regPhonePinNum = arr[0];
                    this.cUpdAccountInfoReq.regPhoneNum = arr[1];
                }
                this.cUpdAccountInfoReq.regEmail = this.cRegistrationEntity.registeredEmail;
                if (this.cRegistrationEntity.regGstNo != 'N')
                    this.cUpdAccountInfoReq.regGSTNum = this.cRegistrationEntity.regGstNo;
                else
                    this.cUpdAccountInfoReq.regGSTNum = this.cRegistrationEntity.regGstNo;
                //resultSet for Active currency
                this.cActivationCurrencySelResultEntity = mCommonResponse.data.ActiveCurrencyList;
                if (this.sCheck.isNotNullList(this.cActivationCurrencySelResultEntity)) {
                    for (let pCurrency of this.cActivationCurrencySelResultEntity) {
                        this.cCurrencyDropDownList.push({ label: pCurrency.currName, value: pCurrency.currId });
                    }
                }
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
            }
        }
        else if (mCommonResponse.isFail) {
            console.log(mCommonResponse.messageDesc);
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
        }
    }
};
AccountInformationComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-account-information',
        templateUrl: './account-information.component.html',
        styleUrls: ['./account-information.component.css'],
    }),
    tslib_1.__param(14, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [Location,
        ActivatedRoute,
        ApiRequestService,
        MerchInfoService,
        ConditionalCheckService,
        AccountInformationService,
        AlertMessageService,
        ErrorMessagesService,
        ErrorHandlerService,
        FormBuilder,
        ResponsiveService,
        PrivilegeService,
        LandingPageMsgService,
        CurrentLoginMerchantService,
        Document])
], AccountInformationComponent);
export { AccountInformationComponent };
//# sourceMappingURL=account-information.component.js.map