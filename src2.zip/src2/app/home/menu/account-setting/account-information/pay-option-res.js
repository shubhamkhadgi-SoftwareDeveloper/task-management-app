export class PayOptionRes {
}
//# sourceMappingURL=pay-option-res.js.map