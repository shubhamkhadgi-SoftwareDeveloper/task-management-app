export class EmiPlansWrapperRes {
}
//# sourceMappingURL=emi-plans-wrapper-res.js.map