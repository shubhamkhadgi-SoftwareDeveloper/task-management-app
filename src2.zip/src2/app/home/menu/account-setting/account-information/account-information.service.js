import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let AccountInformationService = class AccountInformationService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseAccountInfoUrl = 'accountInformation/';
        this.cUpdAccountInfoURL = this.cBaseAccountInfoUrl + 'updAccountInfo';
        this.cFetchAccountInfoURL = this.cBaseAccountInfoUrl + 'fetchAccountInfo';
        this.cfetchAccountCurrwiseDetailURL = this.cBaseAccountInfoUrl + 'fetchAccountCurrwiseDetail';
        this.cfetchAccountEMIOptionsURL = this.cBaseAccountInfoUrl + 'fetchAccountEMIOptions';
        this.cfetchAccountPayOptionsURL = this.cBaseAccountInfoUrl + 'fetchAccountPayOptions';
    }
    fetchAccountInfo(pAccountInfoReq) {
        return this.pApiRequestService.httpPostRequest(pAccountInfoReq, this.cFetchAccountInfoURL);
    }
    updAccountInfo(pUpdAccountInfoReq) {
        return this.pApiRequestService.httpPostRequest(pUpdAccountInfoReq, this.cUpdAccountInfoURL);
    }
    fetchAccountCurrwiseDetail(pAccountInfoReq) {
        return this.pApiRequestService.httpPostRequest(pAccountInfoReq, this.cfetchAccountCurrwiseDetailURL);
    }
    fetchAccountEMIOptions(pAccountInfoReq) {
        return this.pApiRequestService.httpPostRequest(pAccountInfoReq, this.cfetchAccountEMIOptionsURL);
    }
    fetchAccountPayOptions(pAccountInfoReq) {
        return this.pApiRequestService.httpPostRequest(pAccountInfoReq, this.cfetchAccountPayOptionsURL);
    }
};
AccountInformationService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], AccountInformationService);
export { AccountInformationService };
//# sourceMappingURL=account-information.service.js.map