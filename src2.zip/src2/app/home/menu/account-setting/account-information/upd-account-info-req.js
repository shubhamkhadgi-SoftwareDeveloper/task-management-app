export class UpdAccountInfoReq {
}
//# sourceMappingURL=upd-account-info-req.js.map