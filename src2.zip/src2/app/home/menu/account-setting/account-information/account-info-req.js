export class AccountInfoReq {
}
//# sourceMappingURL=account-info-req.js.map