export class PaymentOptionWrapperRes {
}
//# sourceMappingURL=payment-option-wrapper-res.js.map