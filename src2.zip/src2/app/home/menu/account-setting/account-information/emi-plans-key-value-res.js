export class EMIPlansKeyValRes {
}
//# sourceMappingURL=emi-plans-key-value-res.js.map