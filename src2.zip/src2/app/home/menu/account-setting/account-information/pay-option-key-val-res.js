export class PayOptionKeyValRes {
}
//# sourceMappingURL=pay-option-key-val-res.js.map