import { TestBed, inject } from '@angular/core/testing';
import { AccountInformationResolverService } from './account-information-resolver.service';
describe('AccountInformationResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AccountInformationResolverService]
        });
    });
    it('should be created', inject([AccountInformationResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=account-information-resolver.service.spec.js.map