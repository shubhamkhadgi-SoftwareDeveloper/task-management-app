export class AccountInformation {
    constructor() {
        this.isAccountDetailClick = false;
        //for isActive on details page
        this.isAccountDetail = false;
    }
}
//# sourceMappingURL=account-information.class.js.map