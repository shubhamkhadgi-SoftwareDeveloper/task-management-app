import { TestBed, inject } from '@angular/core/testing';
import { AccountInformationService } from './account-information.service';
describe('AccountInformationService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AccountInformationService]
        });
    });
    it('should be created', inject([AccountInformationService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=account-information.service.spec.js.map