export class SettlementBankRes {
}
//# sourceMappingURL=set-bank-res.js.map