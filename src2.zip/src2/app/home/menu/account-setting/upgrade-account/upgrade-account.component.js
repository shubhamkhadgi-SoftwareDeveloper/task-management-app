import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
let UpgradeAccountComponent = class UpgradeAccountComponent {
    constructor() { }
    ngOnInit() {
    }
};
UpgradeAccountComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-upgrade-account',
        templateUrl: './upgrade-account.component.html',
        styleUrls: ['./upgrade-account.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [])
], UpgradeAccountComponent);
export { UpgradeAccountComponent };
//# sourceMappingURL=upgrade-account.component.js.map