import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonAndThirdPartyModule } from '../../../common-modules/common-and-third-party.module';
import { AccountSettingRoutingModule, AccountSettingRoutedComponents } from './account-setting.routing';
let AccountSettingModule = class AccountSettingModule {
};
AccountSettingModule = tslib_1.__decorate([
    NgModule({
        imports: [
            CommonAndThirdPartyModule,
            AccountSettingRoutingModule
        ],
        declarations: [AccountSettingRoutedComponents]
    })
], AccountSettingModule);
export { AccountSettingModule };
//# sourceMappingURL=account-setting.module.js.map