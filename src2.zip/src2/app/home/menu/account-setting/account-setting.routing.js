import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
//Routing-Component
import { AccountInformationComponent } from './account-information/account-information.component';
import { UpgradeAccountComponent } from './upgrade-account/upgrade-account.component';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { ViewPrivilegesComponent } from './manage-users/view-privileges/view-privileges.component';
import { NewUserComponent } from './manage-users/new-user/new-user.component';
import { EditUserComponent } from './manage-users/edit-user/edit-user.component';
import { ManageLinkedAccountsComponent } from './manage-linked-accounts/manage-linked-accounts.component';
//Resolver - services
import { ManageUsersResolverService } from './manage-users/manage-users-resolver.service';
import { ManageLinkedAccountsResolverService } from './manage-linked-accounts/manage-linked-accounts-resolver.service';
import { AccountInformationResolverService } from './account-information/account-information-resolver.service';
import { NewUserResolverService } from './manage-users/new-user/new-user-resolver.service';
import { EditUserResolverService } from './manage-users/edit-user/edit-user-resolver.service';
//API - services
import { ManageUsersService } from './manage-users/manage-users.service';
import { ManageLinkedAccountsService } from './manage-linked-accounts/manage-linked-accounts.service';
import { AccountInformationService } from './account-information/account-information.service';
//Guard services
import { CanActivateRouteGuard } from '../../../common-guard-services/can-activate-route.guard';
const routes = [
    { path: 'accountInformation', component: AccountInformationComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: AccountInformationResolverService } },
    { path: 'upgradeAccount', component: UpgradeAccountComponent, canActivate: [CanActivateRouteGuard], },
    { path: 'manageUsers', component: ManageUsersComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: ManageUsersResolverService } },
    { path: 'manageUsers/newUser', component: NewUserComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: NewUserResolverService } },
    { path: 'manageUsers/editUser/:userId', component: EditUserComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: EditUserResolverService } },
    { path: 'manageLinkedAccounts', component: ManageLinkedAccountsComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: ManageLinkedAccountsResolverService } },
    { path: '', redirectTo: 'accountInformation', canActivate: [CanActivateRouteGuard], pathMatch: 'full' },
    { path: '**', component: AccountInformationComponent, canActivate: [CanActivateRouteGuard], }
];
let AccountSettingRoutingModule = class AccountSettingRoutingModule {
};
AccountSettingRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [ManageUsersService, NewUserResolverService, EditUserResolverService, ManageUsersResolverService, ManageLinkedAccountsService, ManageLinkedAccountsResolverService, AccountInformationService, AccountInformationResolverService]
    })
], AccountSettingRoutingModule);
export { AccountSettingRoutingModule };
export const AccountSettingRoutedComponents = [AccountInformationComponent, UpgradeAccountComponent, ManageUsersComponent, ViewPrivilegesComponent, NewUserComponent, EditUserComponent, ManageLinkedAccountsComponent];
//# sourceMappingURL=account-setting.routing.js.map