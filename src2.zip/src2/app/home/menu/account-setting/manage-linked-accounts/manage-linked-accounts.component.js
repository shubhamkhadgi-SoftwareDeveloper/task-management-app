import * as tslib_1 from "tslib";
import { Component, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { CommonResponse } from './../../../../common-response/common-response.res';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ErrorHandlerService } from './../../../../common-services/error-handler.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import * as sha256 from 'crypto-js/sha256';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { ManageAccountsSearchReq } from './manage-accounts-search-req';
import { ManageLinkedAccounts } from './manage-linked-accounts.class';
import { ManageLinkedAccountsService } from './manage-linked-accounts.service';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { DOCUMENT } from '@angular/common';
import { CurrentLoginMerchantService } from 'app/common-services/current-login-merchant.service';
let ManageLinkedAccountsComponent = class ManageLinkedAccountsComponent {
    constructor(sActivatedRoute, pMerchInfoService, sFormBuilder, sCheck, sResponsiveService, sErrorHandler, sAlertMessageService, sErrorMessagesService, sLandingPageMsgService, pModalService, pManageLinkedAccountsService, document, sCurrentLoginMerchantService) {
        this.sActivatedRoute = sActivatedRoute;
        this.pMerchInfoService = pMerchInfoService;
        this.sFormBuilder = sFormBuilder;
        this.sCheck = sCheck;
        this.sResponsiveService = sResponsiveService;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.pModalService = pModalService;
        this.pManageLinkedAccountsService = pManageLinkedAccountsService;
        this.document = document;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.isSearchPanelClick = false;
        this.isAnyAccountLinked = false;
        this.createForm();
        this.cManageLinkedAccounts = new ManageLinkedAccounts();
        this.cManageAccountsSearchReq = new ManageAccountsSearchReq();
        this.cManageAccountsSearchReq.regParentId = this.pMerchInfoService.getRegId();
        this.cMenuList = JSON.parse(sessionStorage.getItem('menuList'));
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cAccountListProcEntity = mCommonResponse.data['accountList'];
                this.cTotalCount = mCommonResponse.data['totalCount'];
                if (this.cTotalCount > 0)
                    this.cManageLinkedAccounts.isAnyLinkedAccount = true;
                else {
                    this.cManageLinkedAccounts.isAnyLinkedAccount = false;
                }
            }
            else {
                //this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cManageLinkedAccounts.landingPageMsg = this.sLandingPageMsgService.noLinkedAccountYetMsg;
                this.cManageLinkedAccounts.isAnyLinkedAccount = false;
            }
        });
        this.createSearchForm();
        this.cSearchForm.controls['searchByValue'].disable();
    }
    //*********************************************** Validation **************************************************//
    createSearchForm() {
        this.cSearchForm = this.sFormBuilder.group({
            searchBy: [''],
            searchByValue: [''],
            status: [''],
        });
    }
    createForm() {
        this.mForm = this.sFormBuilder.group({
            userId: [''],
            userPass: [''],
        });
    }
    //***********************************************Button Click Event********************************************//
    onSelectActionClick() {
        this.isSearchPanelClick = false;
        this.cManageLinkedAccounts.isSelectActionClick = !this.cManageLinkedAccounts.isSelectActionClick;
    }
    onSearchPanelClick() {
        //this.createSearchForm();
        this.cManageLinkedAccounts.selectedAccounts = [];
        this.cManageLinkedAccounts.isAllAccountsCheck = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onCancelPanelClick() {
        this.sResponsiveService.closeSearch();
        this.cManageLinkedAccounts.selectedAccounts = [];
        this.cManageLinkedAccounts.isAllAccountsCheck = false;
        this.cManageAccountsSearchReq = null;
        this.cManageAccountsSearchReq = new ManageAccountsSearchReq();
        this.cManageAccountsSearchReq.regParentId = this.pMerchInfoService.getRegId();
        this.cSearchForm.controls['searchByValue'].setValue(null);
        this.cSearchForm.controls['searchByValue'].disable();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.onSearchClick();
    }
    onDeselectClick(pEvent) {
        if (pEvent) {
            this.cManageLinkedAccounts.isAllAccountsCheck = false;
            this.cManageLinkedAccounts.selectedAccounts = [];
        }
    }
    onSearchByClick() {
        this.cManageAccountsSearchReq.searchByValue = null;
        if (this.cManageAccountsSearchReq.searchBy == 'regId') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cManageAccountsSearchReq.searchBy == 'userId' || this.cManageAccountsSearchReq.searchBy == 'userName') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators(Validators.required);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            this.pManageLinkedAccountsService.fetchAllManageAccounts(this.cManageAccountsSearchReq)
                .subscribe(pResponse => this.fetchAccountListSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.cSearchForm);
        }
    }
    onSelectDeleteClick(pTemplate) {
        this.cManageLinkedAccounts.isSelectActionClick = false;
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onDeleteClick(pTemplate, pValue) {
        this.cManageLinkedAccounts.selectedAccounts = [];
        this.cManageLinkedAccounts.selectedAccounts.push(pValue);
        this.cManageLinkedAccounts.isSelectActionClick = false;
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onConfirmDeleteClick() {
        if (this.cManageLinkedAccounts.selectedAccounts != null && this.cManageLinkedAccounts.selectedAccounts.length > 0) {
            this.cManageAccountsSearchReq.regId = this.cManageLinkedAccounts.selectedAccounts;
            this.pManageLinkedAccountsService.deleteManageAccounts(this.cManageAccountsSearchReq)
                .subscribe(pResponse => this.deleteLinkedAccountSuccess(pResponse), error => { console.log('error'); });
        }
        this.cModalRef.hide();
    }
    declineDeleteTask() {
        this.cModalRef.hide();
        this.cManageLinkedAccounts.isAllAccountsCheck = false;
        this.cManageLinkedAccounts.selectedAccounts = [];
    }
    onOpenPopupClick(pTemplate) {
        this.cManageAccountsSearchReq.userId = null;
        this.cManageAccountsSearchReq.userPass = null;
        this.cError = null;
        this.cModalRef = this.pModalService.show(pTemplate, { ignoreBackdropClick: true });
    }
    onAddAccountClick() {
        let mPassword = sha256(this.cManageAccountsSearchReq.userPass);
        this.cManageAccountsSearchReq.userPass = mPassword.toString();
        this.pManageLinkedAccountsService.addManageAccounts(this.cManageAccountsSearchReq)
            .subscribe(pResponse => this.addLinkedAccountSuccess(pResponse), error => { console.log('error'); });
    }
    //***********************************************CheckBox Check Event*******************************************//
    onAllAccountsCheck(pEvent) {
        if (pEvent) {
            this.cManageLinkedAccounts.selectedAccounts = [];
            for (let pAccounts of this.cAccountListProcEntity) {
                this.cManageLinkedAccounts.selectedAccounts.push(pAccounts.registeredParentId.toString());
            }
        }
        else {
            this.cManageLinkedAccounts.selectedAccounts = [];
        }
    }
    onAccountsCheck(pEvent) {
        if (pEvent) {
            if (this.cManageLinkedAccounts.selectedAccounts.length === this.cAccountListProcEntity.length) {
                this.cManageLinkedAccounts.isAllAccountsCheck = true;
            }
        }
        else {
            this.cManageLinkedAccounts.isAllAccountsCheck = false;
        }
    }
    //***********************************************Mouse Event*******************************************//
    //Select Action
    mouseleaveSelectActionEvent() {
        this.cManageLinkedAccounts.isSelectActionClick = false;
    }
    //***********************************************Server Call Event**********************************************//
    fetchAccountListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cAccountListProcEntity = mCommonResponse.data['accountList'];
                this.cTotalCount = mCommonResponse.data['totalCount'];
                this.isSearchPanelClick = false;
                this.sResponsiveService.closeSearch();
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cManageLinkedAccounts.landingPageMsg = this.sLandingPageMsgService.noLinkedAccountFoundMsg;
                this.cAccountListProcEntity = null;
                this.cTotalCount = null;
                this.isSearchPanelClick = false;
                this.sResponsiveService.closeSearch();
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cManageLinkedAccounts.landingPageMsg = this.sLandingPageMsgService.noLinkedAccountFoundMsg;
                this.cAccountListProcEntity = null;
                this.cTotalCount = null;
                this.isSearchPanelClick = false;
                this.sResponsiveService.closeSearch();
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cManageLinkedAccounts.landingPageMsg = this.sLandingPageMsgService.noLinkedAccountFoundMsg;
            this.cAccountListProcEntity = null;
            this.cTotalCount = null;
            this.cManageLinkedAccounts.isSearchPanelClick = false;
            this.sResponsiveService.closeSearch();
        }
    }
    addLinkedAccountSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cManageLinkedAccounts.isAnyLinkedAccount = true;
                this.onSearchClick();
                this.cModalRef.hide();
            }
            else if (mCommonResponse.isFail) {
                this.cError = mCommonResponse.messageDesc;
            }
        }
    }
    deleteLinkedAccountSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        this.onSearchClick();
    }
};
ManageLinkedAccountsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-manage-linked-accounts',
        templateUrl: './manage-linked-accounts.component.html',
        styleUrls: ['./manage-linked-accounts.component.css'],
        animations: [
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 }),
        ]
    }),
    tslib_1.__param(11, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        MerchInfoService,
        FormBuilder,
        ConditionalCheckService,
        ResponsiveService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        LandingPageMsgService,
        BsModalService,
        ManageLinkedAccountsService,
        Document,
        CurrentLoginMerchantService])
], ManageLinkedAccountsComponent);
export { ManageLinkedAccountsComponent };
//# sourceMappingURL=manage-linked-accounts.component.js.map