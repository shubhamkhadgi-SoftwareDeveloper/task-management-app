import { async, TestBed } from '@angular/core/testing';
import { ManageLinkedAccountsComponent } from './manage-linked-accounts.component';
describe('ManageLinkedAccountsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ManageLinkedAccountsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(ManageLinkedAccountsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=manage-linked-accounts.component.spec.js.map