export class ManageLinkedAccounts {
    constructor() {
        this.selectedAccounts = [];
        this.isSearchPanelClick = false;
        this.isAllAccountsCheck = false;
        this.isSelectActionClick = false;
        this.isSearchByClick = false;
        this.searchBy = [];
        this.searchBy.push({ label: 'Search by', value: '' });
        this.searchBy.push({ label: 'MID', value: 'regId' });
        this.searchBy.push({ label: 'User ID', value: 'userId' });
        this.searchBy.push({ label: 'User Name', value: 'userName' });
        this.accountStatus = [];
        this.accountStatus.push({ label: 'Select', value: '' });
        this.accountStatus.push({ label: 'Verified', value: 'Y' });
        this.accountStatus.push({ label: 'Not Verified', value: 'N' });
    }
}
//# sourceMappingURL=manage-linked-accounts.class.js.map