import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let ManageLinkedAccountsService = class ManageLinkedAccountsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'manageLinkedAccounts/';
        this.cFetchAllManageAccounts = this.cBaseUrl + 'fetchAllManageAccounts';
        this.cAddManageAccounts = this.cBaseUrl + 'addManageAccounts';
        this.cDeleteManageAccounts = this.cBaseUrl + 'deleteManageAccounts';
    }
    fetchAllManageAccounts(pManageAccountsSearchReq) {
        return this.pApiRequestService.httpPostRequest(pManageAccountsSearchReq, this.cFetchAllManageAccounts);
    }
    addManageAccounts(pManageAccountsSearchReq) {
        return this.pApiRequestService.httpPostRequest(pManageAccountsSearchReq, this.cAddManageAccounts);
    }
    deleteManageAccounts(pManageAccountsSearchReq) {
        return this.pApiRequestService.httpPostRequest(pManageAccountsSearchReq, this.cDeleteManageAccounts);
    }
};
ManageLinkedAccountsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], ManageLinkedAccountsService);
export { ManageLinkedAccountsService };
//# sourceMappingURL=manage-linked-accounts.service.js.map