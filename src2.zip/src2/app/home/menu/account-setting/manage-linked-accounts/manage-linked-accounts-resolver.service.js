import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { ManageAccountsSearchReq } from './manage-accounts-search-req';
import { ManageLinkedAccountsService } from './manage-linked-accounts.service';
let ManageLinkedAccountsResolverService = class ManageLinkedAccountsResolverService {
    constructor(sManageLinkedAccountsService) {
        this.sManageLinkedAccountsService = sManageLinkedAccountsService;
    }
    resolve(route, state) {
        let mManageAccountsSearchReq = new ManageAccountsSearchReq();
        return this.sManageLinkedAccountsService.fetchAllManageAccounts(mManageAccountsSearchReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
ManageLinkedAccountsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ManageLinkedAccountsService])
], ManageLinkedAccountsResolverService);
export { ManageLinkedAccountsResolverService };
//# sourceMappingURL=manage-linked-accounts-resolver.service.js.map