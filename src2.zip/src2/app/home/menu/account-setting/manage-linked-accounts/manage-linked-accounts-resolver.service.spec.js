import { TestBed, inject } from '@angular/core/testing';
import { ManageLinkedAccountsResolverService } from './manage-linked-accounts-resolver.service';
describe('ManageLinkedAccountsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ManageLinkedAccountsResolverService]
        });
    });
    it('should be created', inject([ManageLinkedAccountsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=manage-linked-accounts-resolver.service.spec.js.map