import { TestBed, inject } from '@angular/core/testing';
import { ManageLinkedAccountsService } from './manage-linked-accounts.service';
describe('ManageLinkedAccountsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ManageLinkedAccountsService]
        });
    });
    it('should be created', inject([ManageLinkedAccountsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=manage-linked-accounts.service.spec.js.map