export class ManageAccountsSearchReq {
    constructor() {
        this.regId = [];
        this.searchPageSize = 25;
        this.searchPageNum = 1;
    }
}
//# sourceMappingURL=manage-accounts-search-req.js.map