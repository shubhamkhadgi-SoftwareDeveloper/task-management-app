export class SiUnSuccessWrapper {
}
//# sourceMappingURL=SiUnSuccessEntityWrapper.js.map