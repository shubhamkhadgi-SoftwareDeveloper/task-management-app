export class SiUnSuccessListResDto {
}
//# sourceMappingURL=siUnsuccesslist.res.js.map