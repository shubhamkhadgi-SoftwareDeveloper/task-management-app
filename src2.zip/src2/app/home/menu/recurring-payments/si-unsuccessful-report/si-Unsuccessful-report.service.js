import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let SiUnSuccessService = class SiUnSuccessService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'siSuccessfulReport/';
        this.cGetAllSiUnSuccess = this.cBaseUrl + 'fetchSIUnsuccessList';
        this.cExportExcelAllSIUnSuccess = this.cBaseUrl + 'exportExcelAllSIUnSuccess';
    }
    fetchSIUnsuccessList(pSiSuccessListReqDto) {
        return this.pApiRequestService.httpPostRequest(pSiSuccessListReqDto, this.cGetAllSiUnSuccess);
    }
    exportExcelAllSIUnSuccess(pSiUnSuccessListReqDto) {
        return this.pApiRequestService.exportFileRequest(pSiUnSuccessListReqDto, this.cExportExcelAllSIUnSuccess, 'SiUnSuccessDetails.xlsx');
    }
};
SiUnSuccessService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], SiUnSuccessService);
export { SiUnSuccessService };
//# sourceMappingURL=si-Unsuccessful-report.service.js.map