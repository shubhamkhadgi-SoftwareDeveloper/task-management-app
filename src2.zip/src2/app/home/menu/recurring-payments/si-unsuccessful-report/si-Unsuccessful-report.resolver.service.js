import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { SiUnSuccessListReqDto } from './SiUnSuccess.req';
import { SiUnSuccessService } from './si-Unsuccessful-report.service';
let SiUnSuccessResolverService = class SiUnSuccessResolverService {
    constructor(cSiUnSuccessService) {
        this.cSiUnSuccessService = cSiUnSuccessService;
    }
    resolve(route, state) {
        let mSiUnSuccessListReqDto = new SiUnSuccessListReqDto();
        return this.cSiUnSuccessService.fetchSIUnsuccessList(mSiUnSuccessListReqDto).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
SiUnSuccessResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [SiUnSuccessService])
], SiUnSuccessResolverService);
export { SiUnSuccessResolverService };
//# sourceMappingURL=si-Unsuccessful-report.resolver.service.js.map