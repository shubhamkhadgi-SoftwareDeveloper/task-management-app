import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { SiUnSuccessListReqDto } from "./SiUnSuccess.req";
import { SiUnSuccessListResDto } from "app/home/menu/recurring-payments/si-unsuccessful-report/siUnsuccesslist.res";
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { SiUnSuccessFull } from "app/home/menu/recurring-payments/si-unsuccessful-report/SiUnSuccessFull.class";
import { SiUnSuccessWrapper } from "app/home/menu/recurring-payments/si-unsuccessful-report/SiUnSuccessEntityWrapper";
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { SiUnSuccessService } from './si-Unsuccessful-report.service';
import { TitleService } from './../../../../common-services/title.service';
let SiUnsuccessfulReportComponent = class SiUnsuccessfulReportComponent {
    constructor(modalService, pSiUnSuccessService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService) {
        this.modalService = modalService;
        this.pSiUnSuccessService = pSiUnSuccessService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.checkStr = true;
        this.cIsWritePrivilege = false;
        this.pageCount = 0;
        this.isSearchByClick = false;
        this.searchflag = 'seachform';
        this.cSiUnSuccessListReqDto = new SiUnSuccessListReqDto();
        this.cSiUnSuccessListResDtoError = new SiUnSuccessListResDto();
        this.cSiUnSuccessFull = new SiUnSuccessFull();
        this.mSiUnSuccessWrapper = new SiUnSuccessWrapper();
        this.sTitleService.setTitle(this.sTitleService.SIUnsuccessfulReport);
    }
    ngOnInit() {
        this.createForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cSiUnSuccessFull.totalCount = Number(mCommonResponse.data['pageTotalCount']);
                    if (this.sCheck.isNotNullList(mCommonResponse.data['SIUnSuccessfulProcEntity'])) {
                        // this.cSiSuccessWrapper = mCommonResponse.data['SISuccessfulProcEntity'] as SiSuccessWrapper[];
                        this.cSiUnSuccessListResDto = mCommonResponse.data['SIUnSuccessfulProcEntity'];
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                    }
                }
                else {
                    this.cSiUnSuccessListResDto = new Array();
                    this.cSiUnSuccessFull.temp = "OK";
                    this.landingPageMsg = "No Si-UnSuccessfull Report were found!";
                    console.log("No Si-UnSuccessfull Report were found!");
                }
            }
        });
        // this.fetchSiUn();
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: [''],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    fetchSiUn() {
        this.pSiUnSuccessService.fetchSIUnsuccessList(this.cSiUnSuccessListReqDto)
            .subscribe(rResponse => this.fetchAllSiUnSuccess(rResponse), error => { console.log('error fetch'); });
    }
    fetchAllSiUnSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cSiUnSuccessFull.totalCount = Number(mCommonResponse.data['pageTotalCount']);
                if (this.sCheck.isNotNullList(mCommonResponse.data['SIUnSuccessfulProcEntity'])) {
                    // this.cSiSuccessWrapper = mCommonResponse.data['SISuccessfulProcEntity'] as SiSuccessWrapper[];
                    this.cSiUnSuccessListResDto = mCommonResponse.data['SIUnSuccessfulProcEntity'];
                    this.pageCount = mCommonResponse.data['pageTotalCount'];
                    this.sResponsiveService.closeSearch();
                }
            }
            else {
                this.cSiUnSuccessListResDto = new Array();
                this.cSiUnSuccessFull.temp = "OK";
                this.landingPageMsg = "No Si-UnSuccessfull Report were found!";
                console.log("No Si-UnSuccessfull Report were found!");
                this.sResponsiveService.closeSearch();
            }
        }
        this.cSiUnSuccessFull.selectedSI = [];
        this.cSiUnSuccessFull.isSelectActionClick = false;
    }
    onSearchPanelClick() {
        this.cSiUnSuccessFull.isExportClick = false;
        this.mForm.controls['searchByValue'].disable();
        this.sResponsiveService.openSearch();
    }
    onSearchByClick() {
        this.cSiUnSuccessFull.isExportClick = false;
        this.cSiUnSuccessFull.isSearchByClick = !this.cSiUnSuccessFull.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cSiUnSuccessFull.isExportClick = false;
        this.cSiUnSuccessFull.isSearchByClick = !this.cSiUnSuccessFull.isSearchByClick;
        this.cSiUnSuccessListReqDto.searchBy = pOption.value;
        this.cSiUnSuccessFull.searchByLabel = pOption.label;
        this.cSiUnSuccessListReqDto.searchByValue = null;
        if (this.cSiUnSuccessFull.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiUnSuccessFull.searchByLabel == 'ID/Reference #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiUnSuccessFull.searchByLabel == 'CCAvenue Ref.#') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiUnSuccessFull.searchByLabel == 'Email ID') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cSiUnSuccessListReqDto.fromDate = value.start.format("DD-MM-YYYY hh:mm:ss");
        this.cSiUnSuccessListReqDto.toDate = value.end.format("DD-MM-YYYY hh:mm:ss");
        this.cSiUnSuccessFull.fromToDate = this.cSiUnSuccessListReqDto.fromDate + ' - ' + this.cSiUnSuccessListReqDto.toDate;
    }
    onExportClick() {
        this.cSiUnSuccessFull.isSearchByClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSiUnSuccessFull.isSearchPanelClick = false;
        }
        this.cSiUnSuccessFull.isSelectActionClick = false;
        this.cSiUnSuccessFull.selectedSI = [];
        this.cSiUnSuccessFull.isExportClick = !this.cSiUnSuccessFull.isExportClick;
    }
    onSearchClick() {
        this.cSiUnSuccessFull.isExportClick = false;
        if (this.mForm.valid) {
            if (this.searchflag == 'seachform') {
                this.cSiUnSuccessListReqDto.pageNumber = 1;
            }
            this.pSiUnSuccessService.fetchSIUnsuccessList(this.cSiUnSuccessListReqDto)
                .subscribe(rResponse => this.fetchAllSiUnSuccess(rResponse), error => { console.log('error'); });
            this.searchflag = 'seachform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onCancelClick() {
        this.cSiUnSuccessFull.isExportClick = false;
        this.cSiUnSuccessFull.isSearchByClick = false;
        this.cSiUnSuccessFull.searchByLabel = 'Search By';
        this.cSiUnSuccessListReqDto = null;
        this.cSiUnSuccessListReqDto = new SiUnSuccessListReqDto();
        this.cSiUnSuccessListReqDto.regId = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSiUnSuccessFull.isSearchPanelClick = false;
        }
        this.cSiUnSuccessFull = new SiUnSuccessFull();
        this.fetchSiUn();
        this.sResponsiveService.closeSearch();
    }
    onDropdownCloseClick() {
        this.isSearchByClick = false;
    }
    onPageChange(event) {
        this.cSiUnSuccessListReqDto.searchPageSize = event.cPageSize;
        this.cSiUnSuccessListReqDto.pageNumber = event.cPageNo;
        this.cSiUnSuccessFull.selectedSI = [];
        this.cSiUnSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
    onExportExcelClick() {
        this.cSiUnSuccessFull.isExportClick = !this.cSiUnSuccessFull.isExportClick;
        this.cSiUnSuccessListReqDto.regId = this.pMerchInfoService.getRegId();
        this.pSiUnSuccessService.exportExcelAllSIUnSuccess(this.cSiUnSuccessListReqDto)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onAllRecurringProfileCheck(pEvent) {
        if (pEvent) {
            this.cSiUnSuccessFull.selectedSI = [];
            for (let pRecInv of this.cSiUnSuccessWrapper) {
                this.cSiUnSuccessFull.selectedSI.push(pRecInv.billPaymentDetailsList.billId.toString());
            }
        }
        else {
            this.cSiUnSuccessFull.selectedSI = [];
        }
    }
};
SiUnsuccessfulReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-si-unsuccessful-report',
        templateUrl: './si-unsuccessful-report.component.html',
        styleUrls: ['./si-unsuccessful-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [BsModalService,
        SiUnSuccessService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService])
], SiUnsuccessfulReportComponent);
export { SiUnsuccessfulReportComponent };
//# sourceMappingURL=si-unsuccessful-report.component.js.map