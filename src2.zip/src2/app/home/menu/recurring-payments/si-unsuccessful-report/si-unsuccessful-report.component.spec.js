import { async, TestBed } from '@angular/core/testing';
import { SiUnsuccessfulReportComponent } from './si-unsuccessful-report.component';
describe('SiUnsuccessfulReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SiUnsuccessfulReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(SiUnsuccessfulReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=si-unsuccessful-report.component.spec.js.map