export class SiUnSuccessListReqDto {
    constructor() {
        this.pageNumber = 1;
        this.searchPageSize = 25;
    }
}
//# sourceMappingURL=SiUnSuccess.req.js.map