export class StandingInstructionListReq {
    constructor() {
    }
}
//# sourceMappingURL=standing-instruction-list-req.js.map