export class StandingInstructionListResWrapper {
    constructor() {
        this.cSICharges = [];
    }
}
//# sourceMappingURL=standing-instruction-list-res-wrapper.js.map