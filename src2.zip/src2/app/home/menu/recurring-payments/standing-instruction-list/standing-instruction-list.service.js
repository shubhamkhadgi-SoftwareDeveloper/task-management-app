import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let StandingInstructionListService = class StandingInstructionListService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'standingInstructionList/';
        this.cfetchStandingInstructionListUrl = this.cBaseUrl + 'fetchStandingInstructionList';
        this.cfetchStandingInstructionListForExportUrl = this.cBaseUrl + 'exportExcelForSIList';
        this.cfetchStandingInstructionDetailUrl = this.cBaseUrl + 'fetchStandingInstructionDetail';
        this.cCancelSiPaymentUrl = this.cBaseUrl + 'cancelSiPayment';
    }
    fetchStandingInstructionList(pStandingInstructionListReq) {
        return this.pApiRequestService.httpPostRequest(pStandingInstructionListReq, this.cfetchStandingInstructionListUrl);
    }
    exportExcelForSIList(pStandingInstructionListReq) {
        return this.pApiRequestService.exportFileRequest(pStandingInstructionListReq, this.cfetchStandingInstructionListForExportUrl, "RecurringPayment.xlsx");
    }
    fetchStandingInstructionDetail(pStandingInstructionListReq) {
        return this.pApiRequestService.httpPostRequest(pStandingInstructionListReq, this.cfetchStandingInstructionDetailUrl);
    }
    cancelSiPayment(pStandingInstructionListReq) {
        return this.pApiRequestService.httpPostRequest(pStandingInstructionListReq, this.cCancelSiPaymentUrl);
    }
};
StandingInstructionListService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], StandingInstructionListService);
export { StandingInstructionListService };
//# sourceMappingURL=standing-instruction-list.service.js.map