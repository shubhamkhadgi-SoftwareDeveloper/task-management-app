import { TestBed, inject } from '@angular/core/testing';
import { StandingInstructionListService } from './standing-instruction-list.service';
describe('StandingInstructionListService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [StandingInstructionListService]
        });
    });
    it('should be created', inject([StandingInstructionListService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=standing-instruction-list.service.spec.js.map