import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder } from '@angular/forms';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { StandingInstructionListReq } from './standing-instruction-list-req';
import { StandingInstructionListResWrapper } from './standing-instruction-list-res-wrapper';
import { StandingInstructionListService } from './standing-instruction-list.service';
import { StandingInstructionList } from './standing-instruction-list';
import { SIDetails } from './sidetails';
import { TitleService } from './../../../../common-services/title.service';
let StandingInstructionListComponent = class StandingInstructionListComponent {
    //***********************************************Life Hooks Event*******************************************//    
    constructor(sFormBuilder, pModalService, sStandingInstructionListService, pApiRequestService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService) {
        this.sFormBuilder = sFormBuilder;
        this.pModalService = pModalService;
        this.sStandingInstructionListService = sStandingInstructionListService;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.cIsWritePrivilege = false;
        this.landingPageMsg = null;
        this.cSiCreateDate = null;
        this.cSbcPayDate = null;
        this.cSiCurrId = null;
        this.cardSuffix = null;
        this.msgDesc = '';
        this.tempDate = new Date();
        this.cSIDetailsTransactionLog = [];
        this.cSIDetailsSubscriberProcEntity = [];
        this.cSIDetailsSubscriptionProcEntity = [];
        this.cSIDetailsCardsProcEntity = [];
        this.cSIDetailsSetupProcEntity = [];
        this.encryptedCardSuffix = null;
        this.cStandingInstructionList = new StandingInstructionList();
        this.cStandingInstructionListResWrapper = new StandingInstructionListResWrapper();
        this.cStandingInstructionListReq = new StandingInstructionListReq();
        this.cSIDetails = new SIDetails();
        this.cStandingInstructionListReq.regId = "" + this.pMerchInfoService.getRegId();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.StandingInstructionsList);
        this.sTitleService.setTitle(this.sTitleService.StandingInstructionsList);
    }
    ngOnInit() {
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.code === 0 || mCommonResponse.message == 'Success') {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cStandingInstructionListReq.totalCounts = mCommonResponse.data.totalCounts;
                    this.cStandingInstructionListResWrapper.cSICharges = mCommonResponse.data.SIChargesProcEntity;
                    this.cStandingInstructionListResWrapper.cSILog = mCommonResponse.data.SILogProcEntity;
                    if (this.cStandingInstructionListResWrapper.cSICharges.length == 0 && this.cStandingInstructionListResWrapper.cSILog.length == 0) {
                        this.cStandingInstructionList.isRecurringPayCreated = true;
                        this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                    }
                    else
                        this.cStandingInstructionList.isRecurringPayCreated = false;
                    this.cStandingInstructionListResWrapper.cSISubscriptionList = mCommonResponse.data.SISubscriptionListProcEntity;
                    this.cStandingInstructionListResWrapper.initiatedChargeTot = mCommonResponse.data.initiatedChargeTot;
                    this.cStandingInstructionListResWrapper.pendingChargeTot = mCommonResponse.data.pendingChargeTot;
                    this.cStandingInstructionListResWrapper.successfulChargeTot = mCommonResponse.data.successfulChargeTot;
                    this.cStandingInstructionListResWrapper.totalCount = mCommonResponse.data.totalCounts;
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                }
                this.msgDesc = mCommonResponse.messageDesc;
            }
            else {
                console.log(mCommonResponse.messageDesc);
            }
        });
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.cSearchForm = this.sFormBuilder.group({
            searchByValue: [''],
            fromDate: [''],
            toDate: [''],
            status: [''],
        });
    }
    //***********************************************Server Call Event*******************************************//    
    onPageChange(event) {
        this.cStandingInstructionListReq.pageSize = event.cPageSize;
        this.cStandingInstructionListReq.pageNum = event.cPageNo;
        this.onSearchClick();
    }
    fetchStandingInstructionListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(pResponse.data)) {
                    this.cStandingInstructionListResWrapper.totalCount = pResponse.data['totalCounts'];
                    this.cStandingInstructionListResWrapper.cSICharges = mCommonResponse.data.SIChargesProcEntity;
                    this.cStandingInstructionListResWrapper.cSISubscriptionList = mCommonResponse.data.SISubscriptionListProcEntity;
                    this.cStandingInstructionListResWrapper.cSILog = mCommonResponse.data.SILogProcEntity;
                    this.cStandingInstructionListResWrapper.initiatedChargeTot = mCommonResponse.data.initiatedChargeTot;
                    this.cStandingInstructionListResWrapper.pendingChargeTot = mCommonResponse.data.pendingChargeTot;
                    this.cStandingInstructionListResWrapper.successfulChargeTot = mCommonResponse.data.successfulChargeTot;
                    if (this.cStandingInstructionListResWrapper.cSILog.length == 0 || this.cStandingInstructionListResWrapper.cSILog == null) {
                        this.cStandingInstructionList.isSearchFound = true;
                        this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayFoundMsg;
                        console.log(mCommonResponse.messageDesc);
                    }
                    else
                        this.cStandingInstructionList.isSearchFound = false;
                    this.cStandingInstructionList.isSearchPanelClick = false;
                }
                this.msgDesc = mCommonResponse.messageDesc;
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = null;
                console.log(mCommonResponse.messageDesc);
                this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                this.cStandingInstructionListResWrapper.totalCount = null;
                this.cStandingInstructionListResWrapper = null;
                this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayFoundMsg;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cStandingInstructionList.isSearchPanelClick = false;
                }
            }
            else {
                this.landingPageMsg = null;
                console.log(mCommonResponse.messageDesc);
                this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                this.cStandingInstructionListResWrapper.totalCount = null;
                this.cStandingInstructionListResWrapper = null;
                this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayFoundMsg;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cStandingInstructionList.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.landingPageMsg = null;
            console.log(this.sErrorMessagesService.responseNull);
            this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
            this.cStandingInstructionListResWrapper.totalCount = null;
            this.cStandingInstructionListResWrapper = null;
            this.landingPageMsg = this.sLandingPageMsgService.noRecurringPayFoundMsg;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cStandingInstructionList.isSearchPanelClick = false;
            }
        }
    }
    fetchSIDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(pResponse.data)) {
                    this.cStandingInstructionListResWrapper.totalCount = pResponse.data['totalCount'];
                    this.cSIDetailsSubscriptionProcEntity = pResponse.data['SIDetailsSubscription'];
                    this.cSIDetailsSubscriberProcEntity = pResponse.data['SIDetailsSubscriber'];
                    this.cSIDetailsTransactionLog = pResponse.data['SIDetailsTransactionLog'];
                    this.cSIDetailsCardsProcEntity = pResponse.data['SIDetailsCards'];
                    this.cSIDetailsSetupProcEntity = pResponse.data['SIDetailsSetup'];
                    this.encryptedCardSuffix = pResponse.data['encryptedCardSuffix'];
                    this.cardSuffix = pResponse.data['cardSuffix'];
                    for (let entry of this.cSIDetailsSubscriberProcEntity) {
                        this.cSiCurrId = entry.siCurrId;
                        this.cSIDetails.siSetupAmt = entry.siSetupAmt;
                        this.cSIDetails.siCurrId = entry.siCurrId;
                        this.cSIDetails.siRefNo = entry.siRefNo;
                        this.cSIDetails.siMerRefNo = entry.siMerRefNo;
                    }
                    for (let entry1 of this.cSIDetailsSetupProcEntity) {
                        this.cSIDetails.paymentsTillDate = entry1.paymentsTillDate;
                        this.cSIDetails.endDate = entry1.endDate;
                        this.cSIDetails.recurringCharge = entry1.recurringCharge;
                        this.cSIDetails.startDate = entry1.startDate;
                        this.cSIDetails.nextBillDate = entry1.nextBillDate;
                    }
                    for (let entry2 of this.cSIDetailsSubscriptionProcEntity) {
                        this.cSiCreateDate = entry2.siCreateDate;
                        this.cSbcPayDate = entry2.sbcPayDate;
                        this.cSIDetails.siStatus = entry2.siStatus;
                        this.cSIDetails.siAmt = entry2.siAmt;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                this.cStandingInstructionListResWrapper.totalCount = null;
                this.cStandingInstructionListResWrapper = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cStandingInstructionList.isSearchPanelClick = false;
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
                this.cStandingInstructionListResWrapper.totalCount = null;
                this.cStandingInstructionListResWrapper = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cStandingInstructionList.isSearchPanelClick = false;
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cStandingInstructionList.landingPgeMsg = this.sLandingPageMsgService.noRecurringPayCreatedYetMsg;
            this.cStandingInstructionListResWrapper.totalCount = null;
            this.cStandingInstructionListResWrapper = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cStandingInstructionList.isSearchPanelClick = false;
            }
        }
    }
    cancelSISuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(pResponse.data)) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
            }
        }
        else if (mCommonResponse.isFail) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
        else {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
    }
    cancelSiPayment() {
        this.sStandingInstructionListService.cancelSiPayment(this.cStandingInstructionListReq)
            .subscribe(pResponse => {
            this.cSIDetails.siStatus = 'CANC';
            this.cancelSISuccess(pResponse);
        }, error => { console.log('error in onCancelSubscriptionClick'); });
        this.cModalRef.hide();
    }
    siIDetailRefresh(psiRefNo, regId) {
        this.cStandingInstructionListReq.siRefNo = psiRefNo;
        this.cStandingInstructionListReq.regId = regId;
        this.sStandingInstructionListService.fetchStandingInstructionDetail(this.cStandingInstructionListReq)
            .subscribe(pResponse => {
            this.fetchSIDetailsSuccess(pResponse);
            this.sResponsiveService.openDetails();
        }, error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cStandingInstructionList.isExportClick = false;
        this.cStandingInstructionList.isSearchByClick = false;
    }
    //***********************************************Button Click Event*******************************************//
    onExportExcelClick() {
        this.cStandingInstructionList.isExportClick = !this.cStandingInstructionList.isExportClick;
        this.cStandingInstructionListReq.exportFlag = 'Y';
        this.sStandingInstructionListService.exportExcelForSIList(this.cStandingInstructionListReq)
            .subscribe(pResponse => {
        }, error => { console.log('error in onExportExcelClick'); });
    }
    onExportClick() {
        this.cStandingInstructionList.isSearchPanelClick = false;
        this.cStandingInstructionList.isExportClick = !this.cStandingInstructionList.isExportClick;
    }
    onCancelSubscriptionClick(template, pSiRefNo) {
        this.cModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cStandingInstructionListReq.siRefNo = pSiRefNo;
    }
    onSearchPanelClick() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.cStandingInstructionList.startDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: '.custom-search',
                singleDatePicker: true,
            };
            this.cStandingInstructionList.endDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: '.custom-search',
                singleDatePicker: true,
                minDate: this.tempDate.start,
            };
        }
        else {
            this.cStandingInstructionList.startDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: 'body',
                singleDatePicker: true,
            };
            this.cStandingInstructionList.endDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: 'body',
                singleDatePicker: true,
                minDate: this.tempDate.start,
            };
        }
        this.cStandingInstructionList.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cStandingInstructionList.isSearchPanelClick = !this.cStandingInstructionList.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cStandingInstructionList.isSearchPanelClick = false;
            this.cStandingInstructionList.isSearchByClick = false;
        }
        this.cStandingInstructionListReq.searchByValue = '';
        this.cStandingInstructionListReq.searchByStatus = '';
        this.cStandingInstructionListReq.searchBy = "";
        this.cStandingInstructionList.searchByLabel = 'Search By';
        this.cSearchForm.controls['searchByValue'].setValue(null);
        this.cSearchForm.controls['searchByValue'].clearValidators();
        this.cSearchForm.controls['searchByValue'].disable();
        this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        this.cStandingInstructionListReq.searchByStatus = null;
        if (this.cStandingInstructionList.searchByLabel == 'Search By') {
            this.cStandingInstructionListReq.searchByValue = '';
        }
        this.cStandingInstructionListReq.searchFromDate = null;
        this.cStandingInstructionListReq.searchToDate = null;
        this.onSearchClick();
    }
    onSearchClick() {
        this.sStandingInstructionListService.fetchStandingInstructionList(this.cStandingInstructionListReq)
            .subscribe(pResponse => { this.fetchStandingInstructionListSuccess(pResponse); }, error => { console.log('error'); });
    }
    onSearchByOptionClick(pOption) {
        this.cStandingInstructionList.isSearchByClick = !this.cStandingInstructionList.isSearchByClick;
        this.cStandingInstructionListReq.searchBy = pOption.value;
        this.cStandingInstructionListReq.searchByValue = '';
        this.cStandingInstructionList.searchByLabel = pOption.label;
        if (this.cStandingInstructionList.searchByLabel == 'Search By') {
            this.cStandingInstructionListReq.searchByValue = '';
            this.cStandingInstructionListReq.searchBy = '';
            this.cSearchForm.controls['searchByValue'].disable();
        }
        else {
            this.cSearchForm.controls['searchByValue'].enable();
        }
    }
    onSearchByClick() {
        this.cStandingInstructionList.isSearchByClick = !this.cStandingInstructionList.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.cStandingInstructionList.isSearchByClick = false;
    }
    onSIDetailClick(psiRefNo, regId) {
        this.sResponsiveService.openDetails();
        this.cStandingInstructionListReq.siRefNo = psiRefNo;
        this.cStandingInstructionListReq.regId = regId;
        this.sStandingInstructionListService.fetchStandingInstructionDetail(this.cStandingInstructionListReq)
            .subscribe(pResponse => {
            this.fetchSIDetailsSuccess(pResponse);
            this.sResponsiveService.openDetails();
        }, error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onBackClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cStandingInstructionList.isSearchPanelClick = false;
        }
        this.sResponsiveService.closeDetails();
        this.cStandingInstructionList.isBackClick = false;
        this.cStandingInstructionList.isSIDetailsClick = false;
        this.onSearchClick();
    }
    //***********************************************Select Event*******************************************//
    selectedStartDate(value) {
        this.tempDate = value;
        this.cStandingInstructionList.isSearchByClick = false;
        this.cStandingInstructionListReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cStandingInstructionListReq.searchToDate = null;
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.cStandingInstructionList.endDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: '.custom-search',
                singleDatePicker: true,
                minDate: new Date(value.start.format("YYYY-MM-DD")),
            };
        }
        else {
            this.cStandingInstructionList.endDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: 'body',
                singleDatePicker: true,
                minDate: new Date(value.start.format("YYYY-MM-DD")),
            };
        }
    }
    selectedEndDate(value) {
        this.cStandingInstructionList.isSearchByClick = false;
        this.cStandingInstructionListReq.searchToDate = value.end.format("DD-MM-YYYY");
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.cStandingInstructionList.startDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: '.custom-search',
                singleDatePicker: true,
            };
        }
        else {
            this.cStandingInstructionList.startDatePicker = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                parentEl: 'body',
                singleDatePicker: true,
            };
        }
    }
};
StandingInstructionListComponent = tslib_1.__decorate([
    Component({
        selector: 'app-standing-instruction-list',
        templateUrl: './standing-instruction-list.component.html',
        styleUrls: ['./standing-instruction-list.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        BsModalService,
        StandingInstructionListService,
        ApiRequestService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService])
], StandingInstructionListComponent);
export { StandingInstructionListComponent };
//# sourceMappingURL=standing-instruction-list.component.js.map