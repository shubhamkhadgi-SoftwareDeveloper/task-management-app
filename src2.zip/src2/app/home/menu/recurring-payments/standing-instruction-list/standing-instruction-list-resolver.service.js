import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StandingInstructionListReq } from "./standing-instruction-list-req";
import { StandingInstructionListService } from './standing-instruction-list.service';
let StandingInstructionResolverService = class StandingInstructionResolverService {
    constructor(sStandingInstructionListService, sRouter) {
        this.sStandingInstructionListService = sStandingInstructionListService;
        this.sRouter = sRouter;
    }
    resolve(route, state) {
        let mStandingInstructionListReq = new StandingInstructionListReq();
        return this.sStandingInstructionListService.fetchStandingInstructionList(mStandingInstructionListReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
StandingInstructionResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [StandingInstructionListService,
        Router])
], StandingInstructionResolverService);
export { StandingInstructionResolverService };
//# sourceMappingURL=standing-instruction-list-resolver.service.js.map