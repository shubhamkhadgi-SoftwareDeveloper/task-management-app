import { async, TestBed } from '@angular/core/testing';
import { StandingInstructionListComponent } from './standing-instruction-list.component';
describe('StandingInstructionListComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [StandingInstructionListComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(StandingInstructionListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=standing-instruction-list.component.spec.js.map