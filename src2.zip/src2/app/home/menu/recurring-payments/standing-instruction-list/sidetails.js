export class SIDetails {
}
//# sourceMappingURL=sidetails.js.map