export class StandingInstructionList {
    constructor() {
        this.isSIDetailsClick = false;
        this.isSearchPanelClick = false;
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.isBackClick = false;
        this.closeButton = false;
        this.isRecurringPayCreated = false;
        this.isSearchFound = false;
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
        };
        this.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            parentEl: 'body',
            singleDatePicker: true,
        };
        this.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            parentEl: 'body',
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.status.push({ label: 'Select', value: '' });
        this.status.push({ label: 'Active', value: 'ACTI' });
        this.status.push({ label: 'Inactive', value: 'INAC' });
        this.status.push({ label: 'Expired', value: 'EXPD' });
        this.status.push({ label: 'Cancelled', value: 'CANC' });
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'ID', value: 'siRefNo' });
        this.searchBy.push({ label: 'Reference #', value: 'merRefNo' });
        this.searchBy.push({ label: 'Customer Name', value: 'userName' });
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=standing-instruction-list.js.map