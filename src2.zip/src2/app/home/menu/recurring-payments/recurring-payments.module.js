import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonAndThirdPartyModule } from '../../../common-modules/common-and-third-party.module';
import { RecurringPaymentsRoutingModule, RecurringPaymentsRoutedComponents } from './recurring-payments.routing';
let RecurringPaymentsModule = class RecurringPaymentsModule {
};
RecurringPaymentsModule = tslib_1.__decorate([
    NgModule({
        imports: [
            RecurringPaymentsRoutingModule,
            CommonAndThirdPartyModule
        ],
        declarations: [RecurringPaymentsRoutedComponents]
    })
], RecurringPaymentsModule);
export { RecurringPaymentsModule };
//# sourceMappingURL=recurring-payments.module.js.map