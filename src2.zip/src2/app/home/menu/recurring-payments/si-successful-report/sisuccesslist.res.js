export class SiSuccessListResDto {
}
//# sourceMappingURL=sisuccesslist.res.js.map