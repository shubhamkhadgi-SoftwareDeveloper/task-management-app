export class SiSuccessListReqDto {
    constructor() {
        this.pageNumber = 1;
        this.searchPageSize = 25;
    }
}
//# sourceMappingURL=SiSuccess.req.js.map