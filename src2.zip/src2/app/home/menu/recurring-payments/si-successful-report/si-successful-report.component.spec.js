import { async, TestBed } from '@angular/core/testing';
import { SiSuccessfulReportComponent } from './si-successful-report.component';
describe('SiSuccessfulReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SiSuccessfulReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(SiSuccessfulReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=si-successful-report.component.spec.js.map