import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let SiSuccessService = class SiSuccessService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'siSuccessfulReport/';
        this.cGetAllSiSuccess = this.cBaseUrl + 'fetchSISuccessList';
        this.cExportExcelAllSISuccessUrl = this.cBaseUrl + 'exportExcelAllSISuccess';
    }
    getAllSiSuccess(pSiSuccessListReqDto) {
        return this.pApiRequestService.httpPostRequest(pSiSuccessListReqDto, this.cGetAllSiSuccess);
    }
    exportExcelAllSISuccess(pSiSuccessListReqDto) {
        return this.pApiRequestService.exportFileRequest(pSiSuccessListReqDto, this.cExportExcelAllSISuccessUrl, 'SiSuccessDetails.xlsx');
    }
};
SiSuccessService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], SiSuccessService);
export { SiSuccessService };
//# sourceMappingURL=si-successful-report.service.js.map