import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { SiSuccessListReqDto } from "app/home/menu/recurring-payments/si-successful-report/SiSuccess.req";
import { SiSuccessListResDto } from "app/home/menu/recurring-payments/si-successful-report/sisuccesslist.res";
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { SiSuccessFull } from "app/home/menu/recurring-payments/si-successful-report/SiSuccessFull.class";
import { SiSuccessWrapper } from "app/home/menu/recurring-payments/si-successful-report/SiSuccessEntityWrapper";
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { SiSuccessService } from './si-successful-report.service';
import { TitleService } from './../../../../common-services/title.service';
let SiSuccessfulReportComponent = class SiSuccessfulReportComponent {
    constructor(modalService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sSiSuccessService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService) {
        this.modalService = modalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sSiSuccessService = sSiSuccessService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.checkStr = true;
        this.cSiSuccessListResDto = [];
        this.cIsWritePrivilege = false;
        this.pageCount = 0;
        this.isSearchByClick = false;
        this.searchflag = 'seachform';
        this.cSiSuccessListReqDto = new SiSuccessListReqDto();
        this.cSiSuccessListResDtoError = new SiSuccessListResDto();
        this.cSiSuccessFull = new SiSuccessFull();
        this.mSiSuccessWrapper = new SiSuccessWrapper();
        this.sTitleService.setTitle(this.sTitleService.SISuccessfulReport);
    }
    ngOnInit() {
        this.createForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse)) {
                    if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                        this.cSiSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                        if (this.sCheck.isNotNullList(mCommonResponse.data['SISuccessfulProcEntity'])) {
                            this.cSiSuccessListResDto = mCommonResponse.data['SISuccessfulProcEntity'];
                            this.pageCount = mCommonResponse.data['pageTotalCount'];
                        }
                    }
                    else {
                        this.cSiSuccessListResDto = new Array();
                        this.cSiSuccessFull.temp = "OK";
                        this.landingPageMsg = "No Si-Successfull Report were found!";
                        console.log("No Si-Successfull Report were found!");
                    }
                }
            }
        });
    }
    fetchSi() {
        this.sSiSuccessService.getAllSiSuccess(this.cSiSuccessListReqDto)
            .subscribe(rResponse => this.fetchAllSiSuccess(rResponse), error => { console.log('error fetch'); });
    }
    fetchAllSiSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cSiSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['SISuccessfulProcEntity'])) {
                        this.cSiSuccessListResDto = mCommonResponse.data['SISuccessfulProcEntity'];
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                        this.sResponsiveService.closeSearch();
                    }
                }
                else {
                    this.cSiSuccessListResDto = new Array();
                    this.cSiSuccessFull.temp = "OK";
                    this.landingPageMsg = "No Si-Successfull Report were found!";
                    console.log("No Si-Successfull Report were found!");
                    this.sResponsiveService.closeSearch();
                }
            }
        }
        this.cSiSuccessFull.selectedSI = [];
        this.cSiSuccessFull.isSelectActionClick = false;
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: [''],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchPanelClick() {
        this.cSiSuccessFull.isExportClick = false;
        this.mForm.controls['searchByValue'].disable();
        this.sResponsiveService.openSearch();
    }
    onCancelClick() {
        this.cSiSuccessFull.searchByLabel = 'Search By';
        this.cSiSuccessListReqDto = null;
        this.cSiSuccessListReqDto = new SiSuccessListReqDto();
        this.cSiSuccessListReqDto.regId = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSiSuccessFull.isSearchPanelClick = false;
        }
        this.cSiSuccessFull = new SiSuccessFull();
        this.sResponsiveService.closeSearch();
        this.fetchSi();
    }
    onSearchByClick() {
        this.cSiSuccessFull.isExportClick = false;
        this.cSiSuccessFull.isSearchByClick = !this.cSiSuccessFull.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cSiSuccessFull.isSearchByClick = !this.cSiSuccessFull.isSearchByClick;
        this.cSiSuccessListReqDto.searchBy = pOption.value;
        this.cSiSuccessFull.searchByLabel = pOption.label;
        this.cSiSuccessListReqDto.searchByValue = null;
        if (this.cSiSuccessFull.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiSuccessFull.searchByLabel == 'ID/Reference #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiSuccessFull.searchByLabel == 'CCAvenue Ref.#') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cSiSuccessFull.searchByLabel == 'Email ID') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cSiSuccessListReqDto.fromDate = value.start.format("DD-MM-YYYY hh:mm:ss");
        this.cSiSuccessListReqDto.toDate = value.end.format("DD-MM-YYYY hh:mm:ss");
        this.cSiSuccessFull.fromToDate = this.cSiSuccessListReqDto.fromDate + ' - ' + this.cSiSuccessListReqDto.toDate;
    }
    onExportClick() {
        this.cSiSuccessFull.isSearchByClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSiSuccessFull.isSearchPanelClick = false;
        }
        this.cSiSuccessFull.isSelectActionClick = false;
        this.cSiSuccessFull.selectedSI = [];
        this.cSiSuccessFull.isExportClick = !this.cSiSuccessFull.isExportClick;
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.searchflag == 'seachform') {
                this.cSiSuccessListReqDto.pageNumber = 1;
            }
            this.sSiSuccessService.getAllSiSuccess(this.cSiSuccessListReqDto)
                .subscribe(rResponse => this.fetchAllSiSuccess(rResponse), error => { console.log('error'); });
            this.searchflag = 'seachform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onDropdownCloseClick() {
        this.isSearchByClick = false;
    }
    onPageChange(event) {
        this.cSiSuccessListReqDto.searchPageSize = event.cPageSize;
        this.cSiSuccessListReqDto.pageNumber = event.cPageNo;
        this.cSiSuccessFull.selectedSI = [];
        this.cSiSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
    onExportExcelClick() {
        this.cSiSuccessFull.isExportClick = !this.cSiSuccessFull.isExportClick;
        this.cSiSuccessListReqDto.regId = this.pMerchInfoService.getRegId();
        this.sSiSuccessService.exportExcelAllSISuccess(this.cSiSuccessListReqDto)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onAllRecurringProfileCheck(pEvent) {
        if (pEvent) {
            this.cSiSuccessFull.selectedSI = [];
            for (let pRecInv of this.cSiSuccessWrapper) {
                this.cSiSuccessFull.selectedSI.push(pRecInv.billPaymentDetailsList.billId.toString());
            }
        }
        else {
            this.cSiSuccessFull.selectedSI = [];
        }
    }
};
SiSuccessfulReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-si-successful-report',
        templateUrl: './si-successful-report.component.html',
        styleUrls: ['./si-successful-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [BsModalService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        SiSuccessService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService])
], SiSuccessfulReportComponent);
export { SiSuccessfulReportComponent };
//# sourceMappingURL=si-successful-report.component.js.map