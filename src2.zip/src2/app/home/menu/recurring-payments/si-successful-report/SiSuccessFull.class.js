export class SiSuccessFull {
    constructor() {
        this.isAllSISuccessCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.landingPageMsg = "You dont't have any SI-Successfull report yet!";
        this.selectedSI = [];
        this.searchByLabel = "Search By";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'ID/Reference #', value: 'SiMerRefNo' });
        this.searchBy.push({ label: 'CCAvenue Ref.#', value: 'ccAvRef' });
        this.searchBy.push({ label: 'Email ID', value: 'siUSerEmail' });
        this.calOptions = {
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY hh:mm:ss' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.currDate = new Date();
    }
}
//# sourceMappingURL=SiSuccessFull.class.js.map