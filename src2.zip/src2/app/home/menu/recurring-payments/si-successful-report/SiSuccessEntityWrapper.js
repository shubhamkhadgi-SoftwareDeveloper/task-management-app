export class SiSuccessWrapper {
}
//# sourceMappingURL=SiSuccessEntityWrapper.js.map