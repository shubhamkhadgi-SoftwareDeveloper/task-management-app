import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { SiSuccessListReqDto } from './SiSuccess.req';
import { SiSuccessService } from './si-successful-report.service';
let SiSuccessResolverService = class SiSuccessResolverService {
    constructor(cSiSuccessService) {
        this.cSiSuccessService = cSiSuccessService;
    }
    resolve(route, state) {
        let mSiSuccessListReqDto = new SiSuccessListReqDto();
        return this.cSiSuccessService.getAllSiSuccess(mSiSuccessListReqDto).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
SiSuccessResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [SiSuccessService])
], SiSuccessResolverService);
export { SiSuccessResolverService };
//# sourceMappingURL=si-successful-report.resolver.service.js.map