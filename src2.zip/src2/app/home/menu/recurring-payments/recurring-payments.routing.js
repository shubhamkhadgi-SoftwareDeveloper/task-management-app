import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { StandingInstructionListComponent } from './standing-instruction-list/standing-instruction-list.component';
import { SiSuccessfulReportComponent } from './si-successful-report/si-successful-report.component';
import { SiUnsuccessfulReportComponent } from './si-unsuccessful-report/si-unsuccessful-report.component';
//Resolver - services
import { StandingInstructionResolverService } from './standing-instruction-list/standing-instruction-list-resolver.service';
import { SiSuccessResolverService } from './si-successful-report/si-successful-report.resolver.service';
import { SiUnSuccessResolverService } from './si-unsuccessful-report/si-Unsuccessful-report.resolver.service';
//API - services
import { StandingInstructionListService } from './standing-instruction-list/standing-instruction-list.service';
import { SiSuccessService } from './si-successful-report/si-successful-report.service';
import { SiUnSuccessService } from './si-unsuccessful-report/si-Unsuccessful-report.service';
const routes = [
    { path: 'standingInstructionList', component: StandingInstructionListComponent, resolve: { commonResponse: StandingInstructionResolverService } },
    { path: 'siSuccessfulReport', component: SiSuccessfulReportComponent, resolve: { commonResponse: SiSuccessResolverService } },
    { path: 'siUnsuccessfulReport', component: SiUnsuccessfulReportComponent, resolve: { commonResponse: SiUnSuccessResolverService } },
    { path: '', redirectTo: 'standingInstructionList', pathMatch: 'full' },
    { path: '**', component: StandingInstructionListComponent }
];
let RecurringPaymentsRoutingModule = class RecurringPaymentsRoutingModule {
};
RecurringPaymentsRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [StandingInstructionResolverService, StandingInstructionListService, SiSuccessService, SiSuccessResolverService, SiUnSuccessService, SiUnSuccessResolverService]
    })
], RecurringPaymentsRoutingModule);
export { RecurringPaymentsRoutingModule };
export const RecurringPaymentsRoutedComponents = [StandingInstructionListComponent, SiSuccessfulReportComponent, SiUnsuccessfulReportComponent];
//# sourceMappingURL=recurring-payments.routing.js.map