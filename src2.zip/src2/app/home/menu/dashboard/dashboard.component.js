import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from './../../../common-response/common-response.res';
import { ConditionalCheckService } from './../../../common-services/conditional-check.service';
import { DashboardService } from './dashboard.service';
import { AlertMessageService } from './../../../common-services/alert-message.service';
import { ErrorMessagesService } from './../../../common-services/error-messages.service';
import { GstDetailsComponent } from './gst-details/gst-details.component';
import { TitleService } from './../../../common-services/title.service';
let DashboardComponent = class DashboardComponent {
    constructor(sActivatedRoute, sCheck, sDashboardService, sAlertMessageService, sErrorMessagesService, cdRef, sModalService, sTitleService) {
        this.sActivatedRoute = sActivatedRoute;
        this.sCheck = sCheck;
        this.sDashboardService = sDashboardService;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.cdRef = cdRef;
        this.sModalService = sModalService;
        this.sTitleService = sTitleService;
        this.fromToDate = "";
        this.cSuccess = [];
        this.cFailure = [];
        this.cAbandoned = [];
        this.cLineXName = "";
        this.cIsLastTransaction = true;
        this.options = {
            autoApply: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            singleDatePicker: false,
            showDropdowns: true,
            dateLimit: {
                days: 30
            },
            maxDate: new Date(),
        };
        // Transaction Summary Doughnut Chart
        this.cTransSummLegend = false;
        this.cTransSummLabels = ['PC / Tablet', 'Mobile', 'Phonepay'];
        this.cTransSummData = [350, 450, 100];
        this.cTransSummChartType = 'doughnut';
        this.cTransSummColors = [{ backgroundColor: ["#536482", "#10C5B6", "#6EBA8C"] }];
        // Transaction Summary Line Chart
        this.cTransSummLineChartLegend = true;
        this.cTransSummLineChartType = 'line';
        this.cTransSummLineChartData = [];
        this.cTransSummLineChartLabels = [];
        this.cTransSummLineChartOptions = null;
        this.cTransSummLineChartColors = [
            {
                backgroundColor: 'rgba(148,159,177,0.2)',
                borderColor: '#526282',
                pointBackgroundColor: '#FFFFFF',
                pointBorderColor: '#526282',
                pointHoverBackgroundColor: '#526282',
                pointHoverBorderColor: '#FFFFFF'
            },
            {
                backgroundColor: 'rgba(77,83,96,0.2)',
                borderColor: '#0FC4B5',
                pointBackgroundColor: '#FFFFFF',
                pointBorderColor: '#0FC4B5',
                pointHoverBackgroundColor: '#0FC4B5',
                pointHoverBorderColor: '#FFFFFF'
            },
            {
                backgroundColor: 'rgba(148,159,177,0.2)',
                borderColor: '#6DBA8C',
                pointBackgroundColor: '#FFFFFF',
                pointBorderColor: '#6DBA8C',
                pointHoverBackgroundColor: '#6DBA8C',
                pointHoverBorderColor: '#FFFFFF'
            }
        ];
        // Succ Trans By Payment Type  Doughnut Chart
        this.cPayTypeLabels = [];
        this.cPayTypeData = [];
        this.cPayAreaData = [];
        this.cPayTypeColors = ['#578ebe', '#62c78b', '#94ceff', '#ff9666', '#f4c84f', '#7ec7c6', '#6badd6', '#db6fda', '#7ec7c6', '#b48787', '#aece4e', '#78718a', '#029afd', '#5a8965', '#ca9b63'];
        //option 
        this.cPayTypeOptions = { formatter: function (y, data) {
                return data.data;
            }, resize: true,
        };
        this.cDuration = 'TODAY';
        this.sTitleService.setTitle(this.sTitleService.Dashboard);
    }
    ngOnInit() {
        this.fromToDate = "";
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.fetchTransactionStatusSuccess(data.commonResponse);
        });
    }
    chartHovered(e) {
        //console.log(e);
    }
    getPerClass(pPercentage) {
        if (pPercentage != undefined && pPercentage != null && pPercentage != NaN) {
            let mValue = pPercentage * (408 / 100);
            return mValue + ',408';
        }
        return '';
    }
    selectedDate(value) {
        this.fromToDate = value.start.format("DD-MM-YYYY") + ' - ' + value.end.format("DD-MM-YYYY");
        this.sDashboardService.fetchTransactionStatus({ 'searchDateForm': value.start.format("DD-MM-YYYY"), 'searchDateTo': value.end.format("DD-MM-YYYY") })
            .subscribe(pResponse => this.fetchTransactionStatusSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onDurationClick(pDuration) {
        this.cDuration = pDuration;
        if (pDuration != 'DATE') {
            this.fromToDate = null;
            this.sDashboardService.fetchTransactionStatus({ 'searchDuration': pDuration })
                .subscribe(pResponse => this.fetchTransactionStatusSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    fetchTransactionStatusSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                //Last Transaction
                if (this.sCheck.isNotNullObject(mCommonResponse.data['isLastTransaction'])) {
                    this.cIsLastTransaction = mCommonResponse.data['isLastTransaction'];
                }
                //Line Chart
                this.cSuccess = mCommonResponse.data['Success'];
                this.cFailure = mCommonResponse.data['Unsuccessful'];
                this.cAbandoned = mCommonResponse.data['Abandoned'];
                let mLabels = mCommonResponse.data['lineXValue'];
                if (this.sCheck.isNotNullString(mCommonResponse.data['lineXName'])) {
                    this.cLineXName = mCommonResponse.data['lineXName'];
                }
                if (this.sCheck.isNotNullList(this.cSuccess) && this.sCheck.isNotNullList(mLabels)) {
                    this.cTransSummLineChartData = [
                        { data: this.cSuccess, label: 'Success' },
                        { data: this.cFailure, label: 'Failure' },
                        { data: this.cAbandoned, label: 'Abandoned' },
                    ];
                    let mLength = this.cSuccess.length;
                    this.cdRef.detectChanges();
                    this.cTransSummLineChartLabels = mLabels.slice(0, mLength);
                    this.cTransSummLineChartOptions = {
                        responsive: true,
                        legend: {
                            position: 'bottom',
                            labels: {
                                boxWidth: 3,
                                padding: 30
                            }
                        },
                        scales: {
                            yAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Transaction Count'
                                    },
                                }],
                            xAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: this.cLineXName,
                                    },
                                }]
                        }
                    };
                }
                // Doughnut Chart
                if (this.sCheck.isNotNullList(mCommonResponse.data['TransactionSummaryList'])) {
                    this.cTransactionSummaryProcEntity = mCommonResponse.data['TransactionSummaryList'][0];
                }
                this.cSuccTransByPaymentTypeProcEntity = mCommonResponse.data['SuccTransByPaymentTypeList'];
                this.cPayTypeLabels = mCommonResponse.data['paymentType'];
                this.cPayTypeData = mCommonResponse.data['paymentTypeData'];
                this.cPayAreaData = [];
                if (this.sCheck.isNotNullObject(this.cPayTypeLabels)) {
                    for (let i = (this.cPayTypeLabels.length - 1); i >= 0; i--) {
                        if (this.cPayTypeData[i] != 0) {
                            this.cPayAreaData.push({ label: this.cPayTypeLabels[i], value: this.cPayTypeData[i], color: this.cPayTypeColors[i], data: this.cSuccTransByPaymentTypeProcEntity[i].totalSales + '(' + this.cSuccTransByPaymentTypeProcEntity[i].perRatio + '%)' });
                        }
                    }
                }
                if (this.sCheck.isNotNullObject(this.cTransactionSummaryProcEntity)) {
                    this.cTransSummData = [this.cTransactionSummaryProcEntity.pcTrn, this.cTransactionSummaryProcEntity.mobileTrn, this.cTransactionSummaryProcEntity.phonepayTrn];
                }
                //RevenueAnalysis
                this.cRevenueAnalysisProcEntity = mCommonResponse.data['RevenueAnalysisList'];
                //GstInfo popup
                if (this.sCheck.isNotNullObject(mCommonResponse.data['isGstInfoUpdated'])) {
                    let isGstInfoUpdated = mCommonResponse.data['isGstInfoUpdated'];
                    if (!isGstInfoUpdated) {
                        let mGstMerchInfo = mCommonResponse.data['merchantData'];
                        this.cModalRef = this.sModalService.show(GstDetailsComponent, { ignoreBackdropClick: true });
                        this.cModalRef.content.cGstMerchInfo = mGstMerchInfo;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
};
DashboardComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-dashboard',
        templateUrl: './dashboard.component.html',
        styleUrls: ['./dashboard.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        ConditionalCheckService,
        DashboardService,
        AlertMessageService,
        ErrorMessagesService,
        ChangeDetectorRef,
        BsModalService,
        TitleService])
], DashboardComponent);
export { DashboardComponent };
//# sourceMappingURL=dashboard.component.js.map