import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { DashboardService } from './dashboard.service';
import { ConditionalCheckService } from './../../../common-services/conditional-check.service';
let DashboardResolverService = class DashboardResolverService {
    constructor(sDashboardService, sCheck) {
        this.sDashboardService = sDashboardService;
        this.sCheck = sCheck;
    }
    resolve(route, state) {
        let mFirstRequest = false;
        if (this.sCheck.isNotNullObject(route.queryParams)) {
            if (this.sCheck.isNotNullString(route.queryParams.firstRequest)) {
                if (route.queryParams.firstRequest == 'Y') {
                    mFirstRequest = true;
                }
            }
        }
        return this.sDashboardService.fetchTransactionStatus({ 'searchDuration': 'TODAY', 'firstRequest': mFirstRequest }).take(1).pipe(map((pCommonResponse) => {
            return pCommonResponse;
        }), catchError(error => {
            console.log(error);
            return Observable.throw(error);
        }));
    }
};
DashboardResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DashboardService,
        ConditionalCheckService])
], DashboardResolverService);
export { DashboardResolverService };
//# sourceMappingURL=dashboard-resolver.service.js.map