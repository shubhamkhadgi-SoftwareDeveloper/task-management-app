import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators } from '@angular/forms';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { DashboardService } from '../dashboard.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
let GstDetailsComponent = class GstDetailsComponent {
    constructor(cdr, sModalRef, sCheck, sFormBuilder, sErrorHandler, sErrorMessages, sAlertMessage, sDashboardService) {
        this.cdr = cdr;
        this.sModalRef = sModalRef;
        this.sCheck = sCheck;
        this.sFormBuilder = sFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessages = sErrorMessages;
        this.sAlertMessage = sAlertMessage;
        this.sDashboardService = sDashboardService;
    }
    ngOnInit() {
        this.createForm();
        this.cForm.get('isRegUnderGst').valueChanges.subscribe((isRegUnderGst) => {
            if (isRegUnderGst === 'Y') {
                this.cForm.get('gstNo').setValidators([Validators.required, Validators.maxLength(15), CustomValidator.gstNo]);
            }
            else if (isRegUnderGst === 'N') {
                //Gst number
                this.cForm.get('gstNo').setValue('');
                this.cForm.get('gstNo').markAsUntouched();
                this.cForm.get('gstNo').markAsPristine();
                this.cForm.get('gstNo').setValidators([]);
                this.cForm.get('gstNo').clearValidators();
            }
            this.cForm.get('gstNo').updateValueAndValidity();
        });
    }
    createForm() {
        this.cForm = this.sFormBuilder.group({
            isRegUnderGst: ['Y'],
            gstNo: ['', [Validators.required, Validators.maxLength(15), CustomValidator.gstNo]],
        });
    }
    onSubmitClick() {
        if (this.cForm.valid) {
            let mGstNo = 'N';
            if (this.cForm.get('isRegUnderGst').value == 'Y') {
                mGstNo = this.cForm.get('gstNo').value;
            }
            this.sDashboardService.updateGstNo({ 'gstNo': mGstNo })
                .subscribe(pResponse => this.updateGstNoSuccess(pResponse), pError => { console.log(this.sErrorMessages.errorResponse); });
        }
        else {
            CustomValidator.validateAllFields(this.cForm);
        }
    }
    updateGstNoSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessage.popupAlertMsg(mCommonResponse.messageDesc);
                this.sModalRef.hide();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.cForm);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessage.popupAlertMsg(mCommonResponse.messageDesc);
                this.sModalRef.hide();
            }
            else {
                this.sAlertMessage.popupAlertMsg(this.sErrorMessages.responseNull);
                this.sModalRef.hide();
            }
        }
        else {
            this.sAlertMessage.popupAlertMsg(this.sErrorMessages.responseNull);
            this.sModalRef.hide();
        }
    }
    //***********************************************Life Hooks Event*******************************************//
    ngDoCheck() {
        this.cdr.detectChanges();
    }
};
GstDetailsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-gst-details',
        templateUrl: './gst-details.component.html',
        styleUrls: ['./gst-details.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        BsModalRef,
        ConditionalCheckService,
        FormBuilder,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        DashboardService])
], GstDetailsComponent);
export { GstDetailsComponent };
//# sourceMappingURL=gst-details.component.js.map