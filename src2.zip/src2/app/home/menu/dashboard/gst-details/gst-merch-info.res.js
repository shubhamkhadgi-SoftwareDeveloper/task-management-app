export class GstMerchInfo {
}
//# sourceMappingURL=gst-merch-info.res.js.map