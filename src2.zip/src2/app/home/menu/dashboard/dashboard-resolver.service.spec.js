import { TestBed, inject } from '@angular/core/testing';
import { DashboardResolverService } from './dashboard-resolver.service';
describe('DashboardResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DashboardResolverService]
        });
    });
    it('should be created', inject([DashboardResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=dashboard-resolver.service.spec.js.map