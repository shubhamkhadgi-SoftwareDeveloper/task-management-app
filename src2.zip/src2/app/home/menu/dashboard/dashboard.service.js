import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../common-services/api-request.service';
let DashboardService = class DashboardService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'dashboard/';
        this.cFetchTransactionStatusUrl = this.cBaseUrl + 'fetchTransactionStatus';
        this.cUpdateGstNoUrl = this.cBaseUrl + 'updateGstNo';
    }
    fetchTransactionStatus(pFetchTransactionStatusReq) {
        return this.pApiRequestService.httpPostRequest(pFetchTransactionStatusReq, this.cFetchTransactionStatusUrl);
    }
    updateGstNo(pUpdateGstNoReq) {
        return this.pApiRequestService.httpPostRequest(pUpdateGstNoReq, this.cUpdateGstNoUrl);
    }
};
DashboardService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], DashboardService);
export { DashboardService };
//# sourceMappingURL=dashboard.service.js.map