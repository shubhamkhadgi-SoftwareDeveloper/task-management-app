export class MerchantLoginResDTO {
}
//# sourceMappingURL=merchant-login.res.js.map