import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { QrCodeComponent } from './qr-code/qr-code.component';
import { DiscountCouponsComponent } from './discount-coupons/discount-coupons.component';
import { NewDiscountCouponComponent } from './discount-coupons/new-discount-coupon/new-discount-coupon.component';
import { EditDiscountCouponComponent } from './discount-coupons/edit-discount-coupon/edit-discount-coupon.component';
import { DiscountCouponTransactionsComponent } from './discount-coupons/discount-coupon-transactions/discount-coupon-transactions.component';
import { PromotionsComponent } from './promotions/promotions.component';
import { CreateNewPromotionComponent } from './promotions/create-new-promotion/create-new-promotion.component';
import { EditPromotionComponent } from './promotions/edit-promotion/edit-promotion.component';
import { PromotionTransactionsComponent } from './promotions/promotion-transactions/promotion-transactions.component';
import { CcavenueSnipComponent } from './ccavenue-snip/ccavenue-snip.component';
import { CreateNewSnipCompaignComponent } from './ccavenue-snip/create-new-snip-compaign/create-new-snip-compaign.component';
import { EditSnipCompaignComponent } from './ccavenue-snip/edit-snip-compaign/edit-snip-compaign.component';
import { CcavenueSnipTransactionsComponent } from './ccavenue-snip/ccavenue-snip-transactions/ccavenue-snip-transactions.component';
//Resolver - services
import { DiscountCouponsResolverService } from './discount-coupons/discount-coupons-resolver.service';
import { EditDiscountCouponResolverService } from './discount-coupons/edit-discount-coupon/edit-discount-coupon-resolver.service';
import { DiscountCouponTransactionsResolverService } from './discount-coupons/discount-coupon-transactions/discount-coupon-transactions-resolver.service';
import { PromotionsResolverService } from './promotions/promotions-resolver.service';
import { EditPromotionResolverService } from './promotions/edit-promotion/edit-promotion-resolver.service';
import { PromotionTransactionsResolverService } from './promotions/promotion-transactions/promotion-transactions-resolver.service';
import { CcavenueSnipResolverService } from './ccavenue-snip/ccavenue-snip-resolver.service';
import { EditSnipResolverService } from './ccavenue-snip/edit-snip-compaign/edit-snip-resolver.service';
import { SnipTransactionsResolverService } from './ccavenue-snip/ccavenue-snip-transactions/snip-transactions-resolver.service';
import { CreateNewSnipResolverService } from './ccavenue-snip/create-new-snip-compaign/create-new-snip-resolver.service';
//API - services
import { DiscountCouponsService } from './discount-coupons/discount-coupons.service';
import { PromotionsService } from './promotions/promotions.service';
import { CcavenueSnipService } from './ccavenue-snip/ccavenue-snip.service';
import { CreateNewSnipService } from './ccavenue-snip/create-new-snip-compaign/create-new-snip.service';
import { SocialStreamsService } from '../settings/social-streams/social-streams.service';
const routes = [
    { path: 'qrCode', component: QrCodeComponent },
    { path: 'discountCoupons', component: DiscountCouponsComponent, resolve: { commonResponse: DiscountCouponsResolverService } },
    { path: 'discountCoupons/newDiscountCoupon', component: NewDiscountCouponComponent },
    { path: 'discountCoupons/editDiscountCoupon', component: EditDiscountCouponComponent, resolve: { commonResponse: EditDiscountCouponResolverService } },
    { path: 'discountCoupons/discountCouponTransactions', component: DiscountCouponTransactionsComponent, resolve: { commonResponse: DiscountCouponTransactionsResolverService } },
    { path: 'promotions', component: PromotionsComponent, resolve: { commonResponse: PromotionsResolverService } },
    { path: 'promotions/createNewPromotion', component: CreateNewPromotionComponent },
    { path: 'promotions/editPromotion', component: EditPromotionComponent, resolve: { commonResponse: EditPromotionResolverService } },
    { path: 'promotions/promotionTransactions', component: PromotionTransactionsComponent, resolve: { commonResponse: PromotionTransactionsResolverService } },
    { path: 'ccavenueSnip', component: CcavenueSnipComponent, resolve: { commonResponse: CcavenueSnipResolverService } },
    { path: 'ccavenueSnip/createNewSnipCompaign', component: CreateNewSnipCompaignComponent, resolve: { commonResponse: CreateNewSnipResolverService } },
    { path: 'ccavenueSnip/editSnipCompaign', component: EditSnipCompaignComponent, resolve: { commonResponse: EditSnipResolverService } },
    { path: 'ccavenueSnip/snipTransactions', component: CcavenueSnipTransactionsComponent, resolve: { commonResponse: SnipTransactionsResolverService } },
    { path: '', redirectTo: 'qrCode', pathMatch: 'full' },
    { path: '**', component: QrCodeComponent }
];
let MarketingToolsRoutingModule = class MarketingToolsRoutingModule {
};
MarketingToolsRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [DiscountCouponsService, DiscountCouponsResolverService, EditDiscountCouponResolverService, DiscountCouponTransactionsResolverService,
            PromotionsService, PromotionsResolverService, EditPromotionResolverService, PromotionTransactionsResolverService,
            CcavenueSnipService, CcavenueSnipResolverService, EditSnipResolverService, SnipTransactionsResolverService,
            SocialStreamsService, CreateNewSnipService, CreateNewSnipResolverService]
    })
], MarketingToolsRoutingModule);
export { MarketingToolsRoutingModule };
export const MarketingToolsRoutedComponents = [
    QrCodeComponent,
    DiscountCouponsComponent, NewDiscountCouponComponent,
    EditDiscountCouponComponent, DiscountCouponTransactionsComponent,
    PromotionsComponent, CreateNewPromotionComponent,
    EditPromotionComponent, PromotionTransactionsComponent,
    CcavenueSnipComponent, CreateNewSnipCompaignComponent,
    EditSnipCompaignComponent, CcavenueSnipTransactionsComponent
];
//# sourceMappingURL=marketing-tools.routing.js.map