import { async, TestBed } from '@angular/core/testing';
import { DiscountCouponTransactionsComponent } from './discount-coupon-transactions.component';
describe('DiscountCouponTransactionsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [DiscountCouponTransactionsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(DiscountCouponTransactionsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=discount-coupon-transactions.component.spec.js.map