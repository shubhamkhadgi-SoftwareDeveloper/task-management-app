import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DiscountCouponRes } from '../discount-coupon-res';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
let DiscountCouponTransactionsComponent = class DiscountCouponTransactionsComponent {
    constructor(pActivatedRoute, pLocation, sCheck) {
        this.pActivatedRoute = pActivatedRoute;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.cCurrentDate = new Date();
        this.cDiscountCouponRes = new DiscountCouponRes();
    }
    ngOnInit() {
        this.pActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cCommonResponse = data.commonResponse;
            }
        });
        this.pActivatedRoute.queryParams.subscribe(param => this.fetchQueryParam(param));
        window.scrollTo(0, 0);
    }
    fetchQueryParam(pParam) {
        this.cDiscountCouponRes.discountCoupon.couponCode = pParam.couponCode;
        this.cDiscountCouponRes.couponStartDateTime = pParam.startDate;
        this.cDiscountCouponRes.couponEndDateTime = pParam.endDate;
        this.cDiscountCouponRes.discountCoupon.couponEnabled = pParam.couponStatus;
        this.cCouponId = pParam.couponId;
        this.cValidity = pParam.validity;
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
    }
};
DiscountCouponTransactionsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-discount-coupon-transactions',
        templateUrl: './discount-coupon-transactions.component.html',
        styleUrls: ['./discount-coupon-transactions.component.css'],
    }),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        Location,
        ConditionalCheckService])
], DiscountCouponTransactionsComponent);
export { DiscountCouponTransactionsComponent };
//# sourceMappingURL=discount-coupon-transactions.component.js.map