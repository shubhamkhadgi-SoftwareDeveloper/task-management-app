import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { TransactionReq } from '../../../transactions/transactions/transaction.req';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
let DiscountCouponTransactionsResolverService = class DiscountCouponTransactionsResolverService {
    constructor(pTransactionsService, pMerchInfoService) {
        this.pTransactionsService = pTransactionsService;
        this.pMerchInfoService = pMerchInfoService;
    }
    resolve(route, state) {
        let mTransactionReq = new TransactionReq();
        mTransactionReq.searchRegId = this.pMerchInfoService.getRegId().toString();
        mTransactionReq.couponId = route.queryParams.couponId;
        mTransactionReq.moduleName = 'DiscountCoupon';
        return this.pTransactionsService.fetchTransList(mTransactionReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
DiscountCouponTransactionsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [TransactionsService,
        MerchInfoService])
], DiscountCouponTransactionsResolverService);
export { DiscountCouponTransactionsResolverService };
//# sourceMappingURL=discount-coupon-transactions-resolver.service.js.map