import { TestBed, inject } from '@angular/core/testing';
import { DiscountCouponTransactionsResolverService } from './discount-coupon-transactions-resolver.service';
describe('DiscountCouponTransactionsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DiscountCouponTransactionsResolverService]
        });
    });
    it('should be created', inject([DiscountCouponTransactionsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=discount-coupon-transactions-resolver.service.spec.js.map