import { async, TestBed } from '@angular/core/testing';
import { DiscountCouponsComponent } from './discount-coupons.component';
describe('DiscountCouponsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [DiscountCouponsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(DiscountCouponsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=discount-coupons.component.spec.js.map