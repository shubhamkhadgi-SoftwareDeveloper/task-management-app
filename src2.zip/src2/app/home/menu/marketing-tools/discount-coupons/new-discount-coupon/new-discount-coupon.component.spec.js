import { async, TestBed } from '@angular/core/testing';
import { NewDiscountCouponComponent } from './new-discount-coupon.component';
describe('NewDiscountCouponComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [NewDiscountCouponComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(NewDiscountCouponComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=new-discount-coupon.component.spec.js.map