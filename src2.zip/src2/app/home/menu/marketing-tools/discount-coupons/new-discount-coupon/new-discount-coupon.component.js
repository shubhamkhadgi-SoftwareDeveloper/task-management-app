import * as tslib_1 from "tslib";
import { Component, HostListener, ChangeDetectorRef, ElementRef, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { DiscountCouponsService } from '../discount-coupons.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { DiscountCoupons } from '../discount-coupons.class';
import { DiscountCouponReq } from '../discount-coupon-req';
import { CommonResponse, CustomResponseCode } from '../../../../../common-response/common-response.res';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { WINDOW } from "../../../../../common-services/window.service";
import { DOCUMENT } from '@angular/common';
let NewDiscountCouponComponent = class NewDiscountCouponComponent {
    constructor(elementRef, cdr, http, pMerchInfoService, pDiscountCouponsService, pLocation, pFormBuilder, sErrorHandler, sErrorMessagesService, sCheck, sAlertMessageService, document, window) {
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.http = http;
        this.pMerchInfoService = pMerchInfoService;
        this.pDiscountCouponsService = pDiscountCouponsService;
        this.pLocation = pLocation;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.document = document;
        this.window = window;
        this.isGlobalLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = false;
        this.checkValidate = false;
        this.cValidateCoupon = false;
        this.cProductPrice = 0;
        this.isCommonInValid = false;
        this.cScrolling = false;
        this.cProductList = [];
        this.cDiscountCoupons = new DiscountCoupons();
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.isCommonInValid = false;
    }
    blockPaste(e) {
        e.preventDefault();
    }
    //    @HostListener('copy', ['$event']) blockCopy(e: KeyboardEvent) {
    //        e.preventDefault();
    //    }
    blockCut(e) {
        e.preventDefault();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.isGlobalLimitCheck = true;
        this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
        this.mForm.controls['couponGlobalLimit'].disable();
        this.isUserLimitCheck = true;
        this.cDiscountCouponReq.couponLimit = 'Infinite';
        this.mForm.controls['couponLimit'].disable();
        this.radioSelectedValue = 'Y';
        this.selectProduct();
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            couponCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20), InvoiceSettingsValidator.isBeginSpecialChar, InvoiceSettingsValidator.isEndSpecialChar, InvoiceSettingsValidator.letterAndNumberOnly], this.validateCouponCode.bind(this)],
            couponGlobalLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponStartDateTime: ['', Validators.required],
            couponEndDateTime: ['', Validators.required],
            couponCurrency: ['', Validators.required],
            discountType: ['', Validators.required],
            couponValue: [''],
            couponMethod: [''],
            couponMinOrderAmount: [''],
            couponProductId: [''],
            couponMaxDiscount: [''],
            radioSelectedValue: ['Y', Validators.required],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
        }, {
            validator: Validators.compose([this.validateLimit])
        });
    }
    validateAmount(value) {
        let isCoupanMethodSel = this.sCheck.isNotNullString(this.mForm.controls['couponMethod'].value);
        if (this.sCheck.isNullString(this.mForm.get('couponValue').value) && this.cDiscountTypeSelect != 'SHIP') {
            if (this.cDiscountTypeSelect == 'FLAT') {
                this.isCommonInValid = true;
            }
            else if (this.cDiscountTypeSelect == 'PERC') {
                this.isCommonInValid = true;
            }
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'FLAT') {
            this.isCommonInValid = true;
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'PERC') {
            this.isCommonInValid = true;
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'SHIP') {
            this.isCommonInValid = true;
        }
        else {
            this.isCommonInValid = false;
        }
    }
    validateLimit(pFormGroup) {
        var couponGlobalLimit = pFormGroup.controls['couponGlobalLimit'];
        var couponLimit = pFormGroup.controls['couponLimit'];
        let userLimit = +couponLimit.value;
        let globalLimit = +couponGlobalLimit.value;
        if (userLimit > globalLimit) {
            couponLimit.setErrors({ validateLimit: true });
        }
        else if (couponLimit.value == 'Infinite') {
            couponLimit.setErrors({ validateLimit: true });
        }
        return null;
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    validateCouponCode(control) {
        if (!control.value) {
            return null;
        }
        return this.pDiscountCouponsService.checkeDiscountCouponAvailability({ 'couponCode': control.value })
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    return null;
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'validateCouponCode': true };
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                return null;
            }
        });
    }
    validateCouponCodeOnProductId(control) {
        if (!control.value) {
            return null;
        }
        return this.pDiscountCouponsService.checkDiscountCouponAvailabilityOnProductId(this.cDiscountCouponReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        this.cValidateCoupon = true;
                        return { 'validateCoupon': true };
                    }
                    else {
                        this.cValidateCoupon = false;
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    this.cValidateCoupon = true;
                    return { 'validateCoupon': true };
                }
            }
            else {
                this.cValidateCoupon = true;
                return { 'validateCoupon': true };
            }
        });
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAndDotAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    percentagesValue(control) {
        let reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'percentagesValue': true };
    }
    flatValue(control) {
        let reg_exp = /^((\d)*(\.)?(\d)+)$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'flatValue': true };
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
    }
    onCreateCouponClick(event) {
        if (this.mForm.valid) {
            this.cDiscountCouponReq.couponStatus = this.radioSelectedValue;
            this.pDiscountCouponsService.addDiscountCoupon(this.cDiscountCouponReq)
                .subscribe(pResponse => { this.cResponse = pResponse; this.addDiscountCouponSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            if (this.cDiscountCouponReq.couponCode != null || this.cDiscountCouponReq.couponCode != '') {
                this.cValidateCoupon = false;
            }
            this.getFormValidationErrors();
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    selectProduct() {
        this.pDiscountCouponsService.fetchProductNames(this.cDiscountCouponReq.regId)
            .subscribe(pResponse => {
            this.cResponse = pResponse;
            this.fetchProductNamesSuccess(pResponse);
        }, error => { console.log('error'); });
    }
    selectProductCurrencyWise() {
        this.pDiscountCouponsService.fetchProductNames(this.cDiscountCouponReq.regId)
            .subscribe(pResponse => {
            this.cResponse = pResponse;
            this.fetchCurrencyWiseProductSuccess(pResponse);
        }, error => { console.log('error'); });
    }
    onGenerateCodeClick() {
        this.mForm.controls['couponProductId'].setValue(null);
        this.cValidateCoupon = false;
        this.cDiscountCoupons.currDate = new Date();
        this.cDiscountCoupons.currentDate = this.cDiscountCoupons.currDate.getTime();
        this.cDiscountCouponReq.couponCode = this.cDiscountCoupons.couponCode + this.cDiscountCoupons.currentDate;
    }
    onDiscountCouponClick(event) {
        if (event) {
            this.cValidateCoupon = false;
            this.mForm.controls['couponProductId'].setValue(null);
        }
    }
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['couponGlobalLimit'].disable();
            this.cDiscountCouponReq.couponGlobalLimit = null;
            this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
            this.isGlobalLimitCheck = true;
            this.isUserLimitDisabled = false;
        }
        else {
            this.mForm.controls['couponGlobalLimit'].enable();
            this.cDiscountCouponReq.couponGlobalLimit = null;
            this.mForm.controls['couponGlobalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
    }
    onUserLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['couponLimit'].disable();
            this.cDiscountCouponReq.couponLimit = null;
            this.cDiscountCouponReq.couponLimit = 'Infinite';
            this.isUserLimitCheck = true;
        }
        else {
            this.mForm.controls['couponLimit'].enable();
            this.cDiscountCouponReq.couponLimit = null;
            this.mForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
    }
    onGlobalLimitChange() {
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = true;
        this.mForm.controls['couponLimit'].enable();
        this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
    }
    onUserLimitClick() {
        this.mForm.controls['couponLimit'].enable();
        this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
    }
    onDiscountTypeChange(event) {
        if (event) {
            this.cProductPrice = 0;
            this.cValidateCoupon = false;
            this.cDiscountCoupons = new DiscountCoupons();
            this.cDiscountCouponReq.couponValue = null;
            this.cDiscountCouponReq.couponMethod = null;
            this.cDiscountCouponReq.couponMinOrderAmount = null;
            this.cDiscountCouponReq.couponProductId = null;
            this.cDiscountCouponReq.couponMaxDiscount = null;
            this.mForm.controls['couponValue'].patchValue(null);
            this.mForm.controls['couponMethod'].patchValue(null);
            this.mForm.controls['couponMinOrderAmount'].patchValue(null);
            this.mForm.controls['couponProductId'].clearValidators();
            this.mForm.controls['couponProductId'].clearAsyncValidators();
            this.mForm.controls['couponProductId'].updateValueAndValidity();
            this.mForm.controls['couponProductId'].setValue(null);
            this.mForm.controls['couponMaxDiscount'].patchValue(null);
            this.cDiscountTypeSelect = event.value;
            if (this.cDiscountTypeSelect == 'SHIP') {
                this.mForm.controls['couponCurrency'].setValidators([Validators.required]);
                this.mForm.controls['couponCurrency'].markAsTouched({ onlySelf: true });
                this.cDiscountCoupons.couponMethod.splice(2);
                this.mForm.controls['couponMethod'].clearValidators();
                this.mForm.controls['couponMethod'].updateValueAndValidity();
                this.mForm.controls['couponMethod'].setValidators([Validators.required]);
            }
            else if (this.cDiscountTypeSelect == 'FLAT') {
                this.mForm.controls['couponCurrency'].setValidators([Validators.required]);
                this.mForm.controls['couponCurrency'].markAsTouched({ onlySelf: true });
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 999999.99;
                this.mForm.controls['couponMethod'].clearValidators();
                this.mForm.controls['couponMethod'].updateValueAndValidity();
                this.mForm.controls['couponMethod'].setValidators([Validators.required]);
            }
            else if (this.cDiscountTypeSelect == 'PERC') {
                this.mForm.controls['couponCurrency'].setValidators([Validators.required]);
                this.mForm.controls['couponCurrency'].markAsTouched({ onlySelf: true });
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(99.99), Validators.maxLength(5), this.percentagesValue]);
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 99.99;
                this.mForm.controls['couponMethod'].clearValidators();
                this.mForm.controls['couponMethod'].updateValueAndValidity();
                this.mForm.controls['couponMethod'].setValidators([Validators.required]);
            }
        }
        this.isCommonInValid = false;
    }
    onCouponMethodChange(event) {
        if (event) {
            this.cProductPrice = 0;
            this.cValidateCoupon = false;
            this.cCouponMethodSelect = event.value;
            if (this.cCouponMethodSelect == 'Entire Order' && this.cDiscountTypeSelect == 'FLAT') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 999999.99;
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponProductId'].clearValidators();
                this.mForm.controls['couponProductId'].clearAsyncValidators();
                this.mForm.controls['couponProductId'].updateValueAndValidity();
                this.mForm.controls['couponProductId'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValue(null);
            }
            else if (this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'FLAT') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 999999.99;
                this.mForm.controls['couponProductId'].clearValidators();
                this.mForm.controls['couponProductId'].clearAsyncValidators();
                this.mForm.controls['couponProductId'].updateValueAndValidity();
                this.mForm.controls['couponProductId'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValue(null);
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.max(999999.99), this.flatValue]);
            }
            else if (this.cCouponMethodSelect == 'Specific Product' && this.cDiscountTypeSelect == 'FLAT') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 999999.99;
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValue(null);
            }
            else if (this.cCouponMethodSelect == 'Entire Order' && this.cDiscountTypeSelect == 'PERC') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(99.99), Validators.maxLength(5), this.percentagesValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 99.99;
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValidators([Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
            }
            else if (this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'PERC') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(99.99), Validators.maxLength(5), this.percentagesValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 99.99;
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.max(999999.99), this.flatValue]);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValidators([Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
            }
            else if (this.cCouponMethodSelect == 'Specific Product' && this.cDiscountTypeSelect == 'PERC') {
                this.mForm.controls['couponValue'].setErrors(null);
                this.mForm.controls['couponValue'].clearValidators();
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), Validators.max(99.99), Validators.maxLength(5), this.percentagesValue]);
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].markAsTouched();
                this.cDiscountCoupons.minCouponValue = 0.01;
                this.cDiscountCoupons.maxCouponValue = 99.99;
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValidators([Validators.max(999999.99), Validators.maxLength(9), this.flatValue]);
            }
            else if (this.cCouponMethodSelect == 'Entire Order' && this.cDiscountTypeSelect == 'SHIP') {
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValue(null);
            }
            else if (this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'SHIP') {
                this.mForm.controls['couponProductId'].clearValidators();
                this.mForm.controls['couponProductId'].clearAsyncValidators();
                this.mForm.controls['couponProductId'].updateValueAndValidity();
                this.mForm.controls['couponProductId'].setValue(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setValue(null);
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.min(1), Validators.max(999999.99), this.flatValue]);
            }
        }
        this.validateAmount(this.cCouponMethodSelect);
    }
    calculator() {
        let value = +this.cDiscountCouponReq.couponValue;
        let minAmt = 0;
        if (this.cProductPrice != 0) {
            minAmt = this.cProductPrice;
        }
        else {
            minAmt = +this.cDiscountCouponReq.couponMinOrderAmount;
        }
        let maxDisAmt = value / 100;
        maxDisAmt = Number(Math.floor(maxDisAmt * minAmt + 1).toFixed());
        if (maxDisAmt < 1) {
            maxDisAmt = 1;
            this.mForm.controls['couponMaxDiscount'].setValidators(Validators.min(maxDisAmt));
            this.cDiscountCoupons.minMaxDisAmt = maxDisAmt;
        }
        else {
            this.mForm.controls['couponMaxDiscount'].setValidators([Validators.min(maxDisAmt), Validators.max(999999.99), this.flatValue]);
            this.mForm.controls['couponMaxDiscount'].markAsDirty({ onlySelf: true });
            this.mForm.controls['couponMaxDiscount'].markAsTouched({ onlySelf: true });
            this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
            this.cDiscountCoupons.minMaxDisAmt = maxDisAmt;
        }
    }
    clearValue(event, value) {
        if (event && value == 'PERC') {
            this.calculator();
        }
    }
    onCurrencyChange(pEvent) {
        if (pEvent) {
            this.cValidateCoupon = false;
            this.cCouponCurr = pEvent.value;
            this.mForm.controls['couponProductId'].setValue(null);
            this.selectProductCurrencyWise();
        }
    }
    onProductListChange(pEvent, discountType) {
        if (pEvent) {
            this.cProductId = this.mForm.controls['couponProductId'].value;
            this.cCouponCurr = this.mForm.controls['couponCurrency'].value;
            if (this.sCheck.isNotNullList(this.cProduct)) {
                for (let value of this.cProduct) {
                    if (this.cProductId != null && value.productId == this.cProductId) {
                        if (value.productComparePrice != null) {
                            this.cProductPrice = value.productComparePrice;
                            if (discountType == 'FLAT') {
                                let b = this.mForm.controls['couponValue'].value;
                                this.cDiscountCoupons.discountAmt = value.productComparePrice;
                                this.mForm.controls['couponValue'].setErrors(null);
                                if (value.productComparePrice < b) {
                                    this.mForm.controls['couponValue'].setErrors({ validateCouponValue: true });
                                }
                            }
                        }
                        else {
                            this.cProductPrice = value.productPrice;
                            if (discountType == 'FLAT') {
                                let b = this.mForm.controls['couponValue'].value;
                                this.cDiscountCoupons.discountAmt = value.productPrice;
                                this.mForm.controls['couponValue'].setErrors(null);
                                if (value.productPrice < b) {
                                    this.mForm.controls['couponValue'].setErrors({ validateCouponValue: true });
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    onBlur(event) {
        let isCoupanMethodSel = this.sCheck.isNotNullString(this.mForm.controls['couponMethod'].value);
        if (this.sCheck.isNullString(this.mForm.get('couponValue').value) && this.cDiscountTypeSelect != 'SHIP') {
            if (this.cDiscountTypeSelect == 'FLAT') {
                this.isCommonInValid = true;
            }
            else if (this.cDiscountTypeSelect == 'PERC') {
                this.isCommonInValid = true;
            }
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'FLAT') {
            this.isCommonInValid = true;
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'PERC') {
            this.isCommonInValid = true;
        }
        else if (this.sCheck.isNullString(this.mForm.get('couponMinOrderAmount').value) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'SHIP') {
            this.isCommonInValid = true;
        }
        else {
            this.isCommonInValid = false;
        }
        if (event) {
            if (this.cDiscountCouponReq.couponValue != null && this.mForm.controls['couponValue'].valid) {
                let value = +this.cDiscountCouponReq.couponValue;
                this.cDiscountCouponReq.couponValue = value.toFixed(2);
            }
            if (this.sCheck.isNotNullString(this.cDiscountCouponReq.couponMinOrderAmount) && +this.cDiscountCouponReq.couponValue < +this.cDiscountCouponReq.couponMinOrderAmount) {
                let value = +this.cDiscountCouponReq.couponMinOrderAmount;
                this.cDiscountCouponReq.couponMinOrderAmount = value.toFixed(2);
            }
            if (this.cDiscountCouponReq.couponMaxDiscount != null) {
                let value = +this.cDiscountCouponReq.couponMaxDiscount;
                this.cDiscountCouponReq.couponMaxDiscount = value.toFixed(2);
            }
        }
    }
    //***********************************************Select Event*******************************************//
    selectedStartDate(value) {
        this.cDiscountCouponReq.couponStartDateTime = value.start.format("DD-MM-YYYY");
        this.cDiscountCoupons.fromDate = value.start.format("YYYY-MM-DD");
        this.cDiscountCoupons.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.cDiscountCoupons.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(this.cDiscountCoupons.fromDate),
        };
        this.mForm.controls['couponEndDateTime'].setValue(this.cDiscountCouponReq.couponStartDateTime);
    }
    selectedEndDate(value) {
        this.cDiscountCouponReq.couponEndDateTime = value.end.format("DD-MM-YYYY");
        this.cDiscountCoupons.toDate = this.cDiscountCouponReq.couponEndDateTime;
        var date = this.cDiscountCouponReq.couponStartDateTime;
        var datearray = date.split("-");
        this.cDiscountCoupons.fromDate = datearray[1] + '-' + datearray[0] + '-' + datearray[2];
        let changedFormat = datearray[2] + '/' + datearray[1] + '/' + datearray[0] + ' 12:00:00';
        let fromDate = this.cDiscountCoupons.fromDate;
        this.cDiscountCoupons.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.cDiscountCoupons.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(changedFormat),
        };
    }
    //***********************************************Server Call Event*******************************************//
    addDiscountCouponSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.isValidationFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.pLocation.back();
                if (this.sCheck.isNotNullString(mCommonResponse.messageDesc)) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    fetchProductNamesSuccess(pResponse) {
        if (this.cResponse.code === -1 && this.cResponse.message == 'Error') {
            this.cDiscountCoupons.couponMethod.splice(2, 1);
        }
        else if (this.sCheck.isNotNullObject(pResponse)) {
            if (this.sCheck.isNotNullObject(pResponse.data)) {
                this.cProduct = pResponse.data;
                if (this.cProduct == null) {
                    this.cDiscountCoupons.couponMethod.splice(2, 1);
                }
                for (let pProduct of this.cProduct) {
                    if (this.sCheck.isNullList(this.cProductList)) {
                        this.cProductList.push({ label: pProduct.productName, value: pProduct.productId });
                    }
                }
            }
        }
    }
    fetchCurrencyWiseProductSuccess(pResponse) {
        if (this.cResponse.code === -1 && this.cResponse.message == 'Error') {
            this.cDiscountCoupons.couponMethod.splice(2, 1);
        }
        else if (this.sCheck.isNotNullObject(pResponse)) {
            if (this.sCheck.isNotNullObject(pResponse.data)) {
                this.cProduct = pResponse.data;
                if (this.cProduct == null) {
                    this.cDiscountCoupons.couponMethod.splice(2, 1);
                }
                this.cProductList = null;
                this.cProductList = [];
                for (let pProduct of this.cProduct) {
                    if (this.cCouponCurr == pProduct.currId) {
                        this.cProductList.push({ label: pProduct.productName, value: pProduct.productId });
                    }
                }
            }
        }
    }
    getProductList() {
        return this.cProductList;
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.cScrolling = true;
        }
        else {
            this.cScrolling = false;
        }
    }
};
tslib_1.__decorate([
    HostListener('paste', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], NewDiscountCouponComponent.prototype, "blockPaste", null);
tslib_1.__decorate([
    HostListener('cut', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], NewDiscountCouponComponent.prototype, "blockCut", null);
tslib_1.__decorate([
    HostListener('document:click', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", void 0)
], NewDiscountCouponComponent.prototype, "onProductListChange", null);
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], NewDiscountCouponComponent.prototype, "onWindowScroll", null);
NewDiscountCouponComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-new-discount-coupon',
        templateUrl: './new-discount-coupon.component.html',
        styleUrls: ['./new-discount-coupon.component.css'],
        providers: [DiscountCouponsService]
    }),
    tslib_1.__param(11, Inject(DOCUMENT)),
    tslib_1.__param(12, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [ElementRef,
        ChangeDetectorRef,
        HttpClient,
        MerchInfoService,
        DiscountCouponsService,
        Location,
        FormBuilder,
        ErrorHandlerService,
        ErrorMessagesService,
        ConditionalCheckService,
        AlertMessageService,
        Document,
        Window])
], NewDiscountCouponComponent);
export { NewDiscountCouponComponent };
//# sourceMappingURL=new-discount-coupon.component.js.map