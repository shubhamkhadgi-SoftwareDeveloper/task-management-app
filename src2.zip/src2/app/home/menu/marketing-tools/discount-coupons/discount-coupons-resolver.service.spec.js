import { TestBed, inject } from '@angular/core/testing';
import { DiscountCouponsResolverService } from './discount-coupons-resolver.service';
describe('DiscountCouponsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DiscountCouponsResolverService]
        });
    });
    it('should be created', inject([DiscountCouponsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=discount-coupons-resolver.service.spec.js.map