export class DiscountCouponReq {
    constructor() {
        this.numOfRecords = 25;
        this.pageNumber = 1;
    }
}
//# sourceMappingURL=discount-coupon-req.js.map