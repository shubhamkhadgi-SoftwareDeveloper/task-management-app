import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { DiscountCouponReq } from "./discount-coupon-req";
import { DiscountCouponsService } from './discount-coupons.service';
let DiscountCouponsResolverService = class DiscountCouponsResolverService {
    constructor(sDiscountCouponsService, sRouter) {
        this.sDiscountCouponsService = sDiscountCouponsService;
        this.sRouter = sRouter;
    }
    resolve(route, state) {
        let mDiscountCouponReq = new DiscountCouponReq();
        return this.sDiscountCouponsService.fetchAllDiscountCoupons(mDiscountCouponReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
DiscountCouponsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DiscountCouponsService,
        Router])
], DiscountCouponsResolverService);
export { DiscountCouponsResolverService };
//# sourceMappingURL=discount-coupons-resolver.service.js.map