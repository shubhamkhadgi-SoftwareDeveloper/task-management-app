import { DiscountCoupon } from '../../../../entities/discountCoupon';
export class DiscountCouponRes {
    constructor() {
        this.discountCoupon = new DiscountCoupon();
    }
}
//# sourceMappingURL=discount-coupon-res.js.map