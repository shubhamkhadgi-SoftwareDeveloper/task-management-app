import * as tslib_1 from "tslib";
import { Component, HostListener, ChangeDetectorRef, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { DiscountCouponsService } from '../discount-coupons.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../../common-response/common-response.res';
import { DiscountCouponReq } from '../discount-coupon-req';
import { DiscountCouponRes } from '../discount-coupon-res';
import { DiscountCoupons } from '../discount-coupons.class';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { WINDOW } from "../../../../../common-services/window.service";
import { DOCUMENT } from '@angular/common';
let EditDiscountCouponComponent = class EditDiscountCouponComponent {
    constructor(cdr, pActivatedRoute, pLocation, pFormBuilder, pDiscountCouponsService, sAlertMessageService, sCheck, sErrorHandler, sErrorMessagesService, sActivatedRoute, document, window) {
        this.cdr = cdr;
        this.pActivatedRoute = pActivatedRoute;
        this.pLocation = pLocation;
        this.pFormBuilder = pFormBuilder;
        this.pDiscountCouponsService = pDiscountCouponsService;
        this.sAlertMessageService = sAlertMessageService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sActivatedRoute = sActivatedRoute;
        this.document = document;
        this.window = window;
        this.isGlobalLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = false;
        this.isGlobalLimitExceeds = false;
        this.fromDate = null;
        this.cTodaysDate = null;
        this.cScrolling = false;
        this.createForm();
        this.cCommonResponse = new CommonResponse();
        this.cDiscountCoupons = new DiscountCoupons();
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.cDiscountCouponRes = new DiscountCouponRes();
    }
    blockPaste(e) {
        e.preventDefault();
    }
    blockCut(e) {
        e.preventDefault();
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.fetchAllDiscountCouponsSuccess(data.commonResponse);
        });
        this.disableFileds();
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            couponCode: [''],
            couponGlobalLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponStartDateTime: ['', Validators.required],
            couponEndDateTime: ['', Validators.required],
            couponCurrency: [''],
            discountType: [''],
            couponValue: [''],
            couponMethod: [''],
            couponMinOrderAmount: [''],
            couponProductId: [''],
            couponMaxDiscount: [''],
            radioSelectedValue: ['', [Validators.required]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
        }, {
            validator: Validators.compose([this.validateLimit])
        });
    }
    disableFileds() {
        this.mForm.controls['couponCode'].disable();
        this.mForm.controls['couponCurrency'].disable();
        this.mForm.controls['discountType'].disable();
        this.mForm.controls['couponValue'].disable();
        this.mForm.controls['couponMethod'].disable();
        this.mForm.controls['couponMinOrderAmount'].disable();
        this.mForm.controls['couponProductId'].disable();
        this.mForm.controls['couponMaxDiscount'].disable();
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    validateLimit(pFormGroup) {
        var couponGlobalLimit = pFormGroup.controls['couponGlobalLimit'];
        var couponLimit = pFormGroup.controls['couponLimit'];
        let userLimit = +couponLimit.value;
        let globalLimit = +couponGlobalLimit.value;
        if (userLimit > globalLimit) {
            couponLimit.setErrors({ validateLimit: true });
        }
        else if (couponLimit.value == 'Infinite') {
            couponLimit.setErrors({ validateLimit: true });
        }
        return null;
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
    }
    onSaveClick() {
        if (this.mForm.valid) {
            this.pDiscountCouponsService.updateDiscountCoupon(this.cDiscountCouponReq)
                .subscribe(pResponse => this.updateDiscountCouponSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['couponGlobalLimit'].disable();
            this.mForm.controls['couponGlobalLimit'].clearValidators();
            this.mForm.controls['couponGlobalLimit'].updateValueAndValidity();
            this.cDiscountCouponReq.couponGlobalLimit = null;
            this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
            this.isGlobalLimitCheck = true;
            this.isUserLimitDisabled = false;
        }
        else {
            this.mForm.controls['couponGlobalLimit'].enable();
            this.cDiscountCouponReq.couponGlobalLimit = null;
            this.mForm.controls['couponGlobalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
    }
    onUserLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['couponLimit'].disable();
            this.mForm.controls['couponLimit'].clearValidators();
            this.mForm.controls['couponLimit'].updateValueAndValidity();
            this.cDiscountCouponReq.couponLimit = null;
            this.cDiscountCouponReq.couponLimit = 'Infinite';
            this.isUserLimitCheck = true;
        }
        else {
            this.mForm.controls['couponLimit'].enable();
            this.cDiscountCouponReq.couponLimit = null;
            this.mForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
    }
    onGlobalLimitChange() {
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = true;
        this.mForm.controls['couponLimit'].enable();
        this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
    }
    onBlur() {
        if (this.cDiscountCouponRes.pendingCount > this.mForm.controls['couponGlobalLimit'].value) {
            this.isGlobalLimitExceeds = true;
        }
        else {
            this.isGlobalLimitExceeds = false;
        }
    }
    onUserLimitClick() {
        this.mForm.controls['couponLimit'].enable();
        this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
    }
    //***********************************************Select Event*******************************************//
    selectedStartDate(value) {
        this.cDiscountCouponReq.couponStartDateTime = value.start.format("DD-MM-YYYY");
        this.cDiscountCoupons.fromDate = value.start.format("YYYY-MM-DD");
        var date1 = Date.parse(this.cDiscountCoupons.fromDate);
        var date2 = Date.parse(this.cTodaysDate);
        let date3 = null;
        if (date1 < date2) {
            date3 = this.cDiscountCoupons.fromDate;
        }
        else {
            date3 = this.cTodaysDate;
        }
        this.cDiscountCoupons.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(date3),
        };
        this.cDiscountCoupons.endDatePicker = {
            autoApply: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(this.cDiscountCoupons.fromDate),
        };
    }
    selectedEndDate(value) {
        this.cDiscountCouponReq.couponEndDateTime = value.end.format("DD-MM-YYYY");
        this.cDiscountCoupons.toDate = this.cDiscountCouponReq.couponEndDateTime;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllDiscountCouponsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullList(pResponse.data['discountCouponResDTOList'])) {
                    this.cDiscountCouponRes = pResponse.data['discountCouponResDTOList'][0];
                    this.cDiscountCouponReq.couponCode = this.cDiscountCouponRes.discountCoupon.couponCode;
                    this.cDiscountCouponReq.couponId = this.cDiscountCouponRes.discountCoupon.discountCouponId.couponId;
                    if (this.sCheck.isNotNullNumber(this.cDiscountCouponRes.discountCoupon.couponGlobalLimit)) {
                        this.cDiscountCouponReq.couponGlobalLimit = this.cDiscountCouponRes.discountCoupon.couponGlobalLimit.toString();
                        if (this.cDiscountCouponReq.couponGlobalLimit == '-1' || this.cDiscountCouponReq.couponGlobalLimit == 'Infinite') {
                            this.cDiscountCouponReq.couponGlobalLimit = null;
                            this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
                            this.mForm.controls['couponGlobalLimit'].setValue('Infinite');
                            this.mForm.controls['couponGlobalLimit'].disable();
                            this.isGlobalLimitCheck = true;
                        }
                    }
                    if (this.sCheck.isNotNullString(this.cDiscountCouponRes.discountCoupon.couponUserLimit)) {
                        this.cDiscountCouponReq.couponLimit = this.cDiscountCouponRes.discountCoupon.couponUserLimit;
                        if (this.cDiscountCouponReq.couponLimit == '-1' || this.cDiscountCouponReq.couponLimit == 'Infinite') {
                            this.cDiscountCouponReq.couponLimit = null;
                            this.cDiscountCouponReq.couponLimit = 'Infinite';
                            this.mForm.controls['couponLimit'].setValue('Infinite');
                            this.mForm.controls['couponLimit'].disable();
                            this.isUserLimitCheck = true;
                        }
                    }
                    this.cDiscountCouponReq.couponStartDateTime = this.cDiscountCouponRes.couponStartDateTime;
                    var date = this.cDiscountCouponReq.couponStartDateTime;
                    var datearray = date.split("-");
                    this.cDiscountCoupons.fromDate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];
                    var today = new Date();
                    var dd = today.getDate();
                    var ddS = today.getDate().toString();
                    var mm = today.getMonth() + 1; //January is 0
                    var mmS = mm.toString();
                    var yyyy = today.getFullYear();
                    if (dd < 10) {
                        ddS = '0' + dd;
                    }
                    if (mm < 10) {
                        mmS = '0' + mm;
                    }
                    var todayDate = yyyy + '-' + mmS + '-' + ddS;
                    this.cTodaysDate = todayDate;
                    var d1 = Date.parse(this.cDiscountCoupons.fromDate);
                    var d2 = Date.parse(todayDate);
                    if (d1 < d2) {
                        this.fromDate = this.cDiscountCoupons.fromDate;
                    }
                    else {
                        this.fromDate = todayDate;
                    }
                    this.cDiscountCoupons.startDatePicker = {
                        autoApply: true,
                        autoUpdateInput: false,
                        locale: { format: 'DD-MM-YYYY' },
                        alwaysShowCalendars: false,
                        "applyClass": "btn-theme",
                        "cancelClass": "btn-blank",
                        singleDatePicker: true,
                        minDate: new Date(this.fromDate),
                    };
                    if (this.sCheck.isNotNullString(this.cDiscountCouponRes.couponEndDateTime)) {
                        let date1;
                        if (d1 > d2) {
                            date1 = this.cDiscountCoupons.fromDate;
                        }
                        else {
                            date1 = new Date();
                        }
                        this.cDiscountCoupons.toDate = '';
                        this.cDiscountCouponReq.couponEndDateTime = this.cDiscountCouponRes.couponEndDateTime;
                        this.cDiscountCoupons.toDate = this.cDiscountCouponReq.couponEndDateTime;
                        this.cDiscountCoupons.endDatePicker = {
                            autoApply: true,
                            autoUpdateInput: false,
                            locale: { format: 'DD-MM-YYYY' },
                            alwaysShowCalendars: false,
                            "applyClass": "btn-theme",
                            "cancelClass": "btn-blank",
                            singleDatePicker: true,
                            minDate: new Date(date1),
                        };
                    }
                    this.cDiscountCouponReq.couponCurrency = this.cDiscountCouponRes.discountCoupon.couponCurrency;
                    this.cDiscountCouponReq.discountType = this.cDiscountCouponRes.discountCoupon.couponDiscountType;
                    if (this.sCheck.isNotNullNumber(this.cDiscountCouponRes.discountCoupon.couponDiscountvalue)) {
                        this.cDiscountCouponReq.couponValue = this.cDiscountCouponRes.discountCoupon.couponDiscountvalue.toFixed(2);
                    }
                    this.cDiscountCouponReq.couponMethod = this.cDiscountCouponRes.discountCoupon.couponDiscountMethod;
                    if (this.sCheck.isNotNullNumber(this.cDiscountCouponRes.discountCoupon.couponMinimumOrderAmount)) {
                        this.cDiscountCouponReq.couponMinOrderAmount = this.cDiscountCouponRes.discountCoupon.couponMinimumOrderAmount.toFixed(2);
                    }
                    if (this.sCheck.isNotNullNumber(this.cDiscountCouponRes.discountCoupon.couponProductId)) {
                        this.cDiscountCouponReq.couponProductId = this.cDiscountCouponRes.discountCoupon.couponProductId.toString();
                    }
                    if (this.sCheck.isNotNullNumber(this.cDiscountCouponRes.discountCoupon.couponMaximumDiscount)) {
                        this.cDiscountCouponReq.couponMaxDiscount = this.cDiscountCouponRes.discountCoupon.couponMaximumDiscount.toFixed(2);
                    }
                    this.cDiscountCouponReq.couponStatus = this.cDiscountCouponRes.discountCoupon.couponEnabled;
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cDiscountCouponRes = null;
            }
            else {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cDiscountCouponRes = null;
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            this.cDiscountCouponRes = null;
        }
    }
    updateDiscountCouponSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.pLocation.back();
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.cScrolling = true;
        }
        else {
            this.cScrolling = false;
        }
    }
};
tslib_1.__decorate([
    HostListener('paste', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], EditDiscountCouponComponent.prototype, "blockPaste", null);
tslib_1.__decorate([
    HostListener('cut', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], EditDiscountCouponComponent.prototype, "blockCut", null);
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], EditDiscountCouponComponent.prototype, "onWindowScroll", null);
EditDiscountCouponComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-edit-discount-coupon',
        templateUrl: './edit-discount-coupon.component.html',
        styleUrls: ['./edit-discount-coupon.component.css'],
        providers: [DiscountCouponsService]
    }),
    tslib_1.__param(10, Inject(DOCUMENT)),
    tslib_1.__param(11, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ActivatedRoute,
        Location,
        FormBuilder,
        DiscountCouponsService,
        AlertMessageService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        ActivatedRoute,
        Document,
        Window])
], EditDiscountCouponComponent);
export { EditDiscountCouponComponent };
//# sourceMappingURL=edit-discount-coupon.component.js.map