import { async, TestBed } from '@angular/core/testing';
import { EditDiscountCouponComponent } from './edit-discount-coupon.component';
describe('EditDiscountCouponComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [EditDiscountCouponComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(EditDiscountCouponComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=edit-discount-coupon.component.spec.js.map