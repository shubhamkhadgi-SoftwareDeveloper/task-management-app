import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { DiscountCouponsService } from '../discount-coupons.service';
import { DiscountCouponReq } from '../discount-coupon-req';
let EditDiscountCouponResolverService = class EditDiscountCouponResolverService {
    constructor(sDiscountCouponsService, sRouter) {
        this.sDiscountCouponsService = sDiscountCouponsService;
        this.sRouter = sRouter;
    }
    resolve(route, state) {
        let mDiscountCouponReq = new DiscountCouponReq();
        mDiscountCouponReq.couponCode = route.queryParams.couponCode;
        return this.sDiscountCouponsService.fetchAllDiscountCoupons(mDiscountCouponReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
EditDiscountCouponResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DiscountCouponsService,
        Router])
], EditDiscountCouponResolverService);
export { EditDiscountCouponResolverService };
//# sourceMappingURL=edit-discount-coupon-resolver.service.js.map