import { TestBed, inject } from '@angular/core/testing';
import { EditDiscountCouponResolverService } from './edit-discount-coupon-resolver.service';
describe('EditDiscountCouponResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [EditDiscountCouponResolverService]
        });
    });
    it('should be created', inject([EditDiscountCouponResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=edit-discount-coupon-resolver.service.spec.js.map