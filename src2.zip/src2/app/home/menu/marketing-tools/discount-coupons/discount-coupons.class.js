export class DiscountCoupons {
    constructor() {
        this.isEditCouponClick = false;
        this.isExportClick = false;
        this.couponCode = 'AVE';
        this.isCurrentDate = false;
        this.isAnyDisCouponCreated = false;
        this.discountType = [];
        this.discountType.push({ label: 'Flat', value: 'FLAT' });
        this.discountType.push({ label: 'Percentage', value: 'PERC' });
        /* this.discountType.push({label: 'Free Shipping' , value: 'SHIP' });*/
        this.dateType = [];
        this.dateType.push({ label: 'Start Date', value: 'startDate' });
        this.dateType.push({ label: 'End Date', value: 'endDate' });
        this.status = [];
        this.status.push({ label: 'Enable', value: 'Y' });
        this.status.push({ label: 'Disable', value: 'P' });
        this.status.push({ label: 'Expired', value: 'Exp' });
        this.couponMethod = [];
        this.couponMethod.push({ label: 'Entire Order', value: 'Entire Order' });
        this.couponMethod.push({ label: 'Orders Over', value: 'Orders Over' });
        this.couponMethodEdit = [];
        this.couponMethodEdit.push({ label: 'Entire Order', value: 'Entire Order' });
        this.couponMethodEdit.push({ label: 'Orders Over', value: 'Orders Over' });
        this.couponMethodEdit.push({ label: 'On Specific Product', value: 'Specific Product' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            opens: 'left',
            showDropdowns: true,
        };
        this.datePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'MMM DD, YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            opens: 'left',
            minDate: new Date(),
        };
        this.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.fromToDate = '';
        this.startEndDate = '';
        this.fromDate = '';
        this.toDate = '';
        this.currDate = new Date();
        this.yesterDaysDate = new Date();
        this.yesterDaysDate.setDate(this.currDate.getDate());
        this.isAnyDisCouponCreated = true;
    }
}
//# sourceMappingURL=discount-coupons.class.js.map