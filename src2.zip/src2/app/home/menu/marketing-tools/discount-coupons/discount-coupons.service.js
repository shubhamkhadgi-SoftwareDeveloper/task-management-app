import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let DiscountCouponsService = class DiscountCouponsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cDiscountCouponsBaseUrl = 'discountCoupons/';
        this.cFetchAllDiscountCouponsUrl = this.cDiscountCouponsBaseUrl + 'fetchAllDiscountCoupons';
        this.cFetchAllDiscountCouponTransactionsUrl = this.cDiscountCouponsBaseUrl + 'fetchAllDiscountCouponTransactions';
        this.cExportExcelAllDiscountCouponsUrl = this.cDiscountCouponsBaseUrl + 'fetchAllDiscountCouponsForExport';
        this.cUpdateDiscountCouponStatusUrl = this.cDiscountCouponsBaseUrl + 'updateDiscountCouponStatus';
        this.cAddDiscountCouponUrl = this.cDiscountCouponsBaseUrl + 'addDiscountCoupon';
        this.cFetchProductNamesUrl = this.cDiscountCouponsBaseUrl + 'fetchProductNames';
        this.cUpdateDiscountCouponUrl = this.cDiscountCouponsBaseUrl + 'updateDiscountCoupon';
        this.cCheckeDiscountCouponAvailability = this.cDiscountCouponsBaseUrl + 'checkDiscountCouponAvailability';
        this.cCheckDiscountCouponAvailabilityOnProductId = this.cDiscountCouponsBaseUrl + 'checkDiscountCouponAvailabilityOnProductId';
    }
    fetchAllDiscountCoupons(pDiscountCouponReq) {
        return this.pApiRequestService.httpPostRequest(pDiscountCouponReq, this.cFetchAllDiscountCouponsUrl);
    }
    fetchAllDiscountCouponTransactions(pTransactionReq) {
        return this.pApiRequestService.httpPostRequest(pTransactionReq, this.cFetchAllDiscountCouponTransactionsUrl);
    }
    exportExcelAllDiscountCouponsUrl(pDiscountCouponReq) {
        return this.pApiRequestService.exportFileRequest(pDiscountCouponReq, this.cExportExcelAllDiscountCouponsUrl, 'DiscountCoupons.xlsx');
    }
    updateDiscountCouponStatus(pDiscountCouponReq) {
        return this.pApiRequestService.httpPostRequest(pDiscountCouponReq, this.cUpdateDiscountCouponStatusUrl);
    }
    addDiscountCoupon(pDiscountCouponReq) {
        return this.pApiRequestService.httpPostRequest(pDiscountCouponReq, this.cAddDiscountCouponUrl);
    }
    updateDiscountCoupon(pDiscountCouponReq) {
        return this.pApiRequestService.httpPostRequest(pDiscountCouponReq, this.cUpdateDiscountCouponUrl);
    }
    fetchProductNames(pRegId) {
        return this.pApiRequestService.httpPostRequest(pRegId, this.cFetchProductNamesUrl);
    }
    checkeDiscountCouponAvailability(pDiscountCouponReq) {
        return this.pApiRequestService.asyncHttpPostRequest(pDiscountCouponReq, this.cCheckeDiscountCouponAvailability);
    }
    checkDiscountCouponAvailabilityOnProductId(pDiscountCouponReq) {
        return this.pApiRequestService.asyncHttpPostRequest(pDiscountCouponReq, this.cCheckDiscountCouponAvailabilityOnProductId);
    }
};
DiscountCouponsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], DiscountCouponsService);
export { DiscountCouponsService };
//# sourceMappingURL=discount-coupons.service.js.map