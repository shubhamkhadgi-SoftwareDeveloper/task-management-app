import * as tslib_1 from "tslib";
import { Component, Inject } from '@angular/core';
import { DOCUMENT, DatePipe } from '@angular/common';
import { DiscountCoupons } from './discount-coupons.class';
import { DiscountCouponReq } from './discount-coupon-req';
import { DiscountCouponsService } from './discount-coupons.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { TitleService } from './../../../../common-services/title.service';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../common-response/common-response.res';
import { ActivatedRoute } from '@angular/router';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { FormBuilder, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { InvoiceSettingsValidator } from '../../invoice/invoice-settings/invoice-settings-validator';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
let DiscountCouponsComponent = class DiscountCouponsComponent {
    //***********************************************Life Hooks Event*******************************************//
    constructor(pDiscountCouponsService, sResponsiveService, sPrivilegeService, sTitleService, sCheck, sLandingPageMsgService, sErrorMessagesService, sActivatedRoute, pMerchInfoService, sAlertMessageService, sModalService, pFormBuilder, sErrorHandler, document) {
        this.pDiscountCouponsService = pDiscountCouponsService;
        this.sResponsiveService = sResponsiveService;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.sCheck = sCheck;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sActivatedRoute = sActivatedRoute;
        this.pMerchInfoService = pMerchInfoService;
        this.sAlertMessageService = sAlertMessageService;
        this.sModalService = sModalService;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.document = document;
        this.cIsWritePrivilege = false;
        this.searchFlag = 'searchform';
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.isSearchPanelClick = false;
        this.isCouponUpdateOnSearch = false;
        this.toDate = '';
        this.fromDate = '';
        this.pendingGlobalCount = 0;
        this.cValidateCoupon = false;
        this.isGlobalLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = false;
        this.isGlobalLimitExceeds = false;
        this.cDiscountCoupons = new DiscountCoupons();
        this.cDiscountCoupons = new DiscountCoupons();
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.DiscountCoupons);
        this.sTitleService.setTitle(this.sTitleService.DiscountCoupons);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        this.cDiscountCoupons.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            showDropdowns: true,
            opens: "left",
        };
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cDiscountCoupons.totalCount = mCommonResponse.data['count'];
                this.totalCount = this.cDiscountCoupons.totalCount;
                this.cDiscountCouponRes = mCommonResponse.data['discountCouponResDTOList'];
                this.cDiscountCoupons.isAnyDisCouponCreated = true;
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.landingPageMsg = this.sLandingPageMsgService.noDiscountCouponYetMsg;
                this.cDiscountCoupons.isAnyDisCouponCreated = false;
            }
        });
        this.isCouponUpdateOnSearch = false;
    }
    ngOnDestroy() {
        console.log("onDestroy");
        if (this.cModalRef)
            this.cModalRef.hide();
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cDiscountCoupons.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onSearchClick() {
        //this.cDiscountCouponReq.couponCode=this.searchCouponCode;
        if (this.cDiscountCouponReq.status == 'Exp') {
            var datePipe = new DatePipe('en-US');
            this.cDiscountCouponReq.couponEndDateTime = datePipe.transform(this.cDiscountCoupons.yesterDaysDate.setDate(this.cDiscountCoupons.currDate.getDate()), 'd-MM-y');
            this.cDiscountCoupons.yesterDaysDate.setDate(this.cDiscountCoupons.currDate.getDate());
        }
        if (this.searchFlag == 'searchform') {
            this.cDiscountCouponReq.pageNumber = 1;
        }
        if (this.cDiscountCouponReq.couponCode != null) {
            this.isCouponUpdateOnSearch = true;
        }
        else {
            this.isCouponUpdateOnSearch = false;
        }
        this.pDiscountCouponsService.fetchAllDiscountCoupons(this.cDiscountCouponReq)
            .subscribe(pResponse => this.fetchAllDiscountCouponsSuccess(pResponse), error => { console.log('error'); });
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.searchFlag = 'searchform';
        // this.searchCouponCode=null;
    }
    onCancelClick() {
        this.cDiscountCouponReq = null;
        this.cDiscountCouponReq = new DiscountCouponReq();
        //this.searchCouponCode=null;
        this.isCouponUpdateOnSearch = false;
        this.cDiscountCouponReq.regId = this.pMerchInfoService.getRegId().toString();
        this.cDiscountCoupons.fromToDate = null;
        // this.cDiscountCoupons.calOptions = {
        //         autoApply: true,
        //         autoUpdateInput: false,
        //         locale: { format: 'DD-MM-YYYY' },
        //         alwaysShowCalendars: false,
        //         "applyClass": "btn-theme",
        //         "cancelClass": "btn-blank",
        //     };
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        //this.searchCouponCode=null;
        this.onSearchClick();
    }
    onExportExcelClick() {
        this.cDiscountCoupons.isExportClick = !this.cDiscountCoupons.isExportClick;
        // this.cDiscountCouponReq.couponCode=this.searchCouponCode;
        this.pDiscountCouponsService.exportExcelAllDiscountCouponsUrl(this.cDiscountCouponReq)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    updateStatus(pEvent, pCouponCode, pCouponEnabled, pCouponCurr, pProductId, pCouponId) {
        this.cDiscountCouponReq.couponCode = pCouponCode;
        this.cDiscountCouponReq.couponCurrency = pCouponCurr;
        this.cDiscountCouponReq.couponProductId = pProductId;
        this.cDiscountCouponReq.couponId = pCouponId;
        if (pEvent) {
            if (pCouponEnabled === 'Y') {
                this.cDiscountCouponReq.couponStatus = 'P';
            }
            else if (pCouponEnabled === 'P') {
                this.cDiscountCouponReq.couponStatus = 'Y';
            }
            this.pDiscountCouponsService.updateDiscountCouponStatus(this.cDiscountCouponReq)
                .subscribe(pResponse => this.updateStatusSuccess(pResponse), error => { console.log('error'); });
            // this.cDiscountCouponReq=null;
            // this.cDiscountCouponReq=new DiscountCouponReq();
            let tempcDiscountCouponReq = this.cDiscountCouponReq;
            this.cDiscountCouponReq = new DiscountCouponReq();
            this.cDiscountCouponReq.couponCode = tempcDiscountCouponReq.couponCode;
            this.cDiscountCouponReq.status = tempcDiscountCouponReq.status;
            this.cDiscountCouponReq.discountType = tempcDiscountCouponReq.discountType;
            this.cDiscountCouponReq.couponStartDateTime = tempcDiscountCouponReq.couponStartDateTime;
            this.cDiscountCouponReq.couponEndDateTime = tempcDiscountCouponReq.couponEndDateTime;
            this.cDiscountCouponReq.dateType = tempcDiscountCouponReq.dateType;
        }
    }
    onCalenderIconClick(dateRangePicker) {
        dateRangePicker.click();
    }
    //***********************************************Select Event************************************************//
    selectedDate(value) {
        this.cDiscountCouponReq.couponStartDateTime = value.start.format("DD-MM-YYYY");
        this.cDiscountCouponReq.couponEndDateTime = value.end.format("DD-MM-YYYY");
        this.cDiscountCoupons.fromToDate = this.cDiscountCouponReq.couponStartDateTime + ' - ' + this.cDiscountCouponReq.couponEndDateTime;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllDiscountCouponsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(pResponse.data)) {
                    this.cDiscountCoupons.totalCount = pResponse.data['count'];
                    this.totalCount = this.cDiscountCoupons.totalCount;
                    console.log("total counts:" + this.totalCount);
                    // this.cRecordFrom=1;
                    // this.cRecordTo=25;
                    this.cDiscountCouponRes = pResponse.data['discountCouponResDTOList'];
                    this.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.landingPageMsg = this.sLandingPageMsgService.noDiscountCouponMsg;
                this.cDiscountCoupons.totalCount = null;
                this.totalCount = this.cDiscountCoupons.totalCount;
                console.log("total counts:" + this.totalCount);
                this.cDiscountCouponRes = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.landingPageMsg = this.sLandingPageMsgService.noDiscountCouponMsg;
                this.cDiscountCoupons.totalCount = null;
                this.totalCount = this.cDiscountCoupons.totalCount;
                console.log("total counts:" + this.totalCount);
                this.cDiscountCouponRes = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.landingPageMsg = this.sLandingPageMsgService.noDiscountCouponMsg;
            this.cDiscountCoupons.totalCount = null;
            this.totalCount = this.cDiscountCoupons.totalCount;
            this.cDiscountCouponRes = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.isSearchPanelClick = false;
            }
        }
    }
    updateStatusSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (pResponse.code == 0 && pResponse.message == 'Success') {
                this.sAlertMessageService.popupAlertMsg(pResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(pResponse.messageDesc);
            }
        }
        if (this.isCouponUpdateOnSearch == true) {
            this.onSearchClick();
            this.cDiscountCouponReq.couponCode = null;
        }
        else {
            this.cDiscountCouponReq.couponCode = null;
            this.onSearchClick();
        }
    }
    onPageChange(event) {
        this.cDiscountCouponReq.numOfRecords = event.cPageSize;
        this.cDiscountCouponReq.pageNumber = event.cPageNo;
        this.searchFlag = 'pageChange';
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        if (this.cDiscountCouponReq.status == 'Exp') {
            var datePipe = new DatePipe('en-US');
            this.cDiscountCouponReq.couponEndDateTime = datePipe.transform(this.cDiscountCoupons.yesterDaysDate.setDate(this.cDiscountCoupons.currDate.getDate()), 'd-MM-y');
            this.cDiscountCoupons.yesterDaysDate.setDate(this.cDiscountCoupons.currDate.getDate());
        }
        if (this.searchFlag == 'searchform') {
            this.cDiscountCouponReq.pageNumber = 1;
        }
        if (this.cDiscountCouponReq.couponCode != null) {
            this.isCouponUpdateOnSearch = true;
        }
        else {
            this.isCouponUpdateOnSearch = false;
        }
        this.pDiscountCouponsService.fetchAllDiscountCoupons(this.cDiscountCouponReq)
            .subscribe(pResponse => this.fetchAllDiscountCouponsSuccess(pResponse), error => { console.log('error'); });
        this.searchFlag = 'searchform';
    }
    //*********************************************** Validation **************************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            couponCode: ['', [Validators.required, Validators.minLength(3), InvoiceSettingsValidator.letterAndNumberOnly, InvoiceSettingsValidator.isBeginSpecialChar, InvoiceSettingsValidator.isEndSpecialChar, InvoiceSettingsValidator.isConsecuSpecialChar, Validators.maxLength(20)], this.validateCouponCode.bind(this)],
            couponGlobalLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9), InvoiceSettingsValidator.numbersOnly]],
            couponLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9), InvoiceSettingsValidator.numbersOnly]],
            couponDate: ['', Validators.required],
            couponCurrency: ['', InvoiceSettingsValidator.isBeginSpecialChar],
            discountType: ['', Validators.required],
            couponValue: ['', [Validators.required, Validators.maxLength(9)]],
            couponMethod: ['', Validators.required],
            couponMinOrderAmount: ['', [Validators.required, Validators.maxLength(9)]],
            couponProductId: [''],
            couponMaxDiscount: ['', [Validators.maxLength(9)]],
            radioSelectedValue: ['Y', Validators.required],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
        }, {
            validator: Validators.compose([this.validateLimit])
        });
    }
    validateLimit(pFormGroup) {
        var couponGlobalLimit = pFormGroup.controls['couponGlobalLimit'];
        var couponLimit = pFormGroup.controls['couponLimit'];
        let userLimit = +couponLimit.value;
        let globalLimit = +couponGlobalLimit.value;
        if (userLimit > globalLimit && globalLimit != 0) {
            couponLimit.setErrors({ validateLimit: true });
        }
        else if (userLimit != 0 && userLimit <= globalLimit) {
            couponLimit.setErrors(null);
        }
        else if (couponGlobalLimit.value == 0 && userLimit != 0) {
            couponLimit.setErrors(null);
        }
        else if (couponGlobalLimit.value == 0 && couponLimit.value == null) {
            couponLimit.setErrors(null);
        }
        // if (userLimit > globalLimit && globalLimit != 0) {
        //     couponLimit.setErrors({ validateLimit: true });
        // } else if (couponLimit.value == 'Infinite') {
        //     couponLimit.setErrors({ validateLimit: true });
        // }
        return null;
    }
    validateAmount() {
        let reg_exp1 = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        let reg_exp2 = /^(\d{1,6}\.\d{1,2}|\d{1,6})$/;
        let reg_exp3 = /^(.\d{1,2})$/;
        let reg_exp4 = /^(\d{1,2}\.)$/;
        const pattern = /[0]/;
        //= /[reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;]/;
        var mDiscountType = this.mForm.controls['discountType'].value;
        var mCouponMethod = this.mForm.controls['couponMethod'].value;
        var mCouponValue = this.mForm.controls['couponValue'].value;
        var mMinValue = this.mForm.controls['couponMinOrderAmount'].value;
        var mMaxValue = this.mForm.controls['couponMaxDiscount'].value;
        let mCouponValueTotal = Number(mCouponValue);
        let mMinValueTotal = Number(mMinValue);
        let mActualMaxValue = Number(mMaxValue);
        var cCouponValue = this.cDiscountCouponReq.couponValue;
        var discountCouponValue = +cCouponValue;
        var couponMinVal = this.cDiscountCouponReq.couponMinOrderAmount;
        var discountCouponMinVal = +couponMinVal;
        var couponMaxVal = this.cDiscountCouponReq.couponMaxDiscount;
        var discountCouponMaxVal = +couponMaxVal;
        this.percAmountValue = Number((Math.round((mMinValueTotal / 100) * mCouponValueTotal + 1)).toFixed(2));
        if (!Number.isNaN(discountCouponMaxVal))
            discountCouponMaxVal = Number((discountCouponMaxVal).toFixed(2));
        // discountCouponMaxVal=Number((Math.round(discountCouponMaxVal)).toFixed(2)); 
        if (mDiscountType === 'FLAT') {
            this.mForm.controls['couponValue'].setErrors(null);
            this.mForm.controls['couponValue'].clearValidators();
            this.mForm.controls['couponValue'].setValidators([Validators.required,
                Validators.maxLength(9)]);
            this.mForm.controls['couponValue'].updateValueAndValidity();
            if (discountCouponValue == 0) {
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01), this.flatValue,
                    Validators.maxLength(9)]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
            }
            else if (Number(this.cDiscountCouponReq.couponValue) > 999999.99) {
                this.mForm.controls['couponValue'].setValidators([Validators.required,
                    Validators.maxLength(9), this.flatValue]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].setErrors({ invalidAmount: true });
            }
            if (mCouponMethod === 'Orders Over') {
                this.mForm.controls['couponMinOrderAmount'].setErrors(null);
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required,
                    Validators.maxLength(9)]);
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                if (discountCouponMinVal == 0 && Number(this.cDiscountCouponReq.couponValue) == 0) {
                    this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                        Validators.maxLength(9)]);
                    this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                    this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                    this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                }
                else if (Number(this.cDiscountCouponReq.couponMinOrderAmount) > 999999.99) {
                    this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                        Validators.maxLength(9), this.flatValue]);
                    this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                    this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                    this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                    this.mForm.controls['couponMinOrderAmount'].setErrors({ invalidAmount: true });
                }
                else if (mCouponValueTotal > mMinValueTotal || mCouponValueTotal == mMinValueTotal) {
                    this.mForm.controls['couponMinOrderAmount'].setErrors({ invalidDiscountAmount: true });
                }
            }
        }
        else if (mDiscountType === 'PERC') {
            this.mForm.controls['couponValue'].setErrors(null);
            this.mForm.controls['couponMaxDiscount'].setErrors(null);
            this.mForm.controls['couponValue'].clearValidators();
            this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.maxLength(9)]);
            this.mForm.controls['couponValue'].updateValueAndValidity();
            if (discountCouponValue == 0) {
                this.mForm.controls['couponValue'].setValidators([Validators.required, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
            }
            else if (Number(this.cDiscountCouponReq.couponValue) > 99.99) {
                this.mForm.controls['couponValue'].setValidators([Validators.required,
                    Validators.maxLength(9)]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
                this.mForm.controls['couponValue'].setErrors({ invalidPercentageRange: true });
            }
            if (mCouponMethod === 'Orders Over') {
                this.mForm.controls['couponMinOrderAmount'].setErrors(null);
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required,
                    Validators.maxLength(9)]);
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMaxDiscount'].setErrors(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].setValidators([Validators.maxLength(9)]);
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                if (discountCouponMinVal == 0) {
                    this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                        Validators.maxLength(9)]);
                    this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                    this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                    this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                }
                else if (Number(this.cDiscountCouponReq.couponMinOrderAmount) > 999999.99) {
                    this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                        Validators.maxLength(9)]);
                    this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                    this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                    this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                    this.mForm.controls['couponMinOrderAmount'].setErrors({ invalidAmount: true });
                }
                if (this.cDiscountCouponReq.couponMaxDiscount.match(pattern) && !this.sCheck.isNotNullNumber(mActualMaxValue)) {
                    console.log("this.cDiscountCouponReq.couponMaxDiscount" + this.cDiscountCouponReq.couponMaxDiscount);
                    console.log("mActualMaxValue" + mActualMaxValue);
                    this.mForm.controls['couponMaxDiscount'].setErrors({ isMaxAmountZero: true });
                }
                else if ((this.percAmountValue > discountCouponMaxVal && discountCouponMaxVal != 0)) {
                    this.mForm.controls['couponMaxDiscount'].setErrors(null);
                    this.mForm.controls['couponMaxDiscount'].setErrors({ invalidMaxAmount: true, });
                }
                else if (Number(this.cDiscountCouponReq.couponMaxDiscount) > 999999.99) {
                    this.mForm.controls['couponMaxDiscount'].setErrors(null);
                    this.mForm.controls['couponMaxDiscount'].setValidators([Validators.maxLength(9), this.flatValue]);
                    this.mForm.controls['couponMaxDiscount'].markAsDirty();
                    this.mForm.controls['couponMaxDiscount'].markAsTouched();
                    this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                    this.mForm.controls['couponMaxDiscount'].setErrors({ invalidAmount: true });
                }
                else {
                    this.mForm.controls['couponMaxDiscount'].setErrors(null);
                }
            }
            else if (mCouponMethod === 'Entire Order') {
                this.mForm.controls['couponMinOrderAmount'].setErrors(null);
                this.mForm.controls['couponMinOrderAmount'].clearValidators();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
                this.mForm.controls['couponMinOrderAmount'].disable();
                this.mForm.controls['couponMaxDiscount'].setErrors(null);
                this.mForm.controls['couponMaxDiscount'].clearValidators();
                this.mForm.controls['couponMaxDiscount'].setValidators([Validators.maxLength(9)]);
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                if (this.cDiscountCouponReq.couponMaxDiscount.match(pattern) && !this.sCheck.isNotNullNumber(mActualMaxValue)) {
                    this.mForm.controls['couponMaxDiscount'].setErrors({ isMaxAmountZero: true });
                }
                else if (Number(this.cDiscountCouponReq.couponMaxDiscount) > 999999.99) {
                    this.mForm.controls['couponMaxDiscount'].setErrors(null);
                    this.mForm.controls['couponMaxDiscount'].setValidators([Validators.maxLength(9), this.flatValue]);
                    this.mForm.controls['couponMaxDiscount'].markAsDirty();
                    this.mForm.controls['couponMaxDiscount'].markAsTouched();
                    this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
                    this.mForm.controls['couponMaxDiscount'].setErrors({ invalidAmount: true });
                }
                else {
                    this.mForm.controls['couponMaxDiscount'].setErrors(null);
                }
            }
        }
    }
    onGlobalLimitTouched(action) {
        if (action === 'Add') {
            this.mForm.controls['couponLimit'].enable();
            this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
        }
        else if (action === 'Edit') {
            this.mEditForm.controls['couponLimit'].enable();
            this.mEditForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
        }
    }
    onBlurAmount() {
        let reg_exp1 = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        var mCouponMethod = this.mForm.controls['couponMethod'].value;
        var mDiscountType = this.mForm.controls['discountType'].value;
        var mCouponValue = this.mForm.controls['couponValue'].value;
        var mMinValue = this.mForm.controls['couponMinOrderAmount'].value;
        var mMaxValue = this.mForm.controls['couponMaxDiscount'].value;
        var cCouponValue = this.cDiscountCouponReq.couponValue;
        var discountCouponValue = +cCouponValue;
        var couponMinVal = this.cDiscountCouponReq.couponMinOrderAmount;
        var discountCouponMinVal = +couponMinVal;
        var couponMaxVal = this.cDiscountCouponReq.couponMaxDiscount;
        var discountCouponMaxVal = +couponMaxVal;
        if (mDiscountType === 'FLAT') {
            if (discountCouponValue != 0 && this.mForm.controls['couponValue'].valid) {
                let value = +this.cDiscountCouponReq.couponValue;
                console.log(value);
                if (!Number.isNaN(value)) {
                    this.cDiscountCouponReq.couponValue = value.toFixed(2);
                }
                this.mForm.controls['couponValue'].setValidators([Validators.required, this.flatValue, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
            }
            if (mCouponMethod === 'Orders Over' && discountCouponMinVal != 0 && this.mForm.controls['couponMinOrderAmount'].valid) {
                let value = +this.cDiscountCouponReq.couponMinOrderAmount;
                if (!Number.isNaN(value) && (value != 0.00 || value != 0)) {
                    this.cDiscountCouponReq.couponMinOrderAmount = value.toFixed(2);
                }
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, this.flatValue, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
            }
        }
        else if (mDiscountType === 'PERC') {
            if (this.cDiscountCouponReq.couponValue != null && Number(this.cDiscountCouponReq.couponValue) != 0 && this.mForm.controls['couponValue'].valid) {
                let value = +this.cDiscountCouponReq.couponValue;
                if (!Number.isNaN(value)) {
                    this.cDiscountCouponReq.couponValue = value.toFixed(2);
                }
                this.mForm.controls['couponValue'].setValidators([Validators.required, this.percentagesValue, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponValue'].markAsDirty();
                this.mForm.controls['couponValue'].markAsTouched();
                this.mForm.controls['couponValue'].updateValueAndValidity();
                if (!this.mForm.controls['couponValue'].value.match(reg_exp1) && this.mForm.controls['couponValue'].valid && this.mForm.controls['couponValue'].value != null) {
                    this.mForm.controls['couponValue'].setErrors({ percentagesValue: true });
                }
            }
            if (mCouponMethod === 'Orders Over' && discountCouponMinVal != 0 && this.mForm.controls['couponMinOrderAmount'].valid) {
                let value = +this.cDiscountCouponReq.couponMinOrderAmount;
                if (!Number.isNaN(value)) {
                    this.cDiscountCouponReq.couponMinOrderAmount = value.toFixed(2);
                }
                this.mForm.controls['couponMinOrderAmount'].setValidators([Validators.required, this.flatValue, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponMinOrderAmount'].markAsDirty();
                this.mForm.controls['couponMinOrderAmount'].markAsTouched();
                this.mForm.controls['couponMinOrderAmount'].updateValueAndValidity();
            }
            if (this.mForm.controls['couponMaxDiscount'].valid && discountCouponMaxVal != 0) {
                let value = +this.cDiscountCouponReq.couponMaxDiscount;
                if (!Number.isNaN(value)) {
                    this.cDiscountCouponReq.couponMaxDiscount = value.toFixed(2);
                }
                this.mForm.controls['couponMaxDiscount'].setValidators([this.flatValue, Validators.min(0.01),
                    Validators.maxLength(9)]);
                this.mForm.controls['couponMaxDiscount'].markAsDirty();
                this.mForm.controls['couponMaxDiscount'].markAsTouched();
                this.mForm.controls['couponMaxDiscount'].updateValueAndValidity();
            }
        }
    }
    onAmountBlur() {
        let reg_exp1 = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        // let reg_exp2 =  /^(\d{1,6}\.\d{1,2}|\d{1,6})$/;
        // let reg_exp3=/^(.\d{1,2}|\d{1,2})$/;
        // let reg_exp4=/^(\d{1,2}\.|\d{1,2})$/;
        // let reg_exp5 = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        // let reg_exp6=/^(\d{1,2})$/;
        var mCouponMethod = this.mForm.controls['couponMethod'].value;
        var mDiscountType = this.mForm.controls['discountType'].value;
        var mCouponValue = this.mForm.controls['couponValue'].value;
        var mMinValue = this.mForm.controls['couponMinOrderAmount'].value;
        var mMaxValue = this.mForm.controls['couponMaxDiscount'].value;
        let mCouponValueTotal = Number(mCouponValue);
        let mMinValueTotal = Number(mMinValue);
        let mActualMaxValue = Number(mMaxValue);
        this.percAmountValue = Number((mMinValueTotal / 100) * mCouponValueTotal);
        if (this.cDiscountCouponReq.couponValue != null && Number(this.cDiscountCouponReq.couponValue) != 0 && this.mForm.controls['discountType'].value == 'PERC' && Number(this.cDiscountCouponReq.couponValue) <= 99.99) {
            this.mForm.controls['couponValue'].setValidators([Validators.required, this.percentagesValue,
                Validators.maxLength(9)]);
            this.mForm.controls['couponValue'].markAsDirty();
            this.mForm.controls['couponValue'].markAsTouched();
            this.mForm.controls['couponValue'].updateValueAndValidity();
            let value = +this.cDiscountCouponReq.couponValue;
            if (!Number.isNaN(value)) {
                this.cDiscountCouponReq.couponValue = value.toFixed(2);
            }
        }
        else if (this.cDiscountCouponReq.couponValue != null && this.mForm.controls['couponValue'].valid && this.mForm.controls['discountType'].value == 'PERC' && Number(this.cDiscountCouponReq.couponValue) > 99.99) {
            this.mForm.controls['couponValue'].setErrors({ invalidPercentageRange: true });
        }
        else if (!this.mForm.controls['couponValue'].value.match(reg_exp1) && this.mForm.controls['discountType'].value == 'PERC' && this.mForm.controls['couponValue'].value != null) {
            this.mForm.controls['couponValue'].setErrors({ percentagesValue: true });
        }
        if (mCouponMethod === 'Orders Over' && this.mForm.controls['discountType'].value == 'PERC' && Number(mMinValue) > 0) {
            let value = +this.cDiscountCouponReq.couponMinOrderAmount;
            this.cDiscountCouponReq.couponMinOrderAmount = value.toFixed(2);
        }
        if (mCouponMethod === 'Orders Over' && this.mForm.controls['discountType'].value == 'FLAT' && mCouponValueTotal < mMinValueTotal && Number(this.cDiscountCouponReq.couponMinOrderAmount) != null) {
            let value = +this.cDiscountCouponReq.couponMinOrderAmount;
            this.cDiscountCouponReq.couponMinOrderAmount = value.toFixed(2);
        }
        else if (mCouponMethod === 'Orders Over' && this.mForm.controls['discountType'].value == 'FLAT' && mCouponValueTotal > mMinValueTotal && (this.sCheck.isNotNullNumber(mCouponValueTotal) && this.sCheck.isNotNullNumber(mMinValueTotal))) {
            this.mForm.controls['couponMinOrderAmount'].setErrors({ invalidDiscountAmount: true });
        }
        if ((this.mForm.controls['discountType'].value == 'PERC' && this.mForm.controls['couponMethod'].value == 'Orders Over') && this.percAmountValue < mActualMaxValue && Number(this.cDiscountCouponReq.couponMaxDiscount) != 0) {
            let value = +this.cDiscountCouponReq.couponMaxDiscount;
            this.cDiscountCouponReq.couponMaxDiscount = value.toFixed(2);
        }
        if ((this.mForm.controls['discountType'].value == 'PERC' && this.mForm.controls['couponMethod'].value == 'Entire Order') && Number(mMaxValue) > 0) {
            let value = +this.cDiscountCouponReq.couponMaxDiscount;
            this.cDiscountCouponReq.couponMaxDiscount = value.toFixed(2);
        }
    }
    validateCouponCode(control) {
        if (!control.value) {
            return null;
        }
        return this.pDiscountCouponsService.checkeDiscountCouponAvailability({ 'couponCode': control.value })
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    return null;
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'validateCouponCode': true };
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                return null;
            }
        });
    }
    validateCouponCodeOnProductId(control) {
        if (!control.value) {
            return null;
        }
        return this.pDiscountCouponsService.checkDiscountCouponAvailabilityOnProductId(this.cDiscountCouponReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        this.cValidateCoupon = true;
                        return { 'validateCoupon': true };
                    }
                    else {
                        this.cValidateCoupon = false;
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    this.cValidateCoupon = true;
                    return { 'validateCoupon': true };
                }
            }
            else {
                this.cValidateCoupon = true;
                return { 'validateCoupon': true };
            }
        });
    }
    getFormValidationErrors(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(key => {
            const controlErrors = pFormGroup.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    onlyNumbersAndDotAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAndLettersAllowed(pEvent) {
        const pattern = /[a-zA-Z0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    flatValue(control) {
        let reg_exp = /^((\d)*(\.)?\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'flatValue': true };
    }
    percentagesValue(control) {
        let reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'percentagesValue': true };
    }
    //***********************************************Button Click Event********************************************//
    onOpenCreatePopupClick(template) {
        this.isUserLimitDisabled = false;
        this.isGlobalLimitCheck = true;
        this.isUserLimitCheck = true;
        this.cDiscountCouponReq = null;
        //this.cDiscountCoupons=null;
        // this.cDiscountCoupons= new DiscountCoupons();
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.createForm();
        this.mForm.controls['isUserLimitCheck'].enable();
        this.mForm.controls['couponMinOrderAmount'].disable();
        this.mForm.controls['couponGlobalLimit'].disable();
        this.mForm.controls['couponLimit'].disable();
        this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
        this.cDiscountCouponReq.couponLimit = 'Infinite';
        var datePipe = new DatePipe('en-US');
        this.cDiscountCouponReq.couponStartDateTime = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.cDiscountCouponReq.couponEndDateTime = datePipe.transform(new Date(), 'dd-MM-yyyy');
        // this.toDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.fromDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.cDiscountCoupons.startEndDate = this.cDiscountCouponReq.couponStartDateTime + ' - ' + this.cDiscountCouponReq.couponEndDateTime;
        this.cModalRef = this.sModalService.show(template, { class: 'modal-sm', keyboard: false, ignoreBackdropClick: true });
    }
    onGenerateCodeClick() {
        this.mForm.controls['couponProductId'].setValue(null);
        this.cValidateCoupon = false;
        this.cDiscountCoupons.currDate = new Date();
        this.cDiscountCoupons.currentDate = this.cDiscountCoupons.currDate.getTime();
        this.cDiscountCouponReq.couponCode = this.cDiscountCoupons.couponCode + this.cDiscountCoupons.currentDate;
    }
    onDiscountTypeChange(event) {
        if (event) {
            this.cDiscountCouponReq.couponCurrency = null;
            this.mForm.controls['couponCurrency'].setValue(null);
            this.cDiscountCouponReq.couponValue = null;
            this.mForm.controls['couponValue'].setValue(null);
        }
    }
    onCouponMethodChange(event) {
        console.log("event value :" + event.value);
        if (event) {
            this.mForm.controls['couponMinOrderAmount'].enable();
            if (event.value == 'Entire Order') {
                this.cDiscountCouponReq.couponMinOrderAmount = null;
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMinOrderAmount'].disable();
            }
            else if (event.value == 'Orders Over') {
                this.cDiscountCouponReq.couponMinOrderAmount = null;
                this.mForm.controls['couponMinOrderAmount'].setValue(null);
                this.mForm.controls['couponMinOrderAmount'].enable();
            }
            if (this.cDiscountCouponReq.discountType == "PERC") {
                this.cDiscountCouponReq.couponMaxDiscount = null;
                this.mForm.controls['couponMaxDiscount'].setValue(null);
            }
        }
    }
    onCreateCouponClick() {
        console.log("this.isUserLimitCheck" + this.isUserLimitCheck + "this.cDiscountCouponReq.couponLimit" + this.cDiscountCouponReq.couponLimit);
        if (this.isUserLimitCheck == false && this.cDiscountCouponReq.couponLimit == null) {
            this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['couponLimit'].enable();
        }
        if (this.mForm.valid) {
            this.cDiscountCouponReq.couponStatus = 'Y';
            this.pDiscountCouponsService.addDiscountCoupon(this.cDiscountCouponReq)
                .subscribe(pResponse => { this.cResponse = pResponse; this.addDiscountCouponSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            // if (this.cDiscountCouponReq.couponCode != null || this.cDiscountCouponReq.couponCode != '') {
            //     this.cValidateCoupon = false;
            // }
            CustomValidator.validateAllFields(this.mForm);
            this.getFormValidationErrors(this.mForm);
        }
        if (this.mForm.valid) {
            this.cModalRef.hide();
        }
    }
    onDiscountCouponClick(event) {
        if (event) {
            this.cValidateCoupon = false;
        }
    }
    selectedStartEndDate(value) {
        this.cDiscountCouponReq.couponStartDateTime = value.start.format("DD-MM-YYYY");
        this.cDiscountCouponReq.couponEndDateTime = value.end.format("DD-MM-YYYY");
        this.cDiscountCoupons.startEndDate = this.cDiscountCouponReq.couponStartDateTime + ' - ' + this.cDiscountCouponReq.couponEndDateTime;
    }
    editClose() {
        this.cDiscountCouponReq = null;
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.isUserLimitDisabled = false;
        this.isGlobalLimitExceeds = false;
        this.cModalRef.hide();
    }
    onCreateClose() {
        this.cDiscountCouponReq = null;
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.cModalRef.hide();
    }
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event, action) {
        if (event) {
            if (action === 'Add') {
                this.mForm.controls['couponGlobalLimit'].disable();
                this.mForm.controls['couponLimit'].disable();
            }
            else if (action === 'Edit') {
                this.isGlobalLimitExceeds = false;
                this.mEditForm.controls['couponGlobalLimit'].disable();
                this.mEditForm.controls['couponGlobalLimit'].clearValidators();
                this.mEditForm.controls['couponGlobalLimit'].updateValueAndValidity();
                this.mEditForm.controls['couponLimit'].disable();
                this.mEditForm.controls['couponLimit'].clearValidators();
                this.mEditForm.controls['couponLimit'].updateValueAndValidity();
            }
            this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
            this.cDiscountCouponReq.couponLimit = 'Infinite';
            if (this.isUserLimitCheck == false)
                this.isUserLimitCheck = true;
            this.isUserLimitDisabled = false;
        }
        else {
            if (action === 'Add') {
                this.mForm.controls['couponGlobalLimit'].enable();
                this.mForm.controls['couponGlobalLimit'].markAsTouched({ onlySelf: true });
                this.mForm.controls['couponGlobalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            }
            else if (action === 'Edit') {
                this.mEditForm.controls['couponGlobalLimit'].enable();
                this.mEditForm.controls['couponGlobalLimit'].markAsTouched({ onlySelf: true });
                this.mEditForm.controls['couponGlobalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            }
            this.cDiscountCouponReq.couponGlobalLimit = null;
            this.cDiscountCouponReq.couponLimit = null;
            this.isUserLimitCheck = false;
            this.isUserLimitDisabled = true;
        }
    }
    onUserLimitCheckBoxClick(event, action) {
        if (event) {
            if (action === 'Add') {
                this.mForm.controls['couponLimit'].disable();
            }
            else if (action === 'Edit') {
                this.mEditForm.controls['couponLimit'].disable();
                this.mEditForm.controls['couponLimit'].clearValidators();
                this.mEditForm.controls['couponLimit'].updateValueAndValidity();
            }
            this.cDiscountCouponReq.couponLimit = null;
            this.cDiscountCouponReq.couponLimit = 'Infinite';
            this.isUserLimitCheck = true;
        }
        else {
            if (action === 'Add') {
                this.mForm.controls['couponLimit'].enable();
                this.mForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            }
            else if (action === 'Edit') {
                this.cDiscountCouponReq.couponLimit = null;
                this.mEditForm.controls['couponLimit'].enable();
                this.mEditForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
                this.mEditForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            }
            this.cDiscountCouponReq.couponLimit = null;
        }
    }
    onGlobalLimitChange(action) {
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = true;
        if (action === 'Add') {
            this.mForm.controls['couponLimit'].enable();
            this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
        else if (action === 'Edit') {
            this.mEditForm.controls['couponLimit'].enable();
            this.mEditForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
            this.mEditForm.controls['couponLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
        }
    }
    onUserLimitClick(action) {
        if (action === 'Add') {
            this.mForm.controls['couponLimit'].enable();
            this.mForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
        }
        else if (action === 'Edit') {
            this.mEditForm.controls['couponLimit'].enable();
            this.mEditForm.controls['couponLimit'].markAsTouched({ onlySelf: true });
        }
    }
    //***********************************************Server Call Event*******************************************//
    addDiscountCouponSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.isValidationFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.cDiscountCouponReq = null;
                this.cDiscountCouponReq = new DiscountCouponReq();
                this.cDiscountCoupons.isAnyDisCouponCreated = true;
                this.onSearchClick();
                this.cRecordFrom = 1;
                this.cRecordTo = 25;
                this.cModalRef.hide();
                if (this.sCheck.isNotNullString(mCommonResponse.messageDesc)) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    //*********************************************** Validation ********************************************//
    creatEditForm() {
        this.mEditForm = this.pFormBuilder.group({
            couponCode: [''],
            couponGlobalLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponLimit: ['', [Validators.required, Validators.min(1), Validators.maxLength(9)]],
            couponDate: ['', Validators.required],
            couponCurrency: [''],
            discountType: [''],
            couponValue: [''],
            couponMethod: [''],
            couponMinOrderAmount: [''],
            couponProductId: [''],
            couponMaxDiscount: ['', [InvoiceSettingsValidator.isConsecuSpecialChar]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
        }, {
            validator: Validators.compose([this.validateLimit])
        });
    }
    //***********************************************Button Click Event********************************************//
    onOpenEditPopupClick(template, object) {
        this.creatEditForm();
        this.cDiscountCouponReq = null;
        this.cDiscountCouponReq = new DiscountCouponReq();
        this.cDiscountCouponReq.couponCode = object.discountCoupon.couponCode;
        this.cDiscountCouponReq.couponId = object.discountCoupon.discountCouponId.couponId;
        if (this.sCheck.isNotNullNumber(object.discountCoupon.couponGlobalLimit)) {
            this.cDiscountCouponReq.couponGlobalLimit = object.discountCoupon.couponGlobalLimit.toString();
            if (this.cDiscountCouponReq.couponGlobalLimit == '-1' || this.cDiscountCouponReq.couponGlobalLimit == 'Infinite') {
                this.cDiscountCouponReq.couponGlobalLimit = null;
                this.cDiscountCouponReq.couponGlobalLimit = 'Infinite';
                this.mEditForm.controls['couponGlobalLimit'].setValue('Infinite');
                this.mEditForm.controls['couponGlobalLimit'].disable();
                this.isGlobalLimitCheck = true;
            }
            else {
                this.isGlobalLimitCheck = false;
            }
        }
        if (this.sCheck.isNotNullString(object.discountCoupon.couponUserLimit)) {
            this.cDiscountCouponReq.couponLimit = object.discountCoupon.couponUserLimit;
            if (this.cDiscountCouponReq.couponLimit == '-1' || this.cDiscountCouponReq.couponLimit == 'Infinite') {
                this.cDiscountCouponReq.couponLimit = null;
                this.cDiscountCouponReq.couponLimit = 'Infinite';
                this.mEditForm.controls['couponLimit'].setValue('Infinite');
                this.mEditForm.controls['couponLimit'].disable();
                this.isUserLimitCheck = true;
            }
            else {
                this.isUserLimitCheck = false;
            }
        }
        var datePipe = new DatePipe('en-US');
        this.cDiscountCouponReq.couponStartDateTime = datePipe.transform(object.couponStartDateTime, 'dd-MM-y');
        this.cDiscountCouponReq.couponEndDateTime = datePipe.transform(object.couponEndDateTime, 'dd-MM-y');
        this.cDiscountCoupons.startEndDate = this.cDiscountCouponReq.couponStartDateTime + ' - ' + this.cDiscountCouponReq.couponEndDateTime;
        this.cDiscountCoupons.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            opens: 'left',
            minDate: new Date()
        };
        this.cDiscountCouponReq.couponCurrency = object.discountCoupon.couponCurrency;
        this.cDiscountCouponReq.discountType = object.discountCoupon.couponDiscountType;
        if (this.sCheck.isNotNullNumber(object.discountCoupon.couponDiscountvalue)) {
            this.cDiscountCouponReq.couponValue = object.discountCoupon.couponDiscountvalue.toFixed(2);
        }
        this.cDiscountCouponReq.couponMethod = object.discountCoupon.couponDiscountMethod;
        if (this.sCheck.isNotNullNumber(object.discountCoupon.couponMinimumOrderAmount)) {
            this.cDiscountCouponReq.couponMinOrderAmount = object.discountCoupon.couponMinimumOrderAmount.toFixed(2);
        }
        if (this.sCheck.isNotNullNumber(object.discountCoupon.couponProductId)) {
            this.cDiscountCouponReq.couponProductId = object.discountCoupon.couponProductId.toString();
        }
        if (this.sCheck.isNotNullNumber(object.discountCoupon.couponMaximumDiscount)) {
            this.cDiscountCouponReq.couponMaxDiscount = object.discountCoupon.couponMaximumDiscount.toFixed(2);
        }
        this.cDiscountCouponReq.couponStatus = object.discountCoupon.couponEnabled;
        if (object.discountCoupon.couponGlobalLimit != -1 || object.discountCoupon.couponGlobalLimit < 0) {
            this.isGlobalLimitExceeds = false;
            this.pendingGlobalCount = object.pendingCount;
        }
        this.disableFileds();
        this.cModalRef = this.sModalService.show(template, { class: 'modal-sm', keyboard: false, ignoreBackdropClick: true });
    }
    disableFileds() {
        this.mEditForm.controls['couponCode'].disable();
        this.mEditForm.controls['couponCurrency'].disable();
        this.mEditForm.controls['discountType'].disable();
        this.mEditForm.controls['couponValue'].disable();
        this.mEditForm.controls['couponMethod'].disable();
        this.mEditForm.controls['couponMinOrderAmount'].disable();
        this.mEditForm.controls['couponProductId'].disable();
        this.mEditForm.controls['couponMaxDiscount'].disable();
    }
    onEditGlobalChange(pEvent) {
        if (pEvent) {
            if (this.sCheck.isNotNullString(this.cDiscountCouponReq.couponGlobalLimit) && Number(this.cDiscountCouponReq.couponGlobalLimit) != 0) {
                if (this.pendingGlobalCount > this.mEditForm.controls["couponGlobalLimit"].value) {
                    console.log("discount coupon value" + this.cDiscountCouponReq.couponGlobalLimit);
                    this.isGlobalLimitExceeds = true;
                }
                else {
                    this.isGlobalLimitExceeds = false;
                }
            }
            else {
                this.isGlobalLimitExceeds = false;
            }
        }
    }
    onSaveClick() {
        if (this.mEditForm.valid && this.isGlobalLimitExceeds == false) {
            console.log("form valid");
            this.pDiscountCouponsService.updateDiscountCoupon(this.cDiscountCouponReq)
                .subscribe(pResponse => this.updateDiscountCouponSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.mEditForm);
            this.getFormValidationErrors(this.mEditForm);
            console.log("form not valid");
        }
        if (this.mEditForm.valid && this.isGlobalLimitExceeds == false) {
            this.cModalRef.hide();
        }
    }
    //***********************************************Server Call Event*******************************************//
    updateDiscountCouponSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cDiscountCouponReq = null;
                this.cDiscountCouponReq = new DiscountCouponReq();
                this.onSearchClick();
                this.cModalRef.hide();
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
};
DiscountCouponsComponent = tslib_1.__decorate([
    Component({
        selector: 'app-discount-coupons',
        templateUrl: './discount-coupons.component.html',
        styleUrls: ['./discount-coupons.component.css'],
        animations: [
            expandOnEnterAnimation({ duration: 500 }),
            collapseOnLeaveAnimation({ duration: 300 }),
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(13, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [DiscountCouponsService,
        ResponsiveService,
        PrivilegeService,
        TitleService,
        ConditionalCheckService,
        LandingPageMsgService,
        ErrorMessagesService,
        ActivatedRoute,
        MerchInfoService,
        AlertMessageService,
        BsModalService,
        FormBuilder,
        ErrorHandlerService,
        Document])
], DiscountCouponsComponent);
export { DiscountCouponsComponent };
//# sourceMappingURL=discount-coupons.component.js.map