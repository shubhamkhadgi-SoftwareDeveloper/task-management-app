import { TestBed, inject } from '@angular/core/testing';
import { DiscountCouponsService } from './discount-coupons.service';
describe('DiscountCouponsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DiscountCouponsService]
        });
    });
    it('should be created', inject([DiscountCouponsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=discount-coupons.service.spec.js.map