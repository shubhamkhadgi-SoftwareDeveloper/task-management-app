export class DiscountCouponResWrapper {
}
//# sourceMappingURL=discount-coupon-res-wrapper.js.map