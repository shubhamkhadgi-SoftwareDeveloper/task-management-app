import { TestBed, inject } from '@angular/core/testing';
import { CcavenueSnipResolverService } from './ccavenue-snip-resolver.service';
describe('CcavenueSnipResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CcavenueSnipResolverService]
        });
    });
    it('should be created', inject([CcavenueSnipResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=ccavenue-snip-resolver.service.spec.js.map