import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../common-response/common-response.res';
import { CcavenueSnipService } from './ccavenue-snip.service';
import { SNIPReq } from './ccavenue-snip.req';
import { SNIP } from './snip.class';
import { CreateNewSNIPReq } from './create-new-snip-compaign/create-new-snip.req';
import { TitleService } from './../../../../common-services/title.service';
let CcavenueSnipComponent = class CcavenueSnipComponent {
    //***********************************************Constructor*******************************************//
    constructor(pMerchInfoService, pCcavenueSnipService, sAlertMessageService, sErrorMessagesService, sCheck, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sErrorHandler, sPrivilegeService, pModalService, sTitleService) {
        this.pMerchInfoService = pMerchInfoService;
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCheck = sCheck;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sErrorHandler = sErrorHandler;
        this.sPrivilegeService = sPrivilegeService;
        this.pModalService = pModalService;
        this.sTitleService = sTitleService;
        this.cCopyLink = '';
        this.searchflag = 'searchform';
        this.cIsWritePrivilege = false;
        this.cSNIPReq = new SNIPReq();
        this.cSNIPReq.regId = this.pMerchInfoService.getRegId();
        this.cSNIP = new SNIP();
        this.cCreateNewSNIPReq = new CreateNewSNIPReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.CCAvenueSNIP);
        this.sTitleService.setTitle(this.sTitleService.CCAvenueSNIP);
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cSNIPProcEntityWrapper = mCommonResponse.data.SNIPResList;
                this.cSNIP.totalCount = mCommonResponse.data.TotalCounts;
                this.cSNIP.txnUrlTiny = mCommonResponse.data.TxnUrlTiny;
                this.cSNIP.isAnyDealCreated = true;
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cSNIP.landingPageMsg = this.sLandingPageMsgService.noSnipRaisedYetMsg;
                this.cSNIP.isAnyDealCreated = false;
            }
        });
    }
    //***********************************************Button Click Event********************************************//
    downloadQRCodeImage() {
        let dataURL = document.getElementById('qrcode');
        this.arr1 = dataURL.innerHTML.valueOf().split("<");
        this.arr2 = this.arr1[2].substring(9).split('"');
        this.arr = this.arr2[0];
    }
    copyToClipboard() { }
    onDeletePopupClick(pDealId, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cDealId = pDealId;
    }
    onConfirmDeleteClick() {
        this.onDeleteSNIPClick(this.cDealId);
    }
    onActionClick(pIndex, pDealId) {
        this.cSNIP.actionIndex = pIndex;
        this.cSNIP.actionPanel = true;
        this.cSNIP.isCopyLinkClick = !this.cSNIP.isCopyLinkClick;
        this.cLink = this.cSNIP.txnUrlTiny + "S" + pDealId;
    }
    onSearchPanelClick() {
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cSNIP.isSearchPanelClick = !this.cSNIP.isSearchPanelClick;
        }
    }
    onSearchClick() {
        if (this.searchflag == 'searchform') {
            this.cSNIPReq.pageNum = 1;
        }
        this.pCcavenueSnipService.fetchSNIPList(this.cSNIPReq)
            .subscribe(pResponse => this.fetchSnipSuccess(pResponse), error => { console.log('error'); });
        this.searchflag = 'searchform';
    }
    onCancelClick() {
        this.cSNIPReq = null;
        this.cSNIPReq = new SNIPReq();
        this.cSNIPReq.regId = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSNIP.isSearchPanelClick = false;
        }
        this.cSNIP = new SNIP();
        this.onSearchClick();
    }
    onDeleteSNIPClick(pDealId) {
        this.cCreateNewSNIPReq.dealId = pDealId;
        this.pCcavenueSnipService.deleteSNIP(this.cCreateNewSNIPReq)
            .subscribe(pResponse => this.deleteSuccess(pResponse), error => { console.log('error'); });
    }
    onUpdateSNIPStatusClick(pEvent, pDealId, pDealStatus) {
        if (pEvent) {
            if (pDealStatus === 'Published') {
                this.cSnipStatus = 'N';
            }
            if (pDealStatus === 'Unpublished') {
                this.cSnipStatus = 'Y';
            }
            this.cCreateNewSNIPReq.dealStatus = this.cSnipStatus;
            this.cCreateNewSNIPReq.dealId = pDealId;
            this.cCreateNewSNIPReq.updSnipStatus = true;
            this.pCcavenueSnipService.updateSNIPStatus(this.cCreateNewSNIPReq)
                .subscribe(pResponse => this.updateSuccess(pResponse), error => { console.log('error'); });
        }
    }
    //***********************************************Server Call Event**********************************************//
    updateSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.onSearchClick();
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    deleteSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.onSearchClick();
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cModalRef.hide();
    }
    fetchSnipSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullList(mCommonResponse.data.SNIPResList)) {
                    this.cSNIPProcEntityWrapper = mCommonResponse.data.SNIPResList;
                    this.cSNIP.totalCount = mCommonResponse.data.TotalCounts;
                    this.cSNIP.txnUrlTiny = mCommonResponse.data.TxnUrlTiny;
                    if (!this.sResponsiveService.isCancelResponsive()) {
                        this.cSNIP.isSearchPanelClick = false;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cSNIPProcEntityWrapper = null;
                this.cSNIP.totalCount = null;
                this.cSNIP.landingPageMsg = this.sLandingPageMsgService.noSnipMsg;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cSNIP.isSearchPanelClick = false;
                }
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
                this.cSNIPProcEntityWrapper = null;
                this.cSNIP.totalCount = null;
                this.cSNIP.landingPageMsg = this.sLandingPageMsgService.noSnipMsg;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cSNIP.isSearchPanelClick = false;
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cSNIPProcEntity = null;
            this.cSNIP.totalCount = null;
            this.cSNIP.landingPageMsg = this.sLandingPageMsgService.noSnipMsg;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cSNIP.isSearchPanelClick = false;
            }
        }
    }
    onPageChange(event) {
        this.cSNIPReq.pageSize = event.cPageSize;
        this.cSNIPReq.pageNum = event.cPageNo;
        this.searchflag = 'pageChange';
        this.onSearchClick();
    }
};
CcavenueSnipComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-ccavenue-snip',
        templateUrl: './ccavenue-snip.component.html',
        styleUrls: ['./ccavenue-snip.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [MerchInfoService,
        CcavenueSnipService,
        AlertMessageService,
        ErrorMessagesService,
        ConditionalCheckService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        ErrorHandlerService,
        PrivilegeService,
        BsModalService,
        TitleService])
], CcavenueSnipComponent);
export { CcavenueSnipComponent };
//# sourceMappingURL=ccavenue-snip.component.js.map