import { async, TestBed } from '@angular/core/testing';
import { CcavenueSnipComponent } from './ccavenue-snip.component';
describe('CcavenueSnipComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CcavenueSnipComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CcavenueSnipComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=ccavenue-snip.component.spec.js.map