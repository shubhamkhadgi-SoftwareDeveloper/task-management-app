export class SNIPReq {
}
//# sourceMappingURL=ccavenue-snip.req.js.map