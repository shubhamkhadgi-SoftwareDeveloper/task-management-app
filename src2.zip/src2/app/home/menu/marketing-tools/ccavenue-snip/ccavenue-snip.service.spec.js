import { TestBed, inject } from '@angular/core/testing';
import { CcavenueSnipService } from './ccavenue-snip.service';
describe('CcavenueSnipService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CcavenueSnipService]
        });
    });
    it('should be created', inject([CcavenueSnipService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=ccavenue-snip.service.spec.js.map