import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { FacebookService } from 'ngx-facebook';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CreateNewSNIPReq } from './create-new-snip.req';
import { CcavenueSnipService } from '../ccavenue-snip.service';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../../common-response/common-response.res';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { CustomFacebookService } from '../../../../../common-services/custom-facebook.service';
import { CreateNewSnipService } from './create-new-snip.service';
import { CreateNewSnip } from './create-new-snip.class';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { SocialStreamsService } from '../../../settings/social-streams/social-streams.service';
import { TwitterPostReqDTO } from './twitter-post-req';
import { GoogleplusPostReq } from './googleplus-post-req';
import { SNIPReq } from '../ccavenue-snip.req';
import { SNIP } from '../snip.class';
let CreateNewSnipCompaignComponent = class CreateNewSnipCompaignComponent {
    constructor(cdr, sActivatedRoute, sFacebook, sCustomFacebookService, pApiRequestService, pLocation, pFormBuilder, pMerchInfoService, pCcavenueSnipService, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, sCreateNewSnipService, pModalService, sSocialStreamsService, pApiEndpoint) {
        this.cdr = cdr;
        this.sActivatedRoute = sActivatedRoute;
        this.sFacebook = sFacebook;
        this.sCustomFacebookService = sCustomFacebookService;
        this.pApiRequestService = pApiRequestService;
        this.pLocation = pLocation;
        this.pFormBuilder = pFormBuilder;
        this.pMerchInfoService = pMerchInfoService;
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCreateNewSnipService = sCreateNewSnipService;
        this.pModalService = pModalService;
        this.sSocialStreamsService = sSocialStreamsService;
        this.pApiEndpoint = pApiEndpoint;
        this.isInfiniteLimitCheck = false;
        this.check = false;
        this.dealImg = null;
        this.cTwitterName = null;
        this.cTwitterImg = null;
        this.cGooglePlusName = null;
        this.cGooglePlusImg = null;
        this.cFBProfileVal = null;
        this.cFBPageVal = null;
        this.cFBPageToken = null;
        this.cFBProfileToken = null;
        this.cDealId = null;
        this.cDealCurrency = null;
        this.cDealPrice = null;
        this.cDealShipping = null;
        this.cPostMsg = null;
        this.cTxnUrlTiny = null;
        this.cIsFileError = false;
        this.cDealFBMsg = null;
        this.cDealFBPageMsg = null;
        this.cDealTwitterMsg = null;
        this.cDealGooglePlusMsg = null;
        this.cCreateNewSNIPReq = new CreateNewSNIPReq();
        this.cCreateNewSNIPReq.regId = this.pMerchInfoService.getRegId();
        this.cCreateNewSnip = new CreateNewSnip();
        this.cCreateNewSNIPReq.dealFacebook = 'N';
        this.cCreateNewSNIPReq.dealFacebookPage = 'N';
        this.cCreateNewSNIPReq.dealTwitter = 'N';
        this.cCreateNewSNIPReq.dealGoogle = 'N';
        this.cCreateNewSNIPReq.dealStatus = 'Y';
        this.cCreateNewSNIPReq.dealType = 'Sale';
        this.cSNIPReq = new SNIPReq();
        this.cCreateNewSNIPReq.dealFbPageMsg;
        this.cSNIP = new SNIP();
        this.cTwitterPostReqDTO = new TwitterPostReqDTO();
        this.cGoogleplusPostReq = new GoogleplusPostReq();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.isInfiniteLimitCheck = true;
        this.cCreateNewSNIPReq.dealQty = 'Infinite';
        this.mCreateForm.controls['dealQty'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    //Configure facebook AppId and version
                    //   if(this.sCheck.isNotNullString(mCommonResponse.data['appId']) && this.sCheck.isNotNullString(mCommonResponse.data['appVersion'])){
                    //Facebook Profile Details
                    if (this.sCheck.isNotNullObject(mCommonResponse.data['Facebook'])) {
                        this.sCustomFacebookService.cFbProfileId = mCommonResponse.data['Facebook'].profileId;
                        this.sCustomFacebookService.cFbProfileName = mCommonResponse.data['Facebook'].profileName;
                        this.sCustomFacebookService.cFbProfilePic = 'https://graph.facebook.com/' + this.sCustomFacebookService.cFbProfileId + '/picture/' + this.sCustomFacebookService.cFbProfileName;
                    }
                    //Facebook Page Details
                    if (this.sCheck.isNotNullObject(mCommonResponse.data['FacebookPage'])) {
                        this.sCustomFacebookService.cFbPageId = mCommonResponse.data['FacebookPage'].fbPageId;
                        this.sCustomFacebookService.cFbPageName = mCommonResponse.data['FacebookPage'].fbPageName;
                        this.sCustomFacebookService.cFbPageCategory = mCommonResponse.data['FacebookPage'].fbPageCategory;
                        this.sCustomFacebookService.cFbPageToken = mCommonResponse.data['FacebookPage'].fbPageToken;
                        this.sCustomFacebookService.cFbPagePic = 'http://graph.facebook.com/' + this.sCustomFacebookService.cFbPageId + '/picture?access_token=' + this.sCustomFacebookService.cFbPageToken;
                    }
                    //Twitter Details
                    if (this.sCheck.isNotNullObject(mCommonResponse.data['Twitter'])) {
                        this.cTwitterName = mCommonResponse.data['Twitter'].name;
                        this.cTwitterImg = mCommonResponse.data['Twitter'].profileimage;
                    }
                    //GooglePlus Details
                    if (this.sCheck.isNotNullObject(mCommonResponse.data['GooglePlus'])) {
                        this.cGooglePlusName = mCommonResponse.data['GooglePlus'].googlePlusProfileName;
                        this.cGooglePlusImg = mCommonResponse.data['GooglePlus'].googlePlusProfileImage;
                    }
                    //}
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
            }
        });
    }
    //***********************************************On Change Event*******************************************//
    onInfiniteLimitCheckBoxClick(event) {
        if (event) {
            this.mCreateForm.controls['dealQty'].disable();
            this.mCreateForm.controls['dealQty'].clearValidators();
            this.mCreateForm.controls['dealQty'].updateValueAndValidity();
            this.cCreateNewSNIPReq.dealQty = null;
            this.cCreateNewSNIPReq.dealQty = 'Infinite';
            this.isInfiniteLimitCheck = true;
        }
        else {
            this.mCreateForm.controls['dealQty'].enable();
            this.cCreateNewSNIPReq.dealQty = null;
            this.mCreateForm.controls['dealQty'].setValidators([
                InvoiceSettingsValidator.integerNumberOnly,
                Validators.required, Validators.min(1),
                Validators.maxLength(9)
            ]);
            this.mCreateForm.controls['dealQty'].updateValueAndValidity();
        }
    }
    onDealTypeChangeClick(pValue) {
        this.cCreateNewSNIPReq.dealType = pValue;
        if (this.cCreateNewSNIPReq.dealType == 'Sale') {
            this.mCreateForm.controls['dealShipping'].setValidators([
                InvoiceSettingsValidator.numbersOnly,
                Validators.required, Validators.min(1),
                Validators.maxLength(9),
                InvoiceSettingsValidator.flatValue
            ]);
            this.mCreateForm.controls['dealShipping'].updateValueAndValidity();
        }
        else if (this.cCreateNewSNIPReq.dealType == 'Donation') {
            this.cCreateNewSNIPReq.dealShipping = null;
            this.mCreateForm.controls['dealShipping'].setValue(null);
            this.mCreateForm.controls['dealShipping'].clearValidators();
            this.mCreateForm.controls['dealShipping'].updateValueAndValidity();
        }
    }
    onBlur(event) {
        if (event) {
            if (this.cCreateNewSNIPReq.dealPrice != null && this.mCreateForm.controls['dealPrice'].valid) {
                let value = +this.cCreateNewSNIPReq.dealPrice;
                this.cCreateNewSNIPReq.dealPrice = value.toFixed(2);
            }
            if (this.cCreateNewSNIPReq.dealShipping != null && this.mCreateForm.controls['dealShipping'].valid) {
                let value = +this.cCreateNewSNIPReq.dealShipping;
                this.cCreateNewSNIPReq.dealShipping = value.toFixed(2);
            } /*else
                this.cCreateNewSNIPReq.dealShipping = '0.00';*/
        }
    }
    customFromToDate(pEvent) {
        const pattern = /^[0-9\s-]+$/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mCreateForm = this.pFormBuilder.group({
            dealTitle: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.snipName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            dealType: [''],
            dealCurrency: ['', [Validators.required]],
            dealPrice: ['', [
                    Validators.required,
                    InvoiceSettingsValidator.numbersOnly,
                    Validators.min(1),
                    Validators.maxLength(10),
                    InvoiceSettingsValidator.flatValue
                ]],
            dealShipping: ['', [
                    InvoiceSettingsValidator.numbersOnly,
                    //Validators.min(1),
                    Validators.maxLength(9),
                    InvoiceSettingsValidator.flatValue
                ]],
            dealQty: ['', [
                    InvoiceSettingsValidator.integerNumberOnly,
                    Validators.required, Validators.min(1),
                    Validators.maxLength(9)
                ]],
            dealAnalytics: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            dealFrom: [''],
            fromTodate: ['', [Validators.required]],
            file: [''],
            isInfiniteLimitCheck: [''],
            dealFbPageMsg: [''],
            dealFbMsg: [''],
            dealTwitterMsg: [''],
            dealGooglePlusMsg: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    getFormValidationErrors() {
        Object.keys(this.mCreateForm.controls).forEach(key => {
            const controlErrors = this.mCreateForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    // console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    //***********************************************Button Click Event*******************************************//
    onRemoveLogoPopupClick(pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    fileChangeEvent(event) {
        let isFileError = false;
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();
            var image = new Image();
            let mError = '';
            this.uploadLogo = event.target.files[0];
            let fileName = this.uploadLogo.name;
            let validExts = [];
            validExts = ['.jpg', '.jpeg', '.png'];
            var fileExt = fileName.substring(fileName.lastIndexOf('.'));
            if (validExts.includes(fileExt)) {
                if (this.uploadLogo.size <= 102400) { //20480
                    this.check = true;
                    reader.onload = (event) => {
                        this.dealImg = event.target.result;
                        /* image.src = event.target.result;
                         image.onload = function() {
                             if(image.width > 250){
                                 isFileError=true;
                             }else{
                                 isFileError=false;
                                 console.log('else img pixel-'+image.width+'value->'+isFileError);
                             }
                         };
                         setTimeout(() => {
                             if(isFileError){
                                 this.cIsFileError=true;
                                 this.onRemoveLogoClick();
                                 this.sAlertMessageService.popupAlertMsg('Image width should not be greater than 250 pixels.');}
                             else{
                                 this.cIsFileError=false;
                             }
                          }, 800 );*/
                    };
                    reader.readAsDataURL(this.uploadLogo);
                }
                else {
                    mError = 'File size should not be greater than 100 KB';
                    this.sAlertMessageService.popupAlertMsg(mError);
                }
            }
            else {
                mError = 'Only jpeg ,jpg & png  files are allowed.';
                this.sAlertMessageService.popupAlertMsg(mError);
            }
        }
    }
    onRemoveLogoClick() {
        this.dealImg = null;
        this.check = false;
        this.cModalRef.hide();
    }
    onSocialMessagePostClick(pSNIPProcEntityWrapper, pTxnUrlTiny) {
        var pTxnUrlTinyWithDealID = pTxnUrlTiny + "S" + pSNIPProcEntityWrapper.snipProcEntity.dealId;
        //FB profile Msg
        if (pSNIPProcEntityWrapper.snipProcEntity.dealFacebook != undefined
            && pSNIPProcEntityWrapper.snipProcEntity.dealFacebook != "N"
            && pSNIPProcEntityWrapper.snipProcEntity.dealFacebook != "") {
            var arr = [] = pSNIPProcEntityWrapper.snipProcEntity.dealFacebook.split(",");
            this.cDealFBMsg = arr[1] + "," + arr[2] + "," + arr[3] + ", " + pTxnUrlTinyWithDealID;
        }
        //FB page Msg
        if (pSNIPProcEntityWrapper.snipProcEntity.dealFacebookPage != undefined
            && pSNIPProcEntityWrapper.snipProcEntity.dealFacebookPage != "N"
            && pSNIPProcEntityWrapper.snipProcEntity.dealFacebookPage != "") {
            var arr = [] = pSNIPProcEntityWrapper.snipProcEntity.dealFacebookPage.split(",");
            this.cDealFBPageMsg = arr[1] + "," + arr[2] + "," + arr[3] + ", " + pTxnUrlTinyWithDealID;
        }
        //Twitter profile Msg
        if (pSNIPProcEntityWrapper.snipProcEntity.dealTwitter != undefined
            && pSNIPProcEntityWrapper.snipProcEntity.dealTwitter != "N"
            && pSNIPProcEntityWrapper.snipProcEntity.dealTwitter != "") {
            var arr = [] = pSNIPProcEntityWrapper.snipProcEntity.dealTwitter.split(",");
            this.cDealTwitterMsg = arr[1] + "," + arr[2] + "," + arr[3] + ", " + pTxnUrlTinyWithDealID;
        }
        //GooglePlus Msg
        if (pSNIPProcEntityWrapper.snipProcEntity.dealGoogle != undefined
            && pSNIPProcEntityWrapper.snipProcEntity.dealGoogle != "N"
            && pSNIPProcEntityWrapper.snipProcEntity.dealGoogle != "") {
            var arr = [] = pSNIPProcEntityWrapper.snipProcEntity.dealGoogle.split(",");
            this.cDealGooglePlusMsg = arr[1] + "," + arr[2] + "," + arr[3] + ", " + pTxnUrlTinyWithDealID;
        }
        //FB profile
        if (this.cCreateNewSNIPReq.dealFacebook == 'Y') {
            this.cFBProfileVal = '/' + this.sCustomFacebookService.cFbProfileId + '/' + 'feed';
            this.cFBProfileToken = this.sCustomFacebookService.cAppId + '|' + this.sCustomFacebookService.cAppSecret;
            this.sFacebook.api(this.cFBProfileVal, 'post', {
                message: this.cDealFBMsg,
                published: true,
                access_token: this.cFBProfileToken,
            }).then((response) => {
                console.log(response);
            }).catch((error) => console.error(error));
        }
        //FB page 
        if (this.cCreateNewSNIPReq.dealFacebookPage == 'Y') {
            this.cFBPageVal = '/' + this.sCustomFacebookService.cFbPageId + '/' + 'feed';
            this.cFBPageToken = this.sCustomFacebookService.cFbPageToken;
            this.sFacebook.api(this.cFBPageVal, 'post', {
                message: this.cDealFBPageMsg,
                published: true,
                access_token: this.cFBPageToken,
            }).then((response) => {
                console.log(response);
            }).catch((error) => console.error(error));
        }
        //Twitter profile
        if (this.cCreateNewSNIPReq.dealTwitter == 'Y') {
            this.cTwitterPostReqDTO.message = this.cDealTwitterMsg;
            this.sSocialStreamsService.postTwitterMsg(this.cTwitterPostReqDTO)
                .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
        }
        //GooglePlus profile
        this.cGoogleplusPostReq.message = "welcome to new MarsTest";
        this.sSocialStreamsService.postGooglePlusMsg(this.cGoogleplusPostReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onCreateClick() {
        if (this.mCreateForm.valid) {
            if (this.cCreateNewSNIPReq.dealType == 'Donation')
                this.cPostMsg = "To give " + this.cCreateNewSNIPReq.dealCurrency + " " + this.cCreateNewSNIPReq.dealPrice + " , simply click on the link ";
            else if (this.cCreateNewSNIPReq.dealType == 'Sale')
                this.cPostMsg = "To purchase for " + this.cCreateNewSNIPReq.dealCurrency + " " + this.cCreateNewSNIPReq.dealPrice + " plus " + this.cCreateNewSNIPReq.dealCurrency + " " + this.cCreateNewSNIPReq.dealShipping + " shipping, simply click on the link ";
            this.cCreateNewSNIPReq.postMsg = this.cPostMsg;
            this.pCcavenueSnipService.createNewSNIP(this.uploadLogo, this.cCreateNewSNIPReq)
                .subscribe(pResponse => { this.CreateSuccess(pResponse); }, error => { console.log('error'); });
            this.check = false;
        }
        else {
            this.validateAllFields(this.mCreateForm);
            this.getFormValidationErrors();
        }
    }
    onCancelClick() {
        this.pLocation.back();
    }
    updSNIPStatus(pEvent, pSNIPStatus) {
        if (pSNIPStatus === 'Y') {
            this.cSNIPStatus = 'N';
        }
        else if (pSNIPStatus === 'N') {
            this.cSNIPStatus = 'Y';
        }
        this.cCreateNewSNIPReq.dealStatus = this.cSNIPStatus;
    }
    updGoogleStatus(pEvent, pDealGoogle) {
        if (pDealGoogle === 'Y') {
            this.cDealGoogle = 'N';
        }
        else if (pDealGoogle === 'N') {
            this.cDealGoogle = 'Y';
        }
        this.cCreateNewSNIPReq.dealGoogle = this.cDealGoogle;
    }
    updTwitterStatus(pEvent, pDealTwitter) {
        if (pDealTwitter === 'Y') {
            this.cDealTwitter = 'N';
        }
        else if (pDealTwitter === 'N') {
            this.cDealTwitter = 'Y';
        }
        this.cCreateNewSNIPReq.dealTwitter = this.cDealTwitter;
    }
    updFacebookPageStatus(pEvent, pDealFacebookPage) {
        if (pDealFacebookPage === 'Y') {
            this.cDealFacebookPage = 'N';
        }
        else if (pDealFacebookPage === 'N') {
            this.cDealFacebookPage = 'Y';
        }
        this.cCreateNewSNIPReq.dealFacebookPage = this.cDealFacebookPage;
    }
    updFacebookProfileStatus(pEvent, pDealFacebookProfile) {
        if (pDealFacebookProfile === 'Y') {
            this.cDealFacebookProfile = 'N';
        }
        else if (pDealFacebookProfile === 'N') {
            this.cDealFacebookProfile = 'Y';
        }
        this.cCreateNewSNIPReq.dealFacebook = this.cDealFacebookProfile;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cCreateNewSNIPReq.dealFrom = value.start.format("YYYY-MM-DD");
        this.cCreateNewSNIPReq.dealTo = value.end.format("YYYY-MM-DD");
        this.cCreateNewSnip.fromToDate = this.cCreateNewSNIPReq.dealFrom + ' - ' + this.cCreateNewSNIPReq.dealTo;
    }
    //***********************************************Server Call Event**********************************************//    
    CreateSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.pCcavenueSnipService.fetchSNIPList(this.cSNIPReq)
                    .subscribe(pResponse => this.fetchSnipSuccess(pResponse), error => { console.log('error'); });
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mCreateForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.pLocation.back();
    }
    fetchSnipSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullList(mCommonResponse.data.SNIPResList)) {
                    this.cSNIPProcEntityWrapper = mCommonResponse.data.SNIPResList[0];
                    this.cTxnUrlTiny = mCommonResponse.data.TxnUrlTiny;
                    this.onSocialMessagePostClick(this.cSNIPProcEntityWrapper, this.cTxnUrlTiny);
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cSNIPProcEntityWrapper = null;
            }
        }
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
};
CreateNewSnipCompaignComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-create-new-snip-compaign',
        templateUrl: './create-new-snip-compaign.component.html',
        styleUrls: ['./create-new-snip-compaign.component.css'],
        providers: [CustomFacebookService, SocialStreamsService]
    }),
    tslib_1.__param(16, Inject('APP_CONFIG')),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ActivatedRoute,
        FacebookService,
        CustomFacebookService,
        ApiRequestService,
        Location,
        FormBuilder,
        MerchInfoService,
        CcavenueSnipService,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        CreateNewSnipService,
        BsModalService,
        SocialStreamsService, String])
], CreateNewSnipCompaignComponent);
export { CreateNewSnipCompaignComponent };
//# sourceMappingURL=create-new-snip-compaign.component.js.map