export class GoogleplusPostReq {
    constructor() {
        this.regId = null;
        this.message = null;
    }
}
//# sourceMappingURL=googleplus-post-req.js.map