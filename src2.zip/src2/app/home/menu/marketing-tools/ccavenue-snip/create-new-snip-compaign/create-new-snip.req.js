export class CreateNewSNIPReq {
    constructor() {
        this.updSnipStatus = false;
    }
}
//# sourceMappingURL=create-new-snip.req.js.map