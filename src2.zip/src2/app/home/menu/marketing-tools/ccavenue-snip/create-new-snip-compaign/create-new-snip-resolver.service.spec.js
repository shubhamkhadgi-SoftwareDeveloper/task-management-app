import { TestBed, inject } from '@angular/core/testing';
import { CreateNewSnipResolverService } from './create-new-snip-resolver.service';
describe('CreateNewSnipResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CreateNewSnipResolverService]
        });
    });
    it('should be created', inject([CreateNewSnipResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=create-new-snip-resolver.service.spec.js.map