import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { CreateNewSnipService } from './create-new-snip.service';
import { SocialStreamsService } from '../../../settings/social-streams/social-streams.service';
let CreateNewSnipResolverService = class CreateNewSnipResolverService {
    constructor(sCreateNewSnipService, sSocialStreamsService) {
        this.sCreateNewSnipService = sCreateNewSnipService;
        this.sSocialStreamsService = sSocialStreamsService;
    }
    resolve(route, state) {
        return this.sSocialStreamsService.fetchAllProfiles().take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
CreateNewSnipResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [CreateNewSnipService,
        SocialStreamsService])
], CreateNewSnipResolverService);
export { CreateNewSnipResolverService };
//# sourceMappingURL=create-new-snip-resolver.service.js.map