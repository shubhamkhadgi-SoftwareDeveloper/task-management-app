export class CreateNewSnip {
    constructor() {
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'YYYY-MM-DD' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        //this.currDate = new Date();
    }
}
//# sourceMappingURL=create-new-snip.class.js.map