export class TwitterPostReqDTO {
    constructor() {
        this.message = null;
    }
}
//# sourceMappingURL=twitter-post-req.js.map