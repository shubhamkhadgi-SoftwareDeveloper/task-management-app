import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
let CreateNewSnipService = class CreateNewSnipService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cFetchAllProfilesUrl = 'fetchAllProfiles';
        this.cAddFbProfileUrl = 'addFbProfile';
        this.cDeleteProfileUrl = 'deleteProfile';
        this.cGetPageLivedTokenUrl = 'getPageLivedToken';
        this.cAddFbPageUrl = 'addFbPage';
        this.cGenerateDealIdUrl = 'generateDealId';
    }
    fetchAllProfiles() {
        return this.pApiRequestService.httpPostRequest(null, this.cFetchAllProfilesUrl);
    }
    addFbProfile(pAddFbProfileReq) {
        return this.pApiRequestService.httpPostRequest(pAddFbProfileReq, this.cAddFbProfileUrl);
    }
    deleteProfile(pDeleteProfileReq) {
        return this.pApiRequestService.httpPostRequest(pDeleteProfileReq, this.cDeleteProfileUrl);
    }
    getPageLivedToken(pGetPageLivedTokenReq) {
        return this.pApiRequestService.httpPostRequest(pGetPageLivedTokenReq, this.cGetPageLivedTokenUrl);
    }
    addFbPage(pAddFbPageReq) {
        return this.pApiRequestService.httpPostRequest(pAddFbPageReq, this.cAddFbPageUrl);
    }
    generateDealId() {
        return this.pApiRequestService.httpPostRequest(null, this.cGenerateDealIdUrl);
    }
};
CreateNewSnipService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], CreateNewSnipService);
export { CreateNewSnipService };
//# sourceMappingURL=create-new-snip.service.js.map