import { async, TestBed } from '@angular/core/testing';
import { CreateNewSnipCompaignComponent } from './create-new-snip-compaign.component';
describe('CreateNewSnipCompaignComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CreateNewSnipCompaignComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CreateNewSnipCompaignComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=create-new-snip-compaign.component.spec.js.map