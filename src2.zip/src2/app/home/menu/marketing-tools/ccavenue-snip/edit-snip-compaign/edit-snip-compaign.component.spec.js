import { async, TestBed } from '@angular/core/testing';
import { EditSnipCompaignComponent } from './edit-snip-compaign.component';
describe('EditSnipCompaignComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [EditSnipCompaignComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(EditSnipCompaignComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=edit-snip-compaign.component.spec.js.map