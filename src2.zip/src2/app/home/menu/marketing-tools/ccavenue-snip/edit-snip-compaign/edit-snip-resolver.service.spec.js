import { TestBed, inject } from '@angular/core/testing';
import { EditSnipResolverService } from './edit-snip-resolver.service';
describe('EditSnipResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [EditSnipResolverService]
        });
    });
    it('should be created', inject([EditSnipResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=edit-snip-resolver.service.spec.js.map