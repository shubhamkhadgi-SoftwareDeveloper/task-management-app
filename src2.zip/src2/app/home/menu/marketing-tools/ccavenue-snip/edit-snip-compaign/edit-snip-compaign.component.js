import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { CreateNewSNIPReq } from '../create-new-snip-compaign/create-new-snip.req';
import { CcavenueSnipService } from '../ccavenue-snip.service';
import { CreateNewSnip } from '../create-new-snip-compaign/create-new-snip.class';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../../common-response/common-response.res';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { SNIP } from '../snip.class';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { CustomFacebookService } from '../../../../../common-services/custom-facebook.service';
import { FacebookService } from 'ngx-facebook';
import { SocialStreamsService } from '../../../settings/social-streams/social-streams.service';
let EditSnipCompaignComponent = class EditSnipCompaignComponent {
    //***********************************************Constructor*******************************************//
    constructor(cdr, pApiRequestService, pLocation, pFormBuilder, pMerchInfoService, pCcavenueSnipService, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, pRouter, sActivatedRoute, sResponsiveService, sFacebook, sCustomFacebookService, pModalService) {
        this.cdr = cdr;
        this.pApiRequestService = pApiRequestService;
        this.pLocation = pLocation;
        this.pFormBuilder = pFormBuilder;
        this.pMerchInfoService = pMerchInfoService;
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.pRouter = pRouter;
        this.sActivatedRoute = sActivatedRoute;
        this.sResponsiveService = sResponsiveService;
        this.sFacebook = sFacebook;
        this.sCustomFacebookService = sCustomFacebookService;
        this.pModalService = pModalService;
        this.check = false;
        this.dealImg = null;
        this.dealURL = null;
        this.txnURL = null;
        this.cTwitterName = null;
        this.cTwitterImg = null;
        this.cGooglePlusName = null;
        this.cGooglePlusImg = null;
        this.cEditSNIPReq = new CreateNewSNIPReq();
        this.cCreateNewSnip = new CreateNewSnip();
        this.cCommonResponse = new CommonResponse();
        this.cSNIP = new SNIP();
        this.cEditSNIPReq.dealStatus = 'Y';
        this.cEditSNIPReq.dealGoogle = 'N';
        this.cEditSNIPReq.dealTwitter = 'N';
        this.cEditSNIPReq.dealFacebookPage = 'N';
        this.cEditSNIPReq.dealFacebook = 'N';
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'YYYY-MM-DD' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
    }
    ngOnInit() {
        this.createForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.fetchSnipDetailsSuccess(data.commonResponse);
        });
    }
    //***********************************************On Change Event*******************************************//
    onInfiniteLimitCheckBoxClick(event) {
        if (event) {
            this.mEditForm.controls['dealQty'].disable();
            this.mEditForm.controls['dealQty'].clearValidators();
            this.mEditForm.controls['dealQty'].updateValueAndValidity();
            this.cEditSNIPReq.dealQty = null;
            this.cEditSNIPReq.dealQty = 'Infinite';
            this.isInfiniteLimitCheck = true;
        }
        else {
            this.mEditForm.controls['dealQty'].enable();
            this.cEditSNIPReq.dealQty = null;
            this.mEditForm.controls['dealQty'].setValidators([InvoiceSettingsValidator.integerNumberOnly,
                Validators.required, Validators.min(1),
                Validators.maxLength(9)]);
            this.mEditForm.controls['dealQty'].updateValueAndValidity();
        }
    }
    onDealTypeChangeClick(pValue) {
        this.cEditSNIPReq.dealType = pValue;
        if (this.cEditSNIPReq.dealType == 'Sale') {
            this.mEditForm.controls['dealShipping'].setValidators([InvoiceSettingsValidator.integerNumberOnly,
                Validators.required, Validators.min(1),
                Validators.maxLength(9),
                InvoiceSettingsValidator.flatValue]);
            this.mEditForm.controls['dealShipping'].updateValueAndValidity();
        }
        else if (this.cEditSNIPReq.dealType == 'Donation') {
            this.cEditSNIPReq.dealShipping = null;
            this.mEditForm.controls['dealShipping'].clearValidators();
            this.mEditForm.controls['dealShipping'].setValue(null);
            this.mEditForm.controls['dealShipping'].updateValueAndValidity();
        }
    }
    onBlur(event) {
        if (event) {
            if (this.cEditSNIPReq.dealPrice != null && this.mEditForm.controls['dealPrice'].valid) {
                let value = +this.cEditSNIPReq.dealPrice;
                this.cEditSNIPReq.dealPrice = value.toFixed(2);
            }
            if (this.cEditSNIPReq.dealShipping != null && this.mEditForm.controls['dealShipping'].valid) {
                let value = +this.cEditSNIPReq.dealShipping;
                this.cEditSNIPReq.dealShipping = value.toFixed(2);
            } /*else
                this.cEditSNIPReq.dealShipping = '0.00';*/
        }
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mEditForm = this.pFormBuilder.group({
            dealTitle: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.snipName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            dealType: [''],
            dealCurrency: ['', [Validators.required]],
            dealPrice: ['', [
                    Validators.required,
                    InvoiceSettingsValidator.numbersOnly,
                    Validators.min(1),
                    Validators.maxLength(10),
                    InvoiceSettingsValidator.flatValue
                ]],
            dealShipping: ['', [
                    InvoiceSettingsValidator.numbersOnly,
                    //Validators.min(1),
                    Validators.maxLength(9),
                    InvoiceSettingsValidator.flatValue
                ]],
            dealQty: ['', [
                    InvoiceSettingsValidator.integerNumberOnly,
                    Validators.required, Validators.min(1),
                    Validators.maxLength(9)
                ]],
            dealAnalytics: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            dealFrom: [''],
            fromTodate: ['', [Validators.required]],
            file: [''],
            isInfiniteLimitCheck: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    getFormValidationErrors() {
        Object.keys(this.mEditForm.controls).forEach(key => {
            const controlErrors = this.mEditForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    // console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    //***********************************************Button Click Event*******************************************//
    onRemoveLogoPopupClick(pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    fileChangeEvent(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();
            let mError = '';
            this.uploadLogo = event.target.files[0];
            let fileName = this.uploadLogo.name;
            let validExts = [];
            validExts = ['.jpg', '.jpeg', '.png'];
            var fileExt = fileName.substring(fileName.lastIndexOf('.'));
            if (validExts.includes(fileExt)) {
                if (this.uploadLogo.size <= 102400) { //20480
                    this.check = true;
                    reader.onload = (event) => {
                        this.dealImg = event.target.result;
                    };
                    reader.readAsDataURL(this.uploadLogo);
                }
                else {
                    mError = 'File size should not be greater than 20 KB';
                    this.sAlertMessageService.popupAlertMsg(mError);
                }
            }
            else {
                mError = 'Only jpeg ,jpg & png  files are allowed.';
                this.sAlertMessageService.popupAlertMsg(mError);
            }
        }
    }
    onRemoveLogoClick() {
        this.dealImg = null;
        this.cEditSNIPReq.dealImgDel = 'Y';
        this.check = false;
        this.cModalRef.hide();
    }
    onCancelClick() {
        this.pLocation.back();
    }
    onDealIdClick(param) {
        //  console.log(param.dealId);
    }
    updSNIPStatus(pEvent, pSNIPStatus) {
        if (pSNIPStatus === 'Y') {
            this.cSNIPStatus = 'N';
        }
        else if (pSNIPStatus === 'N') {
            this.cSNIPStatus = 'Y';
        }
        this.cEditSNIPReq.dealStatus = this.cSNIPStatus;
    }
    updGoogleStatus(pEvent, pDealGoogle) {
        if (pDealGoogle === 'Y') {
            this.cDealGoogle = 'N';
        }
        else if (pDealGoogle === 'N') {
            this.cDealGoogle = 'Y';
        }
        this.cEditSNIPReq.dealGoogle = this.cDealGoogle;
    }
    updTwitterStatus(pEvent, pDealTwitter) {
        if (pDealTwitter === 'Y') {
            this.cDealTwitter = 'N';
        }
        else if (pDealTwitter === 'N') {
            this.cDealTwitter = 'Y';
        }
        this.cEditSNIPReq.dealTwitter = this.cDealTwitter;
    }
    updFacebookPageStatus(pEvent, pDealFacebookPage) {
        if (pDealFacebookPage === 'Y') {
            this.cDealFacebookPage = 'N';
        }
        else if (pDealFacebookPage === 'N') {
            this.cDealFacebookPage = 'Y';
        }
        this.cEditSNIPReq.dealFacebookPage = this.cDealFacebookPage;
    }
    updFacebookProfileStatus(pEvent, pDealFacebookProfile) {
        if (pDealFacebookProfile === 'Y') {
            this.cDealFacebookProfile = 'N';
        }
        else if (pDealFacebookProfile === 'N') {
            this.cDealFacebookProfile = 'Y';
        }
        this.cEditSNIPReq.dealFacebook = this.cDealFacebookProfile;
    }
    onUpdateSNIPClick() {
        if (this.mEditForm.valid) {
            if (this.check == false) {
                this.uploadLogo = null;
            }
            if (this.cEditSNIPReq.dealImgDel != 'Y') {
                this.cEditSNIPReq.dealImgDel = '';
            }
            this.pCcavenueSnipService.updateSNIP(this.uploadLogo, this.cEditSNIPReq)
                .subscribe(pResponse => this.updateSuccess(pResponse), error => { console.log('error'); });
            this.check = false;
        }
        else {
            this.validateAllFields(this.mEditForm);
            this.getFormValidationErrors();
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cEditSNIPReq.dealFrom = value.start.format("YYYY-MM-DD");
        this.cEditSNIPReq.dealTo = value.end.format("YYYY-MM-DD");
        this.cCreateNewSnip.fromToDate = this.cEditSNIPReq.dealFrom + ' - ' + this.cEditSNIPReq.dealTo;
    }
    //***********************************************Server Call Event**********************************************//
    fetchSnipDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data.SNIPDetails)) {
                    this.cSNIPProcEntity = mCommonResponse.data.SNIPDetails;
                    this.dealURL = mCommonResponse.data.FinalURL;
                    this.txnURL = mCommonResponse.data.txnURL;
                    this.cEditSNIPReq.dealTitle = this.cSNIPProcEntity.dealTitle;
                    this.cEditSNIPReq.dealCurrency = this.cSNIPProcEntity.dealCurrency;
                    if (this.cSNIPProcEntity.dealPriceAmt != null && this.cSNIPProcEntity.dealPriceAmt != undefined)
                        this.cEditSNIPReq.dealPrice = this.cSNIPProcEntity.dealPriceAmt.toFixed(2);
                    if (this.cSNIPProcEntity.dealShippingAmt != null && this.cSNIPProcEntity.dealShippingAmt != undefined)
                        this.cEditSNIPReq.dealShipping = this.cSNIPProcEntity.dealShippingAmt.toFixed(2);
                    else
                        this.cEditSNIPReq.dealShipping = '0.00';
                    this.cEditSNIPReq.dealType = this.cSNIPProcEntity.dealType;
                    if (this.cSNIPProcEntity.dealQty.toString() == '-1') {
                        this.cEditSNIPReq.dealQty = 'Infinite';
                        this.isInfiniteLimitCheck = true;
                        this.mEditForm.controls['dealQty'].disable();
                        this.mEditForm.controls['dealQty'].clearValidators();
                        this.mEditForm.controls['dealQty'].updateValueAndValidity();
                    }
                    else {
                        this.cEditSNIPReq.dealQty = this.cSNIPProcEntity.dealQty.toString();
                    }
                    this.cEditSNIPReq.dealAnalytics = this.cSNIPProcEntity.dealAnalytics;
                    this.cEditSNIPReq.dealFacebook = this.cSNIPProcEntity.dealFacebook;
                    this.cEditSNIPReq.dealFacebookPage = this.cSNIPProcEntity.dealFacebookPage;
                    this.cEditSNIPReq.dealGoogle = this.cSNIPProcEntity.dealGoogle;
                    this.cEditSNIPReq.dealInstagram = this.cSNIPProcEntity.dealInstagram;
                    this.cEditSNIPReq.dealTwitter = this.cSNIPProcEntity.dealTwitter;
                    this.cEditSNIPReq.dealImageAlt = this.cSNIPProcEntity.dealImageURL;
                    this.dealImg = this.dealURL;
                    if (this.cSNIPProcEntity.dealStatus == 'Published') {
                        this.cEditSNIPReq.dealStatus = 'Y';
                    }
                    else if (this.cSNIPProcEntity.dealStatus == 'Unpublished') {
                        this.cEditSNIPReq.dealStatus = 'N';
                    }
                    this.cEditSNIPReq.dealId = this.cSNIPProcEntity.dealId;
                    this.cEditSNIPReq.dealFrom = this.cSNIPProcEntity.dealFrom;
                    this.cEditSNIPReq.dealTo = this.cSNIPProcEntity.dealTo;
                    this.cCreateNewSnip.fromToDate = this.cEditSNIPReq.dealFrom + ' - ' + this.cEditSNIPReq.dealTo;
                }
                /***************** social stream response *************************/
                //Configure facebook AppId and version
                //   if(this.sCheck.isNotNullString(mCommonResponse.data['appId']) && this.sCheck.isNotNullString(mCommonResponse.data['appVersion'])){
                //Facebook Profile Details
                if (this.sCheck.isNotNullObject(mCommonResponse.data['Facebook'])) {
                    this.sCustomFacebookService.cFbProfileId = mCommonResponse.data['Facebook'].profileId;
                    this.sCustomFacebookService.cFbProfileName = mCommonResponse.data['Facebook'].profileName;
                    this.sCustomFacebookService.cFbProfilePic = 'https://graph.facebook.com/' + this.sCustomFacebookService.cFbProfileId + '/picture/' + this.sCustomFacebookService.cFbProfileName;
                }
                //Facebook Page Details
                if (this.sCheck.isNotNullObject(mCommonResponse.data['FacebookPage'])) {
                    this.sCustomFacebookService.cFbPageId = mCommonResponse.data['FacebookPage'].fbPageId;
                    this.sCustomFacebookService.cFbPageName = mCommonResponse.data['FacebookPage'].fbPageName;
                    this.sCustomFacebookService.cFbPageCategory = mCommonResponse.data['FacebookPage'].fbPageCategory;
                    this.sCustomFacebookService.cFbPageToken = mCommonResponse.data['FacebookPage'].fbPageToken;
                    this.sCustomFacebookService.cFbPagePic = 'http://graph.facebook.com/' + this.sCustomFacebookService.cFbPageId + '/picture?access_token=' + this.sCustomFacebookService.cFbPageToken;
                }
                //Twitter Details
                if (this.sCheck.isNotNullObject(mCommonResponse.data['Twitter'])) {
                    this.cTwitterName = mCommonResponse.data['Twitter'].name;
                    this.cTwitterImg = mCommonResponse.data['Twitter'].profileimage;
                }
                //}
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cSNIPProcEntity = null;
                this.cSNIP.totalCount = null;
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
                this.cSNIPProcEntity = null;
                this.cSNIP.totalCount = null;
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cSNIPProcEntity = null;
            this.cSNIP.totalCount = null;
        }
    }
    updateSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mEditForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.pLocation.back();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
};
EditSnipCompaignComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-edit-snip-compaign',
        templateUrl: './edit-snip-compaign.component.html',
        styleUrls: ['./edit-snip-compaign.component.css'],
        providers: [CustomFacebookService, SocialStreamsService]
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ApiRequestService,
        Location,
        FormBuilder,
        MerchInfoService,
        CcavenueSnipService,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        ActivatedRoute,
        ActivatedRoute,
        ResponsiveService,
        FacebookService,
        CustomFacebookService,
        BsModalService])
], EditSnipCompaignComponent);
export { EditSnipCompaignComponent };
//# sourceMappingURL=edit-snip-compaign.component.js.map