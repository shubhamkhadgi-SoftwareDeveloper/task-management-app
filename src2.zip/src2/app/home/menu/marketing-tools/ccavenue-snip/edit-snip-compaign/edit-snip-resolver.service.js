import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CcavenueSnipService } from '../ccavenue-snip.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { SNIPReq } from '../ccavenue-snip.req';
let EditSnipResolverService = class EditSnipResolverService {
    constructor(pRouter, pCcavenueSnipService, pMerchInfoService) {
        this.pRouter = pRouter;
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.pMerchInfoService = pMerchInfoService;
    }
    resolve(route, state) {
        let mSNIPReq = new SNIPReq();
        mSNIPReq.dealId = route.queryParams.dealId;
        return this.pCcavenueSnipService.getSNIPById(mSNIPReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
EditSnipResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        CcavenueSnipService,
        MerchInfoService])
], EditSnipResolverService);
export { EditSnipResolverService };
//# sourceMappingURL=edit-snip-resolver.service.js.map