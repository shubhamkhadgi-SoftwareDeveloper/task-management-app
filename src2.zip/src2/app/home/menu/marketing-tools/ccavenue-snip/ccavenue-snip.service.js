import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let CcavenueSnipService = class CcavenueSnipService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseSnipUrl = 'ccavenueSnip/';
        this.cFetchSNIPListURL = this.cBaseSnipUrl + 'fetchSNIPList';
        this.cCreateNewSNIPURL = this.cBaseSnipUrl + 'addSNIPCompaign';
        this.cDeleteSNIPURL = this.cBaseSnipUrl + 'deleteSNIPCompaign';
        this.cUpdateSNIPURL = this.cBaseSnipUrl + 'updSNIPCompaign';
        this.cGetSNIPByIdURL = this.cBaseSnipUrl + 'getSNIPById';
        this.cFetchSNIPTransURL = this.cBaseSnipUrl + 'fetchTransList';
        this.cUpdateSnipStatusURL = this.cBaseSnipUrl + 'updateSNIPStatus';
    }
    fetchSNIPList(pSNIPReq) {
        return this.pApiRequestService.httpPostRequest(pSNIPReq, this.cFetchSNIPListURL);
    }
    createNewSNIP(pUploadLogo, pCreateNewSNIPReq) {
        return this.pApiRequestService.fileUploadRequest(pUploadLogo, pCreateNewSNIPReq, this.cCreateNewSNIPURL);
    }
    deleteSNIP(pDelSNIPReq) {
        return this.pApiRequestService.httpPostRequest(pDelSNIPReq, this.cDeleteSNIPURL);
    }
    updateSNIP(uploadLogo, pUpdSNIPReq) {
        return this.pApiRequestService.fileUploadRequest(uploadLogo, pUpdSNIPReq, this.cUpdateSNIPURL);
    }
    getSNIPById(pSNIPReq) {
        return this.pApiRequestService.httpPostRequest(pSNIPReq, this.cGetSNIPByIdURL);
    }
    updateSNIPStatus(pUpdSNIPReq) {
        return this.pApiRequestService.httpPostRequest(pUpdSNIPReq, this.cUpdateSnipStatusURL);
    }
};
CcavenueSnipService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], CcavenueSnipService);
export { CcavenueSnipService };
//# sourceMappingURL=ccavenue-snip.service.js.map