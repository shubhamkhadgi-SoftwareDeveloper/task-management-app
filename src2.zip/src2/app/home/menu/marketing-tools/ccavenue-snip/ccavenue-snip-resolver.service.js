import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { CcavenueSnipService } from './ccavenue-snip.service';
import { SNIPReq } from './ccavenue-snip.req';
let CcavenueSnipResolverService = class CcavenueSnipResolverService {
    constructor(sRouter, pMerchInfoService, pCcavenueSnipService) {
        this.sRouter = sRouter;
        this.pMerchInfoService = pMerchInfoService;
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.cSNIPReq = new SNIPReq();
    }
    resolve(route, state) {
        return this.pCcavenueSnipService.fetchSNIPList(this.cSNIPReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
CcavenueSnipResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router,
        MerchInfoService,
        CcavenueSnipService])
], CcavenueSnipResolverService);
export { CcavenueSnipResolverService };
//# sourceMappingURL=ccavenue-snip-resolver.service.js.map