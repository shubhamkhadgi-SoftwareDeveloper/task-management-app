export class SNIP {
    constructor() {
        this.isSearchPanelClick = false;
        this.isCopyLinkClick = false;
        this.actionPanel = false;
        this.isAnyDealCreated = true;
        this.cDealTypeList = [];
        this.cDealTypeList.push({ label: 'Type', value: null });
        this.cDealTypeList.push({ label: 'Sale', value: 'Sale' });
        this.cDealTypeList.push({ label: 'Donation', value: 'Donation' });
        this.cDealStatusList = [];
        this.cDealStatusList.push({ label: 'Status', value: null });
        this.cDealStatusList.push({ label: 'Enable', value: 'Y' });
        this.cDealStatusList.push({ label: 'Disable', value: 'N' });
        //Expired
        this.cDealStatusList.push({ label: 'Expired', value: 'E' });
    }
}
//# sourceMappingURL=snip.class.js.map