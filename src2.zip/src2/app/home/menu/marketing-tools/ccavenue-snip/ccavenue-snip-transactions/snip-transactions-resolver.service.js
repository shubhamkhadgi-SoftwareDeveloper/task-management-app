import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { CcavenueSnipService } from '../ccavenue-snip.service';
import { TransactionReq } from '../../../transactions/transactions/transaction.req';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
let SnipTransactionsResolverService = class SnipTransactionsResolverService {
    constructor(pCcavenueSnipService, pTransactionsService) {
        this.pCcavenueSnipService = pCcavenueSnipService;
        this.pTransactionsService = pTransactionsService;
    }
    resolve(route, state) {
        let mTransactionReq = new TransactionReq();
        mTransactionReq.orderDealId = route.queryParams.dealId;
        //mTransactionReq.searchTransactionStatus='Shipped';
        return this.pTransactionsService.fetchTransList(mTransactionReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
SnipTransactionsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [CcavenueSnipService,
        TransactionsService])
], SnipTransactionsResolverService);
export { SnipTransactionsResolverService };
//# sourceMappingURL=snip-transactions-resolver.service.js.map