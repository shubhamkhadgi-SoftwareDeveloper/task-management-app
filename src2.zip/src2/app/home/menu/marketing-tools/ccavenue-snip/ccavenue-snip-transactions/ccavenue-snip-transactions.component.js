import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { SNIP } from '../snip.class';
import { CommonResponse } from '../../../../../common-response/common-response.res';
let CcavenueSnipTransactionsComponent = class CcavenueSnipTransactionsComponent {
    constructor(pLocation, pRouter) {
        this.pLocation = pLocation;
        this.pRouter = pRouter;
        this.cSNIP = new SNIP();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.pRouter.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cCommonResponse = data.commonResponse;
            }
        });
        this.pRouter.queryParams.subscribe(param => this.fetchSNIPFields(param));
        window.scrollTo(0, 0);
    }
    fetchSNIPFields(param) {
        this.cSNIP.dealId = param.dealId;
        this.cSNIP.dealTitle = param.dealTitle;
        this.cSNIP.dealType = param.dealType;
        this.cSNIP.dealFrom = param.startDate;
        this.cSNIP.dealTo = param.endDate;
        this.cSNIP.dealStatus = param.dealStatus;
        this.cSNIP.dealValidity = param.dealValidity;
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
        this.cSNIP = new SNIP();
    }
};
CcavenueSnipTransactionsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-ccavenue-snip-transactions',
        templateUrl: './ccavenue-snip-transactions.component.html',
        styleUrls: ['./ccavenue-snip-transactions.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [Location,
        ActivatedRoute])
], CcavenueSnipTransactionsComponent);
export { CcavenueSnipTransactionsComponent };
//# sourceMappingURL=ccavenue-snip-transactions.component.js.map