import { async, TestBed } from '@angular/core/testing';
import { CcavenueSnipTransactionsComponent } from './ccavenue-snip-transactions.component';
describe('CcavenueSnipTransactionsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CcavenueSnipTransactionsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CcavenueSnipTransactionsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=ccavenue-snip-transactions.component.spec.js.map