import { TestBed, inject } from '@angular/core/testing';
import { SnipTransactionsResolverService } from './snip-transactions-resolver.service';
describe('SnipTransactionsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SnipTransactionsResolverService]
        });
    });
    it('should be created', inject([SnipTransactionsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=snip-transactions-resolver.service.spec.js.map