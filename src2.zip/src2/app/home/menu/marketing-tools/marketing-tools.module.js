import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonAndThirdPartyModule } from '../../../common-modules/common-and-third-party.module';
import { MarketingToolsRoutingModule, MarketingToolsRoutedComponents } from './marketing-tools.routing';
import { TransactionsModule } from '../transactions/transactions.module';
import { CcavenueSnipTransactionsComponent } from './ccavenue-snip/ccavenue-snip-transactions/ccavenue-snip-transactions.component';
import { CreateNewSnipCompaignComponent } from './ccavenue-snip/create-new-snip-compaign/create-new-snip-compaign.component';
import { EditSnipCompaignComponent } from './ccavenue-snip/edit-snip-compaign/edit-snip-compaign.component';
import { CopyPasteControlModule } from '../../../common-modules/copy-paste-control.module';
let MarketingToolsModule = class MarketingToolsModule {
};
MarketingToolsModule = tslib_1.__decorate([
    NgModule({
        imports: [
            CommonAndThirdPartyModule,
            MarketingToolsRoutingModule,
            TransactionsModule,
            CopyPasteControlModule,
        ],
        declarations: [MarketingToolsRoutedComponents, CcavenueSnipTransactionsComponent, CreateNewSnipCompaignComponent, EditSnipCompaignComponent]
    })
], MarketingToolsModule);
export { MarketingToolsModule };
//# sourceMappingURL=marketing-tools.module.js.map