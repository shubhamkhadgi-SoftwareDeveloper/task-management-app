export class CreateNewPromotion {
    constructor() {
        this.cPromoTypeList = [];
        //  this.cPromoTypeList.push({label:'Select'  , value: null });
        this.cPromoTypeList.push({ label: 'Cashback', value: 'CASHBACK' });
        this.cPromoTypeList.push({ label: 'Discount', value: 'DISCOUNT' });
        this.cPromoMethodList = [];
        // this.cPromoMethodList.push({label:'Select Promotion Method'  , value:null });
        this.cPromoMethodList.push({ label: 'Entire Order', value: 'Order Amount' });
        this.cPromoMethodList.push({ label: 'Order Over', value: 'Orders Over' });
        this.cPromoDiscountType = [];
        //  this.cPromoDiscountType.push({label:'Select Cashback/Discount Type'  , value: null });
        this.cPromoDiscountType.push({ label: 'Flat', value: 'FLAT' });
        this.cPromoDiscountType.push({ label: 'Percentage', value: 'PERC' });
        this.calOptions = {
            autoUpdateInput: true,
            locale: { format: 'yyyy-MM-dd hh:mm:ss' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.datePicker = {
            autoUpdateInput: true,
            locale: { format: 'YYYY-MM-DD HH:MM:SS' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.startDatePicker = {
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
            showDropdowns: true,
            opens: "center",
        };
        this.endDatePicker = {
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.fromToDate = '';
        this.formFromToDate = '';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=create-new-promotion.class.js.map