export class PromotionReq {
}
//# sourceMappingURL=promotions.req.js.map