export class PromotionsSearchReq {
    constructor() {
        this.pageNumber = 1;
        this.pageSize = 25;
    }
}
//# sourceMappingURL=promotions-search-req.js.map