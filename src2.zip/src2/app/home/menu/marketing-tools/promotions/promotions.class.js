export class Promotions {
    constructor() {
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isUsedCountClick = false;
        this.promoValidity = null;
        this.searchByLabel = "Search by";
        this.searchBy = [];
        this.searchBy.push({ label: 'Promotion Name', value: 'promoName' });
        this.searchBy.push({ label: 'Promotion Code', value: 'promoCode' });
        this.cPromoStatusList = [];
        this.cPromoStatusList.push({ label: 'Enable', value: 'Y' });
        this.cPromoStatusList.push({ label: 'Disable', value: 'P' });
        this.cPromoStatusList.push({ label: 'Expired', value: 'E' });
        this.cPromoTypeList = [];
        this.cPromoTypeList.push({ label: 'Cashback', value: 'CASHBACK' });
        this.cPromoTypeList.push({ label: 'Discount', value: 'DISCOUNT' });
        this.dateFlag = [];
        this.dateFlag.push({ label: 'Start Date', value: 'S' });
        this.dateFlag.push({ label: 'End Date', value: 'E' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            opens: 'left',
            minDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.currDate = new Date();
        this.isAnyPromoCreated = true;
    }
}
//# sourceMappingURL=promotions.class.js.map