export class PromotionsRes {
}
//# sourceMappingURL=promotions.res.js.map