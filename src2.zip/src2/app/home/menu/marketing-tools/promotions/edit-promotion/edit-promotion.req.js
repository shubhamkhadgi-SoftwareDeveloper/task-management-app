export class EditPromotionReq {
}
//# sourceMappingURL=edit-promotion.req.js.map