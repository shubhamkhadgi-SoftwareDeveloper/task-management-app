import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PromotionsService } from './../promotions.service';
import { PromotionDetailsReq } from './../promotion-details.req';
let EditPromotionResolverService = class EditPromotionResolverService {
    constructor(pRouter, pPromotionsService) {
        this.pRouter = pRouter;
        this.pPromotionsService = pPromotionsService;
    }
    resolve(route, state) {
        let mPromotionDetailsReq = new PromotionDetailsReq();
        mPromotionDetailsReq.promoId = route.queryParams.promoId;
        return this.pPromotionsService.fetchPromotionDetails(mPromotionDetailsReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
EditPromotionResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        PromotionsService])
], EditPromotionResolverService);
export { EditPromotionResolverService };
//# sourceMappingURL=edit-promotion-resolver.service.js.map