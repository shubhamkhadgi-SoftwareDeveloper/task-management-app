import * as tslib_1 from "tslib";
import { Component, HostListener, Inject } from '@angular/core';
import { WINDOW } from "../../../../../common-services/window.service";
import { DOCUMENT } from '@angular/common';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { PromotionsService } from '../promotions.service';
import { CreateNewPromotion } from '../create-new-promotion.class';
import { PromotionReq } from '../promotions.req';
import { PromotionsSearchReq } from '../promotions-search-req';
import { EditPromotionReq } from './edit-promotion.req';
import { PromotionDetailsReq } from '../promotion-details.req';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { CardTypeArrRes } from './card-type-arr-res';
let EditPromotionComponent = class EditPromotionComponent {
    //***********************************************Constructor*******************************************//
    constructor(pFormBuilder, pApiRequestService, pMerchInfoService, pPromotionsService, pLocation, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, sActivatedRoute, document, window) {
        this.pFormBuilder = pFormBuilder;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pPromotionsService = pPromotionsService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sActivatedRoute = sActivatedRoute;
        this.document = document;
        this.window = window;
        this.cCardTypeArrRes = [];
        this.cardNameArr = [];
        this.cardType = null;
        this.isGlobalLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isCardLimitCheck = false;
        this.scrolling = false;
        this.isUserLimitDisabled = false;
        this.isCardLimitDisabled = false;
        this.fromDate = null;
        this.paymentBinArr = [];
        this.cCommonResponse = new CommonResponse();
        this.cCreateNewPromotion = new CreateNewPromotion();
        this.cPromotionReq = new PromotionReq();
        this.cPromotionsSearchReq = new PromotionsSearchReq();
        //this.cPromotionsSearchReq.regId = this.pMerchInfoService.getRegId();
        this.cEditPromotionReq = new EditPromotionReq();
        this.cPromotionDetailsReq = new PromotionDetailsReq();
        this.cCardTypeOpt = new CardTypeArrRes();
        this.calOptions = {
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.createForm();
    }
    blockPaste(e) {
        e.preventDefault();
    }
    //    @HostListener('copy', ['$event']) blockCopy(e: KeyboardEvent) {
    //        e.preventDefault();
    //    }
    blockCut(e) {
        e.preventDefault();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            this.fetchPromoDetailsSuccess(data.commonResponse);
        });
        this.disableFileds();
    }
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['globalLimit'].disable();
            this.mForm.controls['globalLimit'].clearValidators();
            this.mForm.controls['globalLimit'].updateValueAndValidity();
            this.cEditPromotionReq.globalLimit = 'Infinite';
            this.isGlobalLimitCheck = true;
            this.isUserLimitDisabled = false;
            this.isCardLimitDisabled = false;
        }
        else {
            this.isUserLimitDisabled = false;
            this.isCardLimitDisabled = false;
            this.mForm.controls['globalLimit'].enable();
            this.cEditPromotionReq.globalLimit = null;
            this.mForm.controls['globalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9),
                InvoiceSettingsValidator.integerNumberOnly]);
        }
    }
    onUserLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['userLimit'].disable();
            this.mForm.controls['userLimit'].clearValidators();
            this.mForm.controls['userLimit'].updateValueAndValidity();
            this.cEditPromotionReq.userLimit = 'Infinite';
            this.isUserLimitCheck = true;
        }
        else {
            this.mForm.controls['userLimit'].enable();
            this.cEditPromotionReq.userLimit = null;
            this.mForm.controls['userLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9),
                InvoiceSettingsValidator.integerNumberOnly]);
        }
    }
    onCardLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['cardLimit'].disable();
            this.mForm.controls['cardLimit'].clearValidators();
            this.mForm.controls['cardLimit'].updateValueAndValidity();
            this.cEditPromotionReq.cardLimit = 'Infinite';
            this.isCardLimitCheck = true;
        }
        else {
            this.mForm.controls['cardLimit'].enable();
            this.cEditPromotionReq.cardLimit = null;
            this.mForm.controls['cardLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9),
                InvoiceSettingsValidator.integerNumberOnly]);
        }
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            promoCode: [''],
            promotionStartDate: [''],
            promotionCurrency: [''],
            promotionType: [''],
            promoDiscountType: [''],
            promoMethod: [''],
            promoDiscountValue: [''],
            promoMinOrderAmount: [''],
            promoMaxDiscountAmount: [''],
            paymentBinList: [''],
            promotionName: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.promotionName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            promotionDesc: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promotionDescription
                ]],
            termsAndCondition: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promoTermsAndConditions
                ]],
            promotionAnalyticsCode: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            promotionEndDate: ['', Validators.required],
            promotionStatus: ['', Validators.required],
            globalLimit: ['', [
                    Validators.required, Validators.min(1), Validators.maxLength(9),
                    InvoiceSettingsValidator.integerNumberOnly,
                ]],
            userLimit: ['', [
                    Validators.required, Validators.min(1), Validators.maxLength(9),
                    InvoiceSettingsValidator.integerNumberOnly
                ]],
            cardLimit: ['', [
                    Validators.required, Validators.min(1), Validators.maxLength(9),
                    InvoiceSettingsValidator.integerNumberOnly
                ]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
            isCardLimitCheck: [''],
        }, {
            validator: Validators.compose([this.validateLimit]),
        });
    }
    disableFileds() {
        this.mForm.controls['promoCode'].disable();
        this.mForm.controls['promotionCurrency'].disable();
        this.mForm.controls['promotionType'].disable();
        this.mForm.controls['promoDiscountType'].disable();
        this.mForm.controls['promoMethod'].disable();
        this.mForm.controls['promoMinOrderAmount'].disable();
        this.mForm.controls['promoMaxDiscountAmount'].disable();
        this.mForm.controls['promoDiscountValue'].disable();
        if (this.sCheck.isNotNullString(this.cEditPromotionReq.promoBin)) {
            this.mForm.controls['cardLimit'].disable();
            this.mForm.controls['isCardLimitCheck'].disable();
        }
        this.mForm.controls['paymentBinList'].disable();
        if (this.cPromotionDetailsProcEntity.promoGlobalLimit != -1) {
            this.isUserLimitDisabled = true;
            this.isCardLimitDisabled = true;
        }
        else {
            this.isUserLimitDisabled = false;
            this.isCardLimitDisabled = false;
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    //console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    validateLimit(pFormGroup) {
        var globalLimit = pFormGroup.controls['globalLimit'];
        var userLimit = pFormGroup.controls['userLimit'];
        var cardLimit = pFormGroup.controls['cardLimit'];
        let globalLimitVal = +globalLimit.value;
        let userLimitVal = +userLimit.value;
        let cardLimitVal = +cardLimit.value;
        if (userLimitVal > globalLimitVal) {
            userLimit.setErrors({ validateLimit: true });
        }
        else if (userLimitVal != 0 && userLimitVal <= globalLimitVal) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && userLimitVal != 0) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && userLimit.value == 'Infinite') {
            userLimit.setErrors(null);
        }
        if (cardLimitVal > globalLimitVal) {
            cardLimit.setErrors({ validateLimit: true });
        }
        else if (cardLimitVal != 0 && cardLimitVal <= globalLimitVal) {
            cardLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && cardLimitVal != 0) {
            cardLimit.setErrors(null);
        }
        if (userLimit.value == 'Infinite' && globalLimit.value != 'Infinite') {
            userLimit.setErrors({ validateLimit: true }); //this.isUserLimitCheck = true;
        }
        if (cardLimit.value == 'Infinite' && globalLimit.value != 'Infinite') {
            cardLimit.setErrors({ validateLimit: true });
        }
        return null;
    }
    onLimitChange() {
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = true;
        this.mForm.controls['userLimit'].enable();
        this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
        this.isCardLimitCheck = false;
        this.isCardLimitDisabled = true;
        if (this.mForm.controls['globalLimit'].value < this.mForm.controls['cardLimit'].value) {
            this.mForm.controls['cardLimit'].enable();
            this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
        }
        else {
            this.mForm.controls['cardLimit'].disable();
        }
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    //***********************************************Select Event*******************************************//
    selectedEndDate(value) {
        this.cEditPromotionReq.promotionEndDate = value.end.format("DD-MM-YYYY");
        this.cCreateNewPromotion.fromDate = this.cEditPromotionReq.promotionEndDate;
    }
    //***********************************************Button Click Event*******************************************//
    onCancelClick() {
        this.pLocation.back();
    }
    onUpdatePromotionClick() {
        if (this.mForm.valid) {
            this.cEditPromotionReq.regId = this.pMerchInfoService.getRegId();
            this.pPromotionsService.updatePromotion(this.cEditPromotionReq)
                .subscribe(pResponse => this.updatePromotionSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
        }
    }
    //***********************************************Select Event*******************************************//
    fetchPromoDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPromotionDetailsProcEntity = mCommonResponse.data['promotionDetailsList'][0];
                this.cPromotionCardDetailsV2ProcEntity = mCommonResponse.data['promoCardDetailsList'];
                this.cCardTypeRes = mCommonResponse.data['cardTypeList'];
                for (var i = 0; i < this.cCardTypeRes.length; i++) {
                    this.cCardTypeOpt.payOptType = this.cCardTypeRes[i].payOptType;
                    this.cCardTypeOpt.cardNamesArr = this.cCardTypeRes[i].cardNames.split(',');
                    this.cCardTypeArrRes.push(this.cCardTypeOpt);
                    this.cCardTypeOpt = new CardTypeArrRes();
                }
                this.cEditPromotionReq.promotionName = this.cPromotionDetailsProcEntity.promoName;
                this.cEditPromotionReq.promotionDesc = this.cPromotionDetailsProcEntity.promoDesc;
                this.cEditPromotionReq.termsAndCondition = this.cPromotionDetailsProcEntity.promoTermCondition;
                if (this.cPromotionDetailsProcEntity.promoGlobalLimit === -1) {
                    this.cEditPromotionReq.globalLimit = 'Infinite';
                    this.isGlobalLimitCheck = true;
                    this.mForm.controls['globalLimit'].disable();
                }
                else {
                    this.cEditPromotionReq.globalLimit = this.cPromotionDetailsProcEntity.promoGlobalLimit;
                }
                if (this.cPromotionDetailsProcEntity.promoUserLimit === -1) {
                    this.cEditPromotionReq.userLimit = 'Infinite';
                    this.isUserLimitCheck = true;
                    this.mForm.controls['userLimit'].disable();
                }
                else {
                    this.cEditPromotionReq.userLimit = this.cPromotionDetailsProcEntity.promoUserLimit;
                }
                if (this.cPromotionDetailsProcEntity.promoCardLimit === -1) {
                    this.cEditPromotionReq.cardLimit = 'Infinite';
                    this.isCardLimitCheck = true;
                    this.mForm.controls['cardLimit'].disable();
                }
                else {
                    this.cEditPromotionReq.cardLimit = this.cPromotionDetailsProcEntity.promoCardLimit;
                }
                this.cEditPromotionReq.promotionStartDate = this.cPromotionDetailsProcEntity.promoValidityFrom;
                this.cEditPromotionReq.promotionEndDate = this.cPromotionDetailsProcEntity.promoValidityTo;
                var date = this.cEditPromotionReq.promotionStartDate;
                var datearray = date.split("-");
                this.cCreateNewPromotion.fromDate = datearray[1] + '-' + datearray[0] + '-' + datearray[2];
                this.fromDate = this.cCreateNewPromotion.fromDate;
                var today = new Date();
                var dd = today.getDate();
                var ddS = today.getDate().toString();
                var mm = today.getMonth() + 1; //January is 0
                var mmS = mm.toString();
                var yyyy = today.getFullYear();
                if (dd < 10) {
                    ddS = '0' + dd;
                }
                if (mm < 10) {
                    mmS = '0' + mm;
                }
                var todayDate = mmS + '-' + ddS + '-' + yyyy;
                var d1 = Date.parse(this.cCreateNewPromotion.fromDate);
                var d2 = Date.parse(todayDate);
                if (d1 < d2) {
                    this.fromDate = todayDate;
                }
                this.cCreateNewPromotion.endDatePicker = {
                    autoUpdateInput: false,
                    locale: { format: 'DD-MM-YYYY' },
                    alwaysShowCalendars: false,
                    "applyClass": "btn-theme",
                    "cancelClass": "btn-blank",
                    singleDatePicker: true,
                    minDate: new Date(this.fromDate),
                };
                this.cEditPromotionReq.promotionAnalyticsCode = this.cPromotionDetailsProcEntity.promoAnalyticsCode;
                this.cEditPromotionReq.promotionStatus = this.cPromotionDetailsProcEntity.promotionStatus;
                this.cEditPromotionReq.promoId = this.cPromotionDetailsProcEntity.promoId;
                this.cEditPromotionReq.promoCode = this.cPromotionDetailsProcEntity.promoCode;
                this.cEditPromotionReq.promoCurrency = this.cPromotionDetailsProcEntity.promoCurrency;
                this.cEditPromotionReq.promoType = this.cPromotionDetailsProcEntity.promoType;
                this.cEditPromotionReq.promoDiscountType = this.cPromotionDetailsProcEntity.promoDiscountType;
                this.cEditPromotionReq.promoDiscountValue = this.cPromotionDetailsProcEntity.promoDiscountValue.toFixed(2);
                if (this.sCheck.isNotNullNumber(this.cPromotionDetailsProcEntity.promoMinOrdAmt)) {
                    this.cEditPromotionReq.promoMinOrdAmt = this.cPromotionDetailsProcEntity.promoMinOrdAmt.toFixed(2);
                }
                this.cEditPromotionReq.promoMethod = this.cPromotionDetailsProcEntity.promoMethod;
                if (this.sCheck.isNotNullNumber(this.cPromotionDetailsProcEntity.promoMaxDiscount)) {
                    this.cEditPromotionReq.promoMaxDiscount = this.cPromotionDetailsProcEntity.promoMaxDiscount.toFixed(2);
                }
                this.cEditPromotionReq.promoBin = this.cPromotionDetailsProcEntity.promoBin;
                this.cEditPromotionReq.paymentBin = this.cPromotionDetailsProcEntity.promoBin.split(',');
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cPromotionDetailsProcEntity = null;
                this.cPromotionCardDetailsV2ProcEntity = null;
                this.cCardTypeRes = null;
            }
            else {
                console.log(this.sErrorMessagesService.responseNull);
                this.cPromotionDetailsProcEntity = null;
                this.cPromotionCardDetailsV2ProcEntity = null;
                this.cCardTypeRes = null;
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cPromotionDetailsProcEntity = null;
            this.cPromotionCardDetailsV2ProcEntity = null;
            this.cCardTypeRes = null;
        }
    }
    updatePromotionSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.pLocation.back();
    }
    enter(e) {
        this.scrolling = true;
    }
    leave(e) {
        this.scrolling = false;
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
};
tslib_1.__decorate([
    HostListener('paste', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], EditPromotionComponent.prototype, "blockPaste", null);
tslib_1.__decorate([
    HostListener('cut', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], EditPromotionComponent.prototype, "blockCut", null);
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], EditPromotionComponent.prototype, "onWindowScroll", null);
EditPromotionComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-edit-promotion',
        templateUrl: './edit-promotion.component.html',
        styleUrls: ['./edit-promotion.component.css'],
        providers: [PromotionsService]
    }),
    tslib_1.__param(10, Inject(DOCUMENT)),
    tslib_1.__param(11, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        ApiRequestService,
        MerchInfoService,
        PromotionsService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        ActivatedRoute,
        Document,
        Window])
], EditPromotionComponent);
export { EditPromotionComponent };
//# sourceMappingURL=edit-promotion.component.js.map