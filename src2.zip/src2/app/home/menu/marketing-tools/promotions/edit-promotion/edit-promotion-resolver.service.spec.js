import { TestBed, inject } from '@angular/core/testing';
import { EditPromotionResolverService } from './edit-promotion-resolver.service';
describe('EditPromotionResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [EditPromotionResolverService]
        });
    });
    it('should be created', inject([EditPromotionResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=edit-promotion-resolver.service.spec.js.map