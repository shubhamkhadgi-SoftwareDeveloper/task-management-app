export class CardTypeArrRes {
}
//# sourceMappingURL=card-type-arr-res.js.map