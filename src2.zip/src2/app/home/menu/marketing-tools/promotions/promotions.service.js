import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let PromotionsService = class PromotionsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBasePromotionsUrl = 'promotions/';
        this.cFetchAllPromotionsUrl = this.cBasePromotionsUrl + 'fetchPromotionsList';
        this.cFetchAllPromotionsForExportUrl = this.cBasePromotionsUrl + 'exportExelForPromotions';
        this.cAddPromotionsUrl = this.cBasePromotionsUrl + 'addPromotions';
        this.cUpdatePromotionStatusUrl = this.cBasePromotionsUrl + 'updatePromotionStatus';
        this.cFetchPromotionDetails = this.cBasePromotionsUrl + 'fetchPromotionDetails';
        this.cUpdatePromotions = this.cBasePromotionsUrl + 'updatePromotion';
        this.cFetchPayOptions = this.cBasePromotionsUrl + 'fetchMultiPaymentOptions';
    }
    fetchAllPromotions(pPromotionsSearchReq) {
        return this.pApiRequestService.httpPostRequest(pPromotionsSearchReq, this.cFetchAllPromotionsUrl);
    }
    fetchAllPromotionsForExport(pPromotionsSearchReq) {
        return this.pApiRequestService.exportFileRequest(pPromotionsSearchReq, this.cFetchAllPromotionsForExportUrl, 'Promotions.xlsx');
    }
    addPromotions(pPromotionReq) {
        return this.pApiRequestService.httpPostRequest(pPromotionReq, this.cAddPromotionsUrl);
    }
    updatePromotionStatus(pPromotionsSearchReq) {
        return this.pApiRequestService.httpPostRequest(pPromotionsSearchReq, this.cUpdatePromotionStatusUrl);
    }
    fetchPromotionDetails(pPromotionDetailsReq) {
        return this.pApiRequestService.httpPostRequest(pPromotionDetailsReq, this.cFetchPromotionDetails);
    }
    updatePromotion(pEditPromotionReq) {
        return this.pApiRequestService.httpPostRequest(pEditPromotionReq, this.cUpdatePromotions);
    }
    fetchPromotionPaymentOpt(pPromotionReq) {
        return this.pApiRequestService.httpPostRequest(pPromotionReq, this.cFetchPayOptions);
    }
};
PromotionsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], PromotionsService);
export { PromotionsService };
//# sourceMappingURL=promotions.service.js.map