import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { PromotionsService } from './promotions.service';
import { PromotionsSearchReq } from './promotions-search-req';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
let PromotionsResolverService = class PromotionsResolverService {
    constructor(pPromotionsService, pMerchInfoService) {
        this.pPromotionsService = pPromotionsService;
        this.pMerchInfoService = pMerchInfoService;
        this.cPromotionsSearchReq = new PromotionsSearchReq();
    }
    resolve(route, state) {
        return this.pPromotionsService.fetchAllPromotions(this.cPromotionsSearchReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PromotionsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [PromotionsService,
        MerchInfoService])
], PromotionsResolverService);
export { PromotionsResolverService };
//# sourceMappingURL=promotions-resolver.service.js.map