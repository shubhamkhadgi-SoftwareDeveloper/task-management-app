import { TestBed, inject } from '@angular/core/testing';
import { PromotionTransactionsResolverService } from './promotion-transactions-resolver.service';
describe('PromotionTransactionsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PromotionTransactionsResolverService]
        });
    });
    it('should be created', inject([PromotionTransactionsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=promotion-transactions-resolver.service.spec.js.map