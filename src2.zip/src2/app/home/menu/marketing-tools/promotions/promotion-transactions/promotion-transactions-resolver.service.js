import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { TransactionReq } from '../../../transactions/transactions/transaction.req';
import { PromotionsService } from '../promotions.service';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
let PromotionTransactionsResolverService = class PromotionTransactionsResolverService {
    constructor(pPromotionsService, pTransactionsService) {
        this.pPromotionsService = pPromotionsService;
        this.pTransactionsService = pTransactionsService;
    }
    resolve(route, state) {
        let mTransactionReq = new TransactionReq();
        mTransactionReq.promoCode = route.queryParams.promoCode;
        mTransactionReq.moduleName = 'Promotions';
        //mTransactionReq.searchTransactionStatus="Shipped"
        return this.pTransactionsService.fetchTransList(mTransactionReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PromotionTransactionsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [PromotionsService,
        TransactionsService])
], PromotionTransactionsResolverService);
export { PromotionTransactionsResolverService };
//# sourceMappingURL=promotion-transactions-resolver.service.js.map