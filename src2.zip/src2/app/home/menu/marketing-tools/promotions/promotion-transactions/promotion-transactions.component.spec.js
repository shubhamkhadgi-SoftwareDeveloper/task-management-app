import { async, TestBed } from '@angular/core/testing';
import { PromotionTransactionsComponent } from './promotion-transactions.component';
describe('PromotionTransactionsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PromotionTransactionsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(PromotionTransactionsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=promotion-transactions.component.spec.js.map