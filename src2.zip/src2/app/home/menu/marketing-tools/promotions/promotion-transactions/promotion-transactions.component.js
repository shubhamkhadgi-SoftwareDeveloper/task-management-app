import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { Promotions } from '../promotions.class';
import { CommonResponse } from '../../../../../common-response/common-response.res';
let PromotionTransactionsComponent = class PromotionTransactionsComponent {
    //***********************************************Constructor*******************************************//
    constructor(pLocation, pRouter) {
        this.pLocation = pLocation;
        this.pRouter = pRouter;
        this.cPromotions = new Promotions();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.pRouter.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cCommonResponse = data.commonResponse;
            }
        });
        this.pRouter.queryParams.subscribe(param => this.fetchPromotionsField(param));
        window.scrollTo(0, 0);
    }
    fetchPromotionsField(param) {
        this.cPromotions.promoCode = param.promoCode;
        this.cPromotions.startDate = param.startDate;
        this.cPromotions.endDate = param.endDate;
        this.cPromotions.status = param.status;
        this.cPromotions.promoValidity = param.promoValidity;
        this.cPromotions.promoId = param.promoId;
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
    }
};
PromotionTransactionsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-promotion-transactions',
        templateUrl: './promotion-transactions.component.html',
        styleUrls: ['./promotion-transactions.component.css'],
    }),
    tslib_1.__metadata("design:paramtypes", [Location,
        ActivatedRoute])
], PromotionTransactionsComponent);
export { PromotionTransactionsComponent };
//# sourceMappingURL=promotion-transactions.component.js.map