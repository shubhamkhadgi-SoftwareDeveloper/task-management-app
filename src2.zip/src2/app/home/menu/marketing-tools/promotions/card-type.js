export class CardType {
}
//# sourceMappingURL=card-type.js.map