import * as tslib_1 from "tslib";
import { Component, HostListener, ChangeDetectorRef, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { PromotionsService } from '../promotions.service';
import { CreateNewPromotion } from '../create-new-promotion.class';
import { PromotionReq } from '../promotions.req';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { CommonResponse, CustomResponseCode, CustomResponseMessage } from '../../../../../common-response/common-response.res';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { WINDOW } from "../../../../../common-services/window.service";
let CreateNewPromotionComponent = class CreateNewPromotionComponent {
    //***********************************************Constructor*******************************************//
    constructor(cdr, pApiRequestService, pMerchInfoService, pPromotionsService, pLocation, pFormBuilder, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, document, window) {
        this.cdr = cdr;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pPromotionsService = pPromotionsService;
        this.pLocation = pLocation;
        this.pFormBuilder = pFormBuilder;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.document = document;
        this.window = window;
        this.isGlobalLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isCardLimitCheck = false;
        this.isScroll = false;
        this.scrolling = false;
        this.isUserLimitDisabled = false;
        this.isCardLimitDisabled = false;
        this.isCommonInValid = false;
        this.newPromoFlag = true;
        this.isMaxAmountZero = false;
        this.cPaymentOption = [];
        this.cPaymentOptionList = [];
        this.cTempCardTypeList = [];
        this.nmcardTypeList = [];
        this.cPaymentCardList = [];
        this.itemList = [];
        this.dropdownList = [];
        this.selectedItems = [];
        this.unSelectedItemsCodes = [];
        this.unSelectedItemsDesc = [];
        this.dropdownSettings = {};
        this.fromDate = null;
        this.paymentBin = [];
        this.paymentBinString = null;
        this.cCommonResponse = new CommonResponse();
        this.cCreateNewPromotion = new CreateNewPromotion();
        this.cPromotionReq = new PromotionReq();
        this.isCommonInValid = false;
        this.calOptions = {
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.cPromotionReq.promotionStatus = "Enabled";
    }
    blockPaste(e) {
        e.preventDefault();
    }
    //    @HostListener('copy', ['$event']) blockCopy(e: KeyboardEvent) {
    //        e.preventDefault();
    //    }
    blockCut(e) {
        e.preventDefault();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.isGlobalLimitCheck = true;
        this.cPromotionReq.globalLimit = 'Infinite';
        this.mForm.controls['globalLimit'].disable();
        this.isUserLimitCheck = true;
        this.cPromotionReq.userLimit = 'Infinite';
        this.mForm.controls['userLimit'].disable();
        this.isCardLimitCheck = true;
        this.cPromotionReq.cardLimit = 'Infinite';
        this.mForm.controls['cardLimit'].disable();
        this.dropdownList = [];
        this.selectedItems = [];
        this.dropdownSettings = {
            singleSelection: false,
            text: "Select Card Type",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            groupBy: "payOptDesc",
            enableSearchFilter: true,
            searchAutofocus: true,
            badgeShowLimit: 1,
            searchPlaceholderText: 'Search Card Name',
        };
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            promotionName: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.promotionName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            promotionDesc: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promotionDescription
                ]],
            termsAndCondition: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promoTermsAndConditions
                ]],
            promotionAnalyticsCode: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            promotionStartDate: ['', Validators.required],
            promotionEndDate: ['', Validators.required],
            promotionCurrency: ['', Validators.required],
            promotionType: ['', Validators.required],
            promoDiscountType: ['', Validators.required],
            promoDiscountValue: ['', Validators.required],
            promoMethod: ['', Validators.required],
            promoMinOrderAmount: [''],
            paymentOption: ['', Validators.required],
            BankCardName: ['', Validators.required],
            promoMaxDiscountAmount: [''],
            promotionStatus: ['', Validators.required],
            globalLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            userLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            cardLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
            isCardLimitCheck: [''],
            paymentBinList: ['', [Validators.maxLength(2000), InvoiceSettingsValidator.promotionBins]],
        }, {
            validator: Validators.compose([this.validateLimit]),
        });
    }
    /* public promotionBins(control : AbstractControl) : {[key : string] : boolean}{
         let reg_exp =  /^\d{6}\s*$/i;
         if(!control.value){
             return null;
         }
         for(var i = 0; i < control.value.length; i++){
             if(reg_exp.test(control.value[i]['display'])){
                 if(control.value.length > i){
                     continue;
                 }else{
                     return null;
                 }
             }else if(reg_exp.test(control.value[i])){
                 if(control.value.length > i){
                     continue;
                 }else{
                     return null;
                 }
             }else{
                return {'promotionBins' : true};
             }
         }
     }*/
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['globalLimit'].disable();
            this.mForm.controls['globalLimit'].clearValidators();
            this.mForm.controls['globalLimit'].setValue(null);
            this.mForm.controls['globalLimit'].updateValueAndValidity();
            this.cPromotionReq.globalLimit = null;
            this.cPromotionReq.globalLimit = 'Infinite';
            this.isGlobalLimitCheck = true;
            let val = this.mForm.controls['userLimit'].value;
            if (val == 'Infinite') {
                this.mForm.controls['userLimit'].setErrors(null);
                this.mForm.controls['userLimit'].markAsDirty();
                this.mForm.controls['userLimit'].markAsTouched();
                this.mForm.controls['userLimit'].updateValueAndValidity();
            }
            this.isUserLimitDisabled = false;
            this.isCardLimitDisabled = false;
        }
        else {
            this.mForm.controls['globalLimit'].enable();
            this.cPromotionReq.globalLimit = null;
            this.mForm.controls['globalLimit'].setValidators([InvoiceSettingsValidator.integerNumberOnly,
                Validators.required, Validators.min(1), Validators.maxLength(9)
            ]);
            this.mForm.controls['globalLimit'].markAsDirty();
            this.mForm.controls['globalLimit'].markAsTouched();
            this.mForm.controls['globalLimit'].updateValueAndValidity();
        }
    }
    onUserLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['userLimit'].disable();
            this.mForm.controls['userLimit'].clearValidators();
            this.mForm.controls['userLimit'].updateValueAndValidity();
            this.cPromotionReq.userLimit = null;
            this.cPromotionReq.userLimit = 'Infinite';
            this.isUserLimitCheck = true;
        }
        else {
            this.mForm.controls['userLimit'].enable();
            this.cPromotionReq.userLimit = null;
            this.mForm.controls['userLimit'].setValidators([Validators.maxLength(9), InvoiceSettingsValidator.integerNumberOnly, Validators.required,
                Validators.min(1)
            ]);
            this.mForm.controls['userLimit'].markAsDirty();
            this.mForm.controls['userLimit'].markAsTouched();
            this.mForm.controls['userLimit'].updateValueAndValidity();
        }
    }
    onCardLimitCheckBoxClick(event) {
        if (event) {
            this.mForm.controls['cardLimit'].disable();
            this.mForm.controls['cardLimit'].clearValidators();
            this.mForm.controls['cardLimit'].updateValueAndValidity();
            this.cPromotionReq.cardLimit = null;
            this.cPromotionReq.cardLimit = 'Infinite';
            this.isCardLimitCheck = true;
        }
        else {
            this.mForm.controls['cardLimit'].enable();
            this.cPromotionReq.cardLimit = null;
            this.mForm.controls['cardLimit'].setValidators([Validators.required, InvoiceSettingsValidator.integerNumberOnly,
                Validators.min(1), Validators.maxLength(9)
            ]);
            this.mForm.controls['cardLimit'].markAsDirty();
            this.mForm.controls['cardLimit'].markAsTouched();
            this.mForm.controls['cardLimit'].updateValueAndValidity();
        }
    }
    onPromoDiscountTypeChange(event) {
        this.cPromotionReq.promoDiscountType = event.value;
        if (this.cPromotionReq.promoDiscountType == 'PERC') {
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99), Validators.maxLength(9)]); //InvoiceSettingsValidator.numbersOnly,
            this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
            this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            this.minDisValue = 0.01;
            this.maxDisValue = 99.99;
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(5), this.percentagesValue]);
            this.mForm.controls['promoDiscountValue'].markAsDirty();
            this.mForm.controls['promoDiscountValue'].markAsTouched();
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
        }
        else if (this.cPromotionReq.promoDiscountType == 'FLAT') {
            this.mForm.controls['promoMaxDiscountAmount'].setErrors(null);
            this.mForm.controls['promoMaxDiscountAmount'].clearValidators();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            this.minDisValue = 0.01;
            this.maxDisValue = 9999.99;
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(7), this.flatValue]);
            this.mForm.controls['promoDiscountValue'].markAsDirty();
            this.mForm.controls['promoDiscountValue'].markAsTouched();
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['promoMaxDiscountAmount'].setErrors(null);
            this.mForm.controls['promoMaxDiscountAmount'].clearValidators();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
        }
    }
    onPromoMethodChange(event) {
        this.cPromotionReq.promoMethod = event.value;
        if (this.cPromotionReq.promoMethod == 'Orders Over') {
            this.maxDisValue = 999999.99;
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].valueChanges;
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly,
                Validators.min(1), Validators.max(this.maxDisValue), Validators.maxLength(9),
                this.flatValue]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].valueChanges;
            this.mForm.controls['promoMaxDiscountAmount'].setValidators([this.flatValue]);
            this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
            this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
        }
        else if (this.cPromotionReq.promoMethod == 'Order Amount') {
            this.mForm.controls['promoMinOrderAmount'].clearValidators();
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['promoMinOrderAmount'].clearValidators();
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
        }
        if (this.sCheck.isNotNullNumber(this.mForm.controls['promoMinOrderAmount'].value) && this.mForm.controls['promoMethod'].value == 'Order Amount') {
            this.isCommonInValid = true;
        }
        else if (!this.sCheck.isNotNullNumber(this.mForm.controls['promoMinOrderAmount'].value) && this.mForm.controls['promoMethod'].value == 'Orders Over' && this.cPromotionReq.promoDiscountType != 'PERC') {
            this.isCommonInValid = true;
        }
    }
    onBlur(event) {
        if (event) {
            if (this.cPromotionReq.promoDiscountValue != null && !this.mForm.controls['promoDiscountValue'].valid && this.cPromotionReq.promoDiscountType == 'PERC') {
                this.minDisValue = 0.01;
                this.maxDisValue = 99.99;
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(7), this.flatValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
                let value = +this.cPromotionReq.promoDiscountValue;
                if (!Number.isNaN(value)) {
                    this.cPromotionReq.promoDiscountValue = value.toFixed(2);
                }
            }
            else {
                this.minDisValue = 0.01;
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.maxLength(7), this.flatValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
                let value = +this.cPromotionReq.promoDiscountValue;
                if (!Number.isNaN(value)) {
                    this.cPromotionReq.promoDiscountValue = value.toFixed(2);
                }
            }
            if (this.cPromotionReq.promoMinOrderAmount != null && this.mForm.controls['promoMinOrderAmount'].valid
            /*&& +this.cPromotionReq.promoDiscountValue < +this.cPromotionReq.promoMinOrderAmount*/ ) {
                this.isCommonInValid = false;
                let value = +this.cPromotionReq.promoMinOrderAmount;
                this.cPromotionReq.promoMinOrderAmount = value.toFixed(2);
            }
            if (this.cPromotionReq.promoMaxDiscountAmount != null && this.mForm.controls['promoMaxDiscountAmount'].valid) {
                let value = +this.cPromotionReq.promoMaxDiscountAmount;
                this.cPromotionReq.promoMaxDiscountAmount = value.toFixed(2);
                if (this.mForm.controls['promoMaxDiscountAmount'].value == 0 || this.mForm.controls['promoMaxDiscountAmount'].value == 0.00)
                    this.isMaxAmountZero = true;
                else
                    this.isMaxAmountZero = false;
            }
        }
    }
    //***********************************************Multiselect Event ********************************************//
    onItemSelect(item) {
        //console.log(this.dropdownList);
        // console.log(item.payOptType); //cTempCardTypeList
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    OnItemDeSelect(item) {
        //          console.log(this.selectedItems);
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    onSelectAll(items) {
        // console.log(items);
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    onDeSelectAll(items) {
        //  console.log(items);
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        if (!this.sCheck.isNotNullObject(this.unSelectedItemsCodes))
            this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
                return !cheArr.includes(el);
            });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    //***********************************************Event*******************************************//
    /*onRemoveValue( event ) {
        if ( event ) {
            this.mForm.controls['paymentBin'].clearValidators();
            this.mForm.controls['paymentBin'].setValidators(this.promotionBins);
            this.mForm.controls['paymentBin'].updateValueAndValidity();
        }
    }

    onValueChange( event ) {
        if ( event ) {
            this.mForm.controls['paymentBin'].clearValidators();
            this.mForm.controls['paymentBin'].setValidators(this.promotionBins);
            this.mForm.controls['paymentBin'].updateValueAndValidity();
        }
    }*/
    //***********************************************Button Click Event*******************************************//
    onCancelClick() {
        this.pLocation.back();
        this.cPromotionReq = new PromotionReq();
        this.cPromotionReq.regId = this.pMerchInfoService.getRegId();
        this.newPromoFlag = true;
    }
    onCreateClick() {
        if (this.cPromotionReq.paymentBin != null && this.cPromotionReq.paymentBin.length > 0) {
            for (var i = 0; i < this.cPromotionReq.paymentBin.length; i++) {
                if (typeof this.cPromotionReq.paymentBin[i]['display'] == 'undefined') {
                    this.paymentBin.push(this.cPromotionReq.paymentBin[i]);
                }
                else {
                    this.paymentBin.push(this.cPromotionReq.paymentBin[i]['display']);
                }
            }
            this.cPromotionReq.paymentBin = this.paymentBin;
        }
        if (this.cPromotionReq.paymentBinList != null && this.cPromotionReq.paymentBinList != undefined)
            this.cPromotionReq.paymentBinList = this.cPromotionReq.paymentBinList.toString();
        this.cPromotionReq.paymentCardBankName = [];
        if (this.selectedItems != null && this.selectedItems != undefined) {
            let i = 0;
            this.selectedItems.forEach(arrayItem => {
                this.cPromotionReq.paymentCardBankName[i] = arrayItem.payOptType + "#" + arrayItem.itemName;
                i++;
            });
        }
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        if (!this.sCheck.isNotNullObject(this.unSelectedItemsCodes))
            this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
                return !cheArr.includes(el);
            });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
        if (this.mForm.valid && this.newPromoFlag && this.unSelectedItemsDesc.length == 0) {
            this.cPromotionReq.regId = this.pMerchInfoService.getRegId();
            this.pPromotionsService.addPromotions(this.cPromotionReq)
                .subscribe(pResponse => this.CreateSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
        }
        if (this.mForm.valid)
            this.newPromoFlag = false;
    }
    onCurrencyChange(pEvent) {
        if (pEvent) {
            this.dropdownList = [];
            this.cPaymentOptionList = [];
            this.cPaymentOptionList = [];
            this.selectedItems = [];
            this.cPromotionReq.paymentOption = [];
            this.mForm.controls['promoMethod'].setValue("");
            this.cPromotionReq.promotionCurrency = null;
            this.cPromotionReq.regId = this.pMerchInfoService.getRegId();
            this.cPromotionReq.promotionCurrency = pEvent.value;
            this.pPromotionsService.fetchPromotionPaymentOpt(this.cPromotionReq)
                .subscribe(pResponse => this.fetchPayOptionSuccess(pResponse), error => { console.log('error'); });
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    //console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    validateLimit(pFormGroup) {
        var globalLimit = pFormGroup.controls['globalLimit'];
        var userLimit = pFormGroup.controls['userLimit'];
        var cardLimit = pFormGroup.controls['cardLimit'];
        let globalLimitVal = +globalLimit.value;
        let userLimitVal = +userLimit.value;
        let cardLimitVal = +cardLimit.value;
        if (userLimitVal > globalLimitVal) {
            userLimit.setErrors({ validateLimit: true });
        }
        else if (userLimitVal != 0 && userLimitVal <= globalLimitVal) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && userLimitVal != 0) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && userLimit.value == 'Infinite') {
            userLimit.setErrors(null);
        }
        if (cardLimitVal > globalLimitVal) {
            cardLimit.setErrors({ validateLimit: true });
        }
        else if (cardLimitVal != 0 && cardLimitVal <= globalLimitVal) {
            cardLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && cardLimitVal != 0) {
            cardLimit.setErrors(null);
        }
        else if (globalLimit.value == 'Infinite' && cardLimit.value == 'Infinite') {
            cardLimit.setErrors(null);
        }
        if (userLimit.value == 'Infinite' && globalLimit.value != 'Infinite') {
            userLimit.setErrors({ validateLimit: true }); //this.isUserLimitCheck = true;
        }
        if (cardLimit.value == 'Infinite' && globalLimit.value != 'Infinite') {
            cardLimit.setErrors({ validateLimit: true });
        }
        return null;
    }
    validateAgain() {
        this.mForm.controls['userLimit'].setValidators([InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]);
        this.mForm.controls['cardLimit'].setValidators([InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]);
        this.mForm.controls['userLimit'].markAsDirty();
        this.mForm.controls['userLimit'].markAsTouched();
        this.mForm.controls['cardLimit'].markAsDirty();
        this.mForm.controls['cardLimit'].markAsTouched();
        this.mForm.controls['cardLimit'].updateValueAndValidity();
        this.mForm.controls['userLimit'].updateValueAndValidity();
    }
    onLimitChange() {
        this.isUserLimitCheck = false;
        this.isUserLimitDisabled = true;
        this.mForm.controls['userLimit'].enable();
        this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
        this.mForm.controls['userLimit'].updateValueAndValidity();
        this.isCardLimitCheck = false;
        this.isCardLimitDisabled = true;
        this.mForm.controls['cardLimit'].enable();
        this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
        this.mForm.controls['cardLimit'].updateValueAndValidity();
    }
    validateAmount() {
        var promoDiscountValue = this.mForm.controls['promoDiscountValue'];
        var promoMinOrderAmount = this.mForm.controls['promoMinOrderAmount'];
        let Discountvalue = +promoDiscountValue.value;
        let minOrderAmount = +promoMinOrderAmount.value;
        let isCoupanMethodSel = this.sCheck.isNotNullString(this.mForm.controls['promoMethod'].value);
        if (!this.sCheck.isNotNullNumber(promoDiscountValue.value)) {
            if (this.cPromotionReq.promoDiscountType == 'FLAT') {
                this.isCommonInValid = true;
            }
            else if (this.cPromotionReq.promoDiscountType == 'PERC') {
                this.isCommonInValid = true;
            }
        }
        else if (this.sCheck.isNotNullNumber(promoMinOrderAmount.value) && this.mForm.controls['promoMethod'].value == 'Order Amount' && this.cPromotionReq.promoDiscountType == 'FLAT') {
            this.isCommonInValid = true;
        }
        else if (!this.sCheck.isNotNullNumber(promoMinOrderAmount.value) && this.mForm.controls['promoMethod'].value == 'Orders Over' && this.cPromotionReq.promoDiscountType == 'FLAT') {
            this.isCommonInValid = true;
        }
        else if (!this.sCheck.isNotNullNumber(promoMinOrderAmount.value) && this.mForm.controls['promoMethod'].value == 'Orders Over' && this.cPromotionReq.promoDiscountType == 'PERC') {
            this.isCommonInValid = true;
        }
        else if (!this.sCheck.isNotNullNumber(promoDiscountValue.value) && this.mForm.controls['promoMethod'].value == 'Order Amount' && this.cPromotionReq.promoDiscountType == 'PERC') {
            this.isCommonInValid = true;
        }
        else {
            this.isCommonInValid = false;
        } /*else if(this.sCheck.isNotNullNumber( promoDiscountValue.value) && this.cPromotionReq.promoDiscountType == 'PERC' && isCoupanMethodSel && (this.cPromotionReq.promoMethod == 'Orders Over' || this.cPromotionReq.promoMethod == 'Entire Order')){
            this.isCommonInValid = true;
        }else if(this.sCheck.isNotNullNumber(promoMinOrderAmount.value) && isCoupanMethodSel && this.cPromotionReq.promoMethod == 'Orders Over' && this.cPromotionReq.promoDiscountType == 'FLAT'){
            this.isCommonInValid = true;
        }else if(this.sCheck.isNotNullNumber(promoMinOrderAmount.value) && isCoupanMethodSel && this.cPromotionReq.promoMethod == 'Orders Over' && this.cPromotionReq.promoDiscountType == 'PERC'){
            this.isCommonInValid = true;
        }else if(this.sCheck.isNullString(promoMinOrderAmount) && isCoupanMethodSel && this.cCouponMethodSelect == 'Orders Over' && this.cDiscountTypeSelect == 'SHIP'){
            this.isCommonInValid = true;
        } else{
            this.isCommonInValid = false;
        }*/
        if (Discountvalue > minOrderAmount && minOrderAmount != 0) {
            promoMinOrderAmount.setErrors({ validateAmount: true });
        }
        else if (minOrderAmount == 0) {
            promoMinOrderAmount.setErrors(null);
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly,
                Validators.min(1), Validators.maxLength(9), this.flatValue
            ]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
        }
        else {
            promoMinOrderAmount.setErrors(null);
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly,
                Validators.min(1), Validators.maxLength(9), this.flatValue
            ]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
        }
        return null;
    }
    calculateMaxDiscountAmt() {
        var minOrderAmt = this.mForm.controls['promoMinOrderAmount'];
        var discountAmt = this.mForm.controls['promoDiscountValue'];
        var promoMaxDiscountAmount = this.mForm.controls['promoMaxDiscountAmount'];
        let minOrderAmtVal = +minOrderAmt.value;
        let discountAmtVal = +discountAmt.value;
        let promoMaxDiscountAmountVal = +promoMaxDiscountAmount.value;
        let val = discountAmtVal / 100;
        let maxDisAmt = Number(Math.floor((val * minOrderAmtVal + 1)).toFixed());
        if (promoMaxDiscountAmountVal != 0 && promoMaxDiscountAmountVal < maxDisAmt && !(this.mForm.controls['promoMethod'].value == 'Order Amount'
            && this.cPromotionReq.promoDiscountType == 'FLAT')) {
            this.cCreateNewPromotion.maxDiscountAmt = maxDisAmt - 1;
            promoMaxDiscountAmount.setErrors({ calculateMaxDiscountAmt: true });
            this.isMaxAmountZero = false;
        }
        else if (promoMaxDiscountAmount.value == 0) {
            this.isMaxAmountZero = true;
        }
        if (this.sCheck.isNotNullNumber(minOrderAmtVal)) {
            this.isCommonInValid = false;
        }
        else {
            this.isCommonInValid = true;
        }
        return null;
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAllowedWithMaxTenDigits(pEvent) {
        const pattern = /[0-9]/;
        ;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAndDotAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    percentagesValue(control) {
        let reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'percentagesValue': true };
    }
    flatValue(control) {
        let reg_exp = /^((\d)*(\.)?\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'flatValue': true };
    }
    //***********************************************Select Event*******************************************//
    selectedStartDate(value) {
        this.cPromotionReq.promotionStartDate = value.start.format("DD-MM-YYYY");
        this.cCreateNewPromotion.fromDate = value.start.format("YYYY-MM-DD");
        this.cCreateNewPromotion.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.cCreateNewPromotion.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(this.cCreateNewPromotion.fromDate),
        };
        this.mForm.controls['promotionEndDate'].setValue(this.cPromotionReq.promotionStartDate);
    }
    selectedEndDate(value) {
        this.cPromotionReq.promotionEndDate = value.start.format("DD-MM-YYYY");
        this.cCreateNewPromotion.toDate = this.cPromotionReq.promotionEndDate;
        var date = this.cPromotionReq.promotionStartDate;
        var datearray = date.split("-");
        this.cCreateNewPromotion.fromDate = datearray[1] + '-' + datearray[0] + '-' + datearray[2];
        this.fromDate = this.cCreateNewPromotion.fromDate;
        this.cCreateNewPromotion.startDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(),
        };
        this.cCreateNewPromotion.endDatePicker = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            minDate: new Date(this.cCreateNewPromotion.fromDate),
        };
    }
    //***********************************************Server Call Event**********************************************//
    fetchPayOptionSuccess(pResponse) {
        this.cardTypeList = [];
        this.cPromotionPaymentOption = [];
        if (this.sCheck.isNotNullObject(pResponse.data)) {
            this.cardTypeList = pResponse.data.promoCardDetailsList;
            this.cCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(this.cCommonResponse)) {
                if (this.sCheck.isNotNullObject(this.cCommonResponse.data)) {
                    if (this.sCheck.isNotNullList(this.cCommonResponse.data['promotionPaymentOpt'])) {
                        this.cPromotionPaymentOption = this.cCommonResponse.data['promotionPaymentOpt'];
                    }
                }
            }
        }
        this.cPaymentOptionList = [];
        if (this.sCheck.isNotNullList(this.cPromotionPaymentOption)) {
            for (let pPayOption of this.cPromotionPaymentOption) {
                this.cPaymentOptionList.push({ label: pPayOption.payOptDesc, value: pPayOption.payOptType });
            }
        }
    }
    getPaymentOptionList() {
        return this.cPaymentOptionList;
    }
    getPaymentCardList() {
        return this.cPaymentCardList;
    }
    selectedPaymentType(event) {
        this.dropdownList = [];
        this.selectedItems = [];
        this.unSelectedItemsCodes = [];
        event.value.forEach(val => {
            this.cardTypeList.forEach(card => {
                if (val == card.payOptType) {
                    // this.dropdownList.push(card);
                    this.dropdownList.push({ "id": card.id, "itemName": card.cardName, "payOptType": card.payOptType, "payOptDesc": card.payOptDesc }); //
                }
            });
        });
    }
    CreateSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.pLocation.back();
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
};
tslib_1.__decorate([
    HostListener('paste', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], CreateNewPromotionComponent.prototype, "blockPaste", null);
tslib_1.__decorate([
    HostListener('cut', ['$event']),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [KeyboardEvent]),
    tslib_1.__metadata("design:returntype", void 0)
], CreateNewPromotionComponent.prototype, "blockCut", null);
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], CreateNewPromotionComponent.prototype, "onWindowScroll", null);
CreateNewPromotionComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-create-new-promotion',
        templateUrl: './create-new-promotion.component.html',
        styleUrls: ['./create-new-promotion.component.css'],
        providers: [PromotionsService]
    }),
    tslib_1.__param(10, Inject(DOCUMENT)),
    tslib_1.__param(11, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ApiRequestService,
        MerchInfoService,
        PromotionsService,
        Location,
        FormBuilder,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        Document,
        Window])
], CreateNewPromotionComponent);
export { CreateNewPromotionComponent };
//# sourceMappingURL=create-new-promotion.component.js.map