import { async, TestBed } from '@angular/core/testing';
import { CreateNewPromotionComponent } from './create-new-promotion.component';
describe('CreateNewPromotionComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CreateNewPromotionComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CreateNewPromotionComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=create-new-promotion.component.spec.js.map