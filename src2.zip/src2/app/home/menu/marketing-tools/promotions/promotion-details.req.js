export class PromotionDetailsReq {
}
//# sourceMappingURL=promotion-details.req.js.map