import { TestBed, inject } from '@angular/core/testing';
import { PromotionsResolverService } from './promotions-resolver.service';
describe('PromotionsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PromotionsResolverService]
        });
    });
    it('should be created', inject([PromotionsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=promotions-resolver.service.spec.js.map