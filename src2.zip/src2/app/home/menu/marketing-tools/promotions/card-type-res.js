export class CardTypeRes {
}
//# sourceMappingURL=card-type-res.js.map