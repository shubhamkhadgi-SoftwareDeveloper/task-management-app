export class PromotionsWrapperRes {
}
//# sourceMappingURL=promotions-wrapper.res.js.map