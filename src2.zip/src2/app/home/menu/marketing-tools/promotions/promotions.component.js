import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef, HostListener, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { TitleService } from './../../../../common-services/title.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonResponse, CustomResponseMessage, CustomResponseCode } from '../../../../common-response/common-response.res';
import { WINDOW } from "../../../../common-services/window.service";
import { DOCUMENT, DatePipe } from '@angular/common';
import { PromotionsService } from './promotions.service';
import { PromotionReq } from './promotions.req';
import { PromotionsSearchReq } from './promotions-search-req';
import { PromotionDetailsReq } from './promotion-details.req';
import { Promotions } from './promotions.class';
import { EditPromotionReq } from './edit-promotion/edit-promotion.req';
import { PromotionDetailsProcEntity } from '../../../../proc-entities/promotion-details-proc-entity';
import { trigger, style, transition, animate, state } from '@angular/animations';
import { InvoiceSettingsValidator } from '../../invoice/invoice-settings/invoice-settings-validator';
import { CreateNewPromotion } from './create-new-promotion.class';
import { CardTypeArrRes } from './card-type-arr-res';
import { expandOnEnterAnimation, collapseOnLeaveAnimation, fadeInExpandOnEnterAnimation, fadeOutCollapseOnLeaveAnimation } from 'angular-animations';
import { PaginatorComponent } from './../../../../common-components/paginator/paginator.component';
let PromotionsComponent = class PromotionsComponent {
    //***********************************************Constructor*******************************************//
    constructor(cdr, pApiRequestService, pMerchInfoService, pPromotionsService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, pFormBuilder, sErrorHandler, sTitleService, pModalService, pDatePipe, document, window) {
        this.cdr = cdr;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pPromotionsService = pPromotionsService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.sTitleService = sTitleService;
        this.pModalService = pModalService;
        this.pDatePipe = pDatePipe;
        this.document = document;
        this.window = window;
        this.cCardTypeArrRes = [];
        this.isGlobalLimitCheck = false;
        this.isEditGlobalLimitCheck = false;
        this.isEditUserLimitCheck = false;
        this.isEditCardLimitCheck = false;
        this.cIsWritePrivilege = false;
        this.isUserLimitCheck = false;
        this.isCardLimitCheck = false;
        this.isScroll = false;
        this.scrolling = false;
        this.isUserLimitDisabled = false;
        this.isCardLimitDisabled = false;
        this.isCommonInValid = false;
        this.newPromoFlag = true;
        this.isMaxAmountZero = false;
        this.isPopNextFlag = false;
        this.isPopNextEditFlag = false;
        this.isFirstModalValid = false;
        this.isShowExportIcon = false;
        this.isRestrictedClick = false;
        this.isRequiredUserLimit = false;
        this.isRequiredGlobalLimit = false;
        this.isRequiredCardLimit = false;
        this.isRequiredEditUserLimit = false;
        this.isRequiredEditGlobalLimit = false;
        this.isRequiredEditCardLimit = false;
        this.isEditUserLimitDisabled = false;
        this.isEditCardLimitDisabled = false;
        this.isPercOnOrderAmount = false;
        this.isPercOverOrderAmount = false;
        this.isDiscountTypePERC = false;
        this.isEditbinValue = false;
        this.isPromotionBinDiv = false;
        this.isSearchPanelClick = false;
        this.isGlobalLimitExceeds = false;
        this.searchflag = 'searchform';
        this.selectedSearchById = '';
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.cPaymentOptionList = [];
        this.nmcardTypeList = [];
        this.cPaymentCardList = [];
        this.paymentBin = [];
        this.paymentBinString = null;
        this.toDate = '';
        this.fromDate = '';
        this.globalPlaceholder = 'Unlimited';
        this.userPlaceholder = 'Unlimited';
        this.cardPlaceholder = 'Unlimited';
        this.editGlobalPlaceholder = 'Unlimited';
        this.editUserPlaceholder = 'Unlimited';
        this.editCardPlaceholder = 'Unlimited';
        this.itemList = [];
        this.dropdownList = [];
        this.selectedItems = [];
        this.unSelectedItemsCodes = [];
        this.unSelectedItemsDesc = [];
        this.dropdownSettings = {};
        this.cCommonResponse = new CommonResponse();
        this.cPromotions = new Promotions();
        this.cPromotionsSearchReq = new PromotionsSearchReq();
        this.cPromotionDetailsReq = new PromotionDetailsReq();
        this.cEditPromotionReq = new EditPromotionReq();
        this.cCreateNewPromotion = new CreateNewPromotion();
        this.cPromotionDetailsEditRes = new PromotionDetailsProcEntity();
        this.cPromotionReq = new PromotionReq();
        this.cPaginatorComponent = new PaginatorComponent();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.Promotions);
        this.sTitleService.setTitle(this.sTitleService.Promotions);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            showDropdowns: true,
            opens: "left",
        };
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        // this.cPromotions = new Promotions();
        this.createForm();
        this.mForm.controls['fromToDate'].disable();
        this.mForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cPromotions.totalCount = mCommonResponse.data['totalCount'];
                this.cPromotionsListProcEntity = mCommonResponse.data['promotionsList'];
                if (this.cPromotionsListProcEntity.length != 0) {
                    this.cPromotions.isAnyPromoCreated = true;
                }
            }
            else {
                this.cPromotions.landingPageMsg = this.sLandingPageMsgService.noPromoCreatedYetMsg;
                this.cPromotions.isAnyPromoCreated = false;
            }
        });
        this.toDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
        this.fromDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
        this.cPromotionReq.promotionEndDate = this.toDate;
        this.cPromotionReq.promotionStartDate = this.fromDate;
        this.cCreateNewPromotion.fromToDate = this.fromDate + '-' + this.toDate;
        this.dropdownSettings = {
            singleSelection: false,
            text: "Select Card / Bank Name",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            groupBy: "payOptDesc",
            enableSearchFilter: false,
            searchAutofocus: true,
            badgeShowLimit: 1,
            searchPlaceholderText: 'Search Card Name',
        };
        this.maxAmountValue = 999999.99;
        this.minAmountValue = 0.01;
    }
    ngOnDestroy() {
        if (this.cModalRef)
            this.cModalRef.hide();
    }
    //***********************************************Mouse Event*******************************************//
    mouseleaveExportEvent() {
        this.cPromotions.isExportClick = false;
    }
    //*****************************Validations********************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchBy: [''],
            searchByValue: [''],
            promotionType: [''],
            //promotionStatus : [''],
            promoSearchStatus: [''],
            fromToDate: [''],
            dateType: ['']
        });
    }
    disableFileds() {
        this.mForm.controls['promotionCurrency'].disable();
        this.mForm.controls['promotionType'].disable();
        this.mForm.controls['promoDiscountType'].disable();
        this.mForm.controls['promoMethod'].disable();
        this.mForm.controls['promoMinOrderAmount'].disable();
        this.mForm.controls['promoMaxDiscountAmount'].disable();
        this.mForm.controls['promoDiscountValue'].disable();
        if (this.sCheck.isNotNullString(this.cEditPromotionReq.promoBin)) {
            this.mForm.controls['cardLimit'].disable();
            this.mForm.controls['isCardLimitCheck'].disable();
        }
        this.mForm.controls['paymentBinList'].disable();
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    validateLimit(pFormGroup) {
        //changes madhe for user and card limit if value id zero
        var globalLimit = pFormGroup.controls['globalLimit'];
        var userLimit = pFormGroup.controls['userLimit'];
        var cardLimit = pFormGroup.controls['cardLimit'];
        let globalLimitVal = +globalLimit.value;
        let userLimitVal = +userLimit.value;
        let cardLimitVal = +cardLimit.value;
        if (userLimitVal > globalLimitVal && globalLimitVal != 0) {
            userLimit.setErrors({ validateLimit: true });
        }
        else if (userLimitVal != 0 && userLimitVal <= globalLimitVal) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 0 && userLimitVal != 0) {
            userLimit.setErrors(null);
        }
        else if (globalLimit.value == 0 && userLimit.value == null) {
            userLimit.setErrors(null);
        }
        if (cardLimitVal > globalLimitVal && globalLimitVal != 0) {
            cardLimit.setErrors({ validateLimit: true });
        }
        else if (cardLimitVal != 0 && cardLimitVal <= globalLimitVal) {
            cardLimit.setErrors(null);
        }
        else if (globalLimit.value == 0 && cardLimitVal != 0) {
            cardLimit.setErrors(null);
        }
        else if (globalLimit.value == 0 && cardLimit.value == null) {
            cardLimit.setErrors(null);
        }
        return null;
    }
    validateFirstModal() {
        this.mForm = this.pFormBuilder.group({
            promotionName: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.promotionName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            promotionDesc: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promotionDescription
                ]],
            termsAndCondition: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promoTermsAndConditions
                ]],
            promotionAnalyticsCode: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            globalLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.min(1), Validators.maxLength(9)]],
            userLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.min(1), Validators.maxLength(9)]],
            cardLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.min(1), Validators.maxLength(9)]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
            isCardLimitCheck: [''],
            promotionStartDate: [''],
            promoStartEndDate: [''],
            formFromToDate: [''],
        }, { validator: Validators.compose([this.validateLimit]),
        });
    }
    validateSecondModal() {
        this.mForm = this.pFormBuilder.group({
            promotionCurrency: ['', Validators.required],
            promotionType: ['', Validators.required],
            promoDiscountType: ['', Validators.required],
            promoDiscountValue: ['', Validators.required],
            promoMethod: ['', Validators.required],
            promoMinOrderAmount: [''],
            paymentOption: ['', Validators.required],
            BankCardName: ['', Validators.required],
            promoMaxDiscountAmount: ['', Validators.max(999999.99)],
            promoStartEndDate: [''],
            paymentBinList: ['', [Validators.maxLength(2000), InvoiceSettingsValidator.promotionBins]],
            paymentBin: ['', [this.promotionBins]],
            isEditbinValue: [''],
            promotionStatus: ['', Validators.required]
        });
    }
    validateSecondEditModal() {
        this.mForm = this.pFormBuilder.group({
            promotionType: ['', Validators.required],
            promoDiscountType: ['', Validators.required],
            promoDiscountValue: ['', Validators.required],
            promoMethod: ['', Validators.required],
            promoMinOrderAmount: [''],
            promoMaxDiscountAmount: [''],
            promotionStatus: ['', Validators.required],
            promoStartEndDate: [''],
            paymentBinList: ['', [Validators.maxLength(2000), InvoiceSettingsValidator.promotionBins]],
            isEditbinValue: ['']
        });
    }
    promotionBins(control) {
        let reg_exp = /^\d{6}\s*$/i;
        if (!control.value) {
            return null;
        }
        for (var i = 0; i < control.value.length; i++) {
            if (reg_exp.test(control.value[i]['display'])) {
                if (control.value.length > i) {
                    continue;
                }
                else {
                    return null;
                }
            }
            else if (reg_exp.test(control.value[i])) {
                if (control.value.length > i) {
                    continue;
                }
                else {
                    return null;
                }
            }
            else {
                return { 'promotionBins': true };
            }
        }
    }
    onEditGlobalChange(pEvent) {
        if (pEvent) {
            if (this.sCheck.isNotNullString(this.cEditPromotionReq.globalLimit) && this.cEditPromotionReq.globalLimit != 0) {
                if (this.pendingGlobalCount > this.mForm.controls["globalLimit"].value) {
                    console.log("discount coupon value" + this.cEditPromotionReq.globalLimit);
                    this.isGlobalLimitExceeds = true;
                }
                else {
                    this.isGlobalLimitExceeds = false;
                }
            }
            else {
                this.isGlobalLimitExceeds = false;
            }
        }
        else {
            this.isGlobalLimitExceeds = false;
        }
    }
    onEditClose() {
        this.isRequiredEditCardLimit = false;
        this.isRequiredEditUserLimit = false;
        this.isRequiredEditGlobalLimit = false;
        this.isGlobalLimitExceeds = false;
        this.pendingGlobalCount = null;
        this.cModalRef.hide();
        this.mForm.reset();
    }
    onCreateClose() {
        this.isRequiredCardLimit = false;
        this.isRequiredUserLimit = false;
        this.isRequiredGlobalLimit = false;
        this.isPercOverOrderAmount = false;
        this.isPercOnOrderAmount = false;
        this.cModalRef.hide();
        this.mForm.reset();
    }
    //***********************************************Event*******************************************//
    onRemoveValue(event) {
        if (event) {
            this.mForm.controls['paymentBin'].clearValidators();
            this.mForm.controls['paymentBin'].setValidators(this.promotionBins);
            this.mForm.controls['paymentBin'].updateValueAndValidity();
        }
    }
    onValueChange(event) {
        if (event) {
            this.mForm.controls['paymentBin'].clearValidators();
            this.mForm.controls['paymentBin'].setValidators(this.promotionBins);
            this.mForm.controls['paymentBin'].updateValueAndValidity();
        }
    }
    //***********************************************Button Click Event********************************************//
    onBackClick() {
        this.pLocation.back();
    }
    onOpenNextClick() {
        if (this.mForm.valid && ((this.isCardLimitCheck == true && this.cPromotionReq.cardLimit) || (this.isCardLimitCheck == false && this.cardPlaceholder == "Unlimited"))
            && ((this.isUserLimitCheck == true && this.cPromotionReq.userLimit) || (this.isUserLimitCheck == false && this.userPlaceholder == "Unlimited"))) {
            this.isPopNextFlag = true;
            this.validateSecondModal();
            if (this.cPromotionReq.promoMethod == 'Order Amount' || this.cPromotionReq.promoMethod == null) {
                this.mForm.controls['promoMinOrderAmount'].disable();
            }
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
        }
    }
    onEditNextClick() {
        if (this.mForm.valid && !this.isGlobalLimitExceeds && ((this.isEditCardLimitCheck == true && this.cEditPromotionReq.cardLimit) || (this.isEditCardLimitCheck == false && this.editCardPlaceholder == "Unlimited"))) {
            this.validateSecondEditModal();
            this.isPopNextEditFlag = true;
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
        }
    }
    onSearchPanelClick() {
        this.createForm();
        if (this.cPromotionsSearchReq.dateFlag == null)
            this.mForm.controls['fromToDate'].disable();
        if (this.cPromotionsSearchReq.searchBy == null) {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
        }
        this.cPromotions.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onSearchByClick() {
        this.cPromotions.isSearchByClick = !this.cPromotions.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.cPromotions.isSearchByClick = false;
    }
    onSearchByOptionClick(pOption) {
        this.cPromotions.isSearchByClick = !this.cPromotions.isSearchByClick;
        this.cPromotionsSearchReq.searchBy = pOption.value;
        this.cPromotions.searchByLabel = pOption.label;
        if (this.cPromotionsSearchReq.searchBy == 'promoName' || this.cPromotionsSearchReq.searchBy == 'promoCode') {
            this.mForm.controls['searchByValue'].enabled;
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cPromotionsSearchReq.searchBy == '' || this.cPromotionsSearchReq.searchBy == null) {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByValueChange() {
        if ((this.cPromotionsSearchReq.searchBy == 'promoName' || this.cPromotionsSearchReq.searchBy == 'promoCode')) {
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onCancelClick() {
        this.cPromotionsSearchReq = null;
        this.cPromotionsSearchReq = new PromotionsSearchReq();
        this.cPromotionsSearchReq.regId = this.pMerchInfoService.getRegId();
        this.cPromotions.fromToDate = null;
        this.selectedSearchById = this.cPromotions.searchBy[0].value;
        this.searchflag = 'searchform';
        this.onSearchClick();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.createForm();
        this.mForm.controls['fromToDate'].disable();
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.mForm.controls['fromToDate'].clearValidators();
        this.mForm.controls['fromToDate'].updateValueAndValidity();
    }
    onExportClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        this.cPromotions.isExportClick = !this.cPromotions.isExportClick;
    }
    onExportExcelClick() {
        this.cPromotions.isExportClick = !this.cPromotions.isExportClick;
        this.cPromotionsSearchReq.pageSize = this.cPromotions.totalCount;
        this.pPromotionsService.fetchAllPromotionsForExport(this.cPromotionsSearchReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.searchflag == 'searchform') {
                this.cPromotionsSearchReq.pageNumber = 1;
            }
            this.pPromotionsService.fetchAllPromotions(this.cPromotionsSearchReq)
                .subscribe(pResponse => this.fetchAllPromotionsSuccess(pResponse), error => { console.log('error'); });
            this.searchflag = 'searchform';
            this.cRecordFrom = 1;
            this.cRecordTo = 25;
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    updateStatusClick(pEvent, pPromoCode, pPromoStatus) {
        if (pEvent) {
            if (pPromoStatus === 'Enabled') {
                this.cPromoStatus = 'P';
            }
            if (pPromoStatus === 'Disabled') {
                this.cPromoStatus = 'Y';
            }
            this.cPromotionsSearchReq.promotionStatus = this.cPromoStatus;
            this.cPromotionsSearchReq.promotionCode = pPromoCode;
            this.cPromotionsSearchReq.regId = this.pMerchInfoService.getRegId();
            this.searchflag = 'searchform';
            this.cRecordFrom = 1;
            this.cRecordTo = 25;
            if (this.cPromotionsSearchReq.promotionCode != null) {
                this.pPromotionsService.updatePromotionStatus(this.cPromotionsSearchReq)
                    .subscribe(pResponse => this.updatePromotionSuccess(pResponse), error => { console.log('error'); });
            }
            let tempPromotionsSearchReq = this.cPromotionsSearchReq;
            this.cPromotionsSearchReq = new PromotionsSearchReq();
            this.cPromotionsSearchReq.searchBy = tempPromotionsSearchReq.searchBy;
            this.cPromotionsSearchReq.searchByValue = tempPromotionsSearchReq.searchByValue;
            this.cPromotionsSearchReq.promoSearchStatus = tempPromotionsSearchReq.promoSearchStatus;
            this.cPromotionsSearchReq.dateFlag = tempPromotionsSearchReq.dateFlag;
            this.cPromotionsSearchReq.promotionStartDate = tempPromotionsSearchReq.promotionStartDate;
            this.cPromotionsSearchReq.promotionEndDate = tempPromotionsSearchReq.promotionEndDate;
            this.cPromotionsSearchReq.promotionType = tempPromotionsSearchReq.promotionType;
        }
    }
    onNewPopupClick() {
        this.validateFirstModal();
        if (this.cPromotionReq.globalLimit) {
            this.isGlobalLimitCheck = true;
            this.mForm.controls['globalLimit'].enable();
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['cardLimit'].enable();
        }
        else {
            if (this.cPromotionReq.cardLimit) {
                this.isCardLimitCheck = true;
                this.mForm.controls['cardLimit'].enable();
            }
            if (this.cPromotionReq.userLimit) {
                this.isUserLimitCheck = true;
                this.mForm.controls['userLimit'].enable();
            }
        }
        this.isPopNextFlag = false;
    }
    onOpenNewPopupClick(template, mainFlag) {
        this.isPopNextFlag = false;
        this.isGlobalLimitCheck = false;
        this.isCardLimitCheck = false;
        this.isUserLimitCheck = false;
        this.isRequiredGlobalLimit = false;
        this.isRequiredCardLimit = false;
        this.isRequiredUserLimit = false;
        this.isCardLimitDisabled = false;
        this.isUserLimitDisabled = false;
        this.isRestrictedClick = false;
        this.isPercOverOrderAmount = false;
        this.isPercOnOrderAmount = false;
        this.globalPlaceholder = "Unlimited";
        this.cardPlaceholder = "Unlimited";
        this.userPlaceholder = "Unlimited";
        this.cPaymentOptionList = [];
        this.dropdownList = [];
        if (this.selectedItems != null)
            this.selectedItems = null;
        this.validateFirstModal();
        if (mainFlag) {
            this.cCreateNewPromotion = new CreateNewPromotion();
            this.cPromotionReq = new PromotionReq();
            this.toDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
            this.fromDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
            this.cPromotionReq.promotionStatus = "Enabled";
            this.cPromotionReq.promotionStartDate = this.fromDate;
            this.cPromotionReq.promotionEndDate = this.toDate;
            this.cCreateNewPromotion.fromDate = this.fromDate;
            this.cCreateNewPromotion.toDate = this.toDate;
            this.cCreateNewPromotion.fromToDate = this.fromDate + ' - ' + this.toDate;
            this.cModalRef = this.pModalService.show(template, { class: 'modal-dialog modal-sm modal-dialog-centered scrollable', keyboard: false, ignoreBackdropClick: true });
        }
    }
    onEditPopupClick() {
        this.validateFirstModal();
        if (this.cEditPromotionReq.globalLimit) {
            this.isEditGlobalLimitCheck = true;
            this.mForm.controls['globalLimit'].enable();
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['cardLimit'].enable();
        }
        else {
            if (this.cEditPromotionReq.cardLimit) {
                this.isEditCardLimitCheck = true;
                this.mForm.controls['cardLimit'].enable();
            }
            if (this.cEditPromotionReq.userLimit) {
                this.isEditUserLimitCheck = true;
                this.mForm.controls['userLimit'].enable();
            }
        }
        this.isPopNextEditFlag = false;
        this.cPromotionDetailsReq.promoId = this.cPromotionsListProc.promoId;
    }
    onOpenEditPopupClick(template, mainFlag, promo) {
        this.isPopNextEditFlag = false;
        this.isGlobalLimitExceeds = false;
        // this.mForm.clearValidators();
        this.validateFirstModal();
        this.cPromotionsListProc = promo;
        if (mainFlag) {
            this.cCreateNewPromotion = new CreateNewPromotion();
            this.cEditPromotionReq = null;
            this.cEditPromotionReq = new EditPromotionReq();
            // this.cEditPromotionReq.promoId = promo.promoId;
            // this.cEditPromotionReq.promoDiscountType = promo.promoDiscountType;
            // this.cEditPromotionReq.promotionName = promo.promotionName;
            // this.cEditPromotionReq.promotionStartDate = promo.promoValidityFrom;
            // this.cEditPromotionReq.promotionEndDate = promo.promoValidityTo;
            // this.cEditPromotionReq.promotionEndDate = promo.promoValidityTo;
            this.pendingGlobalCount = promo.ordersCount;
            this.cPromotionDetailsReq.promoId = promo.promoId;
            let mPromotionDetailsReq = new PromotionDetailsReq();
            mPromotionDetailsReq = promo;
            this.pPromotionsService.fetchPromotionDetails(this.cPromotionDetailsReq)
                .subscribe(pResponse => this.fetchPromoDetailsSuccess(pResponse), error => { console.log('error'); });
            this.cModalRef = this.pModalService.show(template, { class: 'modal-dialog modal-sm modal-dialog-centered scrollable', keyboard: false, ignoreBackdropClick: true });
            this.disableFileds();
        }
    }
    onCancleClick() {
        this.cModalRef.hide();
    }
    onLimitChange(pEvent, action) {
        if (pEvent) {
            if (action == 'edit') {
                if ((this.sCheck.isNullString(String(this.cEditPromotionReq.globalLimit)) && this.isEditGlobalLimitCheck == true) || (this.cEditPromotionReq.globalLimit == null && this.isEditGlobalLimitCheck == true)) {
                    this.editGlobalPlaceholder = "";
                    this.mForm.controls['globalLimit'].setValue(null);
                    this.mForm.controls['globalLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['globalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['globalLimit'].updateValueAndValidity();
                    //this.isRequiredEditGlobalLimit = true;
                }
                else {
                    this.editGlobalPlaceholder = "Unlimited";
                    this.mForm.controls['globalLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['globalLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['globalLimit'].updateValueAndValidity();
                    // this.isRequiredEditGlobalLimit = false;
                }
                if ((this.sCheck.isNullString(String(this.cEditPromotionReq.cardLimit)) && this.isEditCardLimitCheck == true) || (this.cEditPromotionReq.cardLimit == null && this.isEditCardLimitCheck == true)) {
                    this.editCardPlaceholder = "";
                    this.mForm.controls['cardLimit'].setValue(null);
                    this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['cardLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['cardLimit'].updateValueAndValidity();
                    //this.isRequiredEditCardLimit = true;
                }
                else {
                    this.editCardPlaceholder = "Unlimited";
                    this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['cardLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['cardLimit'].updateValueAndValidity();
                    //this.isRequiredEditCardLimit = false;
                }
                if ((this.sCheck.isNullString(String(this.cEditPromotionReq.userLimit)) && this.isEditUserLimitCheck == true) || (this.cEditPromotionReq.userLimit == null && this.isEditUserLimitCheck == true)) {
                    this.editUserPlaceholder = "";
                    this.mForm.controls['userLimit'].setValue(null);
                    this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['userLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['userLimit'].updateValueAndValidity();
                    //this.isRequiredEditUserLimit = true;
                }
                else {
                    this.editUserPlaceholder = "Unlimited";
                    this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
                    this.mForm.controls['userLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
                    this.mForm.controls['userLimit'].updateValueAndValidity();
                    // this.isRequiredEditUserLimit = false;
                }
                //  this.validateLimit(this.mForm);
            }
            if (action == 'create') {
                if (this.userPlaceholder == '' || this.userPlaceholder == null) {
                    this.mForm.controls['userLimit'].setErrors({ required: true });
                }
                if (this.cardPlaceholder == '' || this.cardPlaceholder == null) {
                    this.mForm.controls['userLimit'].setErrors({ required: true });
                }
                this.mForm.controls['userLimit'].enable();
                this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
                this.mForm.controls['userLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
                this.mForm.controls['userLimit'].updateValueAndValidity();
                this.mForm.controls['cardLimit'].enable();
                this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
                this.mForm.controls['cardLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
                this.mForm.controls['cardLimit'].updateValueAndValidity();
            }
        }
        else {
        }
    }
    onlyNumbersAllowedWithMaxTenDigits(pEvent) {
        const pattern = /[0-9]/;
        ;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    getPaymentOptionList() {
        return this.cPaymentOptionList;
    }
    onRestrictedClick() {
        this.isRestrictedClick = !this.isRestrictedClick;
    }
    onUpdatePromotionClick() {
        if (this.mForm.valid) {
            this.cEditPromotionReq.regId = this.pMerchInfoService.getRegId();
            if (this.editGlobalPlaceholder == "Unlimited" && this.isEditGlobalLimitCheck == false) {
                this.cEditPromotionReq.globalLimit = "Infinite";
            }
            if (this.editUserPlaceholder == "Unlimited" && this.isEditCardLimitCheck == false) {
                this.cEditPromotionReq.cardLimit = "Infinite";
            }
            if (this.editCardPlaceholder == "Unlimited" && this.isEditUserLimitCheck == false) {
                this.cEditPromotionReq.userLimit = "Infinite";
            }
            if (this.cEditPromotionReq.promoMethod == "Order Over")
                this.cEditPromotionReq.promoMethod = "Orders Over";
            else if (this.cEditPromotionReq.promoMethod = "Entire Order")
                this.cEditPromotionReq.promoMethod == "Order Amount";
            this.pPromotionsService.updatePromotion(this.cEditPromotionReq)
                .subscribe(pResponse => this.updatePromotionSuccess(pResponse), error => {
                console.log('error');
            });
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
            this.cModalRef.hide();
        }
        if (this.mForm.valid) {
            this.newPromoFlag = false;
            this.cModalRef.hide();
        }
    }
    onEditCancleClick() {
        this.cModalRef.hide();
    }
    onCalenderIconClick(dateRangePickerElement) {
        dateRangePickerElement.click();
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cPromotionsSearchReq.promotionStartDate = value.start.format("DD-MM-YYYY");
        this.cPromotionsSearchReq.promotionEndDate = value.end.format("DD-MM-YYYY");
        this.cPromotions.fromToDate = this.cPromotionsSearchReq.promotionStartDate + ' - ' + this.cPromotionsSearchReq.promotionEndDate;
    }
    selectedFormStartToDate(value) {
        this.cPromotionReq.promotionStartDate = value.start.format("DD-MM-YYYY");
        this.cPromotionReq.promotionEndDate = value.end.format("DD-MM-YYYY");
        this.cCreateNewPromotion.fromToDate = value.start.format("YYYY-MM-DD");
        this.cCreateNewPromotion.startDatePicker = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
        };
        this.cCreateNewPromotion.endDatePicker = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
        };
        this.cCreateNewPromotion.fromToDate = this.cPromotionReq.promotionStartDate + " - " + this.cPromotionReq.promotionEndDate;
        this.cCreateNewPromotion.fromDate = this.cPromotionReq.promotionStartDate;
        this.cCreateNewPromotion.toDate = this.cPromotionReq.promotionEndDate;
    }
    editFormStartToDate(value) {
        this.cPromotionReq.promotionStartDate = value.start.format('DD-MM-YYYY');
        this.cPromotionReq.promotionEndDate = value.end.format("DD-MM-YYYY");
        this.cCreateNewPromotion.fromToDate = value.start.format("YYYY-MM-DD");
        this.cCreateNewPromotion.startDatePicker = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
        };
        this.cCreateNewPromotion.endDatePicker = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
        };
        this.cEditPromotionReq.PromoStartEndDate = this.cPromotionReq.promotionStartDate + " - " + this.cPromotionReq.promotionEndDate;
        this.cEditPromotionReq.promotionStartDate = this.cPromotionReq.promotionStartDate;
        this.cEditPromotionReq.promotionEndDate = this.cPromotionReq.promotionEndDate;
    }
    //***********************************************Server Call Event**********************************************//
    fetchAllPromotionsSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.isSuccess) {
                this.cPromotions.totalCount = mCommonResponse.data['totalCount'];
                this.cPromotionsListProcEntity = mCommonResponse.data['promotionsList'];
                if (this.cPromotionsListProcEntity.length != 0) {
                    this.cPromotions.isAnyPromoCreated = true;
                    // this.cRecordFrom=1;
                    // this.cRecordTo=25;
                }
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cPromotions.landingPageMsg = this.sLandingPageMsgService.noPromoMsg;
                this.cPromotions.totalCount = null;
                this.cPromotionsListProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else {
                this.cPromotions.landingPageMsg = this.sLandingPageMsgService.noPromoMsg;
                this.cPromotions.totalCount = null;
                this.cPromotionsListProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.cPromotions.landingPageMsg = this.sLandingPageMsgService.noPromoMsg;
            this.cPromotions.totalCount = null;
            this.cPromotionsListProcEntity = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.isSearchPanelClick = false;
            }
        }
    }
    updatePromotionSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                if (this.sCheck.isNotNullList(mCommonResponse.data['promotionsList'])) {
                    this.cPromotionsListProcEntity = mCommonResponse.data['promotionsList'];
                    this.cPromotions.totalCount = mCommonResponse.data['totalCount'];
                }
            }
        }
        if (mCommonResponse.isSuccess) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            //for refreshing listing page
            this.cPromotionsSearchReq.regId = this.pMerchInfoService.getRegId();
            // this.searchflag = 'searchform'; 
            // this.cRecordFrom = 1;
            // this.cRecordTo = 25;  
            this.pPromotionsService.fetchAllPromotions(this.cPromotionsSearchReq)
                .subscribe(pResponse => this.fetchAllPromotionsSuccess(pResponse), error => { console.log('error'); });
            this.cModalRef.hide();
        }
        else if (mCommonResponse.isFail) {
            this.cPromotionsListProcEntity = [];
            this.cPromotionsSearchReq.promotionCode = "";
            this.cPromotions.landingPageMsg = this.sLandingPageMsgService.noPromoMsg;
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    CreateSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        ;
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (mCommonResponse.code === CustomResponseCode.SUCCESS && mCommonResponse.message === CustomResponseMessage.SUCCESS) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cPromotionsSearchReq.regId = this.pMerchInfoService.getRegId();
                this.cRecordFrom = 1;
                this.cRecordTo = 25;
                this.onSearchClick();
                // this.pPromotionsService.fetchAllPromotions(this.cPromotionsSearchReq)
                //     .subscribe(pResponse => this.fetchAllPromotionsSuccess(pResponse), error => { console.log('error'); })
                this.cModalRef.hide();
                this.cPromotions.isAnyPromoCreated = true;
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL && mCommonResponse.message === CustomResponseMessage.VALIDATION_FAIL) {
                {
                    this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm);
                }
            }
            else if (mCommonResponse.code === CustomResponseCode.FAIL) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onPageChange(event) {
        this.cPromotionsSearchReq.pageSize = event.cPageSize;
        this.cPromotionsSearchReq.pageNumber = event.cPageNo;
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.searchflag = 'pageChange';
        if (this.searchflag == 'searchform') {
            this.cPromotionsSearchReq.pageNumber = 1;
        }
        this.pPromotionsService.fetchAllPromotions(this.cPromotionsSearchReq)
            .subscribe(pResponse => this.fetchAllPromotionsSuccess(pResponse), error => { console.log('error'); });
        this.searchflag = 'searchform';
    }
    onDateFlagChange() {
        this.mForm.controls['fromToDate'].enable();
    }
    fetchPayOptionSuccess(pResponse) {
        this.cardTypeList = [];
        this.cPromotionPaymentOption = [];
        if (this.sCheck.isNotNullObject(pResponse.data)) {
            this.cardTypeList = pResponse.data.promoCardDetailsList;
            this.cCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(this.cCommonResponse)) {
                if (this.sCheck.isNotNullObject(this.cCommonResponse.data)) {
                    if (this.sCheck.isNotNullList(this.cCommonResponse.data['promotionPaymentOpt'])) {
                        this.cPromotionPaymentOption = this.cCommonResponse.data['promotionPaymentOpt'];
                    }
                }
            }
        }
        this.cPaymentOptionList = [];
        if (this.sCheck.isNotNullList(this.cPromotionPaymentOption)) {
            for (let pPayOption of this.cPromotionPaymentOption) {
                this.cPaymentOptionList.push({ label: pPayOption.payOptDesc, value: pPayOption.payOptType });
            }
        }
    }
    selectedPaymentType(event) {
        this.dropdownList = [];
        this.selectedItems = [];
        this.unSelectedItemsCodes = [];
        event.value.forEach(val => {
            this.cardTypeList.forEach(card => {
                if (val == card.payOptType) {
                    // this.dropdownList.push(card);
                    this.dropdownList.push({ "id": card.id, "itemName": card.cardName, "payOptType": card.payOptType, "payOptDesc": card.payOptDesc }); //
                }
            });
        });
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //*********************************************** Validation ********************************************//
    createNewPromoForm() {
        this.mForm = this.pFormBuilder.group({
            promotionName: ['', [
                    Validators.required,
                    Validators.maxLength(100),
                    Validators.minLength(3),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.promotionName,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                ]],
            promotionDesc: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promotionDescription
                ]],
            termsAndCondition: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.promoTermsAndConditions
                ]],
            promotionAnalyticsCode: ['', [
                    Validators.maxLength(20),
                    InvoiceSettingsValidator.promotionAnalyticsCode,
                ]],
            fromToDate: [''],
            formFromToDate: [''],
            promotionCurrency: ['', Validators.required],
            promotionType: ['', Validators.required],
            promoDiscountType: ['', Validators.required],
            promoDiscountValue: ['', Validators.required],
            promoMethod: ['', Validators.required],
            promoMinOrderAmount: [''],
            promoMaxDiscountAmount: [''],
            promotionStatus: ['', Validators.required],
            globalLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            userLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            cardLimit: ['', [InvoiceSettingsValidator.integerNumberOnly, Validators.required, Validators.min(1), Validators.maxLength(9)]],
            isGlobalLimitCheck: [''],
            isUserLimitCheck: [''],
            isCardLimitCheck: [''],
            promotionStartDate: [''],
            promoStartEndDate: [''],
            paymentBinList: ['', [Validators.maxLength(2000), InvoiceSettingsValidator.promotionBins]],
        });
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    //***********************************************On Change Event*******************************************//
    onGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.globalPlaceholder = "";
            this.isRequiredGlobalLimit = true;
            this.mForm.controls['globalLimit'].enable();
            this.mForm.controls['globalLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['cardLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['globalLimit'].updateValueAndValidity();
            this.isGlobalLimitCheck = !this.isGlobalLimitCheck;
            this.userPlaceholder = "";
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['userLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['userLimit'].updateValueAndValidity();
            this.isUserLimitCheck = true;
            this.isUserLimitDisabled = true;
            if (!this.cPromotionReq.userLimit)
                this.isRequiredUserLimit = true;
            this.cardPlaceholder = "";
            this.mForm.controls['cardLimit'].enable();
            this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['cardLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['cardLimit'].updateValueAndValidity();
            this.isCardLimitCheck = true;
            if (!this.cPromotionReq.cardLimit)
                this.isRequiredCardLimit = true;
            this.isCardLimitDisabled = true;
        }
        else {
            this.isRequiredGlobalLimit = false;
            this.cPromotionReq.globalLimit = null;
            this.globalPlaceholder = "Unlimited";
            this.mForm.controls['globalLimit'].disable();
            this.mForm.controls['userLimit'].setValue(null);
            this.isUserLimitDisabled = false;
            this.isUserLimitCheck = false;
            this.userPlaceholder = "Unlimited";
            this.mForm.controls['userLimit'].disable();
            this.isRequiredUserLimit = false;
            this.mForm.controls['cardLimit'].setValue(null);
            this.mForm.controls['cardLimit'].enable();
            this.isCardLimitDisabled = false;
            this.isCardLimitCheck = false;
            this.cardPlaceholder = "Unlimited";
            this.mForm.controls['cardLimit'].disable();
            this.isRequiredCardLimit = false;
        }
    }
    onEditGlobalLimitCheckBoxClick(event) {
        if (event) {
            this.editGlobalPlaceholder = "";
            this.mForm.controls['globalLimit'].enable();
            this.mForm.controls['globalLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['globalLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['globalLimit'].updateValueAndValidity();
            this.isRequiredEditGlobalLimit = true;
            this.editUserPlaceholder = "";
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['userLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['userLimit'].updateValueAndValidity();
            if (!this.cEditPromotionReq.userLimit)
                this.isRequiredEditUserLimit = true;
            this.editCardPlaceholder = "";
            this.mForm.controls['cardLimit'].enable();
            this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['cardLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['cardLimit'].updateValueAndValidity();
            if (!this.cEditPromotionReq.cardLimit)
                this.isRequiredEditCardLimit = true;
            //this.isEditGlobalLimitCheck = !this.isEditGlobalLimitCheck;
            this.isEditGlobalLimitCheck = true;
            this.isEditUserLimitCheck = true;
            this.isEditUserLimitDisabled = true;
            this.isEditCardLimitCheck = true;
            this.isEditCardLimitDisabled = true;
        }
        else {
            this.cEditPromotionReq.globalLimit = null;
            this.editGlobalPlaceholder = "Unlimited";
            this.mForm.controls['globalLimit'].setValue(null);
            this.mForm.controls['globalLimit'].disable();
            this.isGlobalLimitExceeds = false;
            this.isRequiredEditGlobalLimit = false;
            // if (this.cEditPromotionReq.userLimit == null) {
            this.cEditPromotionReq.userLimit = null;
            this.isEditUserLimitDisabled = false;
            this.isEditUserLimitCheck = false;
            this.editUserPlaceholder = "Unlimited";
            this.mForm.controls['userLimit'].disable();
            this.isRequiredEditUserLimit = false;
            // }
            //  else
            //   this.isEditUserLimitDisabled = false;
            // / if (this.cEditPromotionReq.cardLimit == null) {
            this.cEditPromotionReq.cardLimit = null;
            this.isEditCardLimitDisabled = false;
            this.isEditCardLimitCheck = false;
            this.editCardPlaceholder = "Unlimited";
            this.mForm.controls['cardLimit'].disable();
            this.isRequiredEditCardLimit = false;
            // }
            //   else
            //    this.isEditCardLimitDisabled = false;
        }
    }
    onUserLimitCheckBoxClick(event) {
        if (event) {
            this.userPlaceholder = "";
            this.isUserLimitCheck = true;
            this.isRequiredUserLimit = true;
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['userLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['userLimit'].updateValueAndValidity();
        }
        else {
            this.cPromotionReq.userLimit = null;
            this.mForm.controls['userLimit'].disable();
            this.userPlaceholder = "Unlimited";
            this.isRequiredUserLimit = false;
        }
    }
    onEditUserLimitCheckBoxClick(event) {
        if (event) {
            this.editUserPlaceholder = "";
            this.isEditUserLimitCheck = true;
            //this.isRequiredEditUserLimit = true;
            this.mForm.controls['userLimit'].enable();
            this.mForm.controls['userLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['userLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['userLimit'].updateValueAndValidity();
        }
        else {
            this.cEditPromotionReq.userLimit = null;
            this.mForm.controls['userLimit'].disable();
            this.mForm.controls['userLimit'].setValidators([Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['userLimit'].updateValueAndValidity();
            this.editUserPlaceholder = "Unlimited";
            //this.isRequiredEditUserLimit = false;
        }
    }
    onCardLimitCheckBoxClick(event) {
        if (event) {
            this.cardPlaceholder = "";
            this.isCardLimitCheck = true;
            this.isRequiredCardLimit = true;
            this.mForm.controls['cardLimit'].enable();
            this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['cardLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['cardLimit'].updateValueAndValidity();
        }
        else {
            this.cPromotionReq.cardLimit = null;
            this.mForm.controls['cardLimit'].disable();
            this.cardPlaceholder = "Unlimited";
            this.isRequiredCardLimit = false;
        }
    }
    onEditCardLimitCheckBoxClick(event) {
        if (event) {
            this.editCardPlaceholder = "";
            this.isEditCardLimitCheck = true;
            //  this.isRequiredEditCardLimit = true;
            this.mForm.controls['cardLimit'].enable();
            this.mForm.controls['cardLimit'].markAsTouched({ onlySelf: true });
            this.mForm.controls['cardLimit'].setValidators([Validators.required, Validators.min(1), Validators.maxLength(9)]);
            this.mForm.controls['cardLimit'].updateValueAndValidity();
        }
        else {
            this.cEditPromotionReq.cardLimit = null;
            this.mForm.controls['cardLimit'].disable();
            this.editCardPlaceholder = "Unlimited";
            // this.isRequiredEditCardLimit = false;
        }
    }
    changeRequiredFlag() {
        if (this.cPromotionReq.cardLimit == null || this.cPromotionReq.cardLimit == "") {
            this.isRequiredCardLimit = true;
        }
        else
            this.isRequiredCardLimit = false;
    }
    changeRequiredUserFlag() {
        if (this.cPromotionReq.userLimit == null || this.cPromotionReq.userLimit == "") {
            this.isRequiredUserLimit = true;
        }
        else
            this.isRequiredUserLimit = false;
    }
    changeRequiredFlagEditUserModal() {
        if (this.cEditPromotionReq.userLimit == null || this.cEditPromotionReq.userLimit == "") {
            this.editUserPlaceholder = '';
            this.isRequiredEditUserLimit = true;
        }
        else
            this.isRequiredEditUserLimit = false;
    }
    changeRequiredFlagEditModal() {
        if (this.cEditPromotionReq.cardLimit == null || this.cEditPromotionReq.cardLimit == "") {
            this.editCardPlaceholder = '';
            this.isRequiredEditCardLimit = true;
        }
        else
            this.isRequiredEditCardLimit = false;
    }
    onPromoDiscountTypeChange(event) {
        this.cPromotionReq.promoDiscountType = event.value;
        var discountAmt = this.mForm.controls['promoDiscountValue'];
        let discountAmtVal = +discountAmt.value;
        if (this.cPromotionReq.promoDiscountType == 'PERC') {
            this.isDiscountTypePERC = true;
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(this.maxAmountValue), Validators.maxLength(9)]); //InvoiceSettingsValidator.numbersOnly,
            this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
            this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            this.minDisValue = 0.01;
            this.maxDisValue = 99.99;
            this.mForm.controls['promoDiscountValue'].setErrors(null);
            this.mForm.controls['promoDiscountValue'].clearValidators();
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(5)]);
            this.mForm.controls['promoDiscountValue'].markAsDirty();
            this.mForm.controls['promoDiscountValue'].markAsTouched();
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            if (this.cPromotionReq.promoMethod == 'Order Amount')
                this.isPercOnOrderAmount = true;
            else
                this.isPercOnOrderAmount = false;
            if (this.cPromotionReq.promoMethod == 'Orders Over')
                this.isPercOverOrderAmount = true;
            else
                this.isPercOverOrderAmount = false;
        }
        else if (this.cPromotionReq.promoDiscountType == 'FLAT') {
            this.isDiscountTypePERC = false;
            this.isPercOnOrderAmount = false;
            this.isPercOverOrderAmount = false;
            this.mForm.controls['promoMaxDiscountAmount'].setErrors(null);
            this.mForm.controls['promoMaxDiscountAmount'].clearValidators();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            this.minDisValue = 0.01;
            this.maxDisValue = 9999.99;
            this.mForm.controls['promoDiscountValue'].setErrors(null);
            this.mForm.controls['promoDiscountValue'].clearValidators();
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue)]);
            this.mForm.controls['promoDiscountValue'].markAsDirty();
            this.mForm.controls['promoDiscountValue'].markAsTouched();
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            if (discountAmtVal == 0) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue)]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            else if (discountAmtVal > 9999.99) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(7)]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
        }
        else {
            this.mForm.controls['promoMaxDiscountAmount'].setErrors(null);
            this.mForm.controls['promoMaxDiscountAmount'].clearValidators();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
        }
    }
    calculateMaxDiscountAmt() {
        var minOrderAmt = this.mForm.controls['promoMinOrderAmount'];
        var discountAmt = this.mForm.controls['promoDiscountValue'];
        var promoMaxDiscountAmount = this.mForm.controls['promoMaxDiscountAmount'];
        const pattern = /[0]/;
        let minOrderAmtVal = +minOrderAmt.value;
        let discountAmtVal = +discountAmt.value;
        let promoMaxDiscountAmountVal = +promoMaxDiscountAmount.value;
        let val = discountAmtVal / 100;
        let maxDisAmt = Number(Math.floor((val * minOrderAmtVal + 1)).toFixed());
        if (!Number.isNaN(promoMaxDiscountAmountVal))
            promoMaxDiscountAmountVal = Number((promoMaxDiscountAmountVal).toFixed(2));
        if (this.cPromotionReq.promoDiscountType == 'PERC') {
            this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99)]);
            this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
            this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            //this.isMaxAmountZero = false;
            if (this.cPromotionReq.promoMethod == 'Orders Over') {
                this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99)]);
                this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                this.isPercOverOrderAmount = true;
                this.isPercOnOrderAmount = false;
                // if(this.cPromotionReq.promoMaxDiscountAmount.match(pattern)&& !this.sCheck.isNotNullNumber(Number(promoMaxDiscountAmount))){       
                if (promoMaxDiscountAmountVal == 0 && Number(this.cPromotionReq.promoMaxDiscountAmount) == 0) {
                    this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.min(0.01), Validators.max(999999.99)]);
                    this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                    this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                    this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                    this.isMaxAmountZero = true;
                }
                else if (promoMaxDiscountAmountVal != 0 && promoMaxDiscountAmountVal < maxDisAmt) {
                    this.cCreateNewPromotion.maxDiscountAmt = maxDisAmt - 1;
                    promoMaxDiscountAmount.setErrors({ calculateMaxDiscountAmt: true });
                    this.isMaxAmountZero = false;
                }
                else if (Number(this.cPromotionReq.promoMaxDiscountAmount) > 999999.99) {
                    this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99)]);
                    this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                    this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                    this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                    this.isMaxAmountZero = false;
                }
            }
            else if (this.cPromotionReq.promoMethod == 'Order Amount') {
                this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99)]);
                this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                // this.mForm.controls['promoMaxDiscountAmount'].setErrors([Validators.required ]);
                this.isPercOnOrderAmount = true;
                this.isPercOverOrderAmount = false;
                if (promoMaxDiscountAmountVal == 0 && Number(this.cPromotionReq.promoMaxDiscountAmount) == 0) {
                    this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.min(0.01), Validators.max(999999.99)]);
                    this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                    this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                    this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                    this.isMaxAmountZero = true;
                }
                else if (Number(this.cPromotionReq.promoMaxDiscountAmount) > 999999.99) {
                    this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.max(999999.99)]);
                    this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                    this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                    this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
                    this.isMaxAmountZero = false;
                }
                else {
                    this.isMaxAmountZero = false;
                }
            }
        }
    }
    onPaymentOptionClick() {
        var paymentOptions = this.getPaymentOptionList().length;
        if (paymentOptions == 0 || paymentOptions == null) {
            this.mForm.controls['promotionCurrency'].markAsTouched({ onlySelf: true });
            this.mForm.controls['promotionCurrency'].updateValueAndValidity();
        }
    }
    percentagesValue(control) {
        let reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'percentagesValue': true };
    }
    flatValue(control) {
        let reg_exp = /^((\d)*(\.)?\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'flatValue': true };
    }
    onlyNumbersAndDotAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onPromoMethodChange(event) {
        this.cPromotionReq.promoMethod = event.value;
        if (this.cPromotionReq.promoMethod == 'Orders Over') {
            this.maxAmountValue = 999999.99;
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].valueChanges;
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly,
                Validators.min(1), Validators.max(this.maxAmountValue), Validators.maxLength(9),
                this.flatValue]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            this.mForm.controls['promoMaxDiscountAmount'].setValue(null);
            this.mForm.controls['promoMaxDiscountAmount'].valueChanges;
            this.mForm.controls['promoMaxDiscountAmount'].setValidators([this.flatValue, Validators.max(999999.99)]);
            this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
            this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
            this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            this.mForm.controls['promoMinOrderAmount'].enable();
            if (this.cPromotionReq.promoDiscountType == 'PERC') {
                this.isPercOverOrderAmount = true;
                this.isPercOnOrderAmount = false;
            }
            else {
                this.isPercOverOrderAmount = false;
            }
        }
        else if (this.cPromotionReq.promoMethod == 'Order Amount') {
            this.mForm.controls['promoMinOrderAmount'].clearValidators();
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            this.mForm.controls['promoMinOrderAmount'].disable();
            if (this.cPromotionReq.promoDiscountType == 'PERC') {
                this.isPercOnOrderAmount = true;
                this.isPercOverOrderAmount = false;
            }
            else {
                this.isPercOnOrderAmount = false;
            }
        }
        else {
            this.mForm.controls['promoMinOrderAmount'].clearValidators();
            this.mForm.controls['promoMinOrderAmount'].setValue(null);
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
        }
        if (this.sCheck.isNotNullNumber(this.mForm.controls['promoMinOrderAmount'].value) && this.mForm.controls['promoMethod'].value == 'Order Amount') {
            this.isCommonInValid = true;
        }
        else if (!this.sCheck.isNotNullNumber(this.mForm.controls['promoMinOrderAmount'].value) && this.mForm.controls['promoMethod'].value == 'Orders Over' && this.cPromotionReq.promoDiscountType != 'PERC') {
            this.isCommonInValid = true;
        }
    }
    onCurrencyChange(pEvent) {
        if (pEvent) {
            this.dropdownList = [];
            this.cPaymentOptionList = [];
            this.cPaymentOptionList = [];
            this.selectedItems = [];
            this.cPromotionReq.paymentOption = [];
            this.cPromotionReq.promotionCurrency = null;
            this.cPromotionReq.regId = this.pMerchInfoService.getRegId();
            this.cPromotionReq.promotionCurrency = pEvent.value;
            this.pPromotionsService.fetchPromotionPaymentOpt(this.cPromotionReq)
                .subscribe(pResponse => this.fetchPayOptionSuccess(pResponse), error => { console.log('error'); });
        }
    }
    onBlur(event) {
        if (event) {
            if (this.cPromotionReq.promoDiscountValue != null && this.mForm.controls['promoDiscountValue'].valid && this.cPromotionReq.promoDiscountType == 'PERC') {
                this.minDisValue = 0.01;
                this.maxDisValue = 99.99;
                let value = +this.cPromotionReq.promoDiscountValue;
                if (!Number.isNaN(value)) {
                    this.cPromotionReq.promoDiscountValue = value.toFixed(2);
                }
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(7), this.percentagesValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            else if (this.cPromotionReq.promoDiscountValue != null && this.mForm.controls['promoDiscountValue'].valid && this.cPromotionReq.promoDiscountType == 'FLAT') {
                this.minDisValue = 0.01;
                this.maxDisValue = 9999.99;
                let value = +this.cPromotionReq.promoDiscountValue;
                if (!Number.isNaN(value)) {
                    this.cPromotionReq.promoDiscountValue = value.toFixed(2);
                }
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(this.minDisValue), Validators.max(this.maxDisValue), Validators.maxLength(7), this.flatValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            if (this.cPromotionReq.promoMinOrderAmount != null && this.mForm.controls['promoMinOrderAmount'].valid
            /*&& +this.cPromotionReq.promoDiscountValue < +this.cPromotionReq.promoMinOrderAmount*/ ) {
                this.isCommonInValid = false;
                let value = +this.cPromotionReq.promoMinOrderAmount;
                if (!Number.isNaN(value)) {
                    this.cPromotionReq.promoMinOrderAmount = value.toFixed(2);
                }
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly,
                    Validators.min(1), Validators.max(this.maxAmountValue), Validators.maxLength(9),
                    this.flatValue]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
            if (this.cPromotionReq.promoMaxDiscountAmount != null && this.mForm.controls['promoMaxDiscountAmount'].valid) {
                let value = +this.cPromotionReq.promoMaxDiscountAmount;
                if (!Number.isNaN(value)) {
                    if (Number(value.toFixed(2)) != 0.00)
                        this.cPromotionReq.promoMaxDiscountAmount = value.toFixed(2);
                }
                // if(this.cPromotionReq.promoMethod === 'Order Amount Over' && this.cPromotionReq.promoDiscountType ==='PERC' ){
                this.mForm.controls['promoMaxDiscountAmount'].setValidators([Validators.min(0.01), this.flatValue, Validators.maxLength(9), Validators.max(999999.99)]);
                this.mForm.controls['promoMaxDiscountAmount'].markAsDirty();
                this.mForm.controls['promoMaxDiscountAmount'].markAsTouched();
                this.mForm.controls['promoMaxDiscountAmount'].updateValueAndValidity();
            }
        }
    }
    onCreateClick() {
        if (this.mForm.valid && this.unSelectedItemsDesc.length == 0) {
            if (this.cPromotionReq.paymentBin != null && this.cPromotionReq.paymentBin.length > 0) {
                for (var i = 0; i < this.cPromotionReq.paymentBin.length; i++) {
                    if (typeof this.cPromotionReq.paymentBin[i]['display'] == 'undefined') {
                        this.paymentBin.push(this.cPromotionReq.paymentBin[i]);
                    }
                    else {
                        this.paymentBin.push(this.cPromotionReq.paymentBin[i]['display']);
                    }
                }
                this.cPromotionReq.paymentBin = this.paymentBin;
            }
            if (this.cPromotionReq.paymentBin != null && this.cPromotionReq.paymentBin != undefined)
                this.cPromotionReq.paymentBinList = this.cPromotionReq.paymentBin.toString();
            this.cPromotionReq.paymentBin = null;
            this.paymentBin = [];
            this.cPromotionReq.paymentCardBankName = [];
            if (this.selectedItems != null && this.selectedItems != undefined) {
                let i = 0;
                this.selectedItems.forEach(arrayItem => {
                    this.cPromotionReq.paymentCardBankName[i] = arrayItem.payOptType + "#" + arrayItem.itemName;
                    i++;
                });
            }
            let cheArr = [];
            for (let k = 0; k < this.selectedItems.length; k++) {
                if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                    cheArr.push(this.selectedItems[k].payOptType);
            }
            if (!this.sCheck.isNotNullObject(this.unSelectedItemsCodes))
                this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
                    return !cheArr.includes(el);
                });
            this.unSelectedItemsDesc = [];
            this.cPaymentOptionList.forEach(card => {
                this.unSelectedItemsCodes.forEach(desc => {
                    if (desc === card.value) {
                        if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                            this.unSelectedItemsDesc.push(card.label);
                    }
                });
            });
            if (this.globalPlaceholder == "Unlimited") {
                this.cPromotionReq.globalLimit = "Infinite";
            }
            if (this.userPlaceholder == "Unlimited") {
                this.cPromotionReq.userLimit = "Infinite";
            }
            if (this.cardPlaceholder == "Unlimited") {
                this.cPromotionReq.cardLimit = "Infinite";
            }
            this.cPromotionReq.promotionStartDate = this.cCreateNewPromotion.fromDate;
            this.cPromotionReq.promotionEndDate = this.cCreateNewPromotion.toDate;
            this.cPromotionReq.regId = this.pMerchInfoService.getRegId();
            this.searchflag = 'searchform';
            this.cRecordFrom = 1;
            this.cRecordTo = 25;
            this.pPromotionsService.addPromotions(this.cPromotionReq)
                .subscribe(pResponse => this.CreateSuccess(pResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
            this.getFormValidationErrors();
        }
        if (this.mForm.valid) {
            this.newPromoFlag = false;
            this.cModalRef.hide();
        }
    }
    //***********************************************Multiselect Event ********************************************//
    onItemSelect(item) {
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    OnItemDeSelect(item) {
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    onSelectAll(items) {
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
            return !cheArr.includes(el);
        });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    onDeSelectAll(items) {
        let cheArr = [];
        for (let k = 0; k < this.selectedItems.length; k++) {
            if (!(cheArr.indexOf(this.selectedItems[k].payOptType) > -1))
                cheArr.push(this.selectedItems[k].payOptType);
        }
        if (!this.sCheck.isNotNullObject(this.unSelectedItemsCodes))
            this.unSelectedItemsCodes = this.cPromotionReq.paymentOption.filter(function (el) {
                return !cheArr.includes(el);
            });
        this.unSelectedItemsDesc = [];
        this.cPaymentOptionList.forEach(card => {
            this.unSelectedItemsCodes.forEach(desc => {
                if (desc === card.value) {
                    if (!(this.unSelectedItemsDesc.indexOf(card.label) > -1))
                        this.unSelectedItemsDesc.push(card.label);
                }
            });
        });
    }
    validateAmount() {
        var promoDiscountValue = this.mForm.controls['promoDiscountValue'];
        var promoMinOrderAmount = this.mForm.controls['promoMinOrderAmount'];
        let Discountvalue = +promoDiscountValue.value;
        let minOrderAmount = +promoMinOrderAmount.value;
        var minOrderAmt = this.mForm.controls['promoMinOrderAmount'];
        var discountAmt = this.mForm.controls['promoDiscountValue'];
        var promoMaxDiscountAmount = this.mForm.controls['promoMaxDiscountAmount'];
        let minOrderAmtVal = +minOrderAmt.value;
        let discountAmtVal = +discountAmt.value;
        let promoMaxDiscountAmountVal = +promoMaxDiscountAmount.value;
        let val = discountAmtVal / 100;
        let maxDisAmt = Number(Math.floor((val * minOrderAmtVal + 1)).toFixed());
        let isCoupanMethodSel = this.sCheck.isNotNullString(this.mForm.controls['promoMethod'].value);
        const pattern = /[reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;]/;
        if (this.cPromotionReq.promoDiscountType == 'FLAT') {
            this.maxDisValue = 9999.99;
            this.mForm.controls['promoDiscountValue'].setErrors(null);
            this.mForm.controls['promoDiscountValue'].clearValidators();
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.maxLength(7)]);
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            if (Discountvalue == 0) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(0.01), this.flatValue,
                    Validators.maxLength(7)]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            else if (Number(this.cPromotionReq.promoDiscountValue) > 9999.99) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.max(this.maxDisValue),
                    Validators.maxLength(7), this.flatValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            promoMinOrderAmount.setErrors(null);
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, Validators.maxLength(9)
            ]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            if (Discountvalue > minOrderAmount && minOrderAmount != 0) {
                promoMinOrderAmount.setErrors({ validateAmount: true });
            }
            else if (minOrderAmount == 0) {
                promoMinOrderAmount.setErrors(null);
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required,
                    Validators.min(1), Validators.maxLength(9)
                ]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
            else if (Number(this.cPromotionReq.promoMinOrderAmount) > 999999.99) {
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                    Validators.maxLength(6), this.flatValue]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
            else {
                promoMinOrderAmount.setErrors(null);
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly, Validators.maxLength(9)
                ]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
        }
        else if (this.cPromotionReq.promoDiscountType == 'PERC') {
            this.maxDisValue = 99.99;
            this.mForm.controls['promoDiscountValue'].setErrors(null);
            this.mForm.controls['promoDiscountValue'].clearValidators();
            this.mForm.controls['promoDiscountValue'].setValidators([Validators.required]);
            this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            if (Discountvalue == 0) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.min(0.01)
                ]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            else if (Number(this.cPromotionReq.promoDiscountValue) > this.maxDisValue) {
                this.mForm.controls['promoDiscountValue'].setValidators([Validators.required, Validators.max(this.maxDisValue),
                    this.flatValue]);
                this.mForm.controls['promoDiscountValue'].markAsDirty();
                this.mForm.controls['promoDiscountValue'].markAsTouched();
                this.mForm.controls['promoDiscountValue'].updateValueAndValidity();
            }
            promoMinOrderAmount.setErrors(null);
            this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required
            ]);
            this.mForm.controls['promoMinOrderAmount'].markAsDirty();
            this.mForm.controls['promoMinOrderAmount'].markAsTouched();
            this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            if (minOrderAmount == 0) {
                promoMinOrderAmount.setErrors(null);
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required,
                    Validators.min(1)
                ]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
            else if (Number(this.cPromotionReq.promoMinOrderAmount) > 999999.99) {
                this.maxAmountValue = 999999.99;
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, Validators.min(0.01),
                    Validators.maxLength(6), Validators.max(this.maxAmountValue)]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
            else {
                promoMinOrderAmount.setErrors(null);
                this.mForm.controls['promoMinOrderAmount'].setValidators([Validators.required, InvoiceSettingsValidator.numbersOnly, Validators.maxLength(9)
                ]);
                this.mForm.controls['promoMinOrderAmount'].markAsDirty();
                this.mForm.controls['promoMinOrderAmount'].markAsTouched();
                this.mForm.controls['promoMinOrderAmount'].updateValueAndValidity();
            }
        }
    }
    //***********************************************Life Hooks Event*******************************************//
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
    /*******************************Edit promotion***************************** */
    fetchPromoDetailsSuccess(pResponse) {
        this.cEditPromotionReq = new EditPromotionReq();
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPromotionDetailsEditRes = mCommonResponse.data['promotionDetailsList'][0];
                this.cPromotionCardDetailsV2ProcEntity = mCommonResponse.data['promoCardDetailsList'];
                this.cCardTypeRes = mCommonResponse.data['cardTypeList'];
                this.cEditPromotionReq.promotionName = this.cPromotionDetailsEditRes.promoName;
                this.cEditPromotionReq.promotionDesc = this.cPromotionDetailsEditRes.promoDesc;
                this.cEditPromotionReq.termsAndCondition = this.cPromotionDetailsEditRes.promoTermCondition;
                if (this.cPromotionDetailsEditRes.promoGlobalLimit === -1) {
                    this.editGlobalPlaceholder = "Unlimited";
                    this.isEditGlobalLimitCheck = false;
                    this.mForm.controls['globalLimit'].disable();
                    this.isEditUserLimitDisabled = false;
                    this.isEditCardLimitDisabled = false;
                    if (this.cPromotionDetailsEditRes.promoUserLimit === -1) {
                        this.editUserPlaceholder = "Unlimited";
                        this.isEditUserLimitCheck = false;
                        this.mForm.controls['userLimit'].disable();
                    }
                    else {
                        this.cEditPromotionReq.userLimit = this.cPromotionDetailsEditRes.promoUserLimit;
                        this.isEditUserLimitCheck = true;
                        this.mForm.controls['userLimit'].enable();
                    }
                    if (this.cPromotionDetailsEditRes.promoCardLimit === -1) {
                        this.editCardPlaceholder = "Unlimited";
                        this.isEditCardLimitCheck = false;
                        this.mForm.controls['cardLimit'].disable();
                    }
                    else {
                        this.cEditPromotionReq.cardLimit = this.cPromotionDetailsEditRes.promoCardLimit;
                        this.isEditCardLimitCheck = true;
                        this.mForm.controls['cardLimit'].enable();
                    }
                }
                else {
                    this.cEditPromotionReq.globalLimit = this.cPromotionDetailsEditRes.promoGlobalLimit;
                    this.isEditGlobalLimitCheck = true;
                    this.mForm.controls['globalLimit'].enable();
                    this.cEditPromotionReq.userLimit = this.cPromotionDetailsEditRes.promoUserLimit;
                    this.isEditUserLimitCheck = true;
                    this.isEditUserLimitDisabled = true;
                    this.mForm.controls['userLimit'].enable();
                    this.cEditPromotionReq.cardLimit = this.cPromotionDetailsEditRes.promoCardLimit;
                    this.isEditCardLimitCheck = true;
                    this.isEditCardLimitDisabled = true;
                    this.mForm.controls['cardLimit'].enable();
                }
                this.cEditPromotionReq.promotionStartDate = this.cPromotionDetailsEditRes.promoValidityFrom;
                this.cEditPromotionReq.promotionEndDate = this.cPromotionDetailsEditRes.promoValidityTo;
                var date1 = this.cEditPromotionReq.promotionStartDate;
                var datearray1 = date1.split("-");
                this.cCreateNewPromotion.fromDate = datearray1[0] + '-' + datearray1[1] + '-' + datearray1[2];
                var date2 = this.cEditPromotionReq.promotionEndDate;
                var datearray2 = date2.split("-");
                this.cCreateNewPromotion.toDate = datearray2[0] + '-' + datearray2[1] + '-' + datearray2[2];
                this.fromDate = this.cCreateNewPromotion.fromDate;
                this.toDate = this.cCreateNewPromotion.toDate;
                // var newstartDate = this.pDatePipe.transform(this.fromDate, "DD-MM-YYYY");
                // var newendDate = this.pDatePipe.transform(this.toDate, "DD-MM-YYYY");
                // this.cEditPromotionReq.PromoStartEndDate = newstartDate  + ' - ' + newendDate;
                this.cEditPromotionReq.PromoStartEndDate = this.fromDate + ' - ' + this.toDate;
                this.cEditPromotionReq.promotionAnalyticsCode = this.cPromotionDetailsEditRes.promoAnalyticsCode;
                this.cEditPromotionReq.promotionStatus = this.cPromotionDetailsEditRes.promotionStatus;
                this.cEditPromotionReq.promoId = this.cPromotionDetailsEditRes.promoId;
                this.cEditPromotionReq.promoCode = this.cPromotionDetailsEditRes.promoCode;
                this.cEditPromotionReq.promoDiscountType = this.cPromotionDetailsEditRes.promoDiscountType;
                if (this.cEditPromotionReq.promoDiscountType == "PERC") {
                    this.isDiscountTypePERC = true;
                }
                else {
                    this.isDiscountTypePERC = true;
                }
                this.cEditPromotionReq.promoCurrency = this.cPromotionDetailsEditRes.promoCurrency;
                this.cEditPromotionReq.promoType = this.cPromotionDetailsEditRes.promoType;
                this.cEditPromotionReq.promoDiscountValue = this.cPromotionDetailsEditRes.promoDiscountValue.toFixed(2);
                if (this.sCheck.isNotNullNumber(this.cPromotionDetailsEditRes.promoMinOrdAmt)) {
                    this.cEditPromotionReq.promoMinOrdAmt = this.cPromotionDetailsEditRes.promoMinOrdAmt.toFixed(2);
                }
                this.cEditPromotionReq.promoMethod = this.cPromotionDetailsEditRes.promoMethod;
                if (this.cEditPromotionReq.promoMethod == "Order Amount" && this.cEditPromotionReq.promoDiscountType == "PERC") {
                    this.isPercOnOrderAmount = true;
                    this.isPercOverOrderAmount = false;
                }
                else {
                    this.isPercOnOrderAmount = false;
                }
                if (this.cEditPromotionReq.promoMethod == "Orders Over" && this.cEditPromotionReq.promoDiscountType == "PERC") {
                    this.isPercOverOrderAmount = true;
                    this.isPercOnOrderAmount = false;
                }
                else {
                    this.isPercOverOrderAmount = false;
                }
                if (this.cEditPromotionReq.promoMethod == "Orders Over") {
                    this.cEditPromotionReq.promoMethod = "Order Over";
                }
                else if (this.cEditPromotionReq.promoMethod == "Order Amount") {
                    this.cEditPromotionReq.promoMethod = "Entire Order";
                }
                // this.cEditPromotionReq.promoMaxDiscount = this.cPromotionDetailsEditRes.promoMaxDiscount;
                if (this.sCheck.isNotNullNumber(this.cPromotionDetailsEditRes.promoMaxDiscount) && (this.cPromotionDetailsEditRes.promoMaxDiscount != 0 || this.cPromotionDetailsEditRes.promoMaxDiscount != 0.00)) {
                    this.cEditPromotionReq.promoMaxDiscount = this.cPromotionDetailsEditRes.promoMaxDiscount;
                    this.cEditPromotionReq.promoMaxDiscount = this.cPromotionDetailsEditRes.promoMaxDiscount.toFixed(2);
                }
                //to empty array
                while (this.cCardTypeArrRes.length != 0) {
                    this.cCardTypeArrRes.pop();
                }
                for (var i = 0; i < this.cCardTypeRes.length; i++) {
                    this.cCardTypeOpt = new CardTypeArrRes();
                    this.cCardTypeOpt.payOptType = this.cCardTypeRes[i].payOptType;
                    this.cCardTypeOpt.cardNamesArr = this.cCardTypeRes[i].cardNames.split(',');
                    this.cCardTypeArrRes.push(this.cCardTypeOpt);
                }
                this.cEditPromotionReq.promoBin = this.cPromotionDetailsEditRes.promoBin;
                this.cEditPromotionReq.paymentBin = this.cPromotionDetailsEditRes.promoBin.length > 0 ? this.cPromotionDetailsEditRes.promoBin.split(',') : [];
                if (this.cEditPromotionReq.paymentBin.length != 0) {
                    this.isPromotionBinDiv = true;
                    this.isEditbinValue = true;
                    this.isRestrictedClick = true;
                }
                else {
                    this.isPromotionBinDiv = false;
                    this.isEditbinValue = false;
                    this.isRestrictedClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cPromotionDetailsProcEntity = null;
                this.cPromotionCardDetailsV2ProcEntity = null;
                this.cCardTypeRes = null;
            }
            else {
                this.cPromotionDetailsProcEntity = null;
                this.cPromotionCardDetailsV2ProcEntity = null;
                this.cCardTypeRes = null;
            }
        }
        else {
            this.cPromotionDetailsProcEntity = null;
            this.cPromotionCardDetailsV2ProcEntity = null;
            this.cCardTypeRes = null;
        }
    }
};
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], PromotionsComponent.prototype, "onWindowScroll", null);
PromotionsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-promotions',
        templateUrl: './promotions.component.html',
        styleUrls: ['./promotions.component.css'],
        animations: [
            trigger('openClose', [
                state('open', style({
                    height: '50px',
                    opacity: 1,
                    paddingTop: '20px'
                })),
                state('closed', style({
                    height: '0px',
                    opacity: 1,
                    paddingTop: '0px'
                })),
                transition('* => *', [
                    animate('0.25s')
                ])
            ]),
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 }),
            fadeInExpandOnEnterAnimation({ duration: 400 }),
            fadeOutCollapseOnLeaveAnimation({ duration: 250 })
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(17, Inject(DOCUMENT)),
    tslib_1.__param(18, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ApiRequestService,
        MerchInfoService,
        PromotionsService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        FormBuilder,
        ErrorHandlerService,
        TitleService,
        BsModalService,
        DatePipe,
        Document,
        Window])
], PromotionsComponent);
export { PromotionsComponent };
//# sourceMappingURL=promotions.component.js.map