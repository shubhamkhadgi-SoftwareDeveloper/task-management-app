import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
let QrCodeComponent = class QrCodeComponent {
    constructor() { }
    ngOnInit() {
    }
};
QrCodeComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-qr-code',
        templateUrl: './qr-code.component.html',
        styleUrls: ['./qr-code.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [])
], QrCodeComponent);
export { QrCodeComponent };
//# sourceMappingURL=qr-code.component.js.map