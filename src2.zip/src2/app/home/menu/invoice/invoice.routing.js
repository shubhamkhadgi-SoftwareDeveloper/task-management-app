import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
//Routing-Component
import { InvoiceComponent } from './invoice/invoice.component';
import { InvoiceDetailComponent } from './invoice/invoice-detail/invoice-detail.component';
import { PreviewInvoiceComponent } from './invoice/preview-invoice/preview-invoice.component';
import { CreateNewInvoiceResolverService } from './invoice/create-new-invoice/create-new-invoice-resolver.service';
import { EditNewInvoiceResolverService } from './invoice/edit-invoice/edit-new-invoice-resolver.service';
import { CreateNewInvoiceComponent } from './invoice/create-new-invoice/create-new-invoice.component';
import { EditInvoiceComponent } from './invoice/edit-invoice/edit-invoice.component';
import { RecurringProfileComponent } from './recurring-profile/recurring-profile.component';
import { InvoiceOrderLookupComponent } from './invoice-order-lookup/invoice-order-lookup.component';
import { InvoiceSettingsComponent } from './invoice-settings/invoice-settings.component';
import { TasksItemsComponent } from './tasks-items/tasks-items.component';
import { RecurringOccurrencesDetailsComponent } from "./recurring-profile/recurring-occurrences-details/recurring-occurrences-details.component";
import { BulkUploadComponent } from './bulk-upload/bulk-upload.component';
//Guard services
import { CanActivateRouteGuard } from '../../../common-guard-services/can-activate-route.guard';
//Resolver - services
import { InvoiceResolverService } from './invoice/invoice-resolver.service';
import { RecurringProfileResolverService } from './recurring-profile/recurring-profile-resolver.service';
import { InvoiceSettingsResolverService } from './invoice-settings/invoice-settings-resolver.service';
import { TasksItemsResolverService } from './tasks-items/tasks-items-resolver.service';
import { PreviewInvoiceResolverService } from './invoice/preview-invoice/preview-invoice-resolver-service';
//API - services
import { InvoiceService } from './invoice/invoice.service';
import { InvoiceSettingsService } from './invoice-settings/invoice-settings.service';
import { TasksItemsService } from './tasks-items/tasks-items.service';
import { RecurringProfileService } from './recurring-profile/recurring-profile.service';
import { InvoiceDataService } from './invoice/InvoiceDataService';
import { BulkUploadResolverService } from './bulk-upload/bulk-upload-resolver.service';
import { BulkUploadDetailComponent } from './bulk-upload/bulk-upload-detail/bulk-upload-detail.component';
const routes = [
    { path: 'invoice', component: InvoiceComponent, canActivate: [CanActivateRouteGuard], resolve: { commonResponse: InvoiceResolverService } },
    { path: 'invoice/previewInvoice', component: PreviewInvoiceComponent, resolve: { commonResponse: PreviewInvoiceResolverService } },
    { path: 'invoice/createNewInvoice', component: CreateNewInvoiceComponent, resolve: { commonResponse: CreateNewInvoiceResolverService } },
    { path: 'recurringProfile', component: RecurringProfileComponent, resolve: { commonResponse: RecurringProfileResolverService } },
    { path: 'invoiceOrderLookup', component: InvoiceOrderLookupComponent },
    { path: 'invoiceSettings', component: InvoiceSettingsComponent, resolve: { commonResponse: InvoiceSettingsResolverService } },
    { path: 'tasksItems', component: TasksItemsComponent, resolve: { commonResponse: TasksItemsResolverService } },
    { path: 'invoice/editInvoice', component: EditInvoiceComponent, resolve: { commonResponse: EditNewInvoiceResolverService } },
    { path: 'bulkUpload', component: BulkUploadComponent, resolve: { commonResponse: BulkUploadResolverService } },
    { path: 'bulkUpload/bulkUploadDetail', component: BulkUploadDetailComponent },
    { path: '', redirectTo: 'invoice', pathMatch: 'full' },
    { path: '**', component: InvoiceComponent }
];
let InvoiceRoutingModule = class InvoiceRoutingModule {
};
InvoiceRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [InvoiceDataService, InvoiceService, InvoiceResolverService, CreateNewInvoiceResolverService,
            RecurringProfileResolverService,
            InvoiceSettingsService, InvoiceSettingsResolverService,
            TasksItemsService, TasksItemsResolverService, RecurringProfileService, PreviewInvoiceResolverService, EditNewInvoiceResolverService, BulkUploadResolverService]
    })
], InvoiceRoutingModule);
export { InvoiceRoutingModule };
export const InvoiceRoutedComponents = [InvoiceComponent, InvoiceDetailComponent, PreviewInvoiceComponent, CreateNewInvoiceComponent, RecurringProfileComponent, InvoiceOrderLookupComponent, InvoiceSettingsComponent, TasksItemsComponent, RecurringOccurrencesDetailsComponent, EditInvoiceComponent, BulkUploadComponent, BulkUploadDetailComponent];
//# sourceMappingURL=invoice.routing.js.map