export class InvoiceDetailRes {
}
//# sourceMappingURL=invoiceDetailRes.res.js.map