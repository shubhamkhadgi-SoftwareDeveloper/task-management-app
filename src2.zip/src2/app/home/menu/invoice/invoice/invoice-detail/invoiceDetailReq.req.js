export class InvoiceSearchReq {
}
//# sourceMappingURL=invoiceDetailReq.req.js.map