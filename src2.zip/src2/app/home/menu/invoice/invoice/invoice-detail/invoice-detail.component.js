import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { InvoiceDetailRes } from './invoiceDetailRes.res';
let InvoiceDetailComponent = class InvoiceDetailComponent {
    constructor(sCheck) {
        this.sCheck = sCheck;
        this.previewInvoiceEvent = new EventEmitter();
        this.backBtnEvent = new EventEmitter();
        this.orderTax = -1.00;
        this.cInvoiceDetailRes = new InvoiceDetailRes();
    }
    ngOnInit() {
        window.scrollTo(0, 0);
    }
    ngOnChanges() {
        this.fee = (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeePercValue
            + this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeeFlat) * this.orderTax;
        this.cOrderFeePerc = null;
        this.cOrderFeeFlat = null;
        this.cOrderFeePerc = this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeePerc > 0.00 ? this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeePerc.toFixed(2) : '0.00';
        this.cOrderFeeFlat = this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeeFlat > 0.00 ? this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderFeeFlat.toFixed(2) : '0.00';
        if (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderBinCountry == "INDIA") {
            this.cardBin = "Domestic";
        }
        else if (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderBinCountry == null) {
            this.cardBin = null;
        }
        else {
            this.cardBin = "International";
        }
        this.cardType = null;
        if (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderCardType == "CRDC") {
            this.cardType = "Credit Card";
        }
        else if (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderCardType == "OPTCASHC") {
            this.cardType = "Cash Card";
        }
        else if (this.cInvoiceDetail.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity.orderCardType == "OPTDBCRD") {
            this.cardType = "Debit Card";
        }
    }
    /*   onPreviewClick(){
          this.previewInvoiceEvent.emit({'invoiceNo' : this.cInvoiceDetail.invoiceNo, 'regId': this.cInvoiceDetail.regId , 'subAcId': null, 'status': 'Successful'});
      } */
    onPreviewClick(invoiceNo, regId, status) {
        this.cInvoiceDetailRes.invoiceNo = Number(invoiceNo);
        this.cInvoiceDetailRes.regId = Number(regId);
        this.cInvoiceDetailRes.paymentStatus = String(status);
        this.previewInvoiceEvent.emit(this.cInvoiceDetailRes);
    }
    onBackclick() {
        this.backBtnEvent.emit(true);
    }
};
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", InvoiceDetailRes)
], InvoiceDetailComponent.prototype, "cInvoiceDetail", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean)
], InvoiceDetailComponent.prototype, "isActiveForInvoiceDetail", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], InvoiceDetailComponent.prototype, "previewInvoiceEvent", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], InvoiceDetailComponent.prototype, "backBtnEvent", void 0);
InvoiceDetailComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-invoice-detail',
        templateUrl: './invoice-detail.component.html',
        styleUrls: ['./invoice-detail.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ConditionalCheckService])
], InvoiceDetailComponent);
export { InvoiceDetailComponent };
//# sourceMappingURL=invoice-detail.component.js.map