import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let InvoiceService = class InvoiceService {
    //private cPreviewInvoiceReqUrl = this.cInvoiceBaseUrl + 'previewInvoice'
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cInvoiceBaseUrl = 'invoice/';
        this.cInvoiceSettingUrl = 'invoiceSettings/';
        this.cFetchAllInvoiceUrl = this.cInvoiceBaseUrl + 'fetchAllInvoice';
        this.cExportExcelAllInvoiceUrl = this.cInvoiceBaseUrl + 'exportExcelAllInvoice';
        this.cExportZipAllInvoiceUrl = this.cInvoiceBaseUrl + 'exportZipAllInvoice';
        this.cFetchInvoiceDetailUrl = this.cInvoiceBaseUrl + 'fetchInvoiceDetail';
        this.cPreviewInvoiceReqUrl = this.cInvoiceBaseUrl + 'previewInvoice';
        this.cPrintInvoiceReqUrl = this.cInvoiceBaseUrl + 'printInvoice';
        this.cCancelInvoiceUrl = this.cInvoiceBaseUrl + 'cancelInvoice';
        this.cResendInvoiceUrl = this.cInvoiceBaseUrl + 'resendInvoice';
        this.cFetcheInvoiceSettingUrl = this.cInvoiceSettingUrl + 'fetchAllInvoiceSettings';
        this.cFetchTaskUrl = this.cInvoiceBaseUrl + 'fetchTask';
        this.cDownloadSimpleInvSampleUrl = this.cInvoiceBaseUrl + 'downloadSimpleInvSampleData';
        this.cUploadInvoiceExcelDataUrl = this.cInvoiceBaseUrl + 'uploadInvoiceExcelData';
        this.cDownloadBulkInvoiceResUrl = this.cInvoiceBaseUrl + 'downloadBulkInvoiceResponse';
        this.cCreateNewInvoiceUrl = this.cInvoiceBaseUrl + 'createNewInvoice';
        this.cFetchAllRequiredSettings = this.cInvoiceBaseUrl + "fetchAllRequiredSettings";
        this.cEditInvoiceReqUrl = this.cInvoiceBaseUrl + 'editInvoice';
    }
    fetchAllInvoice(pInvoiceSearchReq) {
        return this.pApiRequestService.httpPostRequest(pInvoiceSearchReq, this.cFetchAllInvoiceUrl);
    }
    exportExcelAllInvoice(pInvoiceSearchReq) {
        return this.pApiRequestService.exportFileRequest(pInvoiceSearchReq, this.cExportExcelAllInvoiceUrl, 'Invoice.csv');
    }
    exportZipAllInvoice(pInvoiceSearchReq) {
        return this.pApiRequestService.exportFileRequest(pInvoiceSearchReq, this.cExportZipAllInvoiceUrl, 'Invoice.zip');
    }
    fetchInvoiceDetail(pInvoiceDetailReq) {
        return this.pApiRequestService.httpPostRequest(pInvoiceDetailReq, this.cFetchInvoiceDetailUrl);
    }
    previewInvoice(pPreviewInvoiceReq) {
        console.log("In invoice service: ", pPreviewInvoiceReq);
        return this.pApiRequestService.httpPostRequest(pPreviewInvoiceReq, this.cPreviewInvoiceReqUrl);
    }
    printInvoice(pPrintInvoiceReq) {
        return this.pApiRequestService.httpPostRequest(pPrintInvoiceReq, this.cPrintInvoiceReqUrl);
    }
    cancelInvoice(pCancelInvoiceReq) {
        return this.pApiRequestService.httpPostRequest(pCancelInvoiceReq, this.cCancelInvoiceUrl);
    }
    resendInvoice(pResendInvoiceReq) {
        return this.pApiRequestService.httpPostRequest(pResendInvoiceReq, this.cResendInvoiceUrl);
    }
    fetchAliasAndSetting(regId) {
        return this.pApiRequestService.httpPostRequest({ "regId": regId }, this.cFetcheInvoiceSettingUrl);
    }
    fetchTask(regId) {
        return this.pApiRequestService.httpPostRequest({ "regId": regId }, this.cFetchTaskUrl);
    }
    downloadSimpleInvSample(pBulkInvoiceReq, pFileName) {
        return this.pApiRequestService.exportFileRequest(pBulkInvoiceReq, this.cDownloadSimpleInvSampleUrl, pFileName); //'InvoiceDetails.xlsx')
    }
    /*public downloadSimpleInvSample2 ( ): Observable<any> {
        return this.pApiRequestService.exportFileRequest(null, this.cDownloadSimpleInvSampleUrl, 'SimpleInvoice.xlsx');
    }*/
    uploadInvoiceExcelData(pUploadFile, pBulkInvoiceReq, pFileName) {
        return this.pApiRequestService.uploadFiledownloadFileRequest(pUploadFile, pBulkInvoiceReq, this.cUploadInvoiceExcelDataUrl, pFileName);
    }
    downloadBulkInvoiceResponse(pBulkInvoiceReq) {
        return this.pApiRequestService.exportFileRequest(pBulkInvoiceReq, this.cDownloadBulkInvoiceResUrl, 'FailedInvoiceDetails.xlsx');
    }
    createNewInvoice(pFile, pCreateNewInvoiceReq) {
        return this.pApiRequestService.fileUploadRequest(pFile, pCreateNewInvoiceReq, this.cCreateNewInvoiceUrl);
    }
    //added for new invoice design
    fetchAllSettings(pInvoiceDataService) {
        return this.pApiRequestService.httpPostRequest(pInvoiceDataService, this.cFetchAllRequiredSettings);
    }
    createCategorizedInvoice(pFile, pCreateNewInvoiceReq) {
        return this.pApiRequestService.fileUploadRequest(pFile, pCreateNewInvoiceReq, this.cCreateNewInvoiceUrl);
    }
    editInvoice(pInvoiceDataService) {
        return this.pApiRequestService.httpPostRequest(pInvoiceDataService, this.cEditInvoiceReqUrl);
    }
};
InvoiceService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], InvoiceService);
export { InvoiceService };
//# sourceMappingURL=invoice.service.js.map