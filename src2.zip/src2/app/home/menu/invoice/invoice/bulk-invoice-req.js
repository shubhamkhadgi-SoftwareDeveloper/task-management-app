export class BulkInvoiceReq {
    constructor() {
        this.isRecurring = false;
    }
}
//# sourceMappingURL=bulk-invoice-req.js.map