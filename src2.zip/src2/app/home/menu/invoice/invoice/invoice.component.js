import * as tslib_1 from "tslib";
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Invoice } from './invoice.class';
import { InvoiceSearchReq } from './invoice-search.req';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { PdfPrintService } from '../../../../common-services/pdf-print.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { InvoiceService } from './invoice.service';
import { BulkInvoiceRes } from './bulk-invoice-res';
import { BulkInvoiceReq } from './bulk-invoice-req';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ErrorHandlerService } from './../../../../common-services/error-handler.service';
import { CommonResponse } from './../../../../common-response/common-response.res';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { TitleService } from './../../../../common-services/title.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { InvoiceSettingsValidator } from '../../invoice/invoice-settings/invoice-settings-validator';
import { trigger, style, transition, animate, state } from '@angular/animations';
import { Component, ViewChild, ElementRef, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ApiRequestService } from "../../../../common-services/api-request.service";
import { InvoiceDataService } from "../invoice/InvoiceDataService";
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { DatePipe } from '@angular/common';
import { InvoiceSettingsService } from '../invoice-settings/invoice-settings.service';
import { InvoiceSettingsReq } from "../invoice-settings/invoiceSettings.req";
let InvoiceComponent = class InvoiceComponent {
    constructor(document, pInvoiceDataService, route, sActivatedRoute, pMerchInfoService, pPdfPrintService, pModalService, sCheck, sResponsiveService, sErrorHandler, sAlertMessageService, sErrorMessagesService, sLandingPageMsgService, sPrivilegeService, pFormBuilder, sTitleService, sInvoiceService, pApiRequestService, pInvoiceSettingService, datepipe) {
        this.document = document;
        this.pInvoiceDataService = pInvoiceDataService;
        this.route = route;
        this.sActivatedRoute = sActivatedRoute;
        this.pMerchInfoService = pMerchInfoService;
        this.pPdfPrintService = pPdfPrintService;
        this.pModalService = pModalService;
        this.sCheck = sCheck;
        this.sResponsiveService = sResponsiveService;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sPrivilegeService = sPrivilegeService;
        this.pFormBuilder = pFormBuilder;
        this.sTitleService = sTitleService;
        this.sInvoiceService = sInvoiceService;
        this.pApiRequestService = pApiRequestService;
        this.pInvoiceSettingService = pInvoiceSettingService;
        this.datepipe = datepipe;
        this.clicked = 0;
        this.cIsWritePrivilege = false;
        this.searchflag = 'seachform';
        this.totalSelectedInvoices = 0;
        this.checkedOne = false;
        this.checkAll = false;
        this.cSubAccountList = [];
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.addInvoice = false;
        //suhail ts code
        this.isSearchPanelClick = false;
        this.newInvoiceArr = [
            { id: 1, name: '200064 - www.ccavenue.com' },
            { id: 2, name: '200065 - www.resavenue.com' },
            { id: 3, name: '200066 - www.eventavenue.com' },
            { id: 4, name: '200067 - www.hotelsavenue.com' }
        ];
        this.subAccArrr = [
            { id: 1, name: 'Avenues1' },
            { id: 1, name: 'Avenues2' },
            { id: 1, name: 'Avenues3' },
            { id: 1, name: 'Avenues4' },
            { id: 1, name: 'Avenues5' },
        ];
        this.cInvoice = new Invoice();
        this.cInvoiceSearchReq = new InvoiceSearchReq();
        this.cBulkInvoiceRes = new BulkInvoiceRes();
        this.cBulkInvoiceReq = new BulkInvoiceReq();
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.Invoice);
        this.sTitleService.setTitle(this.sTitleService.Invoice);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchByValue'].disable();
        this.pInvoiceSettingService.fetchAllInvoiceSettings(this.cInvoiceSettingsReq)
            .subscribe(rResponse => this.fetchAllInvoiceSettingsSuccess(rResponse), error => { console.log('error'); });
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cInvoice.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                this.cInvoice.isAnyInvoiceCreate = true;
            }
            else {
                this.cInvoice.landingPageMsg = "No record found from " + this.datepipe.transform(new Date(), 'dd-MM-yyyy') + " to " + this.datepipe.transform(new Date(), 'dd-MM-yyyy');
                this.cInvoice.isAnyInvoiceCreate = false;
            }
        });
    }
    //*****************************Validations********************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchBy: [null],
            searchByValue: [''],
            searchRegId: [''],
            searchSubAcId: [''],
            searchCurrency: [''],
            searchStatus: [''],
            fromToDate: ['']
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    //***********************************************Button Click Event*******************************************//
    onNextClick() {
        if ((this.cInvoice.constColumn + 6) < this.cInvoice.customColumn.length) {
            this.cInvoice.constColumn++;
            this.cInvoice.activeColumn = this.cInvoice.customColumn.slice(this.cInvoice.constColumn, this.cInvoice.constColumn + 6);
        }
    }
    onPrevClick() {
        if ((this.cInvoice.constColumn + 5) > 5) {
            this.cInvoice.constColumn--;
            this.cInvoice.activeColumn = this.cInvoice.customColumn.slice(this.cInvoice.constColumn, this.cInvoice.constColumn + 6);
        }
    }
    onSelActionClick() {
        this.cInvoice.isExportClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvoice.isSearchPanelClick = false;
        }
        this.cInvoice.isSelActionClick = !this.cInvoice.isSelActionClick;
    }
    onSearchPanelClick() {
        this.cInvoice.selectedInvoice = [];
        if (!this.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
        }
    }
    ;
    onExportClick() {
        this.cInvoice.isSelActionClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvoice.isSearchPanelClick = false;
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isExportClick = !this.cInvoice.isExportClick;
    }
    onSearchClick(isResendClick = false) {
        if (this.mForm.valid) {
            if (this.searchflag == 'seachform') {
                this.cInvoiceSearchReq.searchPageNo = 1;
            }
            console.log(this.cInvoiceSearchReq);
            this.sInvoiceService.fetchAllInvoice(this.cInvoiceSearchReq)
                .subscribe(pResponse => this.fetchAllInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
            this.searchflag = 'seachform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
        if (!isResendClick)
            this.isSearchPanelClick = !this.isSearchPanelClick;
    }
    onCancelPanelClick() {
        this.cInvoiceSearchReq = null;
        this.cInvoiceSearchReq = new InvoiceSearchReq();
        this.cInvoice.fromToDate = null;
        this.cInvoiceSearchReq.searchDateForm = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
        this.cInvoiceSearchReq.searchDateTo = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
        console.log(this.cInvoiceSearchReq);
        this.sInvoiceService.fetchAllInvoice(this.cInvoiceSearchReq)
            .subscribe(pResponse => this.fetchAllInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        this.cInvoiceSearchReq.searchDateForm = null;
        this.cInvoiceSearchReq.searchDateTo = null;
        this.cInvoice.calOptions = {
            maxDate: new Date(),
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme-link",
            showDropdowns: true,
            singleDatePicker: false,
            opens: 'right'
        };
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvoice.isSearchPanelClick = false;
        }
        this.mForm.controls['searchBy'].setValue(null);
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.cInvoice = new Invoice();
        this.isSearchPanelClick = !this.isSearchPanelClick;
    }
    onInvoiceDetailClick(pInvoiceNo, regId) {
        this.cInvoiceDetailRes = null;
        this.sInvoiceService.fetchInvoiceDetail({ 'invoiceNo': pInvoiceNo, 'regId': regId })
            .subscribe(pResponse => this.fetchInvoiceDetailSuccess(pResponse), error => { console.log("error-->" + JSON.stringify(error)); });
    }
    onPreviewClick(cInvoiceDetailRes) {
        console.log("from detail page");
        console.log(cInvoiceDetailRes);
        this.pInvoiceDataService.regId = cInvoiceDetailRes.regId;
        this.pInvoiceDataService.invoiceNo = cInvoiceDetailRes.invoiceNo;
        this.pInvoiceDataService.paymentStatus = cInvoiceDetailRes.paymentStatus;
        this.route.navigate(['home/menu/invoice/invoice/previewInvoice']);
    }
    bckClick() {
        this.route.navigate(['home/menu/invoice/invoice']);
    }
    PreviewClick(pRegId, pInvoiceNo, pPaymentStatus) {
        this.pInvoiceDataService.regId = pRegId;
        this.pInvoiceDataService.invoiceNo = pInvoiceNo;
        this.pInvoiceDataService.paymentStatus = pPaymentStatus;
        this.route.navigate(['home/menu/invoice/invoice/previewInvoice']);
    }
    EditClick(pRegId, pSubAccId, pInvoiceNo) {
        this.pInvoiceDataService.regId = pRegId;
        this.pInvoiceDataService.subAccId = pSubAccId;
        this.pInvoiceDataService.invoiceNo = pInvoiceNo;
        this.pInvoiceDataService.editRequest = true;
        this.pInvoiceDataService.isRecurring = 'N';
        console.log(this.pInvoiceDataService);
        this.route.navigate(['home/menu/invoice/invoice/createNewInvoice']);
    }
    onBackClick() {
        this.cInvoice.isInvoiceDetailClick = false;
    }
    onActionClick(pIndex, pInvoiceLogList) {
        this.cInvoice.actionIndex = pIndex;
        this.cInvoice.actionPanel = true;
        this.cInvoice.invoiceDateTime = [];
        if (pInvoiceLogList != null) {
            let mSplitInvLog = pInvoiceLogList.split(",");
            for (let pInvLog of mSplitInvLog) {
                pInvLog = pInvLog.trim();
                let mDateTime = { date: "", time: "" };
                mDateTime.date = pInvLog.substr(0, pInvLog.length - 8).trim();
                mDateTime.time = pInvLog.substr(pInvLog.length - 8, pInvLog.length).trim();
                this.cInvoice.invoiceDateTime.push(mDateTime);
            }
        }
    }
    onResendClick() {
        if (this.cInvoice.selectedInvoice != null && this.cInvoice.selectedInvoice.length > 0) {
            this.sInvoiceService.resendInvoice({ "billId": this.cInvoice.selectedInvoice })
                .subscribe(pResponse => this.resendInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        ;
    }
    onPopupCancelClick(pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onPopupSentHistoryClick(pTemplate) {
        this.cHistoryModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onPopupResendInvoice(pTemplate, invoiceNo, invoiceRegId) {
        this.cResendModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cInvoiceRefNo = invoiceNo;
        this.cInvoiceRegId = invoiceRegId;
    }
    onPopupCancelPayment(pTemplate, invoiceNo, invoiceRegId) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cInvoiceRefNo = invoiceNo;
        this.cInvoiceRegId = invoiceRegId;
    }
    onCancelConfirmClick() {
        if (this.cInvoice.selectedInvoice != null && this.cInvoice.selectedInvoice.length > 0) {
            this.cBillAndRegId = this.cInvoice.selectedInvoice.toString();
        }
        this.onSingleCancelClick(this.cBillAndRegId);
    }
    onCancelYesClick(cInvoiceRefNo, cInvoiceRegId) {
        let selectedInvoiceNo = [];
        selectedInvoiceNo = [cInvoiceRefNo + '|' + cInvoiceRegId];
        this.cBillAndRegId = selectedInvoiceNo.toString();
        this.onSingleCancelClick(this.cBillAndRegId);
    }
    onResendYesClick(cInvoiceRefNo, cInvoiceRegId) {
        let selectedInvoiceNo = [];
        selectedInvoiceNo = [cInvoiceRefNo + '|' + cInvoiceRegId];
        this.sInvoiceService.resendInvoice({ "billId": selectedInvoiceNo })
            .subscribe(pResponse => this.resendInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        this.cResendModalRef.hide();
    }
    onSingleCancelClick(pBillAndRegId) {
        this.cInvoice.isSelActionClick = !this.cInvoice.isSelActionClick;
        this.sInvoiceService.cancelInvoice({ "billId": [pBillAndRegId] })
            .subscribe(pResponse => this.cancelInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onSendMailClick(event) {
        this.sInvoiceService.resendInvoice(event)
            .subscribe(pResponse => this.resendInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onExportExcelClick() {
        this.cInvoice.isExportClick = !this.cInvoice.isExportClick;
        this.sInvoiceService.exportExcelAllInvoice(this.cInvoiceSearchReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onExportPdfClick() {
        this.cInvoice.isExportClick = !this.cInvoice.isExportClick;
        this.pPdfPrintService.pdfPrint('invoiceList');
    }
    onExportZipClick() {
        this.cInvoice.isExportClick = !this.cInvoice.isExportClick;
        this.sInvoiceService.exportZipAllInvoice(this.cInvoiceSearchReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSearchDateForm(pSearchDateForm) {
        this.cInvoice.minSearchDateTo = pSearchDateForm;
        this.cInvoiceSearchReq.searchDateTo = null;
    }
    onSearchByClick() {
        this.cInvoice.isSearchByClick = !this.cInvoice.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.cInvoice.isSearchByClick = false;
    }
    onSearchByOptionClick(event) {
        this.cInvoice.isSearchByClick = !this.cInvoice.isSearchByClick;
        this.cInvoiceSearchReq.searchBy = event.value;
        this.cInvoice.searchByLabel = event.label;
        this.cInvoiceSearchReq.searchByValue = null;
        if (this.cInvoice.searchByLabel == 'Invoice #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cInvoice.searchByLabel == 'Email ID') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cInvoice.searchByLabel == 'Mobile #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, InvoiceSettingsValidator.mobile]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cInvoice.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onOpenModalClick(template) {
        this.cModalRef = this.pModalService.show(template, { ignoreBackdropClick: true });
        this.cInvoice.closeButton = true;
        this.cBulkInvoiceRes.failedCount = null;
        this.cBulkInvoiceRes.errorDesc = null;
        this.cInvoice.isBulkInvoiceExcelUpload = false;
    }
    onCancelAllNoClick() {
        this.cInvoice.isSelActionClick = false;
        this.cInvoice.isAllInvoiceCheck = false;
        this.cInvoice.selectedInvoice = [];
        this.cModalRef.hide();
    }
    //***********************************************CheckBox Check Event*******************************************//
    onAllInvoiceCheck(pEvent) {
        this.checkedOne = !this.checkedOne;
        if (pEvent) {
            this.cInvoice.selectedInvoice = [];
            for (let pInvoice of this.cInvoiceProcEntity) {
                if (pInvoice.paymentStatus == 'Pending') {
                    this.cInvoice.selectedInvoice.push(pInvoice.invoiceNo + "|" + pInvoice.regId);
                }
            }
            this.totalSelectedInvoices = this.cInvoice.selectedInvoice.length;
        }
        else {
            this.cInvoice.selectedInvoice = [];
            this.totalSelectedInvoices = 0;
        }
    }
    onInvoiceCheck(pEvent) {
        if (pEvent) {
            if (this.cInvoice.selectedInvoice.length === this.cInvoiceProcEntity.length) {
                this.cInvoice.isAllInvoiceCheck = true;
            }
        }
        else {
            this.cInvoice.isAllInvoiceCheck = false;
        }
        if (pEvent) {
            if (this.cInvoice.selectedInvoice.length > 0 && this.cInvoice.selectedInvoice.length != this.cInvoiceProcEntity.length) {
                this.cInvoice.isAllInvoiceCheck = false;
                this.checkedOne = true;
            }
            else if (this.cInvoice.selectedInvoice.length === this.cInvoiceProcEntity.length) {
                this.cInvoice.isAllInvoiceCheck = true;
                this.checkedOne = true;
            }
            else if (this.cInvoice.selectedInvoice.length === 0) {
                this.cInvoice.isAllInvoiceCheck = false;
                this.checkedOne = false;
            }
            this.totalSelectedInvoices = this.cInvoice.selectedInvoice.length;
        }
        else {
            this.checkedOne = !this.checkedOne;
            this.cInvoice.selectedInvoice = [];
            this.totalSelectedInvoices = 0;
        }
    }
    deSelect() {
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.cInvoice.selectedInvoice.length == 0;
        this.checkedOne = false;
    }
    ;
    //**************************************************Mouse Event***********************************************//
    //Invoice History Panel
    mouseleaveActionEvent() {
        this.cInvoice.actionPanel = false;
    }
    mouseenterTimePanelEvent() {
        this.cInvoice.timePanel = true;
    }
    mouseleaveTimePanelEvent() {
        this.cInvoice.timePanel = false;
    }
    //Export Panel
    mouseleaveExportEvent() {
        this.cInvoice.isExportClick = false;
    }
    //Select Action Panel
    mouseleaveSelActionEvent() {
        this.cInvoice.isSelActionClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cInvoiceSearchReq.searchDateForm = value.start.format("DD-MM-YYYY");
        this.cInvoiceSearchReq.searchDateTo = value.end.format("DD-MM-YYYY");
        this.cInvoice.fromToDate = this.cInvoiceSearchReq.searchDateForm + ' - ' + this.cInvoiceSearchReq.searchDateTo;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cInvoice.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                this.cInvoice.isAnyInvoiceCreate = true;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cInvoice.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchAllInvoice(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchAllInvoice(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchAllInvoice(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchAllInvoice(pResMsg) {
        this.cInvoice.landingPageMsg = this.sLandingPageMsgService.invoiceNoRecMsg;
        this.cInvoice.pageTotalCount = null;
        this.cInvoiceProcEntity = null;
        this.cInvoice.isAnyInvoiceCreate = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvoice.isSearchPanelClick = false;
        }
    }
    cancelInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.onSearchClick();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.totalSelectedInvoices = 0;
        this.isSearchPanelClick = false;
        this.cModalRef.hide();
    }
    resendInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cInvoiceSearchReq = null;
                this.cInvoiceSearchReq = new InvoiceSearchReq();
                this.cInvoice.fromToDate = null;
                this.cInvoiceSearchReq.searchDateForm = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
                this.cInvoiceSearchReq.searchDateTo = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
                this.onSearchClick(true);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.totalSelectedInvoices = 0;
        this.checkedOne = !this.checkedOne;
    }
    fetchInvoiceDetailSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cInvoiceDetailRes = mCommonResponse.data;
                if (this.sCheck.isNotNullObject(this.cInvoiceDetailRes) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity)) {
                    this.cInvoice.isInvoiceDetailClick = true;
                    this.cInvoice.isActiveForInvoiceDetail = true;
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    previewInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPreviewInvoiceDetailRes = mCommonResponse.data;
                this.cInvoice.isInvoiceDetailClick = true;
                this.cInvoice.isActiveForInvoiceDetail = false;
                //[cInvoiceDetail]="cInvoiceDetailRes"
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onPageChange(event) {
        this.cInvoiceSearchReq.searchPageSize = event.cPageSize;
        this.cInvoiceSearchReq.searchPageNo = event.cPageNo;
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.searchflag = 'pageChange';
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.onSearchClick(true);
    }
    //***********************************************Download Event*******************************************//
    onDownloadExcelClick() {
        this.cBulkInvoiceReq.isRecurring = false;
        this.sInvoiceService.downloadSimpleInvSample(this.cBulkInvoiceReq, 'InvoiceDetails.xlsx')
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSimpInvExcelDownloadClick() {
        this.sInvoiceService.downloadSimpleInvSample(this.cBulkInvoiceReq, 'SimpleInvoice.xlsx')
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    //***********************************************Upload Event*******************************************//
    onChooseFile(event) {
        let fileList = event.target.files;
        if (fileList.length > 0) {
            if (fileList[0].type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
                this.cInvoice.uploadFile = fileList[0];
                this.cInvoice.uploadFileName = fileList[0].name;
                this.cInvoice.isBulkInvoiceExcelUpload = true;
            }
            else {
                this.cModalRef.hide();
                this.sAlertMessageService.popupAlertMsg("Please upload valid .XLSX file.");
            }
        }
    }
    onUploadClick() {
        this.cBulkInvoiceReq.isRecurring = false;
        this.sInvoiceService.uploadInvoiceExcelData(this.cInvoice.uploadFile, this.cBulkInvoiceReq, 'InvoiceDetails.xlsx') //InvoiceDetails.xlsx
            .subscribe(rResponse => this.onUploadSuccess(rResponse), error => this.onUploadError(error));
        this.cInvoice.uploadFileName = "";
        this.cInvoice.uploadFile = null;
    }
    onDownloadClick() {
        this.cBulkInvoiceReq.failedList = this.cBulkInvoiceRes.failedList;
        this.sInvoiceService.downloadBulkInvoiceResponse(this.cBulkInvoiceReq)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    onUploadSuccess(pResponse) {
        this.cModalRef.hide();
        this.sAlertMessageService.popupAlertMsg("File Uploaded Successfully");
        this.sInvoiceService.fetchAllInvoice(this.cInvoiceSearchReq)
            .subscribe(pResponse => this.fetchAllInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onUploadError(pError) {
        this.cModalRef.hide();
        this.sAlertMessageService.popupAlertMsg("No records updated/ or you are not uploading proper file./or you are uploading blank file..");
    }
    onCancelClick() {
        if (!this.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
    }
    isSearchResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.add('absolute');
            this.document.body.classList.add('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.add('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            }
            if (this.document.getElementsByClassName('daterangepicker').length > 0) {
                this.document.getElementsByClassName('slideL')[0].appendChild(this.document.getElementsByClassName('daterangepicker')[0]);
            }
            return true;
        }
        else {
            return false;
        }
    }
    isCancelResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.remove('absolute');
            this.document.body.classList.remove('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.remove('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.remove('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    nextClick() {
        if (this.document.getElementsByClassName('tbl-prev')[0].classList.contains('inactive')) {
            this.document.getElementsByClassName('tbl-prev')[0].classList.remove('inactive');
            this.document.getElementsByClassName('tbl-prev')[0].classList.add('tbl-prev');
        }
        this.hideIndex = 4 + this.clicked;
        this.showIndex = 8 + this.clicked;
        if (window.matchMedia('(min-width:1153px)').matches) {
            for (var i = 0; i < this.tableRef.nativeElement.rows.length; i++) {
                if (this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.contains('t-show')) {
                    this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.remove('t-show');
                    this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.add('t-hide');
                    if (this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.contains('t-hide')) {
                        this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.remove('t-hide');
                        this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.add('t-show');
                    }
                }
            }
        }
        ;
        this.clicked += 1;
        if (this.showIndex === 9) {
            this.document.getElementsByClassName('tbl-next')[0].classList.add('inactive');
        }
    }
    prevClick() {
        if (this.document.getElementsByClassName('tbl-next')[0].classList.contains('inactive')) {
            this.document.getElementsByClassName('tbl-next')[0].classList.remove('inactive');
            this.document.getElementsByClassName('tbl-next')[0].classList.add('tbl-next');
        }
        if (window.matchMedia('(min-width:1153px)').matches) {
            for (var i = 0; i < this.tableRef.nativeElement.rows.length; i++) {
                if (this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.contains('t-hide')) {
                    this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.remove('t-hide');
                    this.tableRef.nativeElement.rows[i].cells[this.hideIndex].classList.add('t-show');
                    if (this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.contains('t-show')) {
                        this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.remove('t-show');
                        this.tableRef.nativeElement.rows[i].cells[this.showIndex].classList.add('t-hide');
                    }
                }
            }
        }
        ;
        this.clicked -= 1;
        this.hideIndex -= this.clicked;
        this.showIndex -= this.clicked;
        if (this.tableRef.nativeElement.rows[0].cells[3].nextElementSibling.classList.contains('t-show')) {
            console.log('-->>', this.tableRef.nativeElement.rows[0].cells[3].nextElementSibling.classList.contains('t-show'));
            this.document.getElementsByClassName('tbl-prev')[0].classList.add('inactive');
        }
    }
    ;
    //end:suhail ts code
    //create new invoice popup
    onOpenNewPopupClick(template) {
        console.log("in here");
        console.log(this.pMerchInfoService.getRegId());
        console.log(this.pMerchInfoService.isChildrenAccount());
        console.log(this.pMerchInfoService.isSubAccount());
        if (!this.pMerchInfoService.isChildrenAccount() && !this.pMerchInfoService.isSubAccount()) {
            this.pInvoiceDataService.regId = String(this.pMerchInfoService.getRegId());
            this.pInvoiceDataService.subAccId = this.cInvoice.subAccId;
            this.pInvoiceDataService.isRecurring = 'N';
            this.pInvoiceDataService.invoiceNo = '';
            this.pInvoiceDataService.editRequest = false;
            this.route.navigate(['home/menu/invoice/invoice/createNewInvoice']);
        }
        else {
            this.cModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
            this.createForm1();
        }
    }
    createForm1() {
        this.mForm1 = this.pFormBuilder.group({
            SubAccId: [''],
            regId: ['']
        });
        this.cInvoice.regId = null;
        this.cInvoice.subAccId = null;
        this.cSubAccountList = [];
        if (this.pMerchInfoService.isChildrenAccount()) {
            this.cChildrenAccountList = [];
            this.cChildrenAccountList = this.pMerchInfoService.getChildrenAccountList();
            this.mForm1.controls['regId'].setValidators([Validators.required]);
        }
        else {
            this.cInvoice.regId = this.pMerchInfoService.getRegId().toString();
        }
        if (this.pMerchInfoService.isSubAccount()) {
            this.cSubAccountList = this.pMerchInfoService.getSubAccountList();
        }
    }
    onChangeMerchantId(event) {
        this.cInvoice.subAccId = null;
        this.getSubAccListForChildrenAcc(this.cInvoice.regId);
    }
    proceedToCreateInvoice() {
        if (this.mForm1.valid) {
            this.pInvoiceDataService.regId = this.cInvoice.regId;
            this.pInvoiceDataService.subAccId = this.cInvoice.subAccId;
            this.pInvoiceDataService.isRecurring = 'N';
            this.pInvoiceDataService.invoiceNo = '';
            console.log(this.pInvoiceDataService);
            this.pInvoiceDataService.editRequest = false;
            this.route.navigate(['home/menu/invoice/invoice/createNewInvoice']);
            this.cModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mForm1);
        }
    }
    //end: create new invoice popup
    fetchAllInvoiceSettingsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            mCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cInvoiceSettingsProcEntity = mCommonResponse.data['invoiceSettings'];
                    this.cInvoiceSettingsAlias = mCommonResponse.data['invoiceSettingsAlias'];
                    if (this.cInvoiceSettingsProcEntity.settingInvQuick == 'Y' || this.cInvoiceSettingsProcEntity.settingInvNew == 'Y')
                        this.addInvoice = true;
                }
            }
        }
    }
    getSubAccListForChildrenAcc(regId) {
        this.pApiRequestService.httpPostRequest({ "regId": parseInt(regId) }, 'common/fetchAllMerchInfo')
            .subscribe(pResponse => {
            this.fetchSubaccListSuccess(pResponse);
        }, error => { console.log('error'); });
    }
    fetchSubaccListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess && this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cSubAccountList = [];
                mCommonResponse.data.subAccounts.forEach(subAccount => {
                    this.cSubAccountList.push({ label: subAccount.subAccountId, value: subAccount.subAccountId });
                });
            }
        }
    }
};
tslib_1.__decorate([
    ViewChild('tableRef', { static: false }),
    tslib_1.__metadata("design:type", ElementRef)
], InvoiceComponent.prototype, "tableRef", void 0);
InvoiceComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-invoice',
        templateUrl: './invoice.component.html',
        styleUrls: ['./invoice.component.css'],
        preserveWhitespaces: true,
        animations: [
            expandOnEnterAnimation({ duration: 700 }),
            collapseOnLeaveAnimation({ duration: 500 }),
            trigger('openClose', [
                state('open', style({
                    height: '64px',
                    opacity: 1,
                    paddingTop: '20px'
                })),
                state('closed', style({
                    height: '0px',
                    opacity: 1,
                    paddingTop: '0px'
                })),
                transition('* => *', [
                    animate('0.25s')
                ])
            ])
        ]
    }),
    tslib_1.__param(0, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [Document,
        InvoiceDataService,
        Router,
        ActivatedRoute,
        MerchInfoService,
        PdfPrintService,
        BsModalService,
        ConditionalCheckService,
        ResponsiveService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        LandingPageMsgService,
        PrivilegeService,
        FormBuilder,
        TitleService,
        InvoiceService,
        ApiRequestService,
        InvoiceSettingsService,
        DatePipe])
], InvoiceComponent);
export { InvoiceComponent };
//# sourceMappingURL=invoice.component.js.map