import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let InvoiceDataService = class InvoiceDataService {
    constructor() {
        this.regId = '';
        this.subAccId = "";
        this.editRequest = false;
    }
    get getRegId() {
        return this.regId;
    }
    set setRegId(_regId) {
        this.regId = _regId;
    }
    get getSubAccId() {
        return this.subAccId;
    }
    set setSubAccId(_subAccId) {
        this.subAccId = _subAccId;
    }
    get getInvoiceNo() {
        return this.invoiceNo;
    }
    set setInvoiceNo(_invoiceNo) {
        this.invoiceNo = _invoiceNo;
    }
    get getMerReferenceNo() {
        return this.merReferenceNo;
    }
    set setMerReferenceNo(_merReferenceNo) {
        this.merReferenceNo = _merReferenceNo;
    }
    get getFrequency() {
        return this.frequency;
    }
    set setFrequency(frequency) {
        this.frequency = frequency;
    }
    get getCustomerName() {
        return this.customerName;
    }
    set setCustomerName(_customerName) {
        this.customerName = _customerName;
    }
    get getDeliveryType() {
        return this.deliveryType;
    }
    set setDeliveryType(_deliveryType) {
        this.deliveryType = _deliveryType;
    }
    get getCustomerEmail() {
        return this.customerEmail;
    }
    set setCustomerEmail(_customerEmail) {
        this.customerEmail = _customerEmail;
    }
    get getEmailSubject() {
        return this.emailSubject;
    }
    set setEmailSubject(_emailSubject) {
        this.emailSubject = _emailSubject;
    }
    get getCurrency() {
        return this.currency;
    }
    set setCurrency(_currency) {
        this.currency = _currency;
    }
    get getAmount() {
        return this.amount;
    }
    set setAmount(_amount) {
        this.amount = _amount;
    }
    get getTermsCondition() {
        return this.termsCondition;
    }
    set setTermsCondition(_termsCondition) {
        this.termsCondition = _termsCondition;
    }
    get getValidFor() {
        return this.validFor;
    }
    set setValidFor(_validFor) {
        this.validFor = _validFor;
    }
    get getPaymentStatus() {
        return this.paymentStatus;
    }
    set setPaymentStatus(_paymentStatus) {
        this.paymentStatus = _paymentStatus;
    }
    get getDate() {
        return this.date;
    }
    set setDate(_date) {
        this.date = _date;
    }
    get getDueDate() {
        return this.dueDate;
    }
    set setDueDate(_dueDate) {
        this.dueDate = _dueDate;
    }
    get getLateFeeType() {
        return this.lateFeeType;
    }
    set setLateFeeType(_lateFeeType) {
        this.lateFeeType = _lateFeeType;
    }
    get getLateFee() {
        return this.lateFee;
    }
    set setLateFee(_lateFee) {
        this.lateFee = _lateFee;
    }
    get getDiscountIf() {
        return this.discountIf;
    }
    set setDiscountIf(_discountIf) {
        this.discountIf = _discountIf;
    }
    get getDiscountType() {
        return this.discountType;
    }
    set setDiscountType(_discountType) {
        this.discountType = _discountType;
    }
    get getDiscount() {
        return this.discount;
    }
    set setDiscount(_discount) {
        this.discount = _discount;
    }
    get getCustomerMobile() {
        return this.customerMobile;
    }
    set setCustomerMobile(_customerMobile) {
        this.customerMobile = _customerMobile;
    }
    get getIsRecurring() {
        return this.isRecurring;
    }
    set setIsRecurring(_isRecurring) {
        this.isRecurring = _isRecurring;
    }
    get getOccurences() {
        return this.occurences;
    }
    set setOccurences(_occurences) {
        this.occurences = _occurences;
    }
    get getRecurringStatus() {
        return this.recurringStatus;
    }
    set setRecurringStatus(_recurringStatus) {
        this.recurringStatus = _recurringStatus;
    }
    get getCreatedBy() {
        return this.createdBy;
    }
    set setCreatedBy(_createdBy) {
        this.createdBy = _createdBy;
    }
    get getMerchantUserId() {
        return this.merchantUserId;
    }
    set setMerchantUserId(_merchantUserId) {
        this.merchantUserId = _merchantUserId;
    }
    get getInvoiceLog() {
        return this.invoiceLog;
    }
    set setInvoiceLog(_invoiceLog) {
        this.invoiceLog = _invoiceLog;
    }
    get getPreviewInvoiceDetail() {
        return this.previewInvoiceDetail;
    }
};
InvoiceDataService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], InvoiceDataService);
export { InvoiceDataService };
//# sourceMappingURL=InvoiceDataService.js.map