export class InvoiceSearchReq {
    constructor() {
        this.searchPageSize = 25;
        this.searchPageNo = 1;
        this.searchIsRecurring = false;
    }
}
//# sourceMappingURL=invoice-search.req.js.map