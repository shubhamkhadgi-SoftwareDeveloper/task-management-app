import { async, TestBed } from '@angular/core/testing';
import { PreviewInvoiceComponent } from './preview-invoice.component';
describe('PreviewInvoiceComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PreviewInvoiceComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(PreviewInvoiceComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=preview-invoice.component.spec.js.map