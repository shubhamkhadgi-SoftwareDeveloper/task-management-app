import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
import { Router, ActivatedRoute } from '@angular/router';
import { InvoiceService } from './../invoice.service';
import { InvoiceDataService } from './../InvoiceDataService';
let PreviewInvoiceResolverService = class PreviewInvoiceResolverService {
    constructor(sActivatedRoute, sInvoiceService, pMerchInfoService, sRouter, route, pInvoiceDataService) {
        this.sActivatedRoute = sActivatedRoute;
        this.sInvoiceService = sInvoiceService;
        this.pMerchInfoService = pMerchInfoService;
        this.sRouter = sRouter;
        this.route = route;
        this.pInvoiceDataService = pInvoiceDataService;
    }
    resolve(route, state) {
        //let pCreateQuickInvoiceDataService = new CreateQuickInvoiceDataService();
        console.log('in preview resolver service : ', this.pInvoiceDataService);
        return this.sInvoiceService.previewInvoice(this.pInvoiceDataService).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                this.pInvoiceDataService.previewInvoiceDetail = pCommonResponse.data;
                console.log("this.pInvoiceDataService.previewInvoiceDetail: ", this.pInvoiceDataService.previewInvoiceDetail);
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PreviewInvoiceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        InvoiceService,
        MerchInfoService,
        Router,
        ActivatedRoute,
        InvoiceDataService])
], PreviewInvoiceResolverService);
export { PreviewInvoiceResolverService };
//# sourceMappingURL=preview-invoice-resolver-service.js.map