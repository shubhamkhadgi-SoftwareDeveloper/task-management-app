export class InvoiceSettingsAlias {
    constructor() {
        this.aliasMerRefNo2 = "Merchant Reference # 3";
        this.aliasMerRefNo3 = "Merchant Reference # 4";
        this.aliasMerRefNo4 = "Merchant Reference # 5";
    }
}
//# sourceMappingURL=invoice-settings-alias.js.map