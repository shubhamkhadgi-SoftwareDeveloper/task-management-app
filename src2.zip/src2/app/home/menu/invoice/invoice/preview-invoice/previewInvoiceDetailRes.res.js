export class PreviewInvoiceDetail {
}
//# sourceMappingURL=previewInvoiceDetailRes.res.js.map