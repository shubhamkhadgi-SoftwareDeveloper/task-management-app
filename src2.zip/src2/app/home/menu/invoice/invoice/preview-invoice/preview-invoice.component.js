import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter, Inject, HostListener } from '@angular/core';
import { PreviewInvoiceDetail } from './previewInvoiceDetailRes.res';
import { PdfPrintService } from '../../../../../common-services/pdf-print.service';
import { InvoiceService } from '../invoice.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { InvoiceDataService } from './../../invoice/InvoiceDataService';
import { WINDOW } from "../../../../../common-services/window.service";
import { DOCUMENT, Location } from '@angular/common';
let PreviewInvoiceComponent = class PreviewInvoiceComponent {
    constructor(document, window, pPdfPrintService, pInvoiceService, sErrorHandler, sAlertMessageService, sErrorMessagesService, sCheck, pInvoiceDataService, pLocation) {
        this.document = document;
        this.window = window;
        this.pPdfPrintService = pPdfPrintService;
        this.pInvoiceService = pInvoiceService;
        this.sErrorHandler = sErrorHandler;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sCheck = sCheck;
        this.pInvoiceDataService = pInvoiceDataService;
        this.pLocation = pLocation;
        this.scrolling = false;
        this.sendMailEvent = new EventEmitter();
        this.cPreviewInvoiceDetails = this.pInvoiceDataService.previewInvoiceDetail;
        console.log("this.cPreviewInvoiceDetail : ", this.cPreviewInvoiceDetails);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        //console.log("this.invoiceDetailsRS3ProcEntity : ", this.cPreviewInvoiceDetails.invoiceDetailsRS3ProcEntity); 
    }
    ngOnInit() {
        window.scrollTo(0, 0);
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
    onBackClick() {
        this.pLocation.back();
    }
    onPrintClick() {
        //this.pPdfPrintService.pdfPrint('invoicePrint');
        this.pInvoiceService.printInvoice({ 'invoiceNo': this.cPreviewInvoiceDetail.invoiceDetailsRS2ProcEntity.billId, 'regId': this.invoicePaymentStatus.regId })
            .subscribe(pResponse => this.printInvoiceSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    printInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess && this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.pPdfPrintService.print(mCommonResponse.data);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    getTax(text) {
        console.log(text);
    }
    onSendMailClick() {
        let mBillReg = [];
        mBillReg.push(this.cPreviewInvoiceDetail.invoiceDetailsRS2ProcEntity.billId + "|" + this.invoicePaymentStatus.regId);
        this.sendMailEvent.emit({ "billId": mBillReg });
    }
};
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", PreviewInvoiceDetail)
], PreviewInvoiceComponent.prototype, "cPreviewInvoiceDetail", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean)
], PreviewInvoiceComponent.prototype, "isActiveForInvoiceDetail", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Object)
], PreviewInvoiceComponent.prototype, "invoicePaymentStatus", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], PreviewInvoiceComponent.prototype, "sendMailEvent", void 0);
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], PreviewInvoiceComponent.prototype, "onWindowScroll", null);
PreviewInvoiceComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-preview-invoice',
        templateUrl: './preview-invoice.component.html',
        styleUrls: ['./preview-invoice.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(0, Inject(DOCUMENT)),
    tslib_1.__param(1, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [Document,
        Window,
        PdfPrintService,
        InvoiceService,
        ErrorHandlerService,
        AlertMessageService,
        ErrorMessagesService,
        ConditionalCheckService,
        InvoiceDataService,
        Location])
], PreviewInvoiceComponent);
export { PreviewInvoiceComponent };
//# sourceMappingURL=preview-invoice.component.js.map