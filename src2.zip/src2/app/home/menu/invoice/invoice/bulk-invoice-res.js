export class BulkInvoiceRes {
}
//# sourceMappingURL=bulk-invoice-res.js.map