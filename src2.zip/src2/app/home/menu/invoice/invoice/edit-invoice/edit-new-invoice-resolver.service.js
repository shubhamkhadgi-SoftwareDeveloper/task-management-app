import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
import { Router } from '@angular/router';
import { InvoiceDataService } from '../InvoiceDataService';
import { InvoiceService } from './../invoice.service';
let EditNewInvoiceResolverService = class EditNewInvoiceResolverService {
    constructor(sInvoiceService, pMerchInfoService, sRouter, pInvoiceDataService) {
        this.sInvoiceService = sInvoiceService;
        this.pMerchInfoService = pMerchInfoService;
        this.sRouter = sRouter;
        this.pInvoiceDataService = pInvoiceDataService;
    }
    resolve(route, state) {
        //let pCreateQuickInvoiceDataService = new CreateQuickInvoiceDataService();
        console.log('in preview resolver service : ', this.pInvoiceDataService);
        return this.sInvoiceService.fetchAllSettings(this.pInvoiceDataService).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                this.pInvoiceDataService.previewInvoiceDetail = pCommonResponse.data;
                console.log("this.pInvoiceDataService.previewInvoiceDetail: ", this.pInvoiceDataService.previewInvoiceDetail);
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
EditNewInvoiceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [InvoiceService,
        MerchInfoService,
        Router,
        InvoiceDataService])
], EditNewInvoiceResolverService);
export { EditNewInvoiceResolverService };
//# sourceMappingURL=edit-new-invoice-resolver.service.js.map