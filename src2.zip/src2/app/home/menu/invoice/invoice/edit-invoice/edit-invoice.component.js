import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef, Inject, HostListener } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CreateNewInvoice } from "./../create-new-invoice/createNewInvoice.class";
import { CreateNewInvoiceReq } from "./../create-new-invoice/createNewInvoiceReq.req";
import { trigger, transition, animate, style } from '@angular/animations';
import { WINDOW } from '../../../../../common-services/window.service';
import { Customer } from '../../../customer/customer.class';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonResponse, CustomResponseCode } from './../../../../../common-response/common-response.res';
import { ApiRequestService } from "../../../../../common-services/api-request.service";
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
import { BsModalService } from "ngx-bootstrap";
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BBValidator } from "./../create-new-invoice/validated";
import { InvoiceTaskReq } from "./../create-new-invoice/invoiceTaskReq.req";
import { InvoiceTaskRes } from "./../create-new-invoice/invoiceTaskRes.res";
import { ItemTaskList } from "./../create-new-invoice/item-task-list.class";
import { CreateInvoiceRes } from "./../create-new-invoice/createInvoiceRes.res";
import { Location, DOCUMENT } from '@angular/common';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { InvoiceSettingsReq } from '../../invoice-settings/invoiceSettings.req';
import { InvoiceService } from './../invoice.service';
import { AddNewCustomerDetailsReq } from 'app/home/menu/customer/AddNewCustomerDetailsReq';
import { CustomerSearchReq } from 'app/home/menu/customer/customer-search.req';
import { PrivilegeService } from 'app/common-services/privilege.service';
import { CustomerService } from 'app/home/menu/customer/customer.service';
import { TransactionsService } from 'app/home/menu/transactions/transactions/transactions.service';
import { ResponsiveService } from 'app/common-services/responsive.service';
import { InvoiceTaskAndItemsReq } from '../../../invoice/tasks-items/invoiceTaskAndItems.req';
import { EditNewTaskAndItemsReq } from '../../../invoice/tasks-items/editNewTaskAndItems.req';
import { TasksItemsService } from '../../../invoice/tasks-items/tasks-items.service';
import { InvoiceTaskAndItems } from '../../../invoice/tasks-items/tasks-items.class';
import { TitleService } from './../../../../../common-services/title.service';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { InvoiceDataService } from '../InvoiceDataService';
let EditInvoiceComponent = class EditInvoiceComponent {
    constructor(pInvoiceDataService, sPrivilegeService, sCustomerService, pTransactionsService, sResponsiveService, pRoute, document, window, sInvoiceService, pTasksItemsService, sTitleService, pApiRequestService, pMerchInfoService, pModalService, pFormBuilder, pActiveRouter, pLocation, pRouter, sRef, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, datepipe) {
        this.pInvoiceDataService = pInvoiceDataService;
        this.sPrivilegeService = sPrivilegeService;
        this.sCustomerService = sCustomerService;
        this.pTransactionsService = pTransactionsService;
        this.sResponsiveService = sResponsiveService;
        this.pRoute = pRoute;
        this.document = document;
        this.window = window;
        this.sInvoiceService = sInvoiceService;
        this.pTasksItemsService = pTasksItemsService;
        this.sTitleService = sTitleService;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.pActiveRouter = pActiveRouter;
        this.pLocation = pLocation;
        this.pRouter = pRouter;
        this.sRef = sRef;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.datepipe = datepipe;
        this.scrolling = false;
        this.cCustomerList1 = [];
        this.cCustomerDataList = [];
        this.deliveryTypeNotSelected = false;
        this.customerDetailsNotSelected = false;
        this.showMinAmount = false;
        this.popUpCount = 0;
        this.checkErr = false;
        this.hideElemet1 = true;
        this.hideElemet2 = true;
        this.dateSelectionfailed = false;
        this.addTruee = true;
        this.removeTrue = false;
        this.cIsWritePrivilege = false;
        this.isItemizedInvoice = false;
        this.cSubAccountList = [];
        this.mySelectedTaskList = [];
        this.gokul = false;
        this.options = {
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            timePicker: false,
            singleDatePicker: true,
            showDropdowns: false,
            minDate: new Date()
        };
        this.itemAlreadyPresnt = false;
        this.newItemNameValid = false;
        this.newItemDescValid = false;
        this.itemNameArray = [];
        this.cIsTaskAndItemWritePrivilege = false;
        this.cCurrencyLeftFlag = false;
        this.cEditCall = false;
        this.cCurrencyIndex = 0;
        this.billMerReferenceNo = '';
        this.billMerReferenceNo1 = '';
        this.billMerReferenceNo2 = '';
        this.billMerReferenceNo3 = '';
        this.billMerReferenceNo4 = '';
        //suhail code
        this.editClicked = false;
        this.arrowDown = true;
        this.dueOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            "applyClass": "btn-theme-link",
            minDate: new Date()
        };
        this.discountIfOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'center',
            minDate: new Date()
        };
        this.calOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: true,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'center',
            minDate: new Date()
        };
        this.calOptionsWithTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY hh:mm A' },
            alwaysShowCalendars: false,
            timePicker: true,
            timePicker24Hour: true,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            "applyClass": "btn-theme-link",
        };
        this.events = [];
        //task items
        this.ngSelectTableRow1 = false;
        this.cars = [];
        this.selectedCars1 = [];
        this.merchantParams = [];
        this.count = 0;
        this.div3 = false;
        this.div4 = false;
        this.div5 = false;
        this.addMPTrue = true;
        this.itemInv = true;
        this.InvDesc = true;
        this.checked = true;
        this.tableRowArr = [''];
        this.create_cust_btn = true;
        this.add_shipping_btn = true;
        this.addLineArr = [''];
        this.selectedName = '';
        this.fileArr = [
            { id: 1, name: 'Upload File' },
            { id: 2, name: 'File URL' }
        ];
        this.selectArr = [
            { id: 'Flat', name: 'Flat' },
            { id: 'Perc', name: 'Percentage' }
        ];
        this.country = [
            { id: 1, name: 'India' },
            { id: 2, name: 'UAE' }
        ];
        this.currency = [
            { id: 0, name: 'Select' },
            { id: 1, name: 'INR' },
            { id: 2, name: 'USD' },
            { id: 3, name: 'GPB' },
            { id: 4, name: 'SGD' }
        ];
        this.type = [
            { id: 'PERCENTAGE', name: 'Perc' },
            { id: 'FLAT', name: 'Flat' }
        ];
        this.selectedPercentageId = this.type[0].id;
        this.selectedPercentId = this.selectArr[1].id;
        this.selectedFlatId = this.selectArr[0].id;
        this.selectedFileId = this.fileArr[0].id;
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            selectAllText: '',
            unSelectAllText: '',
            itemsShowLimit: 1,
            allowSearchFilter: false,
            limitSelection: 2
        };
        this.selectedItems = [];
        this.appendHTML = `<span class="fal fa-angle-down"></span>`;
        this.cCreateNewInvoice = new CreateNewInvoice();
        this.cCreateNewInvoiceReq = new CreateNewInvoiceReq();
        this.cInvoiceTaskReq = new InvoiceTaskReq();
        this.cInvoiceTaskRes = new InvoiceTaskRes();
        this.cItemTaskList = [];
        this.cCreateInvoiceRes = new CreateInvoiceRes();
        this.cCreateNewInvoiceReq.recurring = 'N';
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
        this.popUpCount = 0;
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'YYYY-MM-DD' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.calOptions2 = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'YYYY-MM-DD HH:mm a' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            timePicker: true,
            timePicker12Hour: true,
            minDate: new Date(),
            singleDatePicker: true
        };
        this.cCreateInvoiceRes = new CreateInvoiceRes();
        //CUSTOMER DATA
        this.cCountryList = [];
        this.customer = new Customer();
        this.cCountry = [];
        this.cCustomerSearchReq = new CustomerSearchReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.Invoice);
        //task and item
        //this.cIsWritePrivilege = 
        this.cIsTaskAndItemWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.TasksItems);
        this.cTaskAndItemsReq = new InvoiceTaskAndItemsReq();
        this.cTaskAndItems = new InvoiceTaskAndItems();
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.sTitleService.setTitle(this.sTitleService.TasksItems);
    }
    ngOnInit() {
        this.cCreateNewInvoice.itemInv = true;
        ;
        this.cCreateNewInvoice.simpInv = false;
        this.cCreateNewInvoice.InvDesc = true;
        this.cCreateNewInvoice.table = false;
        this.cCreateNewInvoice.isCustomerSelection = false;
        this.cCreateNewInvoice.invCur = this.pMerchInfoService.getCurrencyList();
        if (this.cCreateNewInvoice.invCur != null && this.cCreateNewInvoice.invCur.length > 0) {
            this.cCreateNewInvoice.invCurLabel = this.cCreateNewInvoice.invCur[0].label;
            this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
            this.selectedCurrency = this.cCreateNewInvoice.invCur[0].label;
        }
        if (this.cCreateNewInvoice.frequencyOptions != null && this.cCreateNewInvoice.frequencyOptions.length > 0) {
            this.cCreateNewInvoice.invOccLabel = this.cCreateNewInvoice.frequencyOptions[0].label;
            this.cCreateNewInvoiceReq.frequency = this.cCreateNewInvoice.frequencyOptions[0].value;
        }
        this.cCreateNewInvoiceReq.frequency = this.cCreateNewInvoice.frequencyOptions[0].value;
        let dataRetrieved;
        this.pActiveRouter.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            console.log('mCommonResponse: ', mCommonResponse);
            this.cCreateNewInvoiceReq.invoiceNo = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billId;
            this.cCreateNewInvoice.settingLogoLocation = mCommonResponse.data.businessLogo;
            this.cCreateNewInvoice.settingWebstoreName = mCommonResponse.data['invoiceDetailsRS1ProcEntity'].settingWebstoreName;
            this.cCreateNewInvoice.regGstNo = mCommonResponse.data['invoiceDetailsRS1ProcEntity'].gstId;
            this.cCreateNewInvoiceReq.subAccId = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].subAccId;
            this.cCreateNewInvoiceReq.invoiceCurrency = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCurrId;
            this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            //this.cCreateNewInvoiceReq.invoiceCurrency = 'AED';
            this.cCreateNewInvoiceReq.invoiceAmount = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billAmount;
            this.cCreateNewInvoiceReq.termsAndCondition = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billTermsCondition;
            this.billMerReferenceNo = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMerReferenceNo;
            this.billMerReferenceNo1 = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMerReferenceNo1;
            this.billMerReferenceNo2 = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMerReferenceNo2;
            this.billMerReferenceNo3 = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMerReferenceNo3;
            this.billMerReferenceNo4 = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMerReferenceNo4;
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustId)) {
                this.cCreateNewInvoiceReq.custId = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustId;
            }
            else {
                this.cCreateNewInvoiceReq.custId = '0';
            }
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMinAmt)) {
                this.cCreateNewInvoiceReq.minAmount = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billMinAmt;
                this.cCreateNewInvoiceReq.RadioCheckModel = 'PP'; //need to change after invoice setting changes
                this.showMinAmount = true;
            }
            //check dis
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustomerEmail)) {
                this.cCreateNewInvoiceReq.custEmail = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustomerEmail;
                this.cCreateNewInvoiceReq.invoiceDescription = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billEmailDesc;
                this.cCreateNewInvoiceReq.emailSubjectLine = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billEmailSubject;
                this.cCreateNewInvoice.showhidmail = true;
                this.cCreateNewInvoice.deliveryCheckEmail = true;
            }
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustomerMobile)) {
                this.cCreateNewInvoiceReq.custMobileNo = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billCustomerMobile;
                this.cCreateNewInvoiceReq.smsContent = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].settingInvMsg;
                this.cCreateNewInvoice.showhidsms = true;
                this.cCreateNewInvoice.deliveryCheckSms = true;
            }
            this.cCreateNewInvoiceReq.subAccId = mCommonResponse.data['subAcId'];
            this.cCreateNewInvoiceReq.regId = mCommonResponse.data['RegId'];
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billDate)) {
                this.cCreateNewInvoiceReq.invoiceDate = this.datepipe.transform(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billDate, 'dd/MM/yyyy HH:mm');
                this.invoiceDateCal = new Date(this.datepipe.transform(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billDate, 'yyyy/mm/dd hh:mm'));
            }
            else {
                this.cCreateNewInvoiceReq.invoiceDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy H:mm');
                this.invoiceDateCal = new Date();
            }
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billExpDatetime)) {
                this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billExpDatetime, 'dd/MM/yyyy HH:mm');
                this.expiryDateCal = new Date(this.datepipe.transform(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billExpDatetime, 'yyyy/mm/dd hh:mm'));
            }
            else {
                this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy H:mm');
                this.expiryDateCal = new Date();
            }
            if (this.sCheck.isNotNullObject(mCommonResponse.data['invoiceDetailsRS3ProcEntity'])) {
                this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice';
                this.taskItemResponse = mCommonResponse.data['invoiceDetailsRS3ProcEntity'];
                //this.itemInv = true;
            }
            else {
                console.log('Dataaaaaaaaaaaaaa');
            }
            if (this.sCheck.isNotNullString(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billDueDatetime)) {
                this.cCreateNewInvoiceReq.dueDate = this.datepipe.transform(mCommonResponse.data['invoiceDetailsRS2ProcEntity'].billDueDatetime, 'dd/MM/yyyy');
            }
            this.pInvoiceDataService.subAccId = mCommonResponse.data['invoiceDetailsRS2ProcEntity'].subAccId;
            this.pInvoiceDataService.regId = String(this.pMerchInfoService.getRegId());
            //customerList
            this.cCustomerList = mCommonResponse.data['customerList'];
            for (let obj of this.cCustomerList) {
                this.cCustomerList1.push({ label: obj.custLabel, value: obj.custId });
            }
            this.cCustomerListEdit = mCommonResponse.data["customerList"];
            for (let pcustomerList of this.cCustomerList) {
                this.cCustomerDataList.push({ label: pcustomerList.custName, value: pcustomerList.custId.toString() });
            }
            dataRetrieved = mCommonResponse;
        });
        this.onCustomerSelectionClick(this.cCreateNewInvoiceReq.custId);
        this.createForm();
        this.mForm.get('Taskitem').disable();
        this.setAliasAndInvoiceSetting(dataRetrieved);
        this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
        this.mForm.controls['LateFee'].disable();
        this.mForm.controls['Discount'].disable();
        this.mForm.controls['DiscountIf'].disable();
        this.fetchTask(this.pMerchInfoService.getRegId());
        this.cCreateNewInvoice.invoiceSettingsList = this.setInvoiceSetting(dataRetrieved);
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvTermsEdit == 'N') {
            this.cCreateNewInvoiceReq.termsAndCondition = this.cCreateNewInvoice.invoiceSettingsList.settingInvTerms;
            this.mForm.controls['termsAndCondition'].disable();
        }
        else {
            this.mForm.controls['termsAndCondition'].setValidators([Validators.minLength(1), Validators.maxLength(500), BBValidator.isBeginSpecialChar, BBValidator.isEndSpecialChar, BBValidator.isConsecuSpecialChar]);
            this.cCreateNewInvoiceReq.termsAndCondition = this.cCreateNewInvoice.invoiceSettingsList.settingInvTerms;
        }
        this.fetchCountryList();
        if (this.sCheck.isNotNullObject(this.taskItemResponse)) {
            this.cCreateNewInvoiceReq.itemizedCheck = true;
        }
    }
    ngSelectNamesChange() {
        this.cCreateNewInvoice.ngSelectNames = true;
    }
    onDeliveryTypeChangeEmail(event) {
        if (event) {
            this.cCreateNewInvoice.deliveryCheckEmail = true;
            if (this.cCreateNewInvoice.invoiceSettingsList.settingInvSubjectEdit == 'Y') {
                this.mForm.controls['emailSubjectLine'].setValidators([Validators.required, Validators.maxLength(100), BBValidator.emailSub, BBValidator.isBeginSpecialChar, BBValidator.isEndSpecialChar, BBValidator.isConsecuSpecialChar]);
                this.cCreateNewInvoiceReq.emailSubjectLine = this.cCreateNewInvoice.invoiceSettingsList.settingInvSubject;
            }
            else {
                this.mForm.controls['emailSubjectLine'].disable();
                this.cCreateNewInvoiceReq.emailSubjectLine = this.cCreateNewInvoice.invoiceSettingsList.settingInvSubject;
            }
            if (this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescriptionEdit == 'N') {
                this.cCreateNewInvoiceReq.invoiceDescription = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            }
            else {
                this.cCreateNewInvoiceReq.invoiceDescription = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            }
            this.deliveryTypeNotSelected = false;
        }
        else {
            this.cCreateNewInvoice.deliveryCheckEmail = false;
            this.mForm.controls['emailSubjectLine'].setValidators([]);
            this.mForm.controls['emailSubjectLine'].setValue("");
            this.mForm.controls['invoiceDescription'].setValue("");
            this.cCreateNewInvoice.invoiceDescription = '';
        }
    }
    onDeliveryTypeChangeSms(event) {
        if (event) {
            if (this.cCreateNewInvoice.invoiceSettingsList.settingInvSMSEdit == 'N') {
                this.cCreateNewInvoiceReq.smsContent = this.cCreateNewInvoice.invoiceSettingsList.settingInvSMSContent;
                this.mForm.controls['smsContent'].disable();
            }
            else {
                this.cCreateNewInvoiceReq.smsContent = this.cCreateNewInvoice.invoiceSettingsList.settingInvSMSContent;
                this.mForm.controls['smsContent'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(100)]);
            }
            this.cCreateNewInvoice.deliveryCheckSms = true;
            this.mForm.controls['showhidsms'].setValue(true);
            this.deliveryTypeNotSelected = false;
        }
        else {
            this.mForm.controls['showhidsms'].setValue(false);
            this.cCreateNewInvoice.deliveryCheckSms = false;
            this.mForm.controls['smsContent'].setValidators([]);
            this.mForm.controls['smsContent'].updateValueAndValidity();
        }
    }
    UnitCostChange(itemnumber) {
        if (itemnumber.itemUnitCost > 0) {
            itemnumber.lineTotal = 0;
            if (typeof itemnumber.itemQty != 'undefined' && itemnumber.itemQty != null) {
                if (itemnumber.itemUnitCost != null && itemnumber.itemUnitCost != 0) {
                    itemnumber.lineTotal = (itemnumber.itemUnitCost * itemnumber.itemQty);
                }
            }
            else {
                itemnumber.lineTotal = 0;
            }
        }
        else {
            itemnumber.itemUnitCost = 0;
            itemnumber.lineTotal = 0;
        }
    }
    QuantityChange(itemnumber) {
        itemnumber.lineTotal = 0;
        if (itemnumber.itemQty > 0) {
            if (itemnumber.itemUnitCost != null && itemnumber.itemUnitCost != undefined) {
                if (typeof itemnumber.itemUnitCost == 'undefined') {
                    itemnumber.lineTotal = 0;
                }
                else {
                    itemnumber.lineTotal = (itemnumber.itemUnitCost * itemnumber.itemQty);
                }
            }
            else {
                itemnumber.itemQty = 0;
                itemnumber.lineTotal = 0;
            }
        }
    }
    enableItemList(itemnumber) {
        itemnumber.controls['itemTax'].enable();
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            /* minAmount:[''],*/
            custId: ['', [Validators.required]],
            invoiceNo: [''],
            invoiceDate: [''],
            dueDate: [''],
            Discount: [''],
            DiscountIf: [''],
            expiryDate: [''],
            invoiceDescription: [''],
            invoiceAmount: ['', [Validators.required,
                    Validators.minLength(1), Validators.max(999999999.99),
                    BBValidator.amount,
                    BBValidator.nonZeroAmount
                ]],
            invoiceCurrency: ['', [Validators.required]],
            showhidmail: [''],
            showhidsms: [''],
            RadioCheck: [''],
            termsAndCondition: [''],
            customerList: [''],
            MerchantReferenceNo: ['', [
                    BBValidator.invoiceMerRefNum,
                    Validators.minLength(3),
                    Validators.maxLength(50),
                ]],
            MerchantReferenceNo1: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo2: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo3: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo4: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            aliasRefNo1: [''],
            aliasRefNo: [''],
            minAmount: [''],
            smsContent: [''],
            emailSubjectLine: [''],
            dynamicEventArray: this.pFormBuilder.array([]),
            Taskitem: this.buildArray(),
            merchantParamsitem1: this.buildMercahntParamsArray1(),
            LateFee: [''],
            Frequency: [''],
            Occurences: [''],
            StartDate: [''],
        });
    }
    fetchTask(regId) {
        this.sInvoiceService.fetchTask(regId)
            .subscribe(rResponse => this.fetchAllTaskSuccess(rResponse), error => { console.log('error'); });
    }
    fetchAllTaskSuccess(pResponse) {
        this.cCreateNewInvoice.taskOption = [];
        this.cCreateNewInvoice.taxOption = [];
        this.cItemTaskList = [];
        // Dropdown Logic For Task
        this.cInvoiceTaskRes.invoiceTaskList = pResponse['invoiceTaskList'];
        this.invoiceMainTaskList = this.cInvoiceTaskRes.invoiceTaskList;
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            this.itemName = this.cInvoiceTaskRes.invoiceTaskList[i].itemName;
            if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null && this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length > 0) {
                for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                    this.invoiceCurrency = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency;
                    this.price = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price;
                    this.itemInvDescription = this.cInvoiceTaskRes.invoiceTaskList[i].itemDescription;
                    this.itemId = this.cInvoiceTaskRes.invoiceTaskList[i].itemId;
                    let itemObj = new ItemTaskList();
                    itemObj.itemCurrency = this.invoiceCurrency;
                    itemObj.itemUnitCost = this.price;
                    itemObj.itemName = this.itemName;
                    itemObj.itemDescription = this.itemInvDescription;
                    itemObj.itemId = this.itemId;
                    itemObj.taskListLabel = this.itemName + " - ( " + this.invoiceCurrency + " - " + this.price + " )";
                    this.cItemTaskList.push(itemObj);
                }
            }
        }
        // DropDown Logic for Tax
        this.cInvoiceTaskRes.taxList = pResponse['taxList'];
        for (var i = 0; i < this.cInvoiceTaskRes.taxList.length; i++) {
            this.cCreateNewInvoice.taxOption.push({ label: this.cInvoiceTaskRes.taxList[i].taxName, value: { id: this.cInvoiceTaskRes.taxList[i].taxRateIndia, name: this.cInvoiceTaskRes.taxList[i].taxName } });
        }
    }
    buildMercahntParamsArray1() {
        this.merchantParamsitem1 = this.pFormBuilder.array([
            this.buildGroup1()
        ]);
        this.merchantParamsitem1.removeAt(0);
        return this.merchantParamsitem1;
    }
    buildGroup1() {
        let aliasRefNoVal;
        let aliasRefIndex;
        let isAliasMerRefNoNull;
        let isFound = true;
        if (typeof this.merchantParamsitem1 == 'undefined') {
            //aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo;
            return this.pFormBuilder.group({
                aliasRefNo: [''],
                merchantReferenceNo: [''],
                index: ['']
            });
        }
        else if (typeof this.merchantParamsitem1 == 'object') {
            for (let i = 1; i <= 6; i++) {
                if (isFound && this.mForm.value.merchantParamsitem1.length > 0) {
                    for (let j = 0; j < this.mForm.value.merchantParamsitem1.length; j++) {
                        if (this.mForm.value.merchantParamsitem1[j].index === i) {
                            isFound = true;
                            break;
                            console.log('===1', j, isFound);
                        }
                        else {
                            isFound = false;
                            console.log('===2', j, isFound);
                        }
                    }
                }
                else {
                    aliasRefIndex = i - 1;
                    if (aliasRefIndex == 1) {
                        if (this.cCreateNewInvoice.aliasRefNo) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'MerchantParam #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 2) {
                        if (this.cCreateNewInvoice.aliasRefNo1) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo1;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'MerchantParam #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 3) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo2) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo2;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'MerchantParam #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 4) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo3) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo3;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'MerchantParam #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 5) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo4) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo4;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'MerchantParam #' + aliasRefIndex;
                            break;
                        }
                    }
                }
            }
        }
        return this.pFormBuilder.group({
            aliasRefNo: aliasRefNoVal,
            merchantReferenceNo: [''],
            index: aliasRefIndex
        });
    }
    buildArray() {
        this.Taskitem = this.pFormBuilder.array([
            this.buildGroup()
        ]);
        return this.Taskitem;
    }
    pushParams(aliasRefNo, merchantReferenceNo, indexNo) {
        return this.pFormBuilder.group({
            aliasRefNo: [aliasRefNo],
            merchantReferenceNo: [merchantReferenceNo],
            index: [indexNo]
        });
    }
    buildGroup() {
        if (this.sCheck.isNotNullObject(this.taskItemResponse)) {
            console.log('in if');
            // for ( let c of this.taskItemResponse ) {
            // console.log('C: ', c);
            this.editTaskGrid = this.pFormBuilder.group({
                selectedNameId: '',
                itemName: 'Computer',
                itemCurrency: 'INR',
                itemDescription: ['dessppp', [
                        BBValidator.itemDesc
                    ]],
                itemUnitCost: [85, [
                        Validators.required,
                        Validators.minLength(1),
                        Validators.maxLength(999999999.99),
                        BBValidator.amount
                    ]],
                itemQty: ['', [
                        Validators.required,
                        Validators.minLength(1),
                        Validators.maxLength(6),
                        BBValidator.nonZeroNumber,
                        BBValidator.nonZeroAmount,
                    ]],
                itemTax1: '',
                itemTax1Value: '',
                itemTax2: '',
                itemTax2Value: '',
                lineTotal: '2132',
                itemTax: [],
                taxCal1: 0,
                taxCal2: 0,
                subTotal: 0,
                totalTax: 0,
                finalInvoiceAmount: '',
                txCalculation: 456987
            });
            // }//end of For loop
            console.log('====>>>>> ', this.editTaskGrid);
            return this.editTaskGrid;
        }
        else {
            console.log('in else');
            this.editTaskGrid = this.pFormBuilder.group({
                selectedNameId: '',
                itemName: '',
                itemCurrency: [''],
                itemDescription: ['', [
                        BBValidator.itemDesc
                    ]],
                itemUnitCost: ['', [
                        Validators.required,
                        Validators.minLength(1),
                        Validators.maxLength(999999999.99),
                        BBValidator.amount
                    ]],
                itemQty: ['', [
                        Validators.required,
                        Validators.minLength(1),
                        Validators.maxLength(6),
                        BBValidator.nonZeroNumber,
                        BBValidator.nonZeroAmount,
                    ]],
                itemTax1: '',
                itemTax1Value: '',
                itemTax2: '',
                itemTax2Value: '',
                lineTotal: '',
                itemTax: [],
                taxCal1: 0,
                taxCal2: 0,
                subTotal: 0,
                totalTax: 0,
                finalInvoiceAmount: '',
                txCalculation: 0
            });
            console.log(this.editTaskGrid);
            return this.editTaskGrid;
        }
    }
    onSelectByOptionClick(pOption) {
        this.cCreateNewInvoice.isCheckInvCur = !this.cCreateNewInvoice.isCheckInvCur;
        this.cCreateNewInvoice.invCurLabel = pOption.label;
        this.cCreateNewInvoice.invoiceCurrency = pOption.value;
    }
    disableItemList(event, itemnumber) {
        let taxArray = event.value;
        if (taxArray.length > 2) {
            let seltax = itemnumber.controls['itemTax'].value;
            seltax.splice(2, taxArray.length);
            //itemnumber.controls['itemTax'].value(seltax);
        }
    }
    onSelectByOptionOccuClick(event) {
        this.cCreateNewInvoice.invOccLabel = event.label;
        this.cCreateNewInvoiceReq.frequency = event.value;
    }
    onSelectTax(event, itemnumber) {
        //itemnumber.lineTotal = 0;
        if (itemnumber.itemQty > 0) {
            let taxArray = event.value;
            if (taxArray.length > 0 && taxArray.length < 3) {
                itemnumber.itemTax1Value = "0";
                itemnumber.itemTax2Value = "0";
                itemnumber.taxCal1 = 0;
                itemnumber.taxCal2 = 0;
                itemnumber.itemTax1Value = taxArray[0].id;
                itemnumber.itemTax1 = taxArray[0].name;
                itemnumber.taxCal1 = (itemnumber.lineTotal) * (parseFloat(itemnumber.itemTax1Value) / 100);
                itemnumber.txCalculation = itemnumber.taxCal1;
                if (taxArray.length == 2) {
                    itemnumber.itemTax2Value = taxArray[1].id;
                    itemnumber.itemTax2 = taxArray[1].name;
                    itemnumber.taxCal2 = (itemnumber.lineTotal) * (parseFloat(itemnumber.itemTax2Value) / 100);
                    itemnumber.txCalculation = itemnumber.txCalculation + itemnumber.taxCal2;
                }
            }
            else if (taxArray.length > 2) {
                itemnumber.taxCal1 = 0;
                itemnumber.taxCal2 = 0;
                this.sAlertMessageService.popupAlertMsg("Please select only 2 taxes");
            }
            else {
                if (taxArray.length == 0) {
                    itemnumber.taxCal1 = 0;
                    itemnumber.taxCal2 = 0;
                }
                if (itemnumber.itemQty == undefined) {
                    itemnumber.taxCal1 = 0;
                    itemnumber.taxCal2 = 0;
                    itemnumber.lineTotal = 0;
                }
                else {
                    itemnumber.lineTotal = (itemnumber.itemUnitCost * itemnumber.itemQty);
                }
            }
            this.valuechange(event, itemnumber);
        }
    }
    valuechange(event, itemnumber) {
        this.cCreateNewInvoice.subTotalAmt = 0;
        this.cCreateNewInvoice.subTotalTaxAmt = 0;
        for (var i = 0; i < this.Taskitem.controls.length; i++) {
            if (typeof itemnumber.taxCal1 == 'undefined') {
                itemnumber.taxCal1 = 0;
            }
            if (typeof itemnumber.taxCal2 == 'undefined') {
                itemnumber.taxCal2 = 0;
            }
            var line = this.Taskitem.controls[i]['lineTotal'];
            if (typeof line == 'undefined') {
                line = 0;
            }
            this.cCreateNewInvoice.subTotalAmt = this.cCreateNewInvoice.subTotalAmt + line;
            var txCalculation = this.Taskitem.controls[i]['txCalculation'];
            if (typeof txCalculation == 'undefined') {
                txCalculation = 0;
            }
            if (typeof itemnumber.txCalculation == 'undefined') {
                itemnumber.txCalculation = 0;
            }
            else {
            }
            this.cCreateNewInvoice.subTotalTaxAmt = this.cCreateNewInvoice.subTotalTaxAmt + txCalculation;
            this.cCreateNewInvoiceReq.invoiceAmount = this.cCreateNewInvoice.subTotalAmt + this.cCreateNewInvoice.subTotalTaxAmt;
            this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoiceReq.invoiceAmount;
            this.invoiceAmountChange();
        }
    }
    invoiceAmountChange() {
        this.mForm.controls['minAmount'].setValue('');
        this.cCreateNewInvoice.invalidMinAmount = false;
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Flat') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['LateFee'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
        }
        if (this.cCreateNewInvoiceReq.discountType == 'Flat') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['Discount'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
        }
    }
    onSelectByOptionLatePayment(event) {
        this.cCreateNewInvoice.lateLabel = event.name;
        this.cCreateNewInvoiceReq.lateFeeType = event.id;
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Perc') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = '%';
            this.mForm.controls['LateFee'].setValidators([BBValidator.percentages, Validators.required]);
            this.mForm.controls['LateFee'].updateValueAndValidity();
        }
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Flat') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['LateFee'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
            this.mForm.controls['LateFee'].updateValueAndValidity();
        }
    }
    onSelectCurrency() {
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        this.fetchSimilarTask(this.pMerchInfoService.getRegId());
    }
    fetchSimilarTask(regId) {
        this.sInvoiceService.fetchTask(regId)
            .subscribe(rResponse => this.fetchSimilarTaskSuccess(rResponse), error => { console.log('error'); });
    }
    fetchSimilarTaskSuccess(pResponse) {
        this.cCreateNewInvoice.taskOption = [];
        this.cCreateNewInvoice.taxOption = [];
        this.cItemTaskList = [];
        // Dropdown Logic For Task
        this.cInvoiceTaskRes.invoiceTaskList = pResponse['invoiceTaskList'];
        this.invoiceMainTaskList = this.cInvoiceTaskRes.invoiceTaskList;
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            this.itemName = this.cInvoiceTaskRes.invoiceTaskList[i].itemName;
            if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null && this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length > 0) {
                for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                    this.invoiceCurrency = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency;
                    if (this.invoiceCurrency == this.cCreateNewInvoiceReq.invoiceCurrency) {
                        this.price = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price;
                        this.itemInvDescription = this.cInvoiceTaskRes.invoiceTaskList[i].itemDescription;
                        this.itemId = this.cInvoiceTaskRes.invoiceTaskList[i].itemId;
                        let itemObj = new ItemTaskList();
                        itemObj.itemCurrency = this.invoiceCurrency;
                        itemObj.itemUnitCost = this.price;
                        itemObj.itemName = this.itemName;
                        itemObj.itemDescription = this.itemInvDescription;
                        itemObj.itemId = this.itemId;
                        itemObj.taskListLabel = this.itemName + " - ( " + this.invoiceCurrency + " - " + this.price + " )";
                        this.cItemTaskList.push(itemObj);
                    }
                }
            }
        }
        // DropDown Logic for Tax
        this.cInvoiceTaskRes.taxList = pResponse['taxList'];
        for (var i = 0; i < this.cInvoiceTaskRes.taxList.length; i++) {
            this.cCreateNewInvoice.taxOption.push({ label: this.cInvoiceTaskRes.taxList[i].taxName, value: { id: this.cInvoiceTaskRes.taxList[i].taxRateIndia, name: this.cInvoiceTaskRes.taxList[i].taxName } });
        }
    }
    onDueDateChange() {
        this.cCreateNewInvoice.dueCheck = false;
        if (typeof this.dueDateCal != 'undefined') {
            if (this.dueDateCal < this.expiryDateCal) {
                this.mForm.controls['LateFee'].enable();
                this.mForm.controls['LateFee'].setValidators([Validators.required, BBValidator.percentages]);
                this.mForm.controls['LateFee'].updateValueAndValidity();
                this.mForm.controls['DiscountIf'].enable();
                this.mForm.controls['DiscountIf'].setValidators([Validators.required]);
                this.mForm.controls['DiscountIf'].updateValueAndValidity();
            }
            else {
                this.mForm.controls['LateFee'].disable();
                this.mForm.controls['LateFee'].setValue('');
                this.mForm.controls['LateFee'].setValidators([]);
                this.mForm.controls['DiscountIf'].disable();
                this.mForm.controls['DiscountIf'].setValue('');
                this.mForm.controls['DiscountIf'].setValidators([]);
            }
            if (this.dueDateCal > this.expiryDateCal) {
                this.cCreateNewInvoice.dueCheck = true;
            }
            else {
                this.cCreateNewInvoice.dueCheck = false;
            }
        }
    }
    onSelectItem(pItemnumber, selectedItemDetail, k) {
        if (selectedItemDetail.itemName == "Select task/item") {
            pItemnumber.itemDescription = null;
            pItemnumber.itemUnitCost = null;
            pItemnumber.itemQty = null;
            pItemnumber.lineTotal = null;
            pItemnumber.itemName = "Select task/item";
        }
        if (selectedItemDetail.itemName == "Add task/item") {
            this.cCreateNewInvoice.isAddTask = "active";
            pItemnumber.itemDescription = null;
            pItemnumber.itemUnitCost = null;
            pItemnumber.itemQty = null;
            pItemnumber.lineTotal = null;
            pItemnumber.itemName = "Select task/item";
            this.cCreateNewInvoice.invalidItemList = false;
            this.mForm.get('Taskitem').markAsPristine();
        }
        if (k == 0) {
            this.cCreateNewInvoiceReq.invoiceCurrency = selectedItemDetail.itemCurrency;
            this.onSelectCurrency();
        }
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            if (this.cInvoiceTaskRes.invoiceTaskList[i].itemName == selectedItemDetail.itemName) {
                this.cCreateNewInvoice.invalidItemList = false;
                if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null) {
                    for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                        if (this.cCreateNewInvoiceReq.invoiceCurrency == this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency) {
                            pItemnumber.itemQty = 0;
                            pItemnumber.lineTotal = 0;
                            pItemnumber.itemUnitCost = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price;
                            pItemnumber.itemName = selectedItemDetail.itemName;
                            pItemnumber.itemCurrency = selectedItemDetail.itemCurrency;
                            pItemnumber.itemDescription = selectedItemDetail.itemDescription;
                            pItemnumber.itemId = selectedItemDetail.itemId;
                        }
                    }
                }
            }
        }
        if (pItemnumber.itemName) {
            pItemnumber.arrowDown2 = false;
            pItemnumber.editClicked2 = true;
        }
    }
    addTask() {
        this.ngSelectTableRow1 = false;
        let removeIndex = -1;
        for (var i = 0; i < this.cCreateNewInvoice.taskOption.length; i++) {
            for (let g = 0; g < this.Taskitem.controls.length; g++) {
                var itemName = this.Taskitem.controls[g]['itemName'];
                if (itemName != undefined && this.cCreateNewInvoice.taskOption[i].value == itemName) {
                    removeIndex = i;
                }
            }
        }
        if (removeIndex > 0) {
            let item = this.cCreateNewInvoice.taskOption.splice(removeIndex, 1);
            this.mySelectedTaskList.push(item);
        }
        this.Taskitem.push(this.buildGroup());
    }
    deleteTask(index, itemnumber) {
        if (this.Taskitem.length > 1) {
            if (this.cCreateNewInvoice.totalAmt > 0) {
                this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoice.totalAmt - itemnumber.lineTotal;
                this.cCreateNewInvoiceReq.invoiceAmount = this.cCreateNewInvoice.totalAmt;
            }
            let itemName = itemnumber.itemName;
            this.cCreateNewInvoice.taskOption.pop();
            this.cCreateNewInvoice.taskOption.shift();
            for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
                if (this.cInvoiceTaskRes.invoiceTaskList[i].itemName == itemName) {
                    this.cCreateNewInvoice.taskOption.splice(i, 0, { label: this.cInvoiceTaskRes.invoiceTaskList[i].itemName, value: this.cInvoiceTaskRes.invoiceTaskList[i].itemName });
                }
            }
            this.cCreateNewInvoice.taskOption.splice(0, 0, { label: 'Select task/item', value: 'Select task/item' });
            this.cCreateNewInvoice.taskOption.push({ label: 'Add task/item', value: 'Add task/item' });
            this.Taskitem.removeAt(index);
        }
        else {
            this.Taskitem.removeAt(index);
            this.fetchTask(this.pMerchInfoService.getRegId());
            this.Taskitem.push(this.buildGroup());
        }
    }
    addMerchantParams(i) {
        this.merchantParamsitem1.push(this.buildGroup1());
    }
    deleteMerchantParams(i, itemnumber) {
        this.merchantParamsitem1.removeAt(i);
    }
    setAliasAndInvoiceSetting(pResponse) {
        this.cCreateNewInvoice.aliasList = pResponse.data['invoiceSettingsAlias'];
        this.cCreateNewInvoice.aliasCustomerName = this.cCreateNewInvoice.aliasList.aliasCustomerName;
        this.cCreateNewInvoice.aliasRefNo = this.cCreateNewInvoice.aliasList.aliasMerRefNo;
        this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo, this.billMerReferenceNo, 1));
        this.cCreateNewInvoice.aliasRefNo1 = this.cCreateNewInvoice.aliasList.aliasMerRefNo1;
        this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo1, this.billMerReferenceNo1, 2));
        this.cCreateNewInvoice.aliasRefNo2 = this.cCreateNewInvoice.aliasList.aliasMerRefNo2;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo2)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo2, this.billMerReferenceNo2, 3));
        }
        this.cCreateNewInvoice.aliasRefNo3 = this.cCreateNewInvoice.aliasList.aliasMerRefNo3;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo3)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo3, this.billMerReferenceNo3, 4));
        }
        this.cCreateNewInvoice.aliasRefNo4 = this.cCreateNewInvoice.aliasList.aliasMerRefNo4;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo4)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo4, this.billMerReferenceNo4, 5));
        }
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityEdit) && this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityEdit == 'N') {
            this.mForm.controls['expiryDate'].disable();
            this.cCreateNewInvoiceReq.validitytype = this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType;
            this.cCreateNewInvoiceReq.invoiceValidFor = this.cCreateNewInvoice.invoiceSettingsList.settingInvValidity;
            //calculation on basis of these two
        }
        else {
            this.mForm.controls['expiryDate'].enable();
        }
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount) && this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y') {
            this.mForm.controls['minAmount'].setValidators([Validators.required, Validators.minLength(1), BBValidator.amount, BBValidator.nonZeroNumber, BBValidator.nonZeroAmount]);
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvAdvance == 'Y' && this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.mForm.controls['dueDate'].setValidators([Validators.required]);
            this.mForm.controls['dueDate'].updateValueAndValidity();
            this.mForm.controls['DiscountIf'].disable();
        }
        this.cCreateNewInvoice.aliasTermCondition = this.cCreateNewInvoice.aliasList.aliasTermsConditions;
        this.cCreateNewInvoice.aliasTask = this.cCreateNewInvoice.aliasList.aliasItems;
        this.cCreateNewInvoice.aliasDescription = this.cCreateNewInvoice.aliasList.aliasDescription;
        this.cCreateNewInvoice.aliasUnitCost = this.cCreateNewInvoice.aliasList.aliasUnitCost;
        this.cCreateNewInvoice.aliasTotalAmt = this.cCreateNewInvoice.aliasList.aliasNetAmount;
    }
    setInvoiceSetting(pResponse) {
        this.cCreateNewInvoice.invoiceSettingsList = pResponse.data['invoiceSettings'];
        this.cCreateNewInvoice.settingBizAddress = this.cCreateNewInvoice.invoiceSettingsList.settingBizAddress;
        this.cCreateNewInvoice.settingBizEmail = this.cCreateNewInvoice.invoiceSettingsList.settingBizEmail;
        this.cCreateNewInvoice.settingBizPhone = this.cCreateNewInvoice.invoiceSettingsList.settingBizPhone;
        return this.cCreateNewInvoice.invoiceSettingsList;
    }
    onChooseAttachmentFile(event) {
        let fileList = event.target.files;
        if (fileList.length > 0) {
            let validExts = [];
            validExts = ['.jpg', '.jpeg', '.doc', '.docx', '.png', '.pdf'];
            var fileExt = fileList[0].name.substring(fileList[0].name.lastIndexOf('.'));
            if (validExts.indexOf(fileExt) >= 0) {
                if (fileList[0].size <= 1000000) {
                    this.cCreateNewInvoice.attachmentFile = fileList[0];
                    this.cCreateNewInvoiceReq.emailAttachmentFileName = fileList[0].name;
                    this.cCreateNewInvoiceReq.emailAttachment = "Y";
                }
                else {
                    this.sAlertMessageService.popupAlertMsg("File size upto 1 MB allowed.");
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg("Only pdf,doc,docx,jpeg,jpg,png files are allowed.");
            }
        }
    }
    onCancelClick() {
        this.pLocation.back();
    }
    openCustomerPopUp() {
        this.cCreateNewInvoice.showCustomerPopoup = "Y";
        this.cCreateNewInvoice.editPopupFlag = 'N';
        this.cCreateNewInvoice.isCustomerDropDown = !this.cCreateNewInvoice.isCustomerDropDown;
    }
    onSelectionClick(pTemplate) {
        this.cCreateNewInvoiceReq.invoiceAction = "Pending"; //pending
        this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
    }
    onSaveDraft(pTemplate) {
        this.cCreateNewInvoiceReq.invoiceAction = "Draft"; //pending
        this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
    }
    decline() {
        this.cModalRef.hide();
        this.pLocation.back();
    }
    declineGenerate() {
        this.cModalRef.hide();
    }
    validateItemList() {
        this.cCreateNewInvoiceReq.invoiceAmount = 0;
        this.cCreateNewInvoiceReq.itemsTasksList.forEach(item => {
            item.itemTax = null;
            if (item.itemName == undefined || item.itemDescription == undefined || item.itemQty == undefined || item.itemQty == 0) {
                this.cCreateNewInvoice.invalidItemList = true;
                return true;
            }
            else {
                let totalCalAmount = Number(this.cCreateNewInvoice.totalAmt);
                this.cCreateNewInvoiceReq.invoiceAmount = totalCalAmount;
                this.cCreateNewInvoice.invalidItemList = false;
            }
        });
        return false;
    }
    onSubmit() {
        this.dateSelectionfailed = this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
        this.onPaymentWayClick(this.cCreateNewInvoiceReq.RadioCheckModel);
        this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
        if (this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.cCreateNewInvoiceReq.itemsTasksList = this.Taskitem.value;
            if (this.cCreateNewInvoiceReq.itemsTasksList.length > 0) {
                this.validateItemList();
            }
            else {
                this.sAlertMessageService.popupAlertMsg("There should be one item in itemized invoice");
            }
        } //end of if
        if (!this.cCreateNewInvoice.invalidItemList) {
            if (this.mForm.valid) {
                this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
                if (this.cCreateNewInvoice.deliveryCheckEmail) {
                    this.cCreateNewInvoiceReq.deliveryType = "EMAIL";
                }
                else if (this.cCreateNewInvoice.deliveryCheckSms) {
                    this.cCreateNewInvoiceReq.deliveryType = "SMS";
                }
                if (this.cCreateNewInvoice.deliveryCheckEmail && this.cCreateNewInvoice.deliveryCheckSms) {
                    this.cCreateNewInvoiceReq.deliveryType = "BOTH";
                }
                if (this.cCreateNewInvoiceReq.RadioCheckModel != 'FP' && this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y' && (parseFloat(this.cCreateNewInvoiceReq.minAmount.toString()) > parseFloat(this.cCreateNewInvoiceReq.invoiceAmount.toString()))) {
                    this.cCreateNewInvoice.invalidMinAmount = true;
                }
                else {
                    if (this.cCreateNewInvoiceReq.deliveryType != null && this.cCreateNewInvoiceReq.deliveryType != '') {
                        // if(this.popUpCount == 0)
                        if (this.dateSelectionfailed == false)
                            this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                                .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { console.log('error'); });
                    }
                    else {
                        this.deliveryTypeNotSelected = true;
                    }
                }
            }
            else {
                CustomValidator.validateAllFields(this.mForm);
                CustomValidator.focusOnFirstInvalidField(this.mForm);
                this.getFormValidationErrors();
            }
        }
        this.popUpCount += 1; //if to track no of 'yes' clicked
    }
    saveAsDraft() {
        this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
        if (this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.cCreateNewInvoiceReq.itemsTasksList = this.Taskitem.value;
            if (this.cCreateNewInvoiceReq.itemsTasksList.length > 0) {
                this.validateItemList();
            }
            else {
                this.sAlertMessageService.popupAlertMsg("There should be one item in itemized invoice");
            }
        }
        if (!this.cCreateNewInvoice.invalidItemList) {
            if (this.cCreateNewInvoice.deliveryCheckEmail) {
                this.cCreateNewInvoiceReq.deliveryType = "EMAIL";
            }
            else if (this.cCreateNewInvoice.deliveryCheckSms) {
                this.cCreateNewInvoiceReq.deliveryType = "SMS";
            }
            if (this.cCreateNewInvoice.deliveryCheckEmail && this.cCreateNewInvoice.deliveryCheckSms) {
                this.cCreateNewInvoiceReq.deliveryType = "BOTH";
            }
            if (this.cCreateNewInvoiceReq.minAmount && this.cCreateNewInvoiceReq.invoiceAmount) {
                if (this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y' && (parseFloat(this.cCreateNewInvoiceReq.minAmount.toString()) > parseFloat(this.cCreateNewInvoiceReq.invoiceAmount.toString()))) {
                    this.cCreateNewInvoice.invalidMinAmount = true;
                }
                else {
                    if (this.popUpCount == 0)
                        this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                            .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { console.log('error'); });
                }
            }
            else {
                if (this.popUpCount == 0)
                    this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                        .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { console.log('error'); });
            }
        }
        this.popUpCount += 1;
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    onCustomerSubmit(value) {
        if (value.custEmail != '' || value.custMobileNo != '') {
            this.mForm1.get('custEmail').clearValidators();
            this.mForm1.get('custEmail').updateValueAndValidity();
            this.mForm1.get('custMobileNo').clearValidators();
            this.mForm1.get('custMobileNo').updateValueAndValidity();
        }
        if (this.mForm1.valid) {
            this.sCustomerService.addCustomerDetails(this.cAddNewCustomerDetailsReq)
                .subscribe(pResponse => {
                this.onAddCustomer(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        else {
            this.validateAllFields(this.mForm1);
        }
    }
    fetchCreateInvoiceResponse(pResponse) {
        if (pResponse.code == 0 && pResponse.message == 'Success') {
            this.cCreateInvoiceRes.billId = pResponse.data['billId'];
            this.cCreateInvoiceRes.success = pResponse.data['success'];
            this.checkErr = false;
            this.sAlertMessageService.popupAlertMsg("Invoice Generated Successfully");
            this.mForm.reset();
            this.buildArray();
            this.mForm.get('Taskitem').disable();
            this.pLocation.back();
        }
        else if (pResponse.code == -1 && pResponse.message == 'Error') {
            this.sAlertMessageService.popupAlertMsg("Invoice generation failed.");
        }
        else if (pResponse.code == -1 && pResponse.message == 'ValidationFail') {
            this.sErrorHandler.setSingleServerError(pResponse.fieldErrors, this.mForm);
        }
        this.cModalRef.hide();
    }
    onCustomerSelectionClick(pValue) {
        console.log("onCustomerSelectionClick");
        this.sCustomerService.getCustomerDetails(pValue)
            .subscribe(pResponse => this.assignCustomerData(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    assignCustomerData(pResponse) {
        let custData = pResponse.data['customerData'];
        this.cCreateNewInvoice.isCustomerSelection = true;
        this.cCreateNewInvoiceReq.custName = custData[0].custName;
        this.cCreateNewInvoiceReq.custEmail = custData[0].custEmail;
        this.cCreateNewInvoiceReq.custMobileNo = custData[0].custMobileNo;
        this.cCreateNewInvoiceReq.customerName = custData[0].custName;
        this.cCreateNewInvoiceReq.emailId = custData[0].custEmail;
        this.cCreateNewInvoiceReq.customerMobileNumber = custData[0].custMobileNo;
        this.cCreateNewInvoiceReq.custGstin = custData[0].custGstin;
        this.cCreateNewInvoiceReq.custBillingAddress = custData[0].custBillingAddress;
        this.cCreateNewInvoiceReq.custBillingCity = custData[0].custBillingCity;
        this.cCreateNewInvoiceReq.custBillingZip = custData[0].custBillingZip;
        this.cCreateNewInvoiceReq.custBillingState = custData[0].custBillingState;
        this.cCreateNewInvoiceReq.custBillingCountry = custData[0].custBillingCountry;
        this.cCreateNewInvoiceReq.custDeliveryAddress = custData[0].custDeliveryAddress;
        this.cCreateNewInvoiceReq.custDeliveryCity = custData[0].custDeliveryCity;
        this.cCreateNewInvoiceReq.custDeliveryState = custData[0].custDeliveryState;
        this.cCreateNewInvoiceReq.custDeliveryZip = custData[0].custDeliveryZip;
        this.cCreateNewInvoiceReq.custDeliveryCountry = custData[0].custDeliveryCountry;
        this.cCreateNewInvoiceReq.custId = custData[0].custId;
        //this.custId = custData[0].custId;
        if (this.cCreateNewInvoiceReq.custId != '') {
            //if(this.custId != ''){
            this.mForm.get('custId').clearValidators();
            this.mForm.get('custId').updateValueAndValidity();
        }
        this.cCreateNewInvoice.editPopupFlag = 'Y';
        this.customerDetailsNotSelected = false;
    }
    onPaymentWayClick(paymentWayType) {
        this.cCreateNewInvoiceReq.RadioCheckModel = paymentWayType;
        if (paymentWayType == 'PP' || paymentWayType == 'MP') {
            this.showMinAmount = true;
        }
        else {
            this.showMinAmount = false;
            this.cCreateNewInvoiceReq.minAmount = 0;
            this.cCreateNewInvoice.invalidMinAmount = false;
            this.mForm.controls['minAmount'].setValidators([]);
            this.mForm.controls['minAmount'].updateValueAndValidity();
        }
    }
    selectedInvoiceDate(event) {
        this.cCreateNewInvoiceReq.invoiceDate = event.start.format("DD/MM/YYYY hh:mm A");
        this.cCreateNewInvoiceReq.invoiceDate = event.start.format("DD/MM/YYYY hh:mm");
        this.invoiceDateCal = event.start.toDate();
        this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
    }
    selectedExpiryDate(event) {
        this.cCreateNewInvoiceReq.expiryDate = event.start.format("DD/MM/YYYY hh:mm A");
        this.cCreateNewInvoiceReq.expiryDate = event.start.format("DD/MM/YYYY hh:mm");
        this.expiryDateCal = event.start.toDate();
        this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
        if (typeof this.dueDateCal != 'undefined') {
            if (this.dueDateCal > this.expiryDateCal) {
                this.cCreateNewInvoice.dueCheck = true;
                this.mForm.controls['LateFee'].disable();
                this.mForm.controls['LateFee'].setValue('');
                this.mForm.controls['LateFee'].setValidators([]);
                this.mForm.controls['DiscountIf'].disable();
                this.mForm.controls['DiscountIf'].setValue('');
                this.mForm.controls['DiscountIf'].setValidators([]);
            }
            else {
                this.cCreateNewInvoice.dueCheck = false;
                this.mForm.controls['LateFee'].enable();
                this.mForm.controls['LateFee'].setValidators([Validators.required, BBValidator.percentages]);
                this.mForm.controls['LateFee'].updateValueAndValidity();
                this.mForm.controls['DiscountIf'].enable();
                this.mForm.controls['DiscountIf'].setValidators([Validators.required]);
                this.mForm.controls['DiscountIf'].updateValueAndValidity();
            }
        }
    }
    selectedDate(event) {
        this.cCreateNewInvoiceReq.startDate = event.start.format("DD/MM/YYYY");
    }
    selectedDueDate(event) {
        this.cCreateNewInvoiceReq.dueDate = event.start.format("DD/MM/YYYY");
        this.dueDateCal = event.start.toDate();
        this.onDueDateChange();
    }
    selectedDiscountDate(event) {
        this.cCreateNewInvoiceReq.discountIf = event.start.format("DD/MM/YYYY");
        this.requiredDiscountIf(event);
    }
    checkMinimum(event) {
        if (parseInt(event.target.value) > this.cCreateNewInvoiceReq.invoiceAmount) {
            this.cCreateNewInvoice.invalidMinAmount = true;
        }
        else {
            this.cCreateNewInvoice.invalidMinAmount = false;
        }
    }
    compareInvoiceandExpiryDates(invoiceDateCal, expiryDateCal) {
        if (expiryDateCal < invoiceDateCal || expiryDateCal.getTime() == invoiceDateCal.getTime()) {
            this.dateSelectionfailed = true;
        }
        else {
            this.dateSelectionfailed = false;
        }
        return this.dateSelectionfailed;
    }
    onSelectByOptionDiscount(event) {
        this.cCreateNewInvoice.discountLabel = event.name;
        this.cCreateNewInvoiceReq.discountType = event.id;
        if (this.cCreateNewInvoiceReq.discountType == 'Perc') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = '%';
            this.mForm.controls['Discount'].setValidators([BBValidator.percentages, Validators.required]);
            this.mForm.controls['Discount'].updateValueAndValidity();
        }
        if (this.cCreateNewInvoiceReq.discountType == 'Flat') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['Discount'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
            this.mForm.controls['Discount'].updateValueAndValidity();
        }
    }
    /*customer changes*/
    onOpenNewPopupClick(template) {
        this.cModalRef1 = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.createForm1();
    }
    createForm1() {
        this.mForm1 = this.pFormBuilder.group({
            custName: ['', [Validators.required,
                    Validators.minLength(3),
                    Validators.maxLength(60),
                    BBValidator.CusomerName,
                    BBValidator.leastOneChar,
                    BBValidator.isBeginSpecialChar,
                    BBValidator.isEndSpecialChar,
                    BBValidator.isConsecuSpecialChar]],
            custEmail: ['', [BBValidator.email,
                    Validators.maxLength(70)]],
            custMobileNo: ['', [BBValidator.customerPhone]],
            custGstin: ['', [BBValidator.gstNo]],
            isBillingDetails: [],
            custBillingCity: ['', [BBValidator.customerCity,
                    Validators.maxLength(30)]],
            custBillingZip: ['', [BBValidator.customerPin,
                    Validators.maxLength(6)]],
            custBillingState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custBillingCountry: [],
            isDeliveryDetails: [],
            isSameAsBillingDetails: [],
            custDeliveryAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300), BBValidator.customerAddress]],
            custDeliveryCity: ['', [BBValidator.customerCity, Validators.maxLength(30)]],
            custDeliveryState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custDeliveryZip: ['', [BBValidator.customerPin, Validators.maxLength(6)]],
            custDeliveryCountry: [],
            createCustomerButton: [],
            addBillingAddressButton: [],
            custBillingAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]],
            orderBillCountry: []
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onBillingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
            this.cAddNewCustomerDetailsReq.isBillingDetails = true;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isBillingDetails = false;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        }
    }
    onaddBillingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custName ||
            (!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
            if (!this.cAddNewCustomerDetailsReq.custName) {
                this.mForm1.controls['custName'].enable();
                this.mForm1.controls['custName'].setValue(null);
                this.mForm1.controls['custName'].dirty;
                this.mForm1.controls['custName'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custName'].setValidators([Validators.required]);
                this.mForm1.controls['custName'].updateValueAndValidity();
            }
            if ((!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
                this.mForm1.controls['custEmail'].enable();
                this.mForm1.controls['custEmail'].setValue(null);
                this.mForm1.controls['custEmail'].dirty;
                this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custEmail'].setValidators([Validators.required]);
                this.mForm1.controls['custEmail'].updateValueAndValidity();
                this.mForm1.controls['custMobileNo'].enable();
                this.mForm1.controls['custMobileNo'].setValue(null);
                this.mForm1.controls['custMobileNo'].dirty;
                this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custMobileNo'].setValidators([Validators.required]);
                this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            }
        }
        else {
            this.mForm1.get('custEmail').clearValidators();
            this.mForm1.get('custEmail').updateValueAndValidity();
            this.mForm1.get('custMobileNo').clearValidators();
            this.mForm1.get('custMobileNo').updateValueAndValidity();
            this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
            this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
        }
    }
    getCountryList() {
        return this.cCountryList;
    }
    fetchCountryList() {
        this.pTransactionsService.fetchCountryList()
            .subscribe(rResponse => this.fetchCountryListSuccess(rResponse), error => { console.log('error '); });
    }
    fetchCountryListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (this.sCheck.isNotNullObject(pResponse.data)) {
                this.cCountry = pResponse.data;
                for (let pCountry of this.cCountry) {
                    this.cCountryList.push({ label: 'Select country', value: '0' });
                    this.cCountryList.push({ label: pCountry, value: pCountry });
                }
            }
        }
    }
    onBackToCustomerDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
        this.cAddNewCustomerDetailsReq.isBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
        this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
    }
    onShippingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = true;
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        }
        else {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        }
    }
    onaddShippingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custBillingAddress ||
            !this.cAddNewCustomerDetailsReq.custBillingState ||
            !this.cAddNewCustomerDetailsReq.custBillingCity ||
            !this.cAddNewCustomerDetailsReq.custBillingZip ||
            (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0')) {
            if (!this.cAddNewCustomerDetailsReq.custBillingAddress) {
                this.mForm1.controls['custBillingAddress'].enable();
                this.mForm1.controls['custBillingAddress'].setValue(null);
                this.mForm1.controls['custBillingAddress'].dirty;
                this.mForm1.controls['custBillingAddress'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingAddress'].setValidators([Validators.required, Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]);
                this.mForm1.controls['custBillingAddress'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingState) {
                this.mForm1.controls['custBillingState'].enable();
                this.mForm1.controls['custBillingState'].setValue(null);
                this.mForm1.controls['custBillingState'].dirty;
                this.mForm1.controls['custBillingState'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingState'].setValidators([Validators.required, BBValidator.customerState, Validators.maxLength(30)]);
                this.mForm1.controls['custBillingState'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCity) {
                this.mForm1.controls['custBillingCity'].enable();
                this.mForm1.controls['custBillingCity'].setValue(null);
                this.mForm1.controls['custBillingCity'].dirty;
                this.mForm1.controls['custBillingCity'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCity'].setValidators([Validators.required, BBValidator.customerCity,
                    Validators.maxLength(30)]);
                this.mForm1.controls['custBillingCity'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingZip) {
                this.mForm1.controls['custBillingZip'].enable();
                this.mForm1.controls['custBillingZip'].setValue(null);
                this.mForm1.controls['custBillingZip'].dirty;
                this.mForm1.controls['custBillingZip'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingZip'].setValidators([Validators.required, BBValidator.customerPin,
                    Validators.maxLength(6)]);
                this.mForm1.controls['custBillingZip'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0') {
                this.mForm1.controls['custBillingCountry'].enable();
                this.mForm1.controls['custBillingCountry'].setValue(null);
                this.mForm1.controls['custBillingCountry'].dirty;
                this.mForm1.controls['custBillingCountry'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCountry'].setValidators([Validators.required]);
                this.mForm1.controls['custBillingCountry'].updateValueAndValidity();
            }
        }
        else {
            this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = true;
            this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
            this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        }
    }
    onBackToBillingDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
        this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
    }
    onSameAsBillingDetails(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = this.cAddNewCustomerDetailsReq.custBillingAddress;
            this.cAddNewCustomerDetailsReq.custDeliveryCity = this.cAddNewCustomerDetailsReq.custBillingCity;
            this.cAddNewCustomerDetailsReq.custDeliveryState = this.cAddNewCustomerDetailsReq.custBillingState;
            this.cAddNewCustomerDetailsReq.custDeliveryZip = this.cAddNewCustomerDetailsReq.custBillingZip;
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = this.cAddNewCustomerDetailsReq.custBillingCountry;
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCity = '';
            this.cAddNewCustomerDetailsReq.custDeliveryState = '';
            this.cAddNewCustomerDetailsReq.custDeliveryZip = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = '';
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = false;
        }
    }
    onAddCustomer(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.customer.isAnyCustomerCreate = true;
                this.cModalRef1.hide();
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.mForm1.reset();
                this.fetchAllCustomers();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                this.cModalRef.hide();
            }
        }
        else {
            this.cModalRef.hide();
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            this.cModalRef.hide();
        }
    }
    fetchAllCustomers() {
        this.sCustomerService.fetchAllCustomers(this.cCustomerSearchReq)
            .subscribe(pResponse => this.fetchAllCustomerSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchAllCustomerSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.customer.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cCustomerList = mCommonResponse.data['customerList'];
                this.cCustomerListEdit = mCommonResponse.data['customerList'];
                if (this.sCheck.isNullList(mCommonResponse.data['customerList'])) {
                    this.onFailFetchAllCustomer('');
                }
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.customer.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchAllCustomer(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchAllCustomer(pResMsg) {
        this.customer.landingPgeMsg = this.sLandingPageMsgService.invoiceNoRecMsg;
        this.customer.pageTotalCount = null;
        this.cCustomerList = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
    }
    /*edit*/
    editCancleClick() {
        this.cModalRef1.hide();
        this.customer.selectedCustomer = [];
    }
    onOpenEditPopupClick(template, obj) {
        this.createForm1();
        this.fetchAllCustomers();
        for (let pcustomerList of this.cCustomerListEdit) {
            if (pcustomerList.custId == obj) {
                this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
                this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
                this.cAddNewCustomerDetailsReq.custName = pcustomerList.custName;
                this.cAddNewCustomerDetailsReq.custEmail = pcustomerList.custEmail;
                this.cAddNewCustomerDetailsReq.custMobileNo = pcustomerList.custMobileNo;
                this.cAddNewCustomerDetailsReq.custGstin = pcustomerList.custGstin;
                this.cAddNewCustomerDetailsReq.isBillingDetails = false;
                this.cAddNewCustomerDetailsReq.custBillingAddress = pcustomerList.custBillingAddress;
                this.cAddNewCustomerDetailsReq.custBillingCity = pcustomerList.custBillingCity;
                this.cAddNewCustomerDetailsReq.custBillingZip = pcustomerList.custBillingZip;
                this.cAddNewCustomerDetailsReq.custBillingState = pcustomerList.custBillingState;
                this.cAddNewCustomerDetailsReq.custBillingCountry = pcustomerList.custBillingCountry;
                this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
                this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = false;
                this.cAddNewCustomerDetailsReq.custDeliveryAddress = pcustomerList.custDeliveryAddress;
                this.cAddNewCustomerDetailsReq.custDeliveryCity = pcustomerList.custDeliveryCity;
                this.cAddNewCustomerDetailsReq.custDeliveryState = pcustomerList.custDeliveryState;
                this.cAddNewCustomerDetailsReq.custDeliveryZip = pcustomerList.custDeliveryZip;
                this.cAddNewCustomerDetailsReq.custDeliveryCountry = pcustomerList.custDeliveryCountry;
                this.cAddNewCustomerDetailsReq.action = 'edit';
                this.cAddNewCustomerDetailsReq.custId = pcustomerList.custId + '';
            }
        }
        this.cModalRef1 = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
    keyUp(ev, ngSelectRef, createNewCust) {
        var inp = String.fromCharCode(ev.keyCode);
        if (ev.keyCode == 13) {
            return false;
        }
        else if (/[a-zA-Z0-9!@#$%^&*(),.?":{}|<>-_/|\+ ]/.test(inp) || ev.keyCode == 8 || ev.keyCode == 46) {
            createNewCust.style.top = ngSelectRef.dropdownPanel._dropdown.clientHeight + 'px';
        }
    }
    openIt(createNewCust) {
        console.log('openIt');
        if (this.cCustomerList.length <= 1) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 38 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cCustomerList.length == 2) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 76 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cCustomerList.length == 3) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 114 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cCustomerList.length == 4) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 152 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cCustomerList.length >= 5) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 190 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
    }
    ;
    closeIt(createNewCust) {
        this.editClicked = true;
        this.arrowDown = false;
        if (this.events.push({ name: '(close)', value: null }) != null) {
            createNewCust.style.visibility = 'hidden';
        }
    }
    ;
    openItTwo(createNewCust) {
        this.ngSelectTableRow1 = true;
        if (this.cItemTaskList.length <= 1) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 38 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 2) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 76 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 3) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 114 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 4) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 152 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length >= 5) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                createNewCust.style.top = 190 + 'px';
                createNewCust.style.visibility = 'visible';
            }
        }
    }
    ;
    closeItTwo(createNewCust) {
        if (this.events.push({ name: '(close)', value: null }) != null) {
            createNewCust.style.visibility = 'hidden';
        }
    }
    ;
    addTableRow() {
        this.tableRowArr.push('');
    }
    ;
    deleteTableRow() {
        this.tableRowArr.pop();
    }
    ;
    addLineRow() {
        this.addLineArr.push('');
    }
    ;
    deleteLineRow() {
        this.addLineArr.pop();
    }
    ;
    onItemSelect(item, multiSelectDropdown) {
        this.selectedItems.push(item);
        if (this.selectedItems.length == 1) {
            multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems[0].name + '</span>';
        }
        else {
            multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems.length + ' items selected' + '</span>';
        }
    }
    onItemDeselect(deselectItemId, multiSelectDropdown) {
        this.selectedItems.forEach((item, index) => {
            if (item.id === deselectItemId.id) {
                this.selectedItems.splice(index, 1);
                if (this.selectedItems.length == 1) {
                    multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems[0].name + '</span>';
                }
                else {
                    multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + 'Select' + '</span>';
                }
            }
        });
    }
    ;
    //end: suhail code
    onBackClick() {
        this.pLocation.back();
    }
    isReccuring() {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            this.cCreateNewInvoiceReq.recurring = 'Y';
            this.mForm.controls['dueDate'].disable();
            this.mForm.controls['expiryDate'].disable();
        }
        else {
            this.cCreateNewInvoiceReq.recurring = 'N';
            this.mForm.controls['dueDate'].enable();
            this.mForm.controls['expiryDate'].enable();
        }
    }
    clickOnInvoiceType() {
        this.cCreateNewInvoice.itemInv = !this.cCreateNewInvoice.itemInv;
        this.cCreateNewInvoice.simpInv = !this.cCreateNewInvoice.simpInv;
        this.cCreateNewInvoice.InvDesc = !this.cCreateNewInvoice.InvDesc;
        this.cCreateNewInvoice.table = !this.cCreateNewInvoice.table;
        this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        if (this.cCreateNewInvoice.simpInv) {
            this.cCreateNewInvoiceReq.invoiceType = 'ItemizedInvoice';
            this.cCreateNewInvoiceReq.dueDate = '';
            this.mForm.get('Taskitem').enable();
            this.isItemizedInvoice = true;
            this.mForm.get('Taskitem').enable();
            this.mForm.controls['invoiceAmount'].untouched;
            this.mForm.controls['invoiceAmount'].setValidators(null);
            this.mForm.controls['invoiceAmount'].setValue("");
            this.mForm.controls['invoiceAmount'].disable();
            this.mForm.controls['invoiceAmount'].updateValueAndValidity();
            this.mForm.controls['invoiceDescription'].setValidators([]);
            this.mForm.controls['invoiceDescription'].updateValueAndValidity();
        }
        else {
            this.cCreateNewInvoiceReq.invoiceType = 'SimpleInvoice';
            this.mForm.get('Taskitem').disable();
            this.cCreateNewInvoiceReq.emailDesc = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            this.mForm.controls['invoiceAmount'].enable();
            this.mForm.controls['invoiceDescription'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(2000), BBValidator.isConsecuSpecialChar]);
            this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
            this.mForm.controls['invoiceDescription'].updateValueAndValidity();
            this.isItemizedInvoice = false;
        }
    }
    onInvoiceTypeClick(invoiceType) {
        if (invoiceType == 'Simple') {
            this.mForm.get('Taskitem').disable();
            this.cCreateNewInvoiceReq.emailDesc = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            this.mForm.controls['invoiceAmount'].enable();
            this.mForm.controls['emailDesc'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(2000), BBValidator.isConsecuSpecialChar]);
            this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
            this.mForm.controls['emailDesc'].updateValueAndValidity();
            this.isItemizedInvoice = false;
        }
        else {
            this.isItemizedInvoice = true;
            this.mForm.get('Taskitem').enable();
            this.mForm.controls['invoiceAmount'].untouched;
            this.mForm.controls['invoiceAmount'].setValidators(null);
            this.mForm.controls['invoiceAmount'].setValue("");
            this.mForm.controls['invoiceAmount'].disable();
            this.mForm.controls['invoiceAmount'].updateValueAndValidity();
            this.mForm.controls['emailDesc'].setValidators([]);
            this.mForm.controls['emailDesc'].updateValueAndValidity();
        }
    }
    requiredDiscountIf(event) {
        if (this.cCreateNewInvoiceReq.discountIf != '') {
            this.mForm.controls['Discount'].enable();
            this.mForm.controls['Discount'].setValidators([Validators.required, BBValidator.amount]);
            this.mForm.controls['Discount'].updateValueAndValidity();
            this.cCreateNewInvoice.discountIfRequired = true;
            if ((this.cCreateNewInvoiceReq.discountIf) > this.cCreateNewInvoiceReq.dueDate) {
                this.cCreateNewInvoice.discountIfIsMoreThanValid = true;
            }
            else {
                this.cCreateNewInvoice.discountIfIsMoreThanValid = false;
            }
        }
        else {
            this.mForm.controls['Discount'].disable();
            this.mForm.controls['Discount'].setValidators([]);
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountIfRequired = false;
        }
    }
    requiredDiscount(event) {
        if (this.cCreateNewInvoiceReq.discount > 0) {
            this.cCreateNewInvoice.discountRequired = true;
        }
        else {
            this.cCreateNewInvoice.discountRequired = false;
        }
    }
    ngAfterViewChecked() {
        this.sRef.detectChanges();
    }
    checkMerchantRefno(event) {
        this.mForm['controls'].merchantParamsitem1['controls'].forEach((item, index) => {
            for (let control in item.controls) {
                if (index < 2) {
                    item.controls.merchantReferenceNo.setValidators([Validators.required]);
                    item.controls.merchantReferenceNo.updateValueAndValidity();
                }
                if (typeof item.controls.merchantReferenceNo.value != 'undefined' && item.controls.merchantReferenceNo.value != '' && item.controls.merchantReferenceNo.value != null) {
                    item.controls.merchantReferenceNo.setValidators([BBValidator.invoiceMerRefNum, Validators.minLength(3), Validators.maxLength(50)]);
                    item.controls.merchantReferenceNo.updateValueAndValidity();
                }
            }
            ;
        });
    }
    //Start: task and item functionality
    createTaskForm() {
        this.mTaskForm = this.pFormBuilder.group({
            itemName: ['', [
                    Validators.required,
                    Validators.maxLength(30),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.letterNumberAndSpaceOnly,
                ]],
            itemDescription: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharDesc,
                    InvoiceSettingsValidator.promotionDescription,
                    InvoiceSettingsValidator.isConsecuSpecialChar
                ]],
            rates: this.buildTaskArray()
        });
    }
    onOpenTaskPopupClick(template) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.cTaskModalRef = this.pModalService.show(template, { ignoreBackdropClick: true });
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.createTaskForm();
    }
    onCurrencyClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            this.currAmtArray.controls[index].get('price').markAsTouched();
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
        }
    }
    onCurrencyClickNewRow(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        this.cCurrencyIndex = index;
        if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') != -1) {
            this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value'), 1);
            this.cCurrencyLeftFlag = false;
        }
        if (this.cCurrencyList.length != 0 && this.sCheck.isNotNullString(this.currAmtArray.value[index]['currency'])) {
            this.cCurrencyLeftFlag = true;
        }
    }
    get currAmtArray() { return this.mTaskForm.get('rates'); }
    buildTaskArray() {
        this.rates = this.pFormBuilder.array([
            this.buildTaskGroup()
        ]);
        return this.rates;
    }
    buildTaskGroup() {
        return this.pFormBuilder.group({
            currency: [''],
            price: ['']
        });
    }
    buildTaskGroup1() {
        return this.pFormBuilder.group({
            currency: ['', Validators.required],
            price: ['', [Validators.required, Validators.min(1), Validators.max(999999999.99)]]
        });
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onPriceClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            this.currAmtArray.controls[index].get('price').markAsTouched();
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
            this.currAmtArray.controls[index].get('currency').clearValidators();
            this.currAmtArray.controls[index].get('currency').setValidators([Validators.required]);
            this.currAmtArray.controls[index].get('currency').markAsTouched();
            this.currAmtArray.controls[index].get('currency').updateValueAndValidity();
        }
    }
    onBlur(event, index) {
        if (event) {
            if (this.currAmtArray.controls[index].get('price').value != null) {
                let value = +this.currAmtArray.controls[index].get('price').value;
                this.currAmtArray.controls[index].get('price').setValue(value.toFixed(2));
            }
        }
    }
    onDeleteCurrencyClick(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        if (curr != null && curr != '') {
            if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') == -1) {
                this.cCurrencyList.push({ "label": curr, "value": curr });
            }
            if (this.cCurrencyList.length != 0) {
                this.cCurrencyLeftFlag = true;
            }
        }
        if (this.cRatesLength == 1 || this.cRatesLength == 0) {
            this.rates.push(this.createItem('', ''));
        }
        this.rates.removeAt(index);
        this.cRatesLength = this.rates.length;
        this.cCurrencyIndex = this.cCurrencyIndex - 1;
    }
    onAddCurrencyClick() {
        if (!this.cEditCall) {
            if (this.currAmtArray.value[this.cCurrencyIndex]['price'] != null && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '' && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '0.00') {
                this.rates.push(this.buildTaskGroup1());
                this.cRatesLength = this.rates.length;
                this.cCurrencyLeftFlag = false;
            }
        }
        else {
            this.rates.push(this.buildTaskGroup1());
            this.cRatesLength = this.rates.length;
            this.cCurrencyLeftFlag = false;
            this.cEditCall = false;
        }
    }
    arrayObjectIndexOf(pArray, pSearchTerm, pProperty) {
        for (var i = 0, len = pArray.length; i < len; i++) {
            if (pArray[i][pProperty] === pSearchTerm)
                return i;
        }
        return -1;
    }
    createItem(curr, price) {
        return this.pFormBuilder.group({
            currency: [curr],
            price: [price]
        });
    }
    onCreateTasksItemsClick(value) {
        if (this.mTaskForm.valid) {
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            if (this.itemNameArray.indexOf(this.cEditNewTaskAndItemsReq.itemName) > -1) {
                this.cEditNewTaskAndItemsReq.itemId = 0;
            }
            this.pTasksItemsService.addInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cTaskModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mTaskForm);
        }
    }
    taskSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cTaskAndItems.selectedTaskAndItems = [];
                this.fetchTask(this.pMerchInfoService.getRegId());
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
    }
    onSearchClick() {
        if (this.mSearchForm.valid) {
            this.pTasksItemsService.fetchAllInvoiceSettings(this.cTaskAndItemsReq)
                .subscribe(rResponse => this.fetchAllTaskAndItemsSuccess(rResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.mSearchForm);
        }
    }
    fetchAllTaskAndItemsSuccess(pResponse) {
        this.itemNameArray = [];
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cTaskAndItems.totalCount = mCommonResponse.data['totalCount'];
                    this.cTaskAndItemsProcEntity = mCommonResponse.data['invoiceTaskItemList'];
                    for (let procEntity of this.cTaskAndItemsProcEntity) {
                        if (procEntity.itemUnitCost != null) {
                            let unitCost = procEntity.itemUnitCost.split("#");
                            unitCost.splice(0, 1);
                            procEntity.currency = [];
                            procEntity.price = [];
                            for (let cost of unitCost) {
                                let unit = cost.split("$");
                                procEntity.currency.push(unit[0]);
                                procEntity.price.push(unit[1]);
                            }
                            this.itemNameArray.push(procEntity.itemName);
                        }
                    }
                    if (!this.sResponsiveService.isCancelResponsive()) {
                        this.cTaskAndItems.isSearchPanelClick = false;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cTaskAndItems.isSearchPanelClick = false;
                }
            }
            else {
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cTaskAndItems.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
            this.cTaskAndItems.totalCount = null;
            this.cTaskAndItemsProcEntity = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cTaskAndItems.isSearchPanelClick = false;
            }
        }
    }
    onItemNameClick() {
        this.mTaskForm.controls['itemName'].setAsyncValidators(this.checkeTaskAvailability.bind(this));
    }
    checkeTaskAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.pTasksItemsService.checkeTaskAvailability(this.cEditNewTaskAndItemsReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkeTaskAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkeTaskAvailability': true };
                }
            }
            else {
                return { 'checkeTaskAvailability': true };
            }
        });
    }
    onOpenTaskEditPopupClick(template, obj) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.createTaskForm();
        this.cCurrLength = this.cCurrencyList.length;
        this.cEditCall = true;
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.cEditNewTaskAndItemsReq.itemName = obj.itemName;
        this.cEditNewTaskAndItemsReq.itemDescription = obj.itemDescription;
        this.cEditNewTaskAndItemsReq.itemUnitCost = obj.itemUnitCost;
        this.cEditNewTaskAndItemsReq.itemId = obj.itemId;
        this.clearArray();
        if (obj.itemCurrency != null && obj.itemCurrency != '') {
            this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, obj.itemCurrency, 'value'), 1);
            this.rates.push(this.createItem(obj.itemCurrency, obj.itemUnitCost));
            this.cRatesLength = this.rates.length;
        }
        else {
            this.rates.push(this.createItem('', ''));
            this.cRatesLength = 0;
        }
        this.cTaskModalRef = this.pModalService.show(template, { ignoreBackdropClick: true });
        if (this.cCurrencyList.length != 0)
            this.cCurrencyLeftFlag = true;
        else
            this.cCurrencyLeftFlag = false;
    }
    clearArray() {
        while (this.rates.length) {
            this.rates.removeAt(0);
        }
    }
    onUpdateTasksItemsClick(value) {
        if (this.mTaskForm.valid) {
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '' && c != '0') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            this.pTasksItemsService.updateInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cTaskModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mTaskForm);
        }
    }
};
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], EditInvoiceComponent.prototype, "onWindowScroll", null);
EditInvoiceComponent = tslib_1.__decorate([
    Component({
        selector: 'app-edit-invoice',
        templateUrl: './edit-invoice.component.html',
        styleUrls: ['./edit-invoice.component.css'],
        preserveWhitespaces: true,
        animations: [
            trigger('fadeInOut', [
                transition(':enter', [
                    style({ transform: 'translateY(-10%)' }),
                    animate('300ms ease-in', style({ transform: 'translateY(0%)' }))
                ]),
                transition(':leave', [
                    animate('300ms ease-in', style({ transform: 'translateY(-10%)' }))
                ])
            ])
        ]
    }),
    tslib_1.__param(6, Inject(DOCUMENT)),
    tslib_1.__param(7, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [InvoiceDataService,
        PrivilegeService,
        CustomerService,
        TransactionsService,
        ResponsiveService,
        Router,
        Document,
        Window,
        InvoiceService,
        TasksItemsService,
        TitleService,
        ApiRequestService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ActivatedRoute,
        Location,
        Router,
        ChangeDetectorRef,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        DatePipe])
], EditInvoiceComponent);
export { EditInvoiceComponent };
//# sourceMappingURL=edit-invoice.component.js.map