import { DatePipe } from '@angular/common';
export class Invoice {
    constructor() {
        this.selectedInvoice = [];
        this.isActiveForInvoiceDetail = false;
        this.isInvoiceDetailClick = false;
        this.isSearchPanelClick = false;
        this.isAllInvoiceCheck = false;
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.closeButton = false;
        this.isBulkInvoiceExcelUpload = false;
        this.constColumn = 0;
        //for pop up added these two
        this.regId = "";
        this.subAccId = "";
        this.MerchantUserId = "";
        this.SubAccId = "";
        this.status = [];
        this.constColumn = 0;
        this.customColumn = ['4', '5', '6', '7', '8', '9', '10', '11'];
        this.activeColumn = ['4', '5', '6', '7', '8', '9'];
        this.searchByLabel = 'Search By';
        this.calOptions = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme-link",
            showDropdowns: true,
            maxDate: new Date(),
            opens: 'left',
            dateLimit: {
                days: 30
            }
        };
        this.status.push({ label: 'Paid', value: 'Successful' });
        this.status.push({ label: 'Pending', value: 'Pending' });
        this.status.push({ label: 'Expired', value: 'Expired' });
        this.status.push({ label: 'Cancelled', value: 'Cancelled' });
        this.status.push({ label: 'Draft', value: 'Draft' });
        this.searchBy = [];
        this.searchBy.push({ label: 'Invoice #', value: 'searchByInvoiceNo' });
        this.searchBy.push({ label: 'Email ID', value: 'searchByEmail' });
        this.searchBy.push({ label: 'Mobile #', value: 'searchByMobile' });
        this.maxSearchDateTo = new Date();
        this.isAnyInvoiceCreate = true;
        var datePipe = new DatePipe('en-US');
        let startDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        let endDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.fromToDate = startDate + '-' + endDate;
    }
}
//# sourceMappingURL=invoice.class.js.map