export class ItemPriceRes {
    constructor() {
        this.currency = "";
    }
}
//# sourceMappingURL=itemPriceRes.res.js.map