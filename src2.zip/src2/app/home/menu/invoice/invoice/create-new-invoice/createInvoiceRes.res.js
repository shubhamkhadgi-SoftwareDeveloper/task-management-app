export class CreateInvoiceRes {
    constructor() {
        this.billId = null;
    }
}
//# sourceMappingURL=createInvoiceRes.res.js.map