export class CreateNewInvoiceReq {
    constructor() {
        this.customerName = "";
        this.invoiceCurrency = "";
        this.validitytype = "";
        this.merchantReferenceNo = "";
        this.merchantReferenceNo1 = "";
        this.emailAttachment = "N";
        this.emailAttachmentFileName = "";
        this.emailId = "";
        this.emailSubjectLine = "";
        this.customerMobileNumber = "";
        this.termsAndCondition = "";
        this.discountIf = "";
        this.lateFeeType = "";
        this.discountType = "";
        this.emailDesc = "";
        this.merchantUserId = "";
        this.regId = "";
        this.subAccId = "";
        this.smsContent = "";
        this.startDate = "";
        this.frequency = "";
        this.occurences = "";
        this.deliveryType = "";
        this.recurring = "";
        this.custName = "";
        this.custEmail = "";
        this.invoiceDescription = "";
        this.dueDate = "";
        this.invoiceType = 'SimpleInvoice';
        this.RadioCheckModel = 'FP';
        this.itemizedCheck = false;
    }
}
//# sourceMappingURL=createNewInvoiceReq.req.js.map