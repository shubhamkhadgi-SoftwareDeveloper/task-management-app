import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
import { Router } from '@angular/router';
import { InvoiceDataService } from '../InvoiceDataService';
import { InvoiceService } from './../invoice.service';
let CreateNewInvoiceResolverService = class CreateNewInvoiceResolverService {
    constructor(sInvoiceService, pMerchInfoService, sRouter, pInvoiceDataService) {
        this.sInvoiceService = sInvoiceService;
        this.pMerchInfoService = pMerchInfoService;
        this.sRouter = sRouter;
        this.pInvoiceDataService = pInvoiceDataService;
    }
    resolve(route, state) {
        console.log(this.pInvoiceDataService);
        if (!this.pInvoiceDataService.editRequest) {
            return this.sInvoiceService.fetchAllSettings(this.pInvoiceDataService).take(1).map(pCommonResponse => {
                if (pCommonResponse) {
                    return pCommonResponse;
                }
                else {
                    return null;
                }
            });
        }
        else {
            return this.sInvoiceService.editInvoice(this.pInvoiceDataService).take(1).map(pCommonResponse => {
                if (pCommonResponse) {
                    return pCommonResponse;
                }
                else {
                    return null;
                }
            });
        }
    }
};
CreateNewInvoiceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [InvoiceService,
        MerchInfoService,
        Router,
        InvoiceDataService])
], CreateNewInvoiceResolverService);
export { CreateNewInvoiceResolverService };
//# sourceMappingURL=create-new-invoice-resolver.service.js.map