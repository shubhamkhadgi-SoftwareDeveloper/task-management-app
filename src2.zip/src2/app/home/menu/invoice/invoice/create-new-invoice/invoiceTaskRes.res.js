export class InvoiceTaskRes {
}
//# sourceMappingURL=invoiceTaskRes.res.js.map