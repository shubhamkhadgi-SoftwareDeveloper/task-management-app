export class InvoiceTask {
}
//# sourceMappingURL=invoiceTask.js.map