import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef, Inject, HostListener } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CreateNewInvoice } from "./createNewInvoice.class";
import { CreateNewInvoiceReq } from "./createNewInvoiceReq.req";
import { ApiRequestService } from "../../../../../common-services/api-request.service";
import { MerchInfoService } from "../../../../../common-services/merch-info/merch-info.service";
import { BsModalService } from "ngx-bootstrap";
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BBValidator } from "./validated";
import { InvoiceTaskReq } from "./invoiceTaskReq.req";
import { InvoiceTaskRes } from "./invoiceTaskRes.res";
import { ActivatedRoute, Router } from '@angular/router';
import { ItemTaskList } from "./item-task-list.class";
import { CreateInvoiceRes } from "./createInvoiceRes.res";
import { CommonResponse, CustomResponseCode } from './../../../../../common-response/common-response.res';
import { Location, DOCUMENT } from '@angular/common';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { InvoiceSettingsReq } from '../../invoice-settings/invoiceSettings.req';
import { InvoiceService } from './../invoice.service';
import { trigger, transition, animate, style, } from '@angular/animations';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { WINDOW } from '../../../../../common-services/window.service';
import { Customer } from '../../../customer/customer.class';
import { AddNewCustomerDetailsReq } from 'app/home/menu/customer/AddNewCustomerDetailsReq';
import { CustomerSearchReq } from 'app/home/menu/customer/customer-search.req';
import { PrivilegeService } from 'app/common-services/privilege.service';
import { CustomerService } from 'app/home/menu/customer/customer.service';
import { TransactionsService } from 'app/home/menu/transactions/transactions/transactions.service';
import { ResponsiveService } from 'app/common-services/responsive.service';
import { InvoiceTaskAndItemsReq } from '../../../invoice/tasks-items/invoiceTaskAndItems.req';
import { EditNewTaskAndItemsReq } from '../../../invoice/tasks-items/editNewTaskAndItems.req';
import { TasksItemsService } from '../../../invoice/tasks-items/tasks-items.service';
import { InvoiceTaskAndItems } from '../../../invoice/tasks-items/tasks-items.class';
import { TitleService } from './../../../../../common-services/title.service';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { InvoiceDataService } from '../InvoiceDataService';
let CreateNewInvoiceComponent = class CreateNewInvoiceComponent {
    constructor(sPrivilegeService, sCustomerService, pInvoiceDataService, pTransactionsService, sResponsiveService, pRoute, document, window, sInvoiceService, pTasksItemsService, sTitleService, pApiRequestService, pMerchInfoService, pModalService, pFormBuilder, pActiveRouter, pLocation, pRouter, sRef, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, datepipe) {
        this.sPrivilegeService = sPrivilegeService;
        this.sCustomerService = sCustomerService;
        this.pInvoiceDataService = pInvoiceDataService;
        this.pTransactionsService = pTransactionsService;
        this.sResponsiveService = sResponsiveService;
        this.pRoute = pRoute;
        this.document = document;
        this.window = window;
        this.sInvoiceService = sInvoiceService;
        this.pTasksItemsService = pTasksItemsService;
        this.sTitleService = sTitleService;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.pActiveRouter = pActiveRouter;
        this.pLocation = pLocation;
        this.pRouter = pRouter;
        this.sRef = sRef;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.datepipe = datepipe;
        this.scrolling = false;
        this.cCustomerDataList = [];
        this.deliveryTypeNotSelected = false;
        this.customerDetailsNotSelected = false;
        this.showMinAmount = false;
        this.popUpCount = 0;
        this.checkErr = false;
        this.hideElemet1 = true;
        this.hideElemet2 = true;
        this.dateSelectionfailed = false;
        this.addTruee = true;
        this.removeTrue = false;
        this.cIsWritePrivilege = false;
        this.isItemizedInvoice = false;
        this.cSubAccountList = [];
        this.mySelectedTaskList = [];
        this.gokul = false;
        this.options = {
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            timePicker: false,
            singleDatePicker: true,
            showDropdowns: false,
            minDate: new Date()
        };
        this.itemAlreadyPresnt = false;
        this.newItemNameValid = false;
        this.newItemDescValid = false;
        this.itemNameArray = [];
        this.cIsTaskAndItemWritePrivilege = false;
        this.cCurrencyLeftFlag = false;
        this.cEditCall = false;
        this.cCurrencyIndex = 0;
        this.startdateSelectionfailed = false;
        this.sendviaEmpty = false;
        this.selectedItemName = '';
        this.isDraftReq = false;
        this.missingplaceholder = false;
        this.bothplaceholder1 = false;
        this.bothplaceholder3 = false;
        this.genClicked = false;
        //suhail code
        this.editClicked = false;
        this.arrowDown = true;
        this.dueOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            "applyClass": "btn-theme-link",
            minDate: new Date()
        };
        this.discountIfOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            minDate: new Date()
        };
        this.calOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: true,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            minDate: new Date()
        };
        this.calOptionsWithTime = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY hh:mm A' },
            alwaysShowCalendars: false,
            timePicker: true,
            timePicker24Hour: true,
            showDropdowns: true,
            singleDatePicker: true,
            opens: 'left',
            minDate: new Date(),
            "applyClass": "btn-theme-link",
        };
        this.events = [];
        this.ngSelectNames = false;
        //task items
        this.ngSelectTableRow1 = false;
        this.cars = [];
        this.selectedCars1 = [];
        this.merchantParams = [];
        this.count = 0;
        this.div3 = false;
        this.div4 = false;
        this.div5 = false;
        this.addMPTrue = true;
        this.itemInv = true;
        this.InvDesc = true;
        this.checked = true;
        this.tableRowArr = [''];
        this.create_cust_btn = true;
        this.add_shipping_btn = true;
        this.addLineArr = [''];
        this.selectedName = '';
        this.fileArr = [
            { id: 1, name: 'Upload File' },
            { id: 2, name: 'File URL' }
        ];
        this.selectArr = [
            { id: 'Flat', name: 'Flat' },
            { id: 'Perc', name: 'Percentage' }
        ];
        this.country = [
            { id: 1, name: 'India' },
            { id: 2, name: 'UAE' }
        ];
        this.currency = [
            { id: 0, name: 'Select' },
            { id: 1, name: 'INR' },
            { id: 2, name: 'USD' },
            { id: 3, name: 'GPB' },
            { id: 4, name: 'SGD' }
        ];
        this.type = [
            { id: 'PERCENTAGE', name: 'Perc' },
            { id: 'FLAT', name: 'Flat' }
        ];
        this.selectedPercentageId = this.type[0].id;
        this.selectedFileId = this.fileArr[0].id;
        this.dropdownSettings = {
            singleSelection: false,
            idField: 'id',
            textField: 'name',
            selectAllText: '',
            unSelectAllText: '',
            itemsShowLimit: 1,
            allowSearchFilter: false,
            limitSelection: 2
        };
        this.selectedItems = [];
        this.appendHTML = `<span class="fal fa-angle-down"></span>`;
        this.cCreateNewInvoice = new CreateNewInvoice();
        this.cCreateNewInvoiceReq = new CreateNewInvoiceReq();
        this.cInvoiceTaskReq = new InvoiceTaskReq();
        this.cInvoiceTaskRes = new InvoiceTaskRes();
        this.cItemTaskList = [];
        this.mEditData;
        this.cCreateInvoiceRes = new CreateInvoiceRes();
        this.cCreateNewInvoiceReq.recurring = 'N';
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
        this.popUpCount = 0;
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        // this.pInvoiceDataService=new InvoiceDataService();
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'YYYY-MM-DD' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            singleDatePicker: true,
            minDate: new Date(),
        };
        this.calOptions2 = {
            autoApply: true,
            autoUpdateInput: true,
            locale: { format: 'YYYY-MM-DD HH:mm a' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            timePicker: true,
            timePicker12Hour: true,
            minDate: new Date(),
            singleDatePicker: true
        };
        this.cCreateInvoiceRes = new CreateInvoiceRes();
        //CUSTOMER DATA
        this.cCountryList = [];
        this.customer = new Customer();
        this.cCountry = [];
        this.cCustomerSearchReq = new CustomerSearchReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.Invoice);
        //task and item
        this.cIsTaskAndItemWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.TasksItems);
        this.cTaskAndItemsReq = new InvoiceTaskAndItemsReq();
        this.cTaskAndItems = new InvoiceTaskAndItems();
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.sTitleService.setTitle(this.sTitleService.TasksItems);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    ngOnInit() {
        this.createForm();
        this.cCreateNewInvoiceReq.deliveryType = "";
        this.cCreateNewInvoiceReq.lateFeeType = null;
        this.cCreateNewInvoiceReq.discountType = null;
        this.cCreateNewInvoiceReq.deliveryType = "";
        this.cCreateNewInvoice.isCustomerSelection = false;
        //for reccuring
        if (this.pInvoiceDataService.isRecurring == 'Y')
            this.cCreateNewInvoiceReq.recurring = this.pInvoiceDataService.isRecurring;
        this.cCreateNewInvoice.invCur = this.pMerchInfoService.getCurrencyList();
        if (this.cCreateNewInvoice.invCur != null && this.cCreateNewInvoice.invCur.length > 0) {
            this.cCreateNewInvoice.invCurLabel = this.cCreateNewInvoice.invCur[0].label;
            this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
            this.selectedCurrency = this.cCreateNewInvoice.invCur[0].label;
        }
        if (this.cCreateNewInvoice.frequencyOptions != null && this.cCreateNewInvoice.frequencyOptions.length > 0) {
            this.cCreateNewInvoice.invOccLabel = this.cCreateNewInvoice.frequencyOptions[0].label;
            this.cCreateNewInvoiceReq.frequency = this.cCreateNewInvoice.frequencyOptions[0].value;
        }
        this.cCreateNewInvoiceReq.frequency = this.cCreateNewInvoice.frequencyOptions[0].value;
        this.viewInvDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy hh:mm a');
        this.cCreateNewInvoiceReq.invoiceDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy HH:mm');
        this.cCreateNewInvoiceReq.startDate = this.datepipe.transform(new Date(), 'dd/MM/yyyy');
        this.invoiceDateCal = new Date();
        this.cCreateNewInvoiceReq.expiryDate = '';
        this.viewExpDate = '';
        this.expiryDateCal = new Date();
        this.cCreateNewInvoiceReq.dueDate = '';
        this.cCreateNewInvoiceReq.discountIf = '';
        let dataRetrieved;
        this.pActiveRouter.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            this.cCustomerList = mCommonResponse.data['customerList'];
            this.cCustomerListEdit = mCommonResponse.data['customerList'];
            this.cCreateNewInvoiceReq.invoiceNo = mCommonResponse.data['InvoiceId'];
            this.cCreateNewInvoice.gatewayData = mCommonResponse.data['GatewaySettingData'];
            dataRetrieved = data.commonResponse.data;
            this.cCreateNewInvoice.invoiceSettingsList = this.setInvoiceSetting(data.commonResponse.data);
            this.cCreateNewInvoiceReq.subAccId = mCommonResponse.data['subAcId'];
            this.cCreateNewInvoiceReq.regId = mCommonResponse.data['RegId'];
            this.cRegistrationEntity = mCommonResponse.data['AccountInfo'].data.regData;
            if (this.pInvoiceDataService.editRequest) {
                this.editClicked = true;
                this.arrowDown = false;
                this.mEditData = mCommonResponse.data['editData'].data;
                console.log(this.mEditData);
                this.cCreateNewInvoiceReq.custId = String(this.mEditData.invoiceDetailsRS2ProcEntity.billCustId);
                this.onCustomerSelectionClick(this.cCreateNewInvoiceReq.custId);
                this.cCreateNewInvoiceReq.invoiceNo = String(this.mEditData.invoiceDetailsRS2ProcEntity.billId);
                this.viewExpDate = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billExpDatetime, 'dd/MM/yyyy hh:mm a');
                this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billExpDatetime, 'dd/MM/yyyy HH:mm');
                this.viewInvDate = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billDate, 'dd/MM/yyyy hh:mm a');
                this.cCreateNewInvoiceReq.invoiceDate = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billDate, 'dd/MM/yyyy HH:mm');
                this.invoiceDateCal = new Date(this.mEditData.invoiceDetailsRS2ProcEntity.billDate);
                this.expiryDateCal = new Date(this.mEditData.invoiceDetailsRS2ProcEntity.billExpDatetime);
                this.dueDateCal = new Date(this.mEditData.invoiceDetailsRS2ProcEntity.billDueDatetime);
                this.cCreateNewInvoiceReq.dueDate = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billDueDatetime, 'dd/MM/yyyy');
                this.cCreateNewInvoiceReq.discountIf = this.datepipe.transform(this.mEditData.invoiceDetailsRS2ProcEntity.billDiscDatetime, 'dd/MM/yyyy');
                this.cCreateNewInvoiceReq.invoiceAmount = Number(this.mEditData.invoiceDetailsRS2ProcEntity.billAmount);
                this.cCreateNewInvoiceReq.termsAndCondition = this.mEditData.invoiceDetailsRS2ProcEntity.billTermsCondition;
                this.cCreateNewInvoiceReq.subAccId = this.mEditData.invoiceDetailsRS2ProcEntity.subAccId;
                this.cCreateNewInvoiceReq.validitytype = this.mEditData.invoiceDetailsRS2ProcEntity.billValidityType;
                this.cCreateNewInvoiceReq.invoiceValidFor = Number(this.mEditData.invoiceDetailsRS2ProcEntity.billValidFor);
                this.cCreateNewInvoiceReq.invoiceCurrency = this.mEditData.invoiceDetailsRS2ProcEntity.billCurrId;
                this.cCreateNewInvoiceReq.emailSubjectLine = this.mEditData.invoiceDetailsRS2ProcEntity.billEmailSubject;
                this.cCreateNewInvoiceReq.invoiceDescription = this.mEditData.invoiceDetailsRS2ProcEntity.billEmailDesc;
                this.cCreateNewInvoiceReq.emailAttachment = this.mEditData.invoiceDetailsRS2ProcEntity.billEmailAttachment;
                this.cCreateNewInvoiceReq.lateFee = this.mEditData.invoiceDetailsRS2ProcEntity.billLateFee;
                this.cCreateNewInvoiceReq.lateFeeType = this.mEditData.invoiceDetailsRS2ProcEntity.billLateFeeType;
                this.cCreateNewInvoiceReq.discountType = this.mEditData.invoiceDetailsRS2ProcEntity.billDiscountType;
                this.cCreateNewInvoiceReq.discount = this.mEditData.invoiceDetailsRS2ProcEntity.billDiscount;
                if (this.cCreateNewInvoiceReq.discountType)
                    this.mForm.controls['DiscountType'].setValue(this.cCreateNewInvoiceReq.discountType);
                if (this.cCreateNewInvoiceReq.lateFeeType)
                    this.mForm.controls['LateFeeType'].setValue(this.cCreateNewInvoiceReq.lateFeeType);
                this.cCreateNewInvoiceReq.custMobileNo = this.sCheck.isNotNullString(this.mEditData.invoiceDetailsRS2ProcEntity.billCustomerMobile) ? this.mEditData.invoiceDetailsRS2ProcEntity.billCustomerMobile : null;
                this.cCreateNewInvoiceReq.custEmail = this.sCheck.isNotNullString(this.mEditData.invoiceDetailsRS2ProcEntity.billCustomerEmail) ? this.mEditData.invoiceDetailsRS2ProcEntity.billCustomerEmail : null;
                if (this.mEditData.deliveryType == "BOTH" || this.mEditData.deliveryType == "EMAIL") {
                    this.onDeliveryTypeChangeEmail(true);
                    this.cCreateNewInvoice.showhidmail = true;
                }
                if (this.mEditData.deliveryType == "BOTH" || this.mEditData.deliveryType == "SMS") {
                    this.onDeliveryTypeChangeSms(true);
                    this.cCreateNewInvoice.showhidsms = true;
                }
                if (this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y' && this.sCheck.isNotNullNumber(this.mEditData.invoiceDetailsRS2ProcEntity.billMinAmt))
                    this.onPaymentWayClick('PP');
            }
            this.createForm();
            this.setAliasAndInvoiceSetting(dataRetrieved);
            if (this.sCheck.isNotNullList(this.cCustomerList)) {
                for (let pcustomerList of this.cCustomerList) {
                    this.cCustomerDataList.push({ label: pcustomerList.custName, value: pcustomerList.custId.toString() });
                }
            }
            if (!(this.cCreateNewInvoice.invoiceSettingsList.settingInvQuick == 'Y' && this.cCreateNewInvoice.invoiceSettingsList.settingInvNew == 'Y')) {
                if (this.cCreateNewInvoice.invoiceSettingsList.settingInvQuick == 'Y') {
                    this.cCreateNewInvoice.itemInv = false;
                    this.cCreateNewInvoice.simpInv = true;
                    this.cCreateNewInvoice.InvDesc = true;
                    this.cCreateNewInvoice.table = false;
                    this.cCreateNewInvoiceReq.invoiceType = "SimpleInvoice";
                    this.createSimpleInvoice();
                }
                else if (this.cCreateNewInvoice.invoiceSettingsList.settingInvNew == 'Y') {
                    this.fetchTask(this.cCreateNewInvoiceReq.regId);
                    this.cCreateNewInvoice.itemInv = true;
                    this.cCreateNewInvoice.simpInv = false;
                    this.cCreateNewInvoice.InvDesc = false;
                    this.cCreateNewInvoice.table = true;
                    this.cCreateNewInvoiceReq.invoiceType = "ItemizedInvoice";
                    this.createItemizedInvoice();
                }
            }
            else {
                this.cCreateNewInvoice.itemInv = false;
                this.cCreateNewInvoice.simpInv = true;
                this.cCreateNewInvoice.InvDesc = true;
                this.cCreateNewInvoice.table = false;
                this.cCreateNewInvoiceReq.invoiceType = "SimpleInvoice";
                this.createSimpleInvoice();
            }
            this.cCreateNewInvoice.settingWebstoreName = this.cCreateNewInvoice.gatewayData.settingWebstoreName;
            this.cCreateNewInvoice.settingLogoLocation = this.cCreateNewInvoice.gatewayData.settingLogoLocation;
            this.cCreateNewInvoice.regGstNo = this.cRegistrationEntity.regGstNo;
        });
        this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
        this.mForm.controls['LateFee'].disable();
        this.mForm.controls['LateFeeType'].disable();
        this.mForm.controls['Discount'].disable();
        this.mForm.controls['DiscountIf'].disable();
        this.mForm.controls['DiscountType'].disable();
        // this.mForm.controls['dueDate'].disable();
        this.mForm.controls['Occurences'].disable();
        this.mForm.controls['StartDate'].disable();
        this.mForm.controls['ValidFor'].disable();
        this.mForm.controls['Frequency'].disable();
        this.mForm.controls['InvValidityType'].disable();
        //  this.mForm.controls['invoiceDate'].disable();
        this.setExpiryDate();
        if (this.cCreateNewInvoiceReq.recurring == 'Y') {
            this.mForm.controls['dueDate'].disable();
            this.mForm.controls['expiryDate'].disable();
            this.mForm.controls['Occurences'].enable();
            this.mForm.controls['StartDate'].enable();
            this.mForm.controls['ValidFor'].enable();
            this.mForm.controls['Frequency'].enable();
            this.mForm.controls['invoiceDate'].enable();
            this.mForm.controls['InvValidityType'].enable();
        }
        this.fetchCountryList();
    }
    editTableArrayFunc(itemData) {
        //const tableFormArrs = new FormArray([]);
        // console.log("cItemTaskList ::", this.cItemTaskList);
        this.cCreateNewInvoice.totalAmt = 0;
        this.cCreateNewInvoiceReq.invoiceAmount = 0;
        this.cCreateNewInvoice.subTotalTaxAmt = 0;
        itemData.forEach(item => {
            this.Taskitem.push(this.pFormBuilder.group({
                itemId: '',
                itemName: item.itemName,
                itemCurrency: item.billCurrId,
                itemDescription: item.itemDescription,
                itemUnitCost: item.itemUnitCost,
                itemQty: item.itemQty,
                itemTax1: item.itemTax1 != null ? item.itemTax1 : undefined,
                itemTax1Value: item.itemTax1Value != null ? item.itemTax1Value : undefined,
                itemTax2: item.itemTax2 != null ? item.itemTax2 : undefined,
                itemTax2Value: item.itemTax2Value != null ? item.itemTax2Value : undefined,
                lineTotal: item.lineTotal != null ? item.lineTotal : undefined,
                itemTax: [[{ id: item.itemTax1Value, name: item.itemTax1 }, { id: item.itemTax2Value, name: item.itemTax2 }]],
                taxCal1: item.itemTax1Value != null && item.lineTotal != null ? (item.lineTotal) * (parseFloat(String(item.itemTax1Value)) / 100) : undefined,
                taxCal2: item.itemTax2Value != null && item.lineTotal != null ? (item.lineTotal) * (parseFloat(String(item.itemTax2Value)) / 100) : undefined,
                subTotal: 0,
                totalTax: 0,
                finalInvoiceAmount: '',
                txCalculation: 0,
                arrowDown2: false,
                editClicked2: true,
            }));
        });
        for (var i = 0; i < this.Taskitem.controls.length; i++) {
            //filter null tax values from tax array
            // this.Taskitem.controls[i].value.itemTax= this.Taskitem.controls[i].value.itemTax.filter(p=>p.id=null);
            if (this.sCheck.isNullString(this.Taskitem.controls[i].value.itemTax1) && this.sCheck.isNullString(this.Taskitem.controls[i].value.itemTax2)) {
                this.Taskitem.controls[i].patchValue({
                    itemTax: null
                });
            }
            // if ((this.sCheck.isNullString(this.Taskitem.controls[i].value.itemTax1) ) && (this.sCheck.isNotNullString(this.Taskitem.controls[i].value.itemTax2) )  ){
            //     this.Taskitem.controls[i].patchValue(    
            //         {    itemTax :[[{ id:  this.Taskitem.controls[i].value.itemTax2Value, name:  this.Taskitem.controls[i].value.itemTax2 }]]
            //         });
            // }
            // if ((this.sCheck.isNullString(this.Taskitem.controls[i].value.itemTax2)) && (this.sCheck.isNotNullString(this.Taskitem.controls[i].value.itemTax1) ) ) {
            //     this.Taskitem.controls[i].patchValue(    
            //         {    itemTax :[[{ id:  this.Taskitem.controls[i].value.itemTax1Value, name:  this.Taskitem.controls[i].value.itemTax1 }]]
            //         });
            // }
            if (typeof this.Taskitem.controls[i].value.taxCal1 == 'undefined') {
                this.Taskitem.controls[i].patchValue({
                    taxCal1: 0
                });
            }
            if (typeof this.Taskitem.controls[i].value.taxCal2 == 'undefined') {
                this.Taskitem.controls[i].patchValue({ taxCal2: 0 });
            }
            var line = this.Taskitem.controls[i].value.lineTotal;
            if (typeof line == 'undefined') {
                line = 0;
            }
            this.cCreateNewInvoice.subTotalAmt = this.cCreateNewInvoice.subTotalAmt + line;
            var txCaltotal = this.Taskitem.controls[i].value.taxCal1 + this.Taskitem.controls[i].value.taxCal2;
            if (typeof txCaltotal == 'undefined') {
                txCaltotal = 0;
            }
            this.Taskitem.controls[i].patchValue({ txCalculation: txCaltotal });
            if (typeof this.Taskitem.controls[i].value.txCalculation == 'undefined') {
                this.Taskitem.controls[i].patchValue({ txCalculation: 0 });
            }
            else {
            }
            this.cCreateNewInvoice.subTotalTaxAmt = this.cCreateNewInvoice.subTotalTaxAmt + Number(txCaltotal);
            this.cCreateNewInvoiceReq.invoiceAmount = Number(this.cCreateNewInvoice.subTotalAmt) + Number(this.cCreateNewInvoice.subTotalTaxAmt);
            this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoiceReq.invoiceAmount;
            this.invoiceAmountChange();
        }
        console.log("For tax : ", this.Taskitem);
        return this.Taskitem;
    }
    ;
    //end: suhail
    isReccuring() {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            this.cCreateNewInvoiceReq.recurring = 'Y';
            this.mForm.controls['dueDate'].disable();
            this.mForm.controls['expiryDate'].disable();
            this.mForm.controls['Occurences'].enable();
            this.mForm.controls['StartDate'].enable();
            this.mForm.controls['ValidFor'].enable();
            this.mForm.controls['Frequency'].enable();
            this.mForm.controls['invoiceDate'].enable();
            this.mForm.controls['InvValidityType'].enable();
        }
        else {
            this.cCreateNewInvoiceReq.recurring = 'N';
            this.mForm.controls['dueDate'].enable();
            this.mForm.controls['expiryDate'].enable();
            this.mForm.controls['Occurences'].disable();
            this.mForm.controls['StartDate'].disable();
            this.mForm.controls['ValidFor'].disable();
            this.mForm.controls['Frequency'].disable();
            this.mForm.controls['invoiceDate'].disable();
            this.mForm.controls['InvValidityType'].disable();
        }
    }
    compareReccStartAndExpDate(invoiceStartDate, invoiceDateCal, expiryDateCal) {
        if (invoiceDateCal.getDate() == new Date().getDate() && (invoiceStartDate <= expiryDateCal)) {
            this.startdateSelectionfailed = false;
        }
        else {
            this.startdateSelectionfailed = true;
        }
    }
    onDeliveryTypeChangeEmail(event) {
        if (event) {
            this.cCreateNewInvoice.deliveryCheckEmail = true;
            this.sendviaEmpty = false;
            this.cCreateNewInvoiceReq.emailSubjectLine = this.pInvoiceDataService.editRequest ? this.mEditData.billEmailSubject : this.cCreateNewInvoice.invoiceSettingsList.settingInvSubject;
            if (this.cCreateNewInvoice.invoiceSettingsList.settingInvSubjectEdit == 'Y')
                this.mForm.controls['emailSubjectLine'].setValidators([Validators.required, Validators.maxLength(100), BBValidator.emailSub, BBValidator.isBeginSpecialChar, BBValidator.isEndSpecialChar, BBValidator.isConsecuSpecialChar, BBValidator.isBlankSpace]);
            else
                this.mForm.controls['emailSubjectLine'].disable();
            this.mForm.controls['emailSubjectLine'].markAsDirty();
            this.deliveryTypeNotSelected = false;
        }
        else {
            this.cCreateNewInvoice.deliveryCheckEmail = false;
            this.mForm.controls['emailSubjectLine'].clearValidators();
            this.mForm.controls['emailSubjectLine'].setValidators([]);
            this.mForm.controls['emailSubjectLine'].setValue("");
            this.mForm.controls['invoiceDescription'].setValue("");
        }
    }
    onDeliveryTypeChangeSms(event) {
        if (event) {
            this.sendviaEmpty = false;
            this.cCreateNewInvoiceReq.smsContent = this.pInvoiceDataService.editRequest ? this.mEditData.invoiceDetailsRS2ProcEntity.settingInvMsg : this.cCreateNewInvoice.invoiceSettingsList.settingInvSMSContent;
            if (this.cCreateNewInvoice.invoiceSettingsList.settingInvSMSEdit == 'N') {
                this.mForm.controls['smsContent'].disable();
            }
            else {
                this.mForm.controls['smsContent'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForSMS,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.smsContent,
                    BBValidator.isBlankSpace]);
            }
            this.cCreateNewInvoice.deliveryCheckSms = true;
            this.mForm.controls['showhidsms'].setValue(true);
            this.deliveryTypeNotSelected = false;
        }
        else {
            this.mForm.controls['showhidsms'].setValue(false);
            this.cCreateNewInvoice.deliveryCheckSms = false;
            this.mForm.controls['smsContent'].setValidators([]);
            this.mForm.controls['smsContent'].updateValueAndValidity();
        }
    }
    //used to fetch
    fetchTask(regId) {
        this.sInvoiceService.fetchTask(regId)
            .subscribe(rResponse => this.fetchAllTaskSuccess(rResponse), error => { console.log('error'); });
    }
    fetchAllTaskSuccess(pResponse) {
        this.cCreateNewInvoice.taskOption = [];
        this.cCreateNewInvoice.taxOption = [];
        this.cItemTaskList = [];
        // Dropdown Logic For Task
        this.cInvoiceTaskRes.invoiceTaskList = pResponse['invoiceTaskList'];
        this.invoiceMainTaskList = this.cInvoiceTaskRes.invoiceTaskList;
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            this.itemName = this.cInvoiceTaskRes.invoiceTaskList[i].itemName;
            if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null && this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length > 0) {
                for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                    this.invoiceCurrency = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency;
                    this.price = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price;
                    this.itemInvDescription = this.cInvoiceTaskRes.invoiceTaskList[i].itemDescription;
                    this.itemId = this.cInvoiceTaskRes.invoiceTaskList[i].itemId;
                    let itemObj = new ItemTaskList();
                    itemObj.itemCurrency = this.invoiceCurrency;
                    itemObj.itemUnitCost = this.price;
                    itemObj.itemName = this.itemName;
                    itemObj.itemDescription = this.itemInvDescription;
                    itemObj.itemId = this.itemId;
                    itemObj.taskListLabel = this.itemName + " ddd - ( " + this.invoiceCurrency + " - " + this.price + " )";
                    this.cItemTaskList.push(itemObj);
                }
            }
        }
        // DropDown Logic for Tax
        this.cInvoiceTaskRes.taxList = pResponse['taxList'];
        for (var i = 0; i < this.cInvoiceTaskRes.taxList.length; i++) {
            //this.cCreateNewInvoice.taxOption.push({ label: this.cInvoiceTaskRes.taxList[i].taxName, value: this.cInvoiceTaskRes.taxList[i].taxName });
            this.cCreateNewInvoice.taxOption.push({ label: this.cInvoiceTaskRes.taxList[i].taxName, value: { id: this.cInvoiceTaskRes.taxList[i].taxRateIndia, name: this.cInvoiceTaskRes.taxList[i].taxName } });
        }
    }
    UnitCostChange(event, i) {
        console.log("event::", this.Taskitem.controls[i].value);
        console.log("index::", i);
        if (this.Taskitem.controls[i].value.itemUnitCost > 0) {
            this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
            if (typeof this.Taskitem.controls[i].value.itemQty != 'undefined' && this.Taskitem.controls[i].value.itemQty != null) {
                if (this.Taskitem.controls[i].value.itemUnitCost != null && this.Taskitem.controls[i].value.itemUnitCost != 0) {
                    this.Taskitem.controls[i].patchValue({ lineTotal: (this.Taskitem.controls[i].value.itemUnitCost * this.Taskitem.controls[i].value.itemQty) });
                }
            }
            else {
                this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
            }
        }
        else {
            this.Taskitem.controls[i].patchValue({ itemUnitCost: 0, lineTotal: 0 });
        }
        this.onSelectTax(i);
        console.log("event::", this.Taskitem.controls[i].value);
    }
    QuantityChange(event, i) {
        this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
        if (this.Taskitem.controls[i].value.itemQty > 0) {
            if (this.Taskitem.controls[i].value.itemUnitCost != null && this.Taskitem.controls[i].value.itemUnitCost != undefined) {
                if (typeof this.Taskitem.controls[i].value.itemUnitCost == 'undefined') {
                    this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
                }
                else {
                    this.Taskitem.controls[i].patchValue({ lineTotal: (this.Taskitem.controls[i].value.itemUnitCost * this.Taskitem.controls[i].value.itemQty) });
                }
            }
            else {
                //  this.Taskitem.controls[i].patchValue({itemQty:0,lineTotal: 0});
                this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
            }
        }
        else {
            // this.Taskitem.controls[i].patchValue({itemQty:0,lineTotal: 0});
            this.Taskitem.controls[i].patchValue({ lineTotal: 0 });
        }
        this.onSelectTax(i);
    }
    enableItemList(itemnumber) {
        itemnumber.controls['itemTax'].enable();
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            /* minAmount:[''],*/
            custId: ['', [Validators.required]],
            invoiceNo: [''],
            invoiceDate: [''],
            dueDate: [''],
            Discount: [''],
            DiscountType: [null, Validators.required],
            DiscountIf: [''],
            expiryDate: [''],
            invoiceDescription: [''],
            invoiceAmount: ['', [Validators.required,
                    Validators.minLength(1), Validators.max(999999999.99),
                    BBValidator.amount,
                    BBValidator.nonZeroAmount
                ]],
            invoiceCurrency: [''],
            showhidmail: [''],
            showhidsms: [''],
            RadioCheck: [''],
            termsAndCondition: ['', BBValidator.termsConditionInv],
            customerList: [''],
            MerchantReferenceNo: ['', [
                    BBValidator.invoiceMerRefNum,
                    Validators.minLength(3),
                    Validators.maxLength(50),
                ]],
            MerchantReferenceNo1: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo2: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo3: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            MerchantReferenceNo4: ['', [
                    Validators.minLength(3),
                    Validators.maxLength(50),
                    BBValidator.invoiceMerRefNum
                ]],
            aliasRefNo1: [''],
            aliasRefNo: [''],
            minAmount: [''],
            smsContent: [''],
            emailSubjectLine: [''],
            dynamicEventArray: this.pFormBuilder.array([]),
            Taskitem: this.buildArray(),
            merchantParamsitem1: this.buildMercahntParamsArray1(),
            LateFee: [''],
            LateFeeType: [null, Validators.required],
            Frequency: ['', Validators.required],
            Occurences: ['', Validators.required],
            StartDate: ['', Validators.required],
            ValidFor: [''],
            dueUpto: [''],
            InvValidityType: [null, Validators.required]
        });
    }
    buildMercahntParamsArray1() {
        this.merchantParamsitem1 = this.pFormBuilder.array([
            this.buildGroup1()
        ]);
        this.merchantParamsitem1.removeAt(0);
        return this.merchantParamsitem1;
    }
    //this.merchantParamsitem.push( this.buildParamsGroup() );
    buildGroup1() {
        let aliasRefNoVal;
        let aliasRefIndex;
        let isAliasMerRefNoNull;
        let isFound = true;
        if (typeof this.merchantParamsitem1 == 'undefined') {
            //aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo;
            return this.pFormBuilder.group({
                aliasRefNo: [''],
                merchantReferenceNo: [''],
                index: ['']
            });
        }
        else if (typeof this.merchantParamsitem1 == 'object') {
            for (let i = 1; i <= 6; i++) {
                if (isFound && this.mForm.value.merchantParamsitem1.length > 0) {
                    for (let j = 0; j < this.mForm.value.merchantParamsitem1.length; j++) {
                        if (this.mForm.value.merchantParamsitem1[j].index === i) {
                            isFound = true;
                            break;
                        }
                        else {
                            isFound = false;
                        }
                    }
                }
                else {
                    aliasRefIndex = i - 1;
                    if (aliasRefIndex == 1) {
                        if (this.cCreateNewInvoice.aliasRefNo) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'Merchant Reference #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 2) {
                        if (this.cCreateNewInvoice.aliasRefNo1) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasRefNo1;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'Merchant Reference #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 3) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo2) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo2;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'Merchant Reference #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 4) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo3) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo3;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'Merchant Reference #' + aliasRefIndex;
                            break;
                        }
                    }
                    else if (aliasRefIndex == 5) {
                        if (this.cCreateNewInvoice.aliasList.aliasMerRefNo4) {
                            aliasRefNoVal = this.cCreateNewInvoice.aliasList.aliasMerRefNo4;
                            break;
                        }
                        else {
                            aliasRefNoVal = 'Merchant Reference #' + aliasRefIndex;
                            break;
                        }
                    }
                }
            }
        }
        return this.pFormBuilder.group({
            aliasRefNo: aliasRefNoVal,
            merchantReferenceNo: [''],
            index: aliasRefIndex
        });
    }
    buildArray() {
        this.Taskitem = this.pFormBuilder.array([
            this.buildGroup()
        ]);
        return this.Taskitem;
    }
    pushParams(aliasRefNo, merchantReferenceNo, indexNo) {
        return this.pFormBuilder.group({
            aliasRefNo: [aliasRefNo],
            merchantReferenceNo: [merchantReferenceNo],
            index: [indexNo]
        });
    }
    buildGroup() {
        return this.pFormBuilder.group({
            itemId: [''],
            itemName: [null],
            itemCurrency: [''],
            itemDescription: ['', [
                    BBValidator.itemDesc
                ]],
            itemUnitCost: ['', [
                    Validators.required,
                    Validators.minLength(1),
                    Validators.maxLength(999999999.99),
                    BBValidator.amount
                ]],
            itemQty: ['', [
                    Validators.required,
                    Validators.maxLength(6),
                    BBValidator.nonZeroQuantity
                ]],
            itemTax1: '',
            itemTax1Value: '',
            itemTax2: '',
            itemTax2Value: '',
            lineTotal: '',
            itemTax: [],
            taxCal1: 0,
            taxCal2: 0,
            subTotal: 0,
            totalTax: 0,
            finalInvoiceAmount: '',
            txCalculation: 0,
            editClicked2: false,
            arrowDown2: true
        });
    }
    onSelectByOptionClick(pOption) {
        this.cCreateNewInvoice.isCheckInvCur = !this.cCreateNewInvoice.isCheckInvCur;
        this.cCreateNewInvoice.invCurLabel = pOption.label;
        this.cCreateNewInvoice.invoiceCurrency = pOption.value;
    }
    disableItemList(event, itemnumber) {
        let taxArray = event.value;
        if (taxArray.length > 2) {
            let seltax = itemnumber.controls['itemTax'].value;
            seltax.splice(2, taxArray.length);
        }
    }
    onSelectByOptionOccuClick(event) {
        this.cCreateNewInvoice.invOccLabel = event.label;
        this.cCreateNewInvoiceReq.frequency = event.value;
    }
    onSelectTax(i) {
        console.log("itemTax :: ", this.mForm.get("Taskitem"));
        //itemnumber.lineTotal = 0;
        if (this.Taskitem.controls[i].value.itemQty >= 0 && this.Taskitem.controls[i].value.itemTax) {
            let taxArray = this.Taskitem.controls[i].value.itemTax;
            if (taxArray.length > 0 && taxArray.length < 3) {
                if (taxArray.length == 1) {
                    this.Taskitem.controls[i].patchValue({
                        itemTax1Value: taxArray[0].id,
                        itemTax1: taxArray[0].name,
                        taxCal1: (this.Taskitem.controls[i].value.lineTotal) * (parseFloat(this.Taskitem.controls[i].value.itemTax[0].id) / 100),
                        itemTax2Value: undefined,
                        itemTax2: undefined,
                        taxCal2: undefined
                    });
                    this.Taskitem.controls[i].patchValue({
                        txCalculation: this.Taskitem.controls[i].value.taxCal1
                    });
                }
                if (taxArray.length == 2) {
                    this.Taskitem.controls[i].patchValue({
                        itemTax2Value: taxArray[1].id,
                        itemTax2: taxArray[1].name,
                        taxCal2: (this.Taskitem.controls[i].value.lineTotal) * (parseFloat(this.Taskitem.controls[i].value.itemTax[1].id) / 100)
                    });
                    this.Taskitem.controls[i].patchValue({
                        txCalculation: Number(this.Taskitem.controls[i].value.taxCal1) + Number(this.Taskitem.controls[i].value.taxCal2)
                    });
                }
            }
            else if (taxArray.length > 2) {
                this.Taskitem.controls[i].patchValue({
                    taxCal2: 0,
                    taxCal1: 0,
                    itemTax: [],
                    txCalculation: 0
                });
                this.sAlertMessageService.popupAlertMsg("Please select only 2 taxes");
            }
            else {
                if (taxArray.length == 0) {
                    this.Taskitem.controls[i].patchValue({
                        taxCal2: 0,
                        taxCal1: 0,
                        txCalculation: 0
                    });
                }
                if (this.Taskitem.controls[i].value.itemQty == undefined) {
                    this.Taskitem.controls[i].patchValue({
                        taxCal2: 0,
                        taxCal1: 0,
                        lineTotal: 0
                    });
                }
                else {
                    this.Taskitem.controls[i].patchValue({
                        lineTotal: (this.Taskitem.controls[i].value.itemUnitCost * this.Taskitem.controls[i].value.itemQty)
                    });
                }
            }
        }
        this.valuechange(i);
    }
    valuechange(j) {
        this.cCreateNewInvoice.subTotalAmt = 0;
        this.cCreateNewInvoice.subTotalTaxAmt = 0;
        for (var i = 0; i < this.Taskitem.controls.length; i++) {
            if (typeof this.Taskitem.controls[j].value.taxCal1 == 'undefined') {
                this.Taskitem.controls[j].patchValue({
                    taxCal1: 0
                });
            }
            if (typeof this.Taskitem.controls[j].value.taxCal2 == 'undefined') {
                this.Taskitem.controls[j].patchValue({ taxCal2: 0 });
            }
            var line = this.Taskitem.controls[i].value.lineTotal;
            if (typeof line == 'undefined') {
                line = 0;
            }
            this.cCreateNewInvoice.subTotalAmt = this.cCreateNewInvoice.subTotalAmt + line;
            var txCalculation = this.Taskitem.controls[i].value.txCalculation;
            if (typeof txCalculation == 'undefined') {
                txCalculation = 0;
            }
            if (typeof this.Taskitem.controls[j].value.txCalculation == 'undefined') {
                this.Taskitem.controls[j].patchValue({ txCalculation: 0 });
            }
            else {
            }
            this.cCreateNewInvoice.subTotalTaxAmt = this.cCreateNewInvoice.subTotalTaxAmt + Number(txCalculation);
            this.cCreateNewInvoiceReq.invoiceAmount = Number(this.cCreateNewInvoice.subTotalAmt) + Number(this.cCreateNewInvoice.subTotalTaxAmt);
            this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoiceReq.invoiceAmount;
            this.invoiceAmountChange();
        }
    }
    invoiceAmountChange() {
        this.mForm.controls['minAmount'].setValue('');
        this.cCreateNewInvoice.invalidMinAmount = false;
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Flat') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['LateFee'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
        }
        if (this.cCreateNewInvoiceReq.discountType == 'Flat') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['Discount'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
        }
    }
    onSelectByOptionLatePayment(event) {
        this.cCreateNewInvoice.lateLabel = event.name;
        this.cCreateNewInvoiceReq.lateFeeType = event.id;
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Perc') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = '%';
            this.mForm.controls['LateFee'].setValidators([BBValidator.percentages, Validators.required]);
            this.mForm.controls['LateFee'].updateValueAndValidity();
        }
        if (this.cCreateNewInvoiceReq.lateFeeType == 'Flat') {
            this.mForm.controls['LateFee'].setValue('');
            this.cCreateNewInvoice.lateFeeKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['LateFee'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
            this.mForm.controls['LateFee'].updateValueAndValidity();
        }
    }
    onSelectCurrency() {
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        this.fetchSimilarTask(this.pInvoiceDataService.regId);
    }
    fetchSimilarTask(regId) {
        this.sInvoiceService.fetchTask(regId)
            .subscribe(rResponse => this.fetchSimilarTaskSuccess(rResponse), error => { console.log('error'); });
    }
    fetchSimilarTaskSuccess(pResponse) {
        this.cCreateNewInvoice.taskOption = [];
        this.cCreateNewInvoice.taxOption = [];
        this.cItemTaskList = [];
        // Dropdown Logic For Task
        this.cInvoiceTaskRes.invoiceTaskList = pResponse['invoiceTaskList'];
        this.invoiceMainTaskList = this.cInvoiceTaskRes.invoiceTaskList;
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            this.itemName = this.cInvoiceTaskRes.invoiceTaskList[i].itemName;
            if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null && this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length > 0) {
                for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                    this.invoiceCurrency = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency;
                    if (this.invoiceCurrency == this.cCreateNewInvoiceReq.invoiceCurrency) {
                        this.price = this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price;
                        this.itemInvDescription = this.cInvoiceTaskRes.invoiceTaskList[i].itemDescription;
                        this.itemId = this.cInvoiceTaskRes.invoiceTaskList[i].itemId;
                        let itemObj = new ItemTaskList();
                        itemObj.itemCurrency = this.invoiceCurrency;
                        itemObj.itemUnitCost = this.price;
                        itemObj.itemName = this.itemName;
                        itemObj.itemDescription = this.itemInvDescription;
                        itemObj.itemId = this.itemId;
                        itemObj.taskListLabel = this.itemName + " aaa- ( " + this.invoiceCurrency + " - " + this.price + " )";
                        this.cItemTaskList.push(itemObj);
                    }
                }
            }
        }
        // DropDown Logic for Tax
        this.cInvoiceTaskRes.taxList = pResponse['taxList'];
        for (var i = 0; i < this.cInvoiceTaskRes.taxList.length; i++) {
            this.cCreateNewInvoice.taxOption.push({ label: this.cInvoiceTaskRes.taxList[i].taxName, value: { id: this.cInvoiceTaskRes.taxList[i].taxRateIndia, name: this.cInvoiceTaskRes.taxList[i].taxName } });
        }
    }
    onDueDateChange() {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            this.cCreateNewInvoice.dueCheck = false;
            if (typeof this.dueDateCal != 'undefined') {
                if (this.dueDateCal < this.expiryDateCal) {
                    this.mForm.controls['LateFee'].enable();
                    this.mForm.controls['LateFeeType'].enable();
                    this.mForm.controls['LateFee'].setValidators([Validators.required]);
                    this.mForm.controls['LateFee'].setValidators([Validators.required, BBValidator.percentages]);
                    this.mForm.controls['LateFee'].updateValueAndValidity();
                    this.mForm.controls['DiscountIf'].enable();
                    this.mForm.controls['DiscountIf'].setValidators([Validators.required]);
                    this.mForm.controls['DiscountIf'].updateValueAndValidity();
                }
                else {
                    this.mForm.controls['LateFee'].disable();
                    this.mForm.controls['LateFeeType'].disable();
                    this.mForm.controls['LateFee'].setValue('');
                    this.mForm.controls['LateFee'].setValidators([]);
                    this.mForm.controls['DiscountIf'].disable();
                    this.mForm.controls['DiscountIf'].setValue('');
                    this.mForm.controls['DiscountIf'].setValidators([]);
                }
                if (this.dueDateCal > this.expiryDateCal)
                    this.cCreateNewInvoice.dueCheck = true;
                else
                    this.cCreateNewInvoice.dueCheck = false;
                if ((this.cCreateNewInvoiceReq.discountIf) > this.cCreateNewInvoiceReq.dueDate)
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = true;
                else
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = false;
            }
        }
        else {
            if ((String(this.cCreateNewInvoiceReq.dueUpto) != '') && this.cCreateNewInvoiceReq.dueUpto != undefined && this.cCreateNewInvoiceReq.dueUpto != null && (Number(this.cCreateNewInvoiceReq.dueUpto) <= Number(this.cCreateNewInvoiceReq.invoiceValidFor))) {
                this.cCreateNewInvoice.dueUptoIsMoreThanValid = false;
                this.mForm.controls['LateFee'].enable();
                this.mForm.controls['LateFeeType'].enable();
                this.mForm.controls['LateFee'].setValidators([Validators.required, BBValidator.percentages]);
                this.mForm.controls['LateFee'].updateValueAndValidity();
                this.mForm.controls['DiscountIf'].enable();
                this.mForm.controls['DiscountIf'].setValidators([Validators.required]);
                this.mForm.controls['DiscountIf'].updateValueAndValidity();
            }
            else {
                if (String(this.cCreateNewInvoiceReq.dueUpto) != '')
                    this.cCreateNewInvoice.dueUptoIsMoreThanValid = true;
                this.mForm.controls['LateFee'].disable();
                this.mForm.controls['LateFee'].setValue('');
                this.mForm.controls['LateFee'].setValidators([]);
                this.mForm.controls['LateFeeType'].disable();
                this.mForm.controls['DiscountIf'].disable();
                this.mForm.controls['DiscountIf'].clearValidators();
                this.mForm.controls['DiscountIf'].setValue('');
                this.mForm.controls['DiscountIf'].setValidators([]);
                this.mForm.controls['DiscountIf'].updateValueAndValidity();
            }
            //settingduedate
            var datePipe = new DatePipe('en-US');
            var d = this.cCreateNewInvoiceReq.startDate.split("/");
            this.date1 = new Date(+d[2], +d[1] - 1, +d[0]);
            if (this.cCreateNewInvoiceReq.validitytype == 'hours') {
                this.date1.setHours(this.date1.getHours() + this.cCreateNewInvoiceReq.dueUpto);
                this.cCreateNewInvoiceReq.dueDate = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
            if (this.cCreateNewInvoiceReq.validitytype == 'minutes') {
                this.date1.setMinutes(this.date1.getMinutes() + this.cCreateNewInvoiceReq.dueUpto);
                this.cCreateNewInvoiceReq.dueDate = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
            if (this.cCreateNewInvoiceReq.validitytype == 'days') {
                this.date1.setDate(this.date1.getDate() + (+this.cCreateNewInvoiceReq.dueUpto));
                this.cCreateNewInvoiceReq.dueDate = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
        }
    }
    setExpiry() {
        var datePipe = new DatePipe('en-US');
        var d = this.cCreateNewInvoiceReq.startDate.split("/");
        this.date1 = new Date(+d[2], +d[1] - 1, +d[0]);
        if (this.cCreateNewInvoiceReq.validitytype == 'hours') {
            this.date1.setHours(this.date1.getHours() + this.cCreateNewInvoiceReq.invoiceValidFor);
            this.viewExpDate = datePipe.transform(this.date1, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = datePipe.transform(this.date1, 'dd/MM/yyyy HH:mm');
        }
        if (this.cCreateNewInvoiceReq.validitytype == 'minutes') {
            this.date1.setMinutes(this.date1.getMinutes() + this.cCreateNewInvoiceReq.invoiceValidFor);
            this.viewExpDate = datePipe.transform(this.date1, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = datePipe.transform(this.date1, 'dd/MM/yyyy HH:mm');
        }
        if (this.cCreateNewInvoiceReq.validitytype == 'days') {
            this.date1.setDate(this.date1.getDate() + (+this.cCreateNewInvoiceReq.invoiceValidFor));
            this.viewExpDate = datePipe.transform(this.date1, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = datePipe.transform(this.date1, 'dd/MM/yyyy HH:mm');
        }
        this.expiryDateCal = new Date(this.cCreateNewInvoiceReq.expiryDate);
        this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
    }
    setInvValidityType(event) {
        if (this.cInvoiceSettingsReq.settingInvValidityEdit == 'Y') {
            this.cCreateNewInvoiceReq.validitytype = event.value;
            this.setExpiry();
        }
    }
    onSelectItem(pItemnumber, selectedItemDetail, k) {
        console.log("in select item::", pItemnumber);
        if (selectedItemDetail.itemName == "Select task/item") {
            this.Taskitem.controls[k].patchValue({
                lineTotal: null,
                itemUnitCost: null,
                itemName: "Select task/item",
                itemDescription: null,
                itemId: selectedItemDetail.itemId,
                itemQty: null
            });
        }
        if (selectedItemDetail.itemName == "Add task/item") {
            this.cCreateNewInvoice.isAddTask = "active";
            this.Taskitem.controls[k].patchValue({
                lineTotal: null,
                itemUnitCost: null,
                itemName: "Select task/item",
                itemDescription: null,
                itemId: selectedItemDetail.itemId,
                itemQty: null
            });
            this.cCreateNewInvoice.invalidItemList = false;
            this.mForm.get('Taskitem').markAsPristine();
        }
        if (k == 0) {
            this.cCreateNewInvoiceReq.invoiceCurrency = selectedItemDetail.itemCurrency;
            this.onSelectCurrency();
        }
        for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
            if (this.cInvoiceTaskRes.invoiceTaskList[i].itemName == selectedItemDetail.itemName) {
                this.cCreateNewInvoice.invalidItemList = false;
                if (this.cInvoiceTaskRes.invoiceTaskList[i].priceList != null) {
                    for (var j = 0; j < this.cInvoiceTaskRes.invoiceTaskList[i].priceList.length; j++) {
                        if (this.cCreateNewInvoiceReq.invoiceCurrency == this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].currency) {
                            this.Taskitem.controls[k].patchValue({
                                lineTotal: 0,
                                itemUnitCost: this.cInvoiceTaskRes.invoiceTaskList[i].priceList[j].price,
                                itemName: selectedItemDetail.itemName,
                                itemCurrency: selectedItemDetail.itemCurrency,
                                itemDescription: selectedItemDetail.itemDescription,
                                itemId: selectedItemDetail.itemId,
                                editClicked2: true,
                                arrowDown2: false
                            });
                        }
                    }
                }
            }
        }
        if (pItemnumber.itemName) {
            pItemnumber.arrowDown2 = false;
            pItemnumber.editClicked2 = true;
        }
        console.log("event::", this.mForm.value);
        this.mForm.updateValueAndValidity();
    }
    addTask() {
        this.ngSelectTableRow1 = false;
        let removeIndex = -1;
        for (var i = 0; i < this.cItemTaskList.length; i++) {
            for (let g = 0; g < this.Taskitem.controls.length; g++) {
                var itemName = this.Taskitem.controls[g]['itemName'];
                if (itemName != undefined && this.cItemTaskList[i].itemName == itemName) {
                    removeIndex = i;
                }
            }
        }
        if (removeIndex != -1) {
            let item = this.cItemTaskList.splice(removeIndex, 1);
            this.mySelectedTaskList.push(item);
        }
        this.Taskitem.push(this.buildGroup());
        console.log("on add : ", this.Taskitem);
    }
    deleteTask(index, itemnumber) {
        if (this.Taskitem.length > 1) {
            if (this.cCreateNewInvoice.totalAmt > 0) {
                // this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoice.totalAmt - itemnumber.lineTotal;
                // this.cCreateNewInvoiceReq.invoiceAmount = this.cCreateNewInvoice.totalAmt;
                var line = this.Taskitem.controls[index].value.lineTotal;
                if (typeof line == 'undefined') {
                    line = 0;
                }
                this.cCreateNewInvoice.subTotalAmt = this.cCreateNewInvoice.subTotalAmt - line;
                var txCalculation = this.Taskitem.controls[index].value.txCalculation;
                if (typeof txCalculation == 'undefined') {
                    txCalculation = 0;
                }
                if (typeof this.Taskitem.controls[index].value.txCalculation == 'undefined') {
                    this.Taskitem.controls[index].patchValue({ txCalculation: 0 });
                }
                else {
                }
                this.cCreateNewInvoice.subTotalTaxAmt = this.cCreateNewInvoice.subTotalTaxAmt - Number(txCalculation);
                this.cCreateNewInvoiceReq.invoiceAmount = Number(this.cCreateNewInvoice.subTotalAmt) + Number(this.cCreateNewInvoice.subTotalTaxAmt);
                this.cCreateNewInvoice.totalAmt = this.cCreateNewInvoiceReq.invoiceAmount;
            }
            let itemName = this.Taskitem.controls[index].value.txCalculation.itemName;
            this.cItemTaskList.pop();
            this.cItemTaskList.shift();
            for (var i = 0; i < this.cInvoiceTaskRes.invoiceTaskList.length; i++) {
                if (this.cInvoiceTaskRes.invoiceTaskList[i].itemName == itemName) {
                    this.cItemTaskList.splice(i, 1);
                }
            }
            this.Taskitem.removeAt(index);
        }
        else {
            this.Taskitem.removeAt(index);
            this.fetchTask(this.cCreateNewInvoiceReq.regId);
            this.Taskitem.push(this.buildGroup());
        }
        ;
        console.log('=====-------->>>>>> ', this.cItemTaskList.length);
    }
    addMerchantParams(i) {
        this.merchantParamsitem1.push(this.buildGroup1());
    }
    deleteMerchantParams(i, itemnumber) {
        this.merchantParamsitem1.removeAt(i);
    }
    setAliasAndInvoiceSetting(pResponse) {
        this.cCreateNewInvoice.aliasList = pResponse['invoiceSettingsAlias'];
        this.cCreateNewInvoice.aliasCustomerName = this.cCreateNewInvoice.aliasList.aliasCustomerName;
        this.cCreateNewInvoice.aliasRefNo = this.cCreateNewInvoice.aliasList.aliasMerRefNo;
        this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo, this.mEditData != undefined ? this.mEditData.invoiceDetailsRS2ProcEntity.billMerReferenceNo : '', 1));
        this.cCreateNewInvoice.aliasRefNo1 = this.cCreateNewInvoice.aliasList.aliasMerRefNo1;
        this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo1, this.mEditData != undefined ? this.mEditData.invoiceDetailsRS2ProcEntity.billMerReferenceNo1 : '', 2));
        this.cCreateNewInvoice.aliasRefNo2 = this.cCreateNewInvoice.aliasList.aliasMerRefNo2;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo2)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo2, this.mEditData != undefined ? this.mEditData.invoiceDetailsRS2ProcEntity.billMerReferenceNo2 : '', 3));
        }
        this.cCreateNewInvoice.aliasRefNo3 = this.cCreateNewInvoice.aliasList.aliasMerRefNo3;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo3)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo3, this.mEditData != undefined ? this.mEditData.invoiceDetailsRS2ProcEntity.billMerReferenceNo3 : '', 4));
        }
        this.cCreateNewInvoice.aliasRefNo4 = this.cCreateNewInvoice.aliasList.aliasMerRefNo4;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.aliasRefNo4)) {
            this.merchantParamsitem1.push(this.pushParams(this.cCreateNewInvoice.aliasRefNo4, this.mEditData != undefined ? this.mEditData.invoiceDetailsRS2ProcEntity.billMerReferenceNo4 : '', 5));
        }
        this.cCreateNewInvoiceReq.validitytype = this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType))
            this.mForm.controls['InvValidityType'].setValue(this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType);
        this.cCreateNewInvoiceReq.invoiceValidFor = this.cCreateNewInvoice.invoiceSettingsList.settingInvValidity;
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityEdit) && this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityEdit == 'N') {
            this.mForm.controls['expiryDate'].disable();
        }
        else {
            this.mForm.controls['expiryDate'].enable();
        }
        if (this.sCheck.isNotNullString(this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount) && this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y') {
            this.mForm.controls['minAmount'].setValidators([Validators.required, Validators.minLength(1), BBValidator.amount, BBValidator.nonZeroAmount]);
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvAdvance == 'Y' && this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.mForm.controls['DiscountIf'].enable();
            this.mForm.controls['dueDate'].disable();
            this.mForm.controls['dueDate'].setValidators([Validators.required]);
            this.mForm.controls['dueDate'].updateValueAndValidity();
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescriptionEdit == 'N') {
            if (this.cCreateNewInvoiceReq.invoiceDescription == null || this.cCreateNewInvoiceReq.invoiceDescription == '') {
                this.cCreateNewInvoiceReq.invoiceDescription = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            }
            this.mForm.controls["invoiceDescription"].disable();
        }
        else {
            if (this.cCreateNewInvoiceReq.invoiceDescription == null || this.cCreateNewInvoiceReq.invoiceDescription == '') {
                this.cCreateNewInvoiceReq.invoiceDescription = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            }
            this.mForm.controls['invoiceDescription'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(500), InvoiceSettingsValidator.letterSpaceUnderscoreColon,
                InvoiceSettingsValidator.isConsecuSpecialCharDesc, BBValidator.isBlankSpace]);
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvTermsEdit == 'N') {
            if (this.cCreateNewInvoiceReq.termsAndCondition == null || this.cCreateNewInvoiceReq.termsAndCondition == '') {
                this.cCreateNewInvoiceReq.termsAndCondition = this.cCreateNewInvoice.invoiceSettingsList.settingInvTerms;
            }
            this.mForm.controls['termsAndCondition'].disable();
        }
        else {
            if (this.cCreateNewInvoiceReq.termsAndCondition == null || this.cCreateNewInvoiceReq.termsAndCondition == '') {
                this.cCreateNewInvoiceReq.termsAndCondition = this.cCreateNewInvoice.invoiceSettingsList.settingInvTerms;
            }
            this.mForm.controls['termsAndCondition'].setValidators([Validators.minLength(1), Validators.maxLength(500), Validators.required, InvoiceSettingsValidator.isBeginSpecialChar,
                InvoiceSettingsValidator.isEndSpecialCharForTerms,
                InvoiceSettingsValidator.isConsecuSpecialCharInvoice,
                InvoiceSettingsValidator.termsConditionInv, BBValidator.isBlankSpace]);
        }
        this.cCreateNewInvoice.aliasTermCondition = this.cCreateNewInvoice.aliasList.aliasTermsConditions;
        this.cCreateNewInvoice.aliasTask = this.cCreateNewInvoice.aliasList.aliasItems;
        this.cCreateNewInvoice.aliasDescription = this.cCreateNewInvoice.aliasList.aliasDescription;
        this.cCreateNewInvoice.aliasUnitCost = this.cCreateNewInvoice.aliasList.aliasUnitCost;
        this.cCreateNewInvoice.aliasTotalAmt = this.cCreateNewInvoice.aliasList.aliasNetAmount;
        this.cCreateNewInvoice.aliasInvoiceId = this.cCreateNewInvoice.aliasList.aliasInvoiceId;
    }
    setInvoiceSetting(pResponse) {
        this.cCreateNewInvoice.invoiceSettingsList = pResponse['invoiceSettings'];
        this.cCreateNewInvoice.settingBizAddress = this.cCreateNewInvoice.invoiceSettingsList.settingBizAddress;
        this.cCreateNewInvoice.settingBizEmail = this.cCreateNewInvoice.invoiceSettingsList.settingBizEmail;
        this.cCreateNewInvoice.settingBizPhone = this.cCreateNewInvoice.invoiceSettingsList.settingBizPhone;
        return this.cCreateNewInvoice.invoiceSettingsList;
    }
    onChooseAttachmentFile(event) {
        let fileList = event.target.files;
        if (fileList.length > 0) {
            let validExts = [];
            validExts = ['.jpg', '.jpeg', '.doc', '.docx', '.png', '.pdf', '.xlsx'];
            var fileExt = fileList[0].name.substring(fileList[0].name.lastIndexOf('.'));
            if (validExts.indexOf(fileExt) >= 0) {
                if (fileList[0].size <= 1000000) {
                    this.cCreateNewInvoice.attachmentFile = fileList[0];
                    this.cCreateNewInvoiceReq.emailAttachmentFileName = fileList[0].name;
                    this.cCreateNewInvoiceReq.emailAttachment = "Y";
                }
                else {
                    this.sAlertMessageService.popupAlertMsg("File size upto 1 MB allowed.");
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg("Only pdf,doc,docx,jpeg,jpg,png,xlsx files are allowed.");
            }
        }
    }
    onCancelClick() {
        this.pLocation.back();
    }
    openCustomerPopUp() {
        this.cCreateNewInvoice.showCustomerPopoup = "Y";
        this.cCreateNewInvoice.editPopupFlag = 'N';
        this.cCreateNewInvoice.isCustomerDropDown = !this.cCreateNewInvoice.isCustomerDropDown;
    }
    onGenerateClick(pTemplate) {
        this.cCreateNewInvoiceReq.invoiceAction = "Pending"; //pending
        this.dateSelectionfailed = this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
        this.onPaymentWayClick(this.cCreateNewInvoiceReq.RadioCheckModel);
        this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
        this.sendviaEmpty = false;
        if (!this.cCreateNewInvoice.showhidsms && !this.cCreateNewInvoice.showhidmail && this.cCreateNewInvoiceReq.custName) {
            this.sendviaEmpty = true;
        }
        // if(!this.mForm.controls['custId'].valid)
        //     this.sAlertMessageService.popupAlertMsg("Customer is mandatory.");
        if (this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.cCreateNewInvoiceReq.itemsTasksList = this.Taskitem.value;
            if (this.cCreateNewInvoiceReq.itemsTasksList[0].itemName != undefined) {
                this.validateItemList();
                if (!this.mForm.valid) {
                    CustomValidator.validateAllFields(this.mForm);
                    CustomValidator.focusOnFirstInvalidField(this.mForm);
                    this.getFormValidationErrors();
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg("Select at least one Item.");
            }
        }
        if (!this.cCreateNewInvoice.invalidItemList && !this.sendviaEmpty && !this.dateSelectionfailed) {
            if (this.mForm.valid) {
                this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
            }
            else {
                CustomValidator.validateAllFields(this.mForm);
                CustomValidator.focusOnFirstInvalidField(this.mForm);
                this.getFormValidationErrors();
            }
        }
    }
    onSaveDraft(pTemplate) {
        this.cCreateNewInvoiceReq.invoiceAction = "Draft"; //pending
        if (this.cCreateNewInvoiceReq.invoiceType == "SimpleInvoice") {
            if (this.mForm.controls['custId'].valid && this.mForm.controls['invoiceAmount'].valid) {
                this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
                this.isDraftReq = true;
            }
            else {
                if (this.mForm.controls['custId'].valid || this.mForm.controls['invoiceAmount'].valid) {
                    if (!this.mForm.controls['custId'].valid)
                        this.sAlertMessageService.popupAlertMsg("Customer is mandatory.");
                    else if (!this.mForm.controls['invoiceAmount'].valid)
                        this.sAlertMessageService.popupAlertMsg("Invoice amount is mandatory.");
                }
                else
                    this.sAlertMessageService.popupAlertMsg("Invoice amount and Customer is mandatory.");
            }
        }
        else {
            this.cCreateNewInvoiceReq.itemsTasksList = this.Taskitem.value;
            if ((this.cCreateNewInvoiceReq.itemsTasksList[0].itemName != undefined) && this.mForm.controls['custId'].valid) {
                this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
                this.isDraftReq = true;
            }
            else {
                if (this.mForm.controls['custId'].valid || this.sCheck.isNotNullString(this.cCreateNewInvoiceReq.itemsTasksList[0].itemName)) {
                    if (!this.mForm.controls['custId'].valid)
                        this.sAlertMessageService.popupAlertMsg("Customer is mandatory.");
                    else if (this.sCheck.isNullString(this.cCreateNewInvoiceReq.itemsTasksList[0].itemName))
                        this.sAlertMessageService.popupAlertMsg("Select at least one Item.");
                }
                else
                    this.sAlertMessageService.popupAlertMsg("At least one item and Customer is mandatory.");
            }
        }
    }
    checkPlaceHolder(event) {
        let str = this.cCreateNewInvoiceReq.smsContent;
        if (!(str.includes("Invoice_Amount") && str.includes('Pay_Link') && str != null && str != ''))
            this.missingplaceholder = true;
        else
            this.missingplaceholder = false;
        if ((str.includes("LegalEntity_Name") && str.includes('Webstore_Name') && str != null && str != ''))
            this.bothplaceholder1 = true;
        else
            this.bothplaceholder1 = false;
        if ((str.includes("Invoice_ID") && str.includes('Invoice_RefNumber') && str != null && str != ''))
            this.bothplaceholder3 = true;
        else
            this.bothplaceholder3 = false;
        if (str == '') {
            this.bothplaceholder3 = false;
            this.bothplaceholder1 = false;
            this.missingplaceholder = false;
        }
    }
    decline() {
        this.cModalRef.hide();
        this.pLocation.back();
    }
    declineGenerate() {
        this.cModalRef.hide();
    }
    validateItemList() {
        this.cCreateNewInvoiceReq.invoiceAmount = 0;
        this.cCreateNewInvoiceReq.itemsTasksList.forEach(item => {
            item.itemTax = null;
            if (item.itemName == undefined || item.itemDescription == undefined || item.itemQty == undefined || item.itemQty == 0) {
                this.cCreateNewInvoice.invalidItemList = true;
                return true;
            }
            else {
                let totalCalAmount = Number(this.cCreateNewInvoice.totalAmt);
                this.cCreateNewInvoiceReq.invoiceAmount = totalCalAmount;
                this.cCreateNewInvoice.invalidItemList = false;
            }
        });
        return false;
    }
    onSubmit() {
        if (!this.cCreateNewInvoice.invalidItemList) {
            if (this.mForm.valid) {
                this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
                if (this.cCreateNewInvoice.deliveryCheckEmail) {
                    this.cCreateNewInvoiceReq.deliveryType = "EMAIL";
                }
                else if (this.cCreateNewInvoice.deliveryCheckSms) {
                    this.cCreateNewInvoiceReq.deliveryType = "SMS";
                }
                if (this.cCreateNewInvoice.deliveryCheckEmail && this.cCreateNewInvoice.deliveryCheckSms) {
                    this.cCreateNewInvoiceReq.deliveryType = "BOTH";
                }
                if (this.cCreateNewInvoiceReq.recurring == 'N') {
                    this.cCreateNewInvoiceReq.startDate = null;
                    this.cCreateNewInvoiceReq.frequency = null;
                    this.cCreateNewInvoiceReq.occurences = null;
                }
                if (this.cCreateNewInvoiceReq.RadioCheckModel != 'FP' && this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y' && (parseFloat(this.cCreateNewInvoiceReq.minAmount.toString()) > parseFloat(this.cCreateNewInvoiceReq.invoiceAmount.toString()))) {
                    this.cCreateNewInvoice.invalidMinAmount = true;
                }
                else {
                    if (this.cCreateNewInvoiceReq.deliveryType != null && this.cCreateNewInvoiceReq.deliveryType != '') {
                        //if(this.popUpCount == 0 && this.dateSelectionfailed == false)
                        if (this.dateSelectionfailed == false) {
                            console.log(this.cCreateNewInvoiceReq);
                            this.genClicked = true;
                            this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                                .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { this.genClicked = false; this.sAlertMessageService.popupAlertMsg('error'); });
                        }
                    }
                    else {
                        this.deliveryTypeNotSelected = true;
                    }
                }
            }
            else {
                CustomValidator.validateAllFields(this.mForm);
                CustomValidator.focusOnFirstInvalidField(this.mForm);
                this.getFormValidationErrors();
            }
        }
        this.popUpCount += 1; //if to track no of 'yes' clicked
    }
    saveAsDraft() {
        this.cCreateNewInvoiceReq.merchantParamsList = this.merchantParamsitem1.value;
        if (this.cCreateNewInvoice.deliveryCheckEmail) {
            this.cCreateNewInvoiceReq.deliveryType = "EMAIL";
        }
        else if (this.cCreateNewInvoice.deliveryCheckSms) {
            this.cCreateNewInvoiceReq.deliveryType = "SMS";
        }
        if (this.cCreateNewInvoice.deliveryCheckEmail && this.cCreateNewInvoice.deliveryCheckSms) {
            this.cCreateNewInvoiceReq.deliveryType = "BOTH";
        }
        if (this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            this.cCreateNewInvoiceReq.itemsTasksList = this.Taskitem.value;
            if (this.cCreateNewInvoiceReq.itemsTasksList.length > 0) {
                this.validateItemList();
            }
            else {
                this.sAlertMessageService.popupAlertMsg("Select at least one Item.");
            }
        }
        if (this.cCreateNewInvoiceReq.invoiceType == 'SimpleInvoice') {
            if (this.cCreateNewInvoiceReq.invoiceAmount) {
                this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                    .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { console.log('error'); });
            }
            else {
                this.sAlertMessageService.popupAlertMsg("Invoice amount is required.");
            }
        }
        if (!this.cCreateNewInvoice.invalidItemList && this.cCreateNewInvoiceReq.invoiceType == 'ItemizedInvoice') {
            if (this.cCreateNewInvoice.deliveryCheckEmail) {
                this.cCreateNewInvoiceReq.deliveryType = "EMAIL";
            }
            else if (this.cCreateNewInvoice.deliveryCheckSms) {
                this.cCreateNewInvoiceReq.deliveryType = "SMS";
            }
            if (this.cCreateNewInvoice.deliveryCheckEmail && this.cCreateNewInvoice.deliveryCheckSms) {
                this.cCreateNewInvoiceReq.deliveryType = "BOTH";
            }
            if (this.cCreateNewInvoiceReq.minAmount && this.cCreateNewInvoiceReq.invoiceAmount) {
                if (this.cCreateNewInvoice.invoiceSettingsList.settingMinInvAmount == 'Y' && (parseFloat(this.cCreateNewInvoiceReq.minAmount.toString()) > parseFloat(this.cCreateNewInvoiceReq.invoiceAmount.toString()))) {
                    this.cCreateNewInvoice.invalidMinAmount = true;
                }
            }
            else {
                if (this.popUpCount == 0)
                    this.sInvoiceService.createNewInvoice(this.cCreateNewInvoice.attachmentFile, this.cCreateNewInvoiceReq)
                        .subscribe(pResponse => this.fetchCreateInvoiceResponse(pResponse), error => { console.log('error'); });
            }
        }
        this.popUpCount += 1;
    }
    getFormValidationErrors() {
        Object.keys(this.mForm.controls).forEach(key => {
            const controlErrors = this.mForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    onCustomerSubmit(value) {
        if (this.cAddNewCustomerDetailsReq.isBillingDetails) {
            this.onaddShippingAddressButton();
        }
        if (this.cAddNewCustomerDetailsReq.isDeliveryDetails) {
            this.validateDeliveryDetails();
        }
        if ((typeof value.custEmail == 'undefined' || value.custEmail == '') && (typeof value.custMobileNo == 'undefined' || value.custMobileNo == '')) {
            this.mForm1.controls['custEmail'].enable();
            this.mForm1.controls['custEmail'].setValue(null);
            this.mForm1.controls['custEmail'].dirty;
            this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
            this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email,
                Validators.maxLength(70)]);
            this.mForm1.controls['custEmail'].updateValueAndValidity();
            this.mForm1.controls['custMobileNo'].enable();
            this.mForm1.controls['custMobileNo'].setValue(null);
            this.mForm1.controls['custMobileNo'].dirty;
            this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
            this.mForm1.controls['custMobileNo'].setValidators([Validators.required, BBValidator.customerPhone]);
            this.mForm1.controls['custMobileNo'].updateValueAndValidity();
        }
        if (typeof value.custGstin !== 'undefined' && value.custGstin !== '') {
            this.mForm1.controls['custGstin'].setValidators([BBValidator.gstNo]);
            this.mForm1.controls['custGstin'].updateValueAndValidity();
        }
        if ((typeof value.custEmail !== 'undefined' && value.custEmail !== '') || (typeof value.custMobileNo !== 'undefined' && value.custMobileNo !== '')) {
            this.mForm1.controls['custEmail'].setValidators([BBValidator.email, Validators.maxLength(70)]);
            this.mForm1.controls['custEmail'].updateValueAndValidity();
            this.mForm1.controls['custMobileNo'].setValidators([BBValidator.customerPhone]);
            this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            if (this.mForm1.pending) {
                let setInitialStatus = () => {
                    if (this.mForm1.pending) {
                        t = setTimeout(setInitialStatus, 5);
                    }
                    else {
                        if (this.mForm1.valid) {
                            this.cAddNewCustomerDetailsReq.regId = Number(this.pInvoiceDataService.regId);
                            this.sCustomerService.addCustomerDetails(this.cAddNewCustomerDetailsReq)
                                .subscribe(pResponse => {
                                this.onAddCustomer(pResponse);
                            }, error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
                        }
                        clearTimeout(t);
                    }
                };
                let t = setTimeout(setInitialStatus, 5);
            }
        }
        if (this.mForm1.valid) {
            this.cAddNewCustomerDetailsReq.regId = Number(this.pInvoiceDataService.regId);
            this.sCustomerService.addCustomerDetails(this.cAddNewCustomerDetailsReq)
                .subscribe(pResponse => {
                this.onAddCustomer(pResponse);
            }, error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
        }
        else {
            this.validateAllFields(this.mForm1);
        }
    }
    validateDeliveryDetails() {
        if (!this.cAddNewCustomerDetailsReq.custDeliveryAddress ||
            !this.cAddNewCustomerDetailsReq.custDeliveryState ||
            !this.cAddNewCustomerDetailsReq.custDeliveryCity ||
            !this.cAddNewCustomerDetailsReq.custDeliveryZip ||
            (!this.cAddNewCustomerDetailsReq.custDeliveryCountry || this.cAddNewCustomerDetailsReq.custDeliveryCountry == '0')) {
            if (!this.cAddNewCustomerDetailsReq.custDeliveryAddress) {
                this.mForm1.controls['custDeliveryAddress'].enable();
                this.mForm1.controls['custDeliveryAddress'].setValue(null);
                this.mForm1.controls['custDeliveryAddress'].dirty;
                this.mForm1.controls['custDeliveryAddress'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryAddress'].setValidators([Validators.required, Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]);
                this.mForm1.controls['custDeliveryAddress'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryState) {
                this.mForm1.controls['custDeliveryState'].enable();
                this.mForm1.controls['custDeliveryState'].setValue(null);
                this.mForm1.controls['custDeliveryState'].dirty;
                this.mForm1.controls['custDeliveryState'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryState'].setValidators([Validators.required, BBValidator.customerState, Validators.maxLength(30)]);
                this.mForm1.controls['custDeliveryState'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryCity) {
                this.mForm1.controls['custDeliveryCity'].enable();
                this.mForm1.controls['custDeliveryCity'].setValue(null);
                this.mForm1.controls['custDeliveryCity'].dirty;
                this.mForm1.controls['custDeliveryCity'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryCity'].setValidators([Validators.required, BBValidator.customerCity,
                    Validators.maxLength(30)]);
                this.mForm1.controls['custDeliveryCity'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryZip) {
                this.mForm1.controls['custDeliveryZip'].enable();
                this.mForm1.controls['custDeliveryZip'].setValue(null);
                this.mForm1.controls['custDeliveryZip'].dirty;
                this.mForm1.controls['custDeliveryZip'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryZip'].setValidators([Validators.required, BBValidator.customerPin,
                    Validators.maxLength(6)]);
                this.mForm1.controls['custDeliveryZip'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryCountry || this.cAddNewCustomerDetailsReq.custDeliveryCountry == '0') {
                this.mForm1.controls['custDeliveryCountry'].enable();
                this.mForm1.controls['custDeliveryCountry'].setValue(null);
                this.mForm1.controls['custDeliveryCountry'].dirty;
                this.mForm1.controls['custDeliveryCountry'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryCountry'].setValidators([Validators.required]);
                this.mForm1.controls['custDeliveryCountry'].updateValueAndValidity();
            }
        }
    }
    fetchCreateInvoiceResponse(pResponse) {
        if (pResponse.code == 0 && pResponse.message == 'Success') {
            this.cCreateInvoiceRes.billId = pResponse.data['billId'];
            this.cCreateInvoiceRes.success = pResponse.data['success'];
            this.checkErr = false;
            if (!this.isDraftReq)
                this.sAlertMessageService.popupAlertMsg("Invoice generated successfully");
            else
                this.sAlertMessageService.popupAlertMsg("Invoice saved as draft successfully");
            // this.mForm.reset();
            // this.buildArray();
            // this.mForm.get('Taskitem').disable();
            this.pLocation.back();
        }
        else if (pResponse.code == -1 && pResponse.message == 'Error') {
            this.sAlertMessageService.popupAlertMsg("Invoice generation failed.");
        }
        else if (pResponse.code == -1 && pResponse.message == 'ValidationFail') {
            this.sErrorHandler.setSingleServerError(pResponse.fieldErrors, this.mForm);
        }
        this.cModalRef.hide();
        this.genClicked = false;
    }
    onCustomerSelectionClick(pValue) {
        this.editClicked = true;
        this.sCustomerService.getCustomerDetails(pValue)
            .subscribe(pResponse => this.assignCustomerData(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    assignCustomerData(pResponse) {
        let custData = pResponse.data['customerData'];
        this.cCreateNewInvoice.isCustomerSelection = true;
        this.cCreateNewInvoiceReq.custName = custData[0].custName;
        this.cCreateNewInvoiceReq.custEmail = custData[0].custEmail;
        this.cCreateNewInvoiceReq.custMobileNo = custData[0].custMobileNo;
        this.cCreateNewInvoiceReq.customerName = custData[0].custName;
        this.cCreateNewInvoiceReq.emailId = custData[0].custEmail;
        this.cCreateNewInvoiceReq.customerMobileNumber = custData[0].custMobileNo;
        this.cCreateNewInvoiceReq.custGstin = custData[0].custGstin;
        this.cCreateNewInvoiceReq.custBillingAddress = custData[0].custBillingAddress;
        this.cCreateNewInvoiceReq.custBillingCity = custData[0].custBillingCity;
        this.cCreateNewInvoiceReq.custBillingZip = custData[0].custBillingZip;
        this.cCreateNewInvoiceReq.custBillingState = custData[0].custBillingState;
        this.cCreateNewInvoiceReq.custBillingCountry = custData[0].custBillingCountry;
        this.cCreateNewInvoiceReq.custDeliveryAddress = custData[0].custDeliveryAddress;
        this.cCreateNewInvoiceReq.custDeliveryCity = custData[0].custDeliveryCity;
        this.cCreateNewInvoiceReq.custDeliveryState = custData[0].custDeliveryState;
        this.cCreateNewInvoiceReq.custDeliveryZip = custData[0].custDeliveryZip;
        this.cCreateNewInvoiceReq.custDeliveryCountry = custData[0].custDeliveryCountry;
        this.cCreateNewInvoiceReq.custId = custData[0].custId;
        if (this.cCreateNewInvoiceReq.custId != '') {
            this.mForm.get('custId').clearValidators();
            this.mForm.get('custId').updateValueAndValidity();
        }
        this.cCreateNewInvoice.editPopupFlag = 'Y';
        this.customerDetailsNotSelected = false;
    }
    onPaymentWayClick(paymentWayType) {
        this.cCreateNewInvoiceReq.RadioCheckModel = paymentWayType;
        if (paymentWayType == 'PP' || paymentWayType == 'MP') {
            this.showMinAmount = true;
            if (this.pInvoiceDataService.editRequest)
                this.cCreateNewInvoiceReq.minAmount = this.mEditData.invoiceDetailsRS2ProcEntity.billMinAmt;
        }
        else {
            this.showMinAmount = false;
            this.cCreateNewInvoice.invalidMinAmount = false;
            this.mForm.controls['minAmount'].setValidators([]);
            this.mForm.controls['minAmount'].updateValueAndValidity();
        }
    }
    selectedInvoiceDate(event) {
        this.viewInvDate = event.start.format("DD/MM/YYYY hh:mm a");
        this.cCreateNewInvoiceReq.invoiceDate = event.start.format("DD/MM/YYYY HH:mm");
        this.invoiceDateCal = event.start.toDate();
        this.cCreateNewInvoiceReq.startDate = event.start.format("DD/MM/YYYY");
        if (this.cCreateNewInvoiceReq.recurring == 'N')
            this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
    }
    //called to set default expirydate
    setExpiryDate() {
        var dt = new Date();
        var dateexpiry;
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType == 'hours') {
            dt.setHours(dt.getHours() + (+this.cCreateNewInvoiceReq.invoiceValidFor));
            this.viewExpDate = this.datepipe.transform(dt, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(dt, 'dd/MM/yyyy HH:mm');
            dateexpiry = this.datepipe.transform(dt, 'yyyy/MM/dd HH:mm');
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType == 'minutes') {
            dt.setMinutes(dt.getMinutes() + (+this.cCreateNewInvoiceReq.invoiceValidFor));
            this.viewExpDate = this.datepipe.transform(dt, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(dt, 'dd/MM/yyyy HH:mm');
            dateexpiry = this.datepipe.transform(dt, 'yyyy/MM/dd HH:mm');
        }
        if (this.cCreateNewInvoice.invoiceSettingsList.settingInvValidityType == 'days') {
            dt.setDate(dt.getDate() + (+this.cCreateNewInvoiceReq.invoiceValidFor));
            this.viewExpDate = this.datepipe.transform(dt, 'dd/MM/yyyy hh:mm a');
            this.cCreateNewInvoiceReq.expiryDate = this.datepipe.transform(dt, 'dd/MM/yyyy HH:mm');
            dateexpiry = this.datepipe.transform(dt, 'yyyy/MM/dd HH:mm');
        }
        this.expiryDateCal = new Date(dateexpiry);
        this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
    }
    selectedExpiryDate(event) {
        this.viewExpDate = event.start.format("DD/MM/YYYY hh:mm a");
        this.cCreateNewInvoiceReq.expiryDate = event.start.format("DD/MM/YYYY HH:mm");
        this.expiryDateCal = event.start.toDate();
        this.compareInvoiceandExpiryDates(this.invoiceDateCal, this.expiryDateCal);
        if (typeof this.dueDateCal != 'undefined') {
            if (this.dueDateCal > this.expiryDateCal) {
                this.cCreateNewInvoice.dueCheck = true;
                this.mForm.controls['LateFee'].disable();
                this.mForm.controls['LateFeeType'].disable();
                this.mForm.controls['LateFee'].setValue('');
                this.mForm.controls['LateFee'].setValidators([]);
                this.mForm.controls['DiscountIf'].disable();
                this.mForm.controls['DiscountIf'].setValue('');
                this.mForm.controls['DiscountIf'].setValidators([]);
            }
            else {
                this.cCreateNewInvoice.dueCheck = false;
                this.mForm.controls['LateFee'].enable();
                this.mForm.controls['LateFeeType'].enable();
                this.mForm.controls['LateFee'].setValidators([Validators.required, BBValidator.percentages]);
                this.mForm.controls['LateFee'].updateValueAndValidity();
                this.mForm.controls['DiscountIf'].enable();
                this.mForm.controls['DiscountIf'].setValidators([Validators.required]);
                this.mForm.controls['DiscountIf'].updateValueAndValidity();
            }
        }
    }
    selectedDate(event) {
        this.cCreateNewInvoiceReq.startDate = event.start.format("DD/MM/YYYY");
        this.invoiceStartDate = event.start.toDate();
        this.viewInvDate = event.start.format("DD/MM/YYYY hh:mm a");
        this.cCreateNewInvoiceReq.invoiceDate = event.start.format("DD/MM/YYYY HH:mm");
        if (this.cCreateNewInvoiceReq.recurring == 'N')
            this.compareReccStartAndExpDate(this.invoiceStartDate, this.invoiceDateCal, this.expiryDateCal);
    }
    selectedDueDate(event) {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            this.cCreateNewInvoiceReq.dueDate = event.start.format("DD/MM/YYYY");
            this.dueDateCal = event.start.toDate();
        }
        this.onDueDateChange();
    }
    selectedDiscountDate(event) {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            this.cCreateNewInvoiceReq.discountIf = event.start.format("DD/MM/YYYY");
        }
        this.requiredDiscountIf(event);
    }
    checkMinimum(event) {
        if (parseInt(event.target.value) > this.cCreateNewInvoiceReq.invoiceAmount) {
            this.cCreateNewInvoice.invalidMinAmount = true;
        }
        else {
            this.cCreateNewInvoice.invalidMinAmount = false;
        }
    }
    compareInvoiceandExpiryDates(invoiceDateCal, expiryDateCal) {
        if (expiryDateCal < invoiceDateCal || expiryDateCal.getTime() == invoiceDateCal.getTime() || invoiceDateCal.getDate() != new Date().getDate()) {
            this.dateSelectionfailed = true;
        }
        else {
            this.dateSelectionfailed = false;
        }
        return this.dateSelectionfailed;
    }
    onSelectByOptionDiscount(event) {
        this.cCreateNewInvoice.discountLabel = event.name;
        this.cCreateNewInvoiceReq.discountType = event.id;
        if (this.cCreateNewInvoiceReq.discountType == 'Perc') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = '%';
            this.mForm.controls['Discount'].setValidators([BBValidator.percentages, Validators.required]);
            this.mForm.controls['Discount'].updateValueAndValidity();
        }
        if (this.cCreateNewInvoiceReq.discountType == 'Flat') {
            this.mForm.controls['Discount'].setValue('');
            this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
            this.mForm.controls['Discount'].setValidators([BBValidator.amount, Validators.required, Validators.max(this.cCreateNewInvoiceReq.invoiceAmount - 1)]);
            this.mForm.controls['Discount'].updateValueAndValidity();
        }
    }
    /*customer changes*/
    onOpenNewPopupClick(template) {
        this.cModalRef1 = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.createForm1();
    }
    createForm1() {
        this.mForm1 = this.pFormBuilder.group({
            custName: ['', [Validators.required,
                    Validators.minLength(3),
                    Validators.maxLength(60),
                    BBValidator.CusomerName,
                    BBValidator.leastOneChar,
                    BBValidator.isBeginSpecialChar,
                    BBValidator.isEndSpecialChar,
                    BBValidator.isConsecuSpecialChar]],
            custEmail: ['', [BBValidator.email,
                    Validators.maxLength(70)]],
            custMobileNo: ['', [BBValidator.customerPhone]],
            custGstin: ['', [BBValidator.gstNo]],
            isBillingDetails: [],
            custBillingCity: ['', [BBValidator.customerCity,
                    Validators.maxLength(30)]],
            custBillingZip: ['', [BBValidator.customerPin,
                    Validators.maxLength(6)]],
            custBillingState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custBillingCountry: [],
            isDeliveryDetails: [],
            isSameAsBillingDetails: [],
            custDeliveryAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300), BBValidator.customerAddress]],
            custDeliveryCity: ['', [BBValidator.customerCity, Validators.maxLength(30)]],
            custDeliveryState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custDeliveryZip: ['', [BBValidator.customerPin, Validators.maxLength(6)]],
            custDeliveryCountry: [],
            createCustomerButton: [],
            addBillingAddressButton: [],
            custBillingAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]],
            orderBillCountry: []
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onBillingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
            this.cAddNewCustomerDetailsReq.isBillingDetails = true;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isBillingDetails = false;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        }
    }
    onaddBillingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custName ||
            (!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
            if (!this.cAddNewCustomerDetailsReq.custName) {
                this.mForm1.controls['custName'].enable();
                this.mForm1.controls['custName'].setValue(null);
                this.mForm1.controls['custName'].dirty;
                this.mForm1.controls['custName'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custName'].setValidators([Validators.required]);
                this.mForm1.controls['custName'].updateValueAndValidity();
            }
            if ((!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
                this.mForm1.controls['custEmail'].enable();
                this.mForm1.controls['custEmail'].setValue(null);
                this.mForm1.controls['custEmail'].dirty;
                this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email,
                    Validators.maxLength(70)]);
                this.mForm1.controls['custEmail'].updateValueAndValidity();
                this.mForm1.controls['custMobileNo'].enable();
                this.mForm1.controls['custMobileNo'].setValue(null);
                this.mForm1.controls['custMobileNo'].dirty;
                this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custMobileNo'].setValidators([Validators.required]);
                this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            }
        }
        else if (this.cAddNewCustomerDetailsReq.custName || this.cAddNewCustomerDetailsReq.custEmail || this.cAddNewCustomerDetailsReq.custMobileNo) {
            if ((typeof this.cAddNewCustomerDetailsReq.custMobileNo == 'undefined' || this.cAddNewCustomerDetailsReq.custMobileNo == '') &&
                (typeof this.cAddNewCustomerDetailsReq.custEmail == 'undefined' || this.cAddNewCustomerDetailsReq.custEmail == '')) {
                this.mForm1.controls['custEmail'].enable();
                this.mForm1.controls['custEmail'].setValue(null);
                this.mForm1.controls['custEmail'].dirty;
                this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email, Validators.maxLength(70)]);
                this.mForm1.controls['custEmail'].updateValueAndValidity();
                this.mForm1.controls['custMobileNo'].enable();
                this.mForm1.controls['custMobileNo'].setValue(null);
                this.mForm1.controls['custMobileNo'].dirty;
                this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custMobileNo'].setValidators([Validators.required, BBValidator.customerPhone]);
                this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            }
            if (this.mForm1.controls['custName'].valid &&
                ((this.cAddNewCustomerDetailsReq.custEmail ? this.mForm1.controls['custEmail'].valid : this.mForm1.controls['custEmail'].valid || this.mForm1.controls['custMobileNo'].valid) &&
                    (this.cAddNewCustomerDetailsReq.custMobileNo ? this.mForm1.controls['custMobileNo'].valid : this.mForm1.controls['custEmail'].valid || this.mForm1.controls['custMobileNo'].valid))) {
                this.mForm1.get('custEmail').clearValidators();
                this.mForm1.get('custEmail').clearAsyncValidators();
                this.mForm1.get('custEmail').updateValueAndValidity();
                this.mForm1.get('custMobileNo').clearValidators();
                this.mForm1.get('custMobileNo').clearAsyncValidators();
                this.mForm1.get('custMobileNo').updateValueAndValidity();
                this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
                this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
                this.cAddNewCustomerDetailsReq.createCustomerButton = true;
                this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            }
        }
    }
    getCountryList() {
        return this.cCountryList;
    }
    fetchCountryList() {
        this.pTransactionsService.fetchCountryList()
            .subscribe(rResponse => this.fetchCountryListSuccess(rResponse), error => { console.log('error '); });
    }
    fetchCountryListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (this.sCheck.isNotNullObject(pResponse.data)) {
                this.cCountry = pResponse.data;
                this.cCountryList.push({ label: 'Select country', value: '0' });
                for (let pCountry of this.cCountry) {
                    this.cCountryList.push({ label: pCountry, value: pCountry });
                }
            }
        }
    }
    onBackToCustomerDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
        this.cAddNewCustomerDetailsReq.isBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
        this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
        this.mForm1.controls['custName'].setValidators([Validators.required]);
        this.mForm1.controls['custEmail'].setValidators([BBValidator.email]);
        this.mForm1.controls['custMobileNo'].setValidators([BBValidator.customerPhone]);
    }
    onShippingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = true;
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        }
        else {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        }
    }
    onaddShippingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custBillingAddress ||
            !this.cAddNewCustomerDetailsReq.custBillingState ||
            !this.cAddNewCustomerDetailsReq.custBillingCity ||
            !this.cAddNewCustomerDetailsReq.custBillingZip ||
            (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0')) {
            if (!this.cAddNewCustomerDetailsReq.custBillingAddress) {
                this.mForm1.controls['custBillingAddress'].enable();
                this.mForm1.controls['custBillingAddress'].setValue(null);
                this.mForm1.controls['custBillingAddress'].dirty;
                this.mForm1.controls['custBillingAddress'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingAddress'].setValidators([Validators.required, Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]);
                this.mForm1.controls['custBillingAddress'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingState) {
                this.mForm1.controls['custBillingState'].enable();
                this.mForm1.controls['custBillingState'].setValue(null);
                this.mForm1.controls['custBillingState'].dirty;
                this.mForm1.controls['custBillingState'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingState'].setValidators([Validators.required, BBValidator.customerState, Validators.maxLength(30)]);
                this.mForm1.controls['custBillingState'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCity) {
                this.mForm1.controls['custBillingCity'].enable();
                this.mForm1.controls['custBillingCity'].setValue(null);
                this.mForm1.controls['custBillingCity'].dirty;
                this.mForm1.controls['custBillingCity'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCity'].setValidators([Validators.required, BBValidator.customerCity,
                    Validators.maxLength(30)]);
                this.mForm1.controls['custBillingCity'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingZip) {
                this.mForm1.controls['custBillingZip'].enable();
                this.mForm1.controls['custBillingZip'].setValue(null);
                this.mForm1.controls['custBillingZip'].dirty;
                this.mForm1.controls['custBillingZip'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingZip'].setValidators([Validators.required, BBValidator.customerPin,
                    Validators.maxLength(6)]);
                this.mForm1.controls['custBillingZip'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0') {
                this.mForm1.controls['custBillingCountry'].enable();
                this.mForm1.controls['custBillingCountry'].setValue(null);
                this.mForm1.controls['custBillingCountry'].dirty;
                this.mForm1.controls['custBillingCountry'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCountry'].setValidators([Validators.required]);
                this.mForm1.controls['custBillingCountry'].updateValueAndValidity();
            }
        }
        else {
            this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = true;
            this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
            this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        }
    }
    onBackToBillingDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
        this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
    }
    onSameAsBillingDetails(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = this.cAddNewCustomerDetailsReq.custBillingAddress;
            this.cAddNewCustomerDetailsReq.custDeliveryCity = this.cAddNewCustomerDetailsReq.custBillingCity;
            this.cAddNewCustomerDetailsReq.custDeliveryState = this.cAddNewCustomerDetailsReq.custBillingState;
            this.cAddNewCustomerDetailsReq.custDeliveryZip = this.cAddNewCustomerDetailsReq.custBillingZip;
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = this.cAddNewCustomerDetailsReq.custBillingCountry;
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCity = '';
            this.cAddNewCustomerDetailsReq.custDeliveryState = '';
            this.cAddNewCustomerDetailsReq.custDeliveryZip = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = '';
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = false;
        }
    }
    onAddCustomer(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                // this.customer.isAnyCustomerCreate = true;
                this.cModalRef1.hide();
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.mForm1.reset();
                this.onCustomerSelectionClick(this.cCreateNewInvoiceReq.custId);
                this.fetchAllCustomers();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                this.cModalRef.hide();
            }
        }
        else {
            this.cModalRef.hide();
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            this.cModalRef.hide();
        }
    }
    fetchAllCustomers() {
        this.cCustomerSearchReq.searchRegId = this.pInvoiceDataService.regId;
        this.sCustomerService.fetchAllCustomers(this.cCustomerSearchReq)
            .subscribe(pResponse => this.fetchAllCustomerSuccess(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    fetchAllCustomerSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.customer.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cCustomerList = mCommonResponse.data['customerList'];
                this.cCustomerListEdit = mCommonResponse.data['customerList'];
                if (this.sCheck.isNullList(mCommonResponse.data['customerList'])) {
                    this.onFailFetchAllCustomer('');
                }
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.customer.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchAllCustomer(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchAllCustomer(pResMsg) {
        this.customer.landingPgeMsg = this.sLandingPageMsgService.invoiceNoRecMsg;
        this.customer.pageTotalCount = null;
        this.cCustomerList = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
    }
    /*edit*/
    editCancleClick() {
        this.cModalRef1.hide();
        this.customer.selectedCustomer = [];
    }
    onOpenEditPopupClick(template, obj) {
        this.createForm1();
        this.fetchAllCustomers();
        for (let pcustomerList of this.cCustomerListEdit) {
            if (pcustomerList.custId == obj) {
                this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
                this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
                this.cAddNewCustomerDetailsReq.custName = pcustomerList.custName;
                this.cAddNewCustomerDetailsReq.custEmail = pcustomerList.custEmail;
                this.cAddNewCustomerDetailsReq.custMobileNo = pcustomerList.custMobileNo;
                this.cAddNewCustomerDetailsReq.custGstin = pcustomerList.custGstin;
                this.cAddNewCustomerDetailsReq.isBillingDetails = false;
                this.cAddNewCustomerDetailsReq.custBillingAddress = pcustomerList.custBillingAddress;
                this.cAddNewCustomerDetailsReq.custBillingCity = pcustomerList.custBillingCity;
                this.cAddNewCustomerDetailsReq.custBillingZip = pcustomerList.custBillingZip;
                this.cAddNewCustomerDetailsReq.custBillingState = pcustomerList.custBillingState;
                this.cAddNewCustomerDetailsReq.custBillingCountry = pcustomerList.custBillingCountry;
                this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
                this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = false;
                this.cAddNewCustomerDetailsReq.custDeliveryAddress = pcustomerList.custDeliveryAddress;
                this.cAddNewCustomerDetailsReq.custDeliveryCity = pcustomerList.custDeliveryCity;
                this.cAddNewCustomerDetailsReq.custDeliveryState = pcustomerList.custDeliveryState;
                this.cAddNewCustomerDetailsReq.custDeliveryZip = pcustomerList.custDeliveryZip;
                this.cAddNewCustomerDetailsReq.custDeliveryCountry = pcustomerList.custDeliveryCountry;
                this.cAddNewCustomerDetailsReq.action = 'edit';
                this.cAddNewCustomerDetailsReq.custId = pcustomerList.custId + '';
            }
        }
        this.cModalRef1 = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onWindowScroll() {
        const offset = this.window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
        if (offset === 110 || offset >= 110) {
            this.scrolling = true;
        }
        else {
            this.scrolling = false;
        }
    }
    keyUp(ev, ngSelectRef, createNewCust) {
        var inp = String.fromCharCode(ev.keyCode);
        if (ev.keyCode == 13) {
            return false;
        }
        else if (/[a-zA-Z0-9!@#$%^&*(),.?":{}|<>-_/|\+ ]/.test(inp) || ev.keyCode == 8 || ev.keyCode == 46) {
            createNewCust.style.top = ngSelectRef.dropdownPanel._dropdown.clientHeight + 'px';
        }
    }
    openIt(createNewCust) {
        if (this.sCheck.isNotNullList(this.cCustomerList)) {
            if (this.cCustomerList.length <= 1) {
                if (this.events.push({ name: '(open)', value: null }) != null) {
                    createNewCust.style.top = 38 + 'px';
                    createNewCust.style.visibility = 'visible';
                }
            }
            else if (this.cCustomerList.length == 2) {
                if (this.events.push({ name: '(open)', value: null }) != null) {
                    createNewCust.style.top = 76 + 'px';
                    createNewCust.style.visibility = 'visible';
                }
            }
            else if (this.cCustomerList.length == 3) {
                if (this.events.push({ name: '(open)', value: null }) != null) {
                    createNewCust.style.top = 114 + 'px';
                    createNewCust.style.visibility = 'visible';
                }
            }
            else if (this.cCustomerList.length == 4) {
                if (this.events.push({ name: '(open)', value: null }) != null) {
                    createNewCust.style.top = 152 + 'px';
                    createNewCust.style.visibility = 'visible';
                }
            }
            else if (this.cCustomerList.length > 5) {
                if (this.events.push({ name: '(open)', value: null }) != null) {
                    createNewCust.style.top = 190 + 'px';
                    createNewCust.style.visibility = 'visible';
                }
            }
        }
        this.ngSelectNames = true;
    }
    ;
    closeIt(createNewCust) {
        this.arrowDown = false;
        setTimeout(() => {
            this.ngSelectNames = false;
        }, 130);
    }
    ;
    openItTwo(NewTaskItemDiv, itemnumber, list) {
        console.log('====>>>> ', list);
        console.log('-------->>>>>', this.cItemTaskList);
        if (this.cItemTaskList.length <= 1) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 35 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 2) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 70 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 3) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 105 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 4) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 138 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        else if (this.cItemTaskList.length == 5) {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 171 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        else {
            if (this.events.push({ name: '(open)', value: null }) != null) {
                NewTaskItemDiv.style.top = 190 + 'px';
                NewTaskItemDiv.style.visibility = 'visible';
            }
        }
        itemnumber.ngSelectTableRow1 = true;
    }
    ;
    closeItTwo(NewTaskItemDiv, pitemnumber) {
        setTimeout(() => {
            pitemnumber.ngSelectTableRow1 = false;
        }, 130);
    }
    ;
    addTableRow() {
        this.tableRowArr.push('');
    }
    ;
    deleteTableRow() {
        this.tableRowArr.pop();
    }
    ;
    addLineRow() {
        this.addLineArr.push('');
    }
    ;
    deleteLineRow() {
        this.addLineArr.pop();
    }
    ;
    onItemSelect(item, multiSelectDropdown) {
        this.selectedItems.push(item);
        if (this.selectedItems.length == 1) {
            multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems[0].name + '</span>';
        }
        else {
            multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems.length + ' items selected' + '</span>';
        }
    }
    onItemDeselect(deselectItemId, multiSelectDropdown) {
        this.selectedItems.forEach((item, index) => {
            if (item.id === deselectItemId.id) {
                this.selectedItems.splice(index, 1);
                if (this.selectedItems.length == 1) {
                    multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItems[0].name + '</span>';
                }
                else {
                    multiSelectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + 'Select' + '</span>';
                }
            }
        });
    }
    ;
    //end: suhail code
    onBackClick() {
        this.pLocation.back();
    }
    clickOnInvoiceType() {
        this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        if (this.cCreateNewInvoice.simpInv) {
            this.cCreateNewInvoiceReq.invoiceType = 'ItemizedInvoice';
            this.fetchTask(this.cCreateNewInvoiceReq.regId);
            this.createItemizedInvoice();
        }
        else {
            this.cCreateNewInvoiceReq.invoiceType = 'SimpleInvoice';
            this.createSimpleInvoice();
        }
        this.cCreateNewInvoice.itemInv = !this.cCreateNewInvoice.itemInv;
        this.cCreateNewInvoice.simpInv = !this.cCreateNewInvoice.simpInv;
        this.cCreateNewInvoice.InvDesc = !this.cCreateNewInvoice.InvDesc;
        this.cCreateNewInvoice.table = !this.cCreateNewInvoice.table;
    }
    createItemizedInvoice() {
        this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        this.cCreateNewInvoiceReq.dueDate = '';
        this.isItemizedInvoice = true;
        this.mForm.get('Taskitem').enable();
        this.mForm.controls['invoiceAmount'].untouched;
        this.mForm.controls['invoiceAmount'].setValidators(null);
        this.mForm.controls['invoiceAmount'].setValue("");
        this.mForm.controls['invoiceAmount'].disable();
        this.mForm.controls['invoiceAmount'].updateValueAndValidity();
        this.mForm.controls['invoiceDescription'].setValidators([]);
        this.mForm.controls['invoiceDescription'].updateValueAndValidity();
        if (this.pInvoiceDataService.editRequest) {
            if (this.sCheck.isNotNullList(this.mEditData.invoiceDetailsRS3ProcEntity)) {
                this.Taskitem.removeAt(0);
                this.mForm.setControl('Taskitem', this.editTableArrayFunc(this.mEditData.invoiceDetailsRS3ProcEntity));
                this.mForm.updateValueAndValidity();
            }
        }
    }
    createSimpleInvoice() {
        this.cCreateNewInvoiceReq.invoiceCurrency = this.cCreateNewInvoice.invCur[0].value;
        this.cCreateNewInvoice.discountKey = this.cCreateNewInvoiceReq.invoiceCurrency;
        this.mForm.get('Taskitem').disable();
        this.cCreateNewInvoiceReq.emailDesc = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
        this.mForm.controls['invoiceAmount'].enable();
        this.mForm.controls['invoiceDescription'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(500), , InvoiceSettingsValidator.letterSpaceUnderscoreColon,
            InvoiceSettingsValidator.isConsecuSpecialCharDesc, BBValidator.isBlankSpace]);
        this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
        this.mForm.controls['invoiceDescription'].updateValueAndValidity();
        this.isItemizedInvoice = false;
    }
    onInvoiceTypeClick(invoiceType) {
        if (invoiceType == 'Simple') {
            this.mForm.get('Taskitem').disable();
            this.cCreateNewInvoiceReq.emailDesc = this.cCreateNewInvoice.invoiceSettingsList.settingEmailDescription;
            this.mForm.controls['invoiceAmount'].enable();
            this.mForm.controls['emailDesc'].setValidators([Validators.required, Validators.minLength(1), Validators.maxLength(2000), BBValidator.isConsecuSpecialChar]);
            this.mForm.controls['invoiceAmount'].setValidators([Validators.required, Validators.minLength(1), Validators.max(999999999.99), BBValidator.amount, BBValidator.nonZeroAmount]);
            this.mForm.controls['emailDesc'].updateValueAndValidity();
            this.isItemizedInvoice = false;
        }
        else {
            this.isItemizedInvoice = true;
            this.mForm.get('Taskitem').enable();
            this.mForm.controls['invoiceAmount'].untouched;
            this.mForm.controls['invoiceAmount'].setValidators(null);
            this.mForm.controls['invoiceAmount'].setValue("");
            this.mForm.controls['invoiceAmount'].disable();
            this.mForm.controls['invoiceAmount'].updateValueAndValidity();
            this.mForm.controls['emailDesc'].setValidators([]);
            this.mForm.controls['emailDesc'].updateValueAndValidity();
        }
    }
    requiredDiscountIf(event) {
        if (this.cCreateNewInvoiceReq.recurring == 'N') {
            if (this.cCreateNewInvoiceReq.discountIf != '') {
                this.mForm.controls['Discount'].enable();
                this.mForm.controls['DiscountType'].enable();
                this.mForm.controls['Discount'].setValidators([Validators.required, BBValidator.amount]);
                this.mForm.controls['Discount'].updateValueAndValidity();
                this.mForm.controls['dueDate'].enable();
                this.mForm.controls['dueDate'].setValidators([Validators.required]);
                this.mForm.controls['dueDate'].updateValueAndValidity();
                this.cCreateNewInvoice.discountIfRequired = true;
                if ((this.cCreateNewInvoiceReq.discountIf) > this.cCreateNewInvoiceReq.dueDate) {
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = true;
                }
                else {
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = false;
                }
            }
            else {
                this.mForm.controls['dueDate'].disable();
                this.mForm.controls['dueDate'].setValue('');
                this.mForm.controls['dueDate'].setValidators([]);
                this.mForm.controls['Discount'].disable();
                this.mForm.controls['DiscountType'].disable();
                this.mForm.controls['Discount'].setValidators([]);
                this.mForm.controls['Discount'].setValue('');
                this.cCreateNewInvoice.discountIfRequired = false;
            }
        }
        else {
            if (this.cCreateNewInvoiceReq.discountUpto != null || this.cCreateNewInvoiceReq.discountUpto != undefined) {
                this.mForm.controls['Discount'].enable();
                this.mForm.controls['DiscountType'].enable();
                this.mForm.controls['Discount'].setValidators([Validators.required, BBValidator.amount]);
                this.mForm.controls['Discount'].updateValueAndValidity();
                this.mForm.controls['dueUpto'].enable();
                this.mForm.controls['dueUpto'].setValidators([Validators.required]);
                this.mForm.controls['dueUpto'].updateValueAndValidity();
                this.cCreateNewInvoice.discountIfRequired = true;
                if ((this.cCreateNewInvoiceReq.discountUpto) > Number(this.cCreateNewInvoiceReq.dueUpto)) {
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = true;
                }
                else {
                    this.cCreateNewInvoice.discountIfIsMoreThanValid = false;
                }
            }
            else {
                this.mForm.controls['Discount'].disable();
                this.mForm.controls['DiscountType'].disable();
                this.mForm.controls['Discount'].setValidators([]);
                this.mForm.controls['Discount'].setValue('');
                this.mForm.controls['dueUpto'].setValidators([]);
                this.mForm.controls['dueUpto'].clearValidators();
                this.mForm.controls['dueUpto'].updateValueAndValidity();
                this.cCreateNewInvoice.discountIfRequired = false;
            }
            //dicountif is used to pass date for bill_discountDateTime
            var datePipe = new DatePipe('en-US');
            var d = this.cCreateNewInvoiceReq.startDate.split("/");
            this.date1 = new Date(+d[2], +d[1] - 1, +d[0]);
            if (this.cCreateNewInvoiceReq.validitytype == 'hours') {
                this.date1.setHours(this.date1.getHours() + this.cCreateNewInvoiceReq.discountUpto);
                this.cCreateNewInvoiceReq.discountIf = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
            if (this.cCreateNewInvoiceReq.validitytype == 'minutes') {
                this.date1.setMinutes(this.date1.getMinutes() + this.cCreateNewInvoiceReq.discountUpto);
                this.cCreateNewInvoiceReq.discountIf = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
            if (this.cCreateNewInvoiceReq.validitytype == 'days') {
                this.date1.setDate(this.date1.getDate() + (+this.cCreateNewInvoiceReq.discountUpto));
                this.cCreateNewInvoiceReq.discountIf = datePipe.transform(this.date1, 'dd/MM/yyyy');
            }
        }
    }
    requiredDiscount(event) {
        if (this.cCreateNewInvoiceReq.discount > 0) {
            this.cCreateNewInvoice.discountRequired = true;
        }
        else {
            this.cCreateNewInvoice.discountRequired = false;
        }
    }
    ngAfterViewChecked() {
        this.sRef.detectChanges();
    }
    checkMerchantRefno(event) {
        this.mForm['controls'].merchantParamsitem1['controls'].forEach((item, index) => {
            for (let control in item.controls) {
                if (index < 2) {
                    item.controls.merchantReferenceNo.setValidators([]);
                    item.controls.merchantReferenceNo.updateValueAndValidity();
                }
                if (typeof item.controls.merchantReferenceNo.value != 'undefined' && item.controls.merchantReferenceNo.value != '' && item.controls.merchantReferenceNo.value != null) {
                    item.controls.merchantReferenceNo.setValidators([BBValidator.invoiceMerRefNum, Validators.minLength(3), Validators.maxLength(50)]);
                    item.controls.merchantReferenceNo.updateValueAndValidity();
                }
            }
            ;
        });
    }
    //Start: task and item functionality
    createTaskForm() {
        this.mTaskForm = this.pFormBuilder.group({
            itemName: ['', [
                    Validators.required,
                    Validators.maxLength(30),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.letterNumberAndSpaceOnly,
                ]],
            itemDescription: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharDesc,
                    InvoiceSettingsValidator.promotionDescription,
                    InvoiceSettingsValidator.isConsecuSpecialChar
                ]],
            rates: this.buildTaskArray()
        });
    }
    onOpenTaskPopupClick(template) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.cTaskModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.createTaskForm();
    }
    onCurrencyClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
        }
    }
    onCurrencyClickNewRow(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        this.cCurrencyIndex = index;
        if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') != -1) {
            this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value'), 1);
            this.cCurrencyLeftFlag = false;
        }
        if (this.cCurrencyList.length != 0 && this.sCheck.isNotNullString(this.currAmtArray.value[index]['currency'])) {
            this.cCurrencyLeftFlag = true;
        }
    }
    get currAmtArray() { return this.mTaskForm.get('rates'); }
    buildTaskArray() {
        this.rates = this.pFormBuilder.array([
            this.buildTaskGroup()
        ]);
        return this.rates;
    }
    buildTaskGroup() {
        return this.pFormBuilder.group({
            currency: [null],
            price: ['']
        });
    }
    buildTaskGroup1() {
        return this.pFormBuilder.group({
            currency: [null, Validators.required],
            price: ['', [Validators.required, Validators.min(1), Validators.max(999999999.99)]]
        });
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onPriceClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            this.currAmtArray.controls[index].get('price').markAsTouched();
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
            this.currAmtArray.controls[index].get('currency').clearValidators();
            this.currAmtArray.controls[index].get('currency').setValidators([Validators.required]);
            this.currAmtArray.controls[index].get('currency').markAsTouched();
            this.currAmtArray.controls[index].get('currency').updateValueAndValidity();
        }
    }
    onBlur(event, index) {
        if (event) {
            if (this.currAmtArray.controls[index].get('price').value != null) {
                let value = +this.currAmtArray.controls[index].get('price').value;
                this.currAmtArray.controls[index].get('price').setValue(value.toFixed(2));
            }
        }
    }
    onDeleteCurrencyClick(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        if (curr != null && curr != '') {
            if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') == -1) {
                this.cCurrencyList.push({ "label": curr, "value": curr });
            }
        }
        this.cRatesLength = this.rates.length;
        if (this.cCurrencyList.length != 0 && this.sCheck.isNotNullObject(this.currAmtArray.value[index - 1]) && this.sCheck.isNotNullString(this.currAmtArray.value[index - 1]['currency']) && this.sCheck.isNotNullNumber(this.currAmtArray.value[index - 1]['price']) && this.currAmtArray.value[index - 1]['price'] != '0.00') {
            this.cCurrencyLeftFlag = true;
        }
        if (this.cRatesLength == 1 || this.cRatesLength == 0) {
            this.rates.push(this.createItem(null, ''));
            this.cCurrencyLeftFlag = false;
        }
        this.rates.removeAt(index);
        this.cRatesLength = this.rates.length;
        this.cCurrencyIndex = this.cCurrencyIndex - 1;
    }
    onAddCurrencyClick() {
        if (!this.cEditCall) {
            this.currAmtArray.controls[this.cCurrencyIndex].get('price').markAsTouched();
            this.currAmtArray.controls[this.cCurrencyIndex].get('price').updateValueAndValidity();
            if (this.currAmtArray.value[this.cCurrencyIndex]['price'] != null && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '' && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '0.00') {
                this.rates.push(this.buildTaskGroup1());
                this.cCurrencyIndex = this.cCurrencyIndex + 1;
                this.cRatesLength = this.rates.length;
                this.cCurrencyLeftFlag = false;
            }
        }
        else {
            this.rates.push(this.buildTaskGroup1());
            this.cCurrencyIndex = this.cCurrencyIndex + 1;
            this.cRatesLength = this.rates.length;
            this.cCurrencyLeftFlag = false;
            this.cEditCall = false;
        }
    }
    arrayObjectIndexOf(pArray, pSearchTerm, pProperty) {
        for (var i = 0, len = pArray.length; i < len; i++) {
            if (pArray[i][pProperty] === pSearchTerm)
                return i;
        }
        return -1;
    }
    createItem(curr, price) {
        return this.pFormBuilder.group({
            currency: [curr],
            price: [price]
        });
    }
    onCreateTasksItemsClick(value) {
        if (this.mTaskForm.valid) {
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            if (this.itemNameArray.indexOf(this.cEditNewTaskAndItemsReq.itemName) > -1) {
                this.cEditNewTaskAndItemsReq.itemId = 0;
            }
            this.cEditNewTaskAndItemsReq.regId = Number(this.cEditNewTaskAndItemsReq.regId);
            this.pTasksItemsService.addInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cTaskModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mTaskForm);
        }
    }
    taskSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cTaskAndItems.selectedTaskAndItems = [];
                //will fetch currency specific task
                this.cCurrencyIndex = -1;
                this.cCurrencyLeftFlag = false;
                this.cRatesLength = -1;
                this.onSelectCurrency();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
    }
    onSearchClick() {
        if (this.mSearchForm.valid) {
            this.cTaskAndItemsReq.regId = Number(this.pInvoiceDataService.regId);
            this.pTasksItemsService.fetchAllInvoiceSettings(this.cTaskAndItemsReq)
                .subscribe(rResponse => this.fetchAllTaskAndItemsSuccess(rResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.mSearchForm);
        }
    }
    fetchAllTaskAndItemsSuccess(pResponse) {
        this.itemNameArray = [];
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cTaskAndItems.totalCount = mCommonResponse.data['totalCount'];
                    this.cTaskAndItemsProcEntity = mCommonResponse.data['invoiceTaskItemList'];
                    for (let procEntity of this.cTaskAndItemsProcEntity) {
                        if (procEntity.itemUnitCost != null) {
                            let unitCost = procEntity.itemUnitCost.split("#");
                            unitCost.splice(0, 1);
                            procEntity.currency = [];
                            procEntity.price = [];
                            for (let cost of unitCost) {
                                let unit = cost.split("$");
                                procEntity.currency.push(unit[0]);
                                procEntity.price.push(unit[1]);
                            }
                            this.itemNameArray.push(procEntity.itemName);
                        }
                    }
                    if (!this.sResponsiveService.isCancelResponsive()) {
                        this.cTaskAndItems.isSearchPanelClick = false;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cTaskAndItems.isSearchPanelClick = false;
                }
            }
            else {
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cTaskAndItems.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
            this.cTaskAndItems.totalCount = null;
            this.cTaskAndItemsProcEntity = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cTaskAndItems.isSearchPanelClick = false;
            }
        }
    }
    onItemNameClick() {
        this.mTaskForm.controls['itemName'].setAsyncValidators(this.checkeTaskAvailability.bind(this));
    }
    checkeTaskAvailability(control) {
        if (!control.value) {
            return null;
        }
        this.cEditNewTaskAndItemsReq.regId = Number(this.pInvoiceDataService.regId);
        return this.pTasksItemsService.checkeTaskAvailability(this.cEditNewTaskAndItemsReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkeTaskAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkeTaskAvailability': true };
                }
            }
            else {
                return { 'checkeTaskAvailability': true };
            }
        });
    }
    onOpenTaskEditPopupClick(template, obj) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.createTaskForm();
        this.cCurrLength = this.cCurrencyList.length;
        this.cEditCall = true;
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.cEditNewTaskAndItemsReq.itemName = obj.itemName;
        this.cEditNewTaskAndItemsReq.itemDescription = obj.itemDescription;
        this.cEditNewTaskAndItemsReq.itemUnitCost = obj.itemUnitCost;
        this.cEditNewTaskAndItemsReq.itemId = obj.itemId;
        this.clearArray();
        if (obj.itemCurrency != null && obj.itemCurrency != '') {
            this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, obj.itemCurrency, 'value'), 1);
            this.rates.push(this.createItem(obj.itemCurrency, obj.itemUnitCost));
            this.cRatesLength = this.rates.length;
        }
        else {
            this.rates.push(this.createItem('', ''));
            this.cRatesLength = 0;
        }
        this.cTaskModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        if (this.cCurrencyList.length != 0)
            this.cCurrencyLeftFlag = true;
        else
            this.cCurrencyLeftFlag = false;
    }
    clearArray() {
        while (this.rates.length) {
            this.rates.removeAt(0);
        }
    }
    onUpdateTasksItemsClick(value) {
        if (this.mTaskForm.valid) {
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '' && c != '0') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            this.cEditNewTaskAndItemsReq.regId = Number(this.pInvoiceDataService.regId);
            this.pTasksItemsService.updateInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cTaskModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mTaskForm);
        }
    }
    //End: task and item functionality
    // public removeEndSpecialChar(val : any) : string
    // {
    //     let reg_exp = /[a-zA-Z0-9\s\>\)\.\:]$/;
    //     if(!val){
    //         return null;
    //     }
    //     while( reg_exp.test(val))
    //     {return val.splice(val.length-1); 
    //     }
    //     return val
    // }
    onEmailIdClick() {
        this.mForm1.controls['custEmail'].setAsyncValidators(this.checkEmailAvailability.bind(this));
    }
    onMobileNoClick() {
        this.mForm1.controls['custMobileNo'].setAsyncValidators(this.checkMobileAvailability.bind(this));
    }
    checkEmailAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.checkEmailAvailability(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkEmailAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkEmailAvailability': true };
                }
            }
            else {
                return { 'checkEmailAvailability': true };
            }
        });
    }
    checkMobileAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.checkMobileAvailability(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkMobileAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkMobileAvailability': true };
                }
            }
            else {
                return { 'checkMobileAvailability': true };
            }
        });
    }
    onGSTINClick() {
        this.mForm1.controls['custGstin'].setAsyncValidators(this.isDuplicateGSTN.bind(this));
    }
    isDuplicateGSTN(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.isDuplicateGSTN(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'isDuplicateGSTN': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'isDuplicateGSTN': true };
                }
            }
            else {
                return { 'isDuplicateGSTN': true };
            }
        });
    }
};
tslib_1.__decorate([
    HostListener("window:scroll", []),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], CreateNewInvoiceComponent.prototype, "onWindowScroll", null);
CreateNewInvoiceComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-create-new-invoice',
        templateUrl: './create-new-invoice.component.html',
        styleUrls: ['./create-new-invoice.component.css'],
        preserveWhitespaces: true,
        animations: [
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 }),
            trigger('fadeInOut', [
                transition(':enter', [
                    style({ transform: 'translateY(-10%)' }),
                    animate('300ms ease-in', style({ transform: 'translateY(0%)' }))
                ]),
                transition(':leave', [
                    animate('300ms ease-in', style({ transform: 'translateY(-10%)' }))
                ])
            ])
        ]
    }),
    tslib_1.__param(6, Inject(DOCUMENT)),
    tslib_1.__param(7, Inject(WINDOW)),
    tslib_1.__metadata("design:paramtypes", [PrivilegeService,
        CustomerService,
        InvoiceDataService,
        TransactionsService,
        ResponsiveService,
        Router,
        Document,
        Window,
        InvoiceService,
        TasksItemsService,
        TitleService,
        ApiRequestService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ActivatedRoute,
        Location,
        Router,
        ChangeDetectorRef,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        DatePipe])
], CreateNewInvoiceComponent);
export { CreateNewInvoiceComponent };
//# sourceMappingURL=create-new-invoice.component.js.map