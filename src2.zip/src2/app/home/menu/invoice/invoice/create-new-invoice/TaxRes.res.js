export class TaxRes {
    constructor() {
        this.taxName = "";
    }
}
//# sourceMappingURL=TaxRes.res.js.map