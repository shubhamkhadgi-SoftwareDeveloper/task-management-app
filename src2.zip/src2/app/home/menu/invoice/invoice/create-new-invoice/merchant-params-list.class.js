export class MerchantParamsList {
}
//# sourceMappingURL=merchant-params-list.class.js.map