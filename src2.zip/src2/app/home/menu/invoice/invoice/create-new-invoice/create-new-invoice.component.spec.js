import { async, TestBed } from '@angular/core/testing';
import { CreateNewInvoiceComponent } from './create-new-invoice.component';
describe('CreateNewInvoiceComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [CreateNewInvoiceComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CreateNewInvoiceComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=create-new-invoice.component.spec.js.map