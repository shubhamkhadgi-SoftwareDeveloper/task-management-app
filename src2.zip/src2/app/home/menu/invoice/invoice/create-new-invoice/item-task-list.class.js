export class ItemTaskList {
    constructor() {
        this.itemName = "";
        this.itemUnitCost = null;
        this.taxCal1 = 0;
        this.taxCal2 = 0;
        this.txCalculation = 0;
        this.editClicked2 = false;
        this.ngSelectTableRow1 = false;
    }
}
//# sourceMappingURL=item-task-list.class.js.map