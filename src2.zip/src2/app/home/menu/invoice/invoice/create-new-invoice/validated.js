export class BBValidator {
    static isBeginSpecialChar(control) {
        let reg_exp = /^[a-zA-Z0-9\s]/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isBeginSpecialChar': true };
    }
    static isEndSpecialChar(control) {
        let reg_exp = /[a-zA-Z0-9\s\>\)\.\:]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialChar': true };
    }
    static isConsecuSpecialChar(control) {
        let reg_exp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\/\/|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isConsecuSpecialChar': true };
    }
    static fullName(control) {
        let reg_exp = /^[a-zA-Z\\s\\s\s\\.\\'\\n]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'fullName': true };
    }
    static CusomerName(control) {
        let reg_exp = /^([a-zA-Z0-9\s\.]+('?)[a-zA-Z\s\.]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'CusomerName': true };
    }
    static leastOneChar(control) {
        let reg_exp = /(?=.*[a-zA-Z])/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'leastOneChar': true };
    }
    static email(control) {
        let reg_exp = /^[\s]*([a-zA-Z0-9]+[\-\._]?)+[a-zA-Z0-9]+@{1}[a-zA-Z\d]+[a-zA-Z\d_\-]+(\.[a-zA-Z_\\-]+)+[\s]*$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'email': true };
    }
    static emailSub(control) {
        let reg_exp = /^[a-zA-Z0-9\s._-]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'emailSub': true };
    }
    static emailDesc(control) {
        let reg_exp = /^(?:(?!(\/\*|\\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'emailDesc': true };
    }
    static numbersOnly(control) {
        let reg_exp = /^[0-9]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'numbersOnly': true };
    }
    static amount(control) {
        let reg_exp = /^((\d)*(\.)?(\d)+)$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'amount': true };
    }
    static invoiceMerRefNum(control) {
        let reg_exp = /^([0-9a-zA-Z]+|[_,-]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'invoiceMerRefNum': true };
    }
    static phone(control) {
        let reg_exp = /^(\+\d{1,3}[- ]?)?\d{10}$/; // ^[\d\s\-]+$/ ; //
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'phone': true };
    }
    static isEndSpecialCharForAddr(control) {
        let reg_exp = /[a-zA-Z0-9\.\)\n\s]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialCharForAddr': true };
    }
    static isBlankSpace(control) {
        if (!control.value) {
            return null;
        }
        return control.value.trim() != '' ? null : { 'isBlankSpace': true };
    }
    static isConsecuSpecialCharInvoice(control) {
        let reg_exp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isConsecuSpecialCharInvoice': true };
    }
    static termsConditionInv(control) {
        let reg_exp = /^[0-9a-zA-Z\s\(\)\#@\.,_\-&\n\/:]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'termsConditionInv': true };
    }
    static percentages(control) {
        let reg_exp = /^(\d{1,2}\.\d{1,2}|\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'percentages': true };
    }
    static nonZeroNumber(control) {
        let reg_exp = /^[0-9]\d*$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'nonZeroNumber': true };
    }
    static nonZeroQuantity(control) {
        let reg_exp = /^[1-9]\d*$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'nonZeroQuantity': true };
    }
    static invalidValidiType(control) {
        let validityTyep = ['Days', 'Minutes', 'Hours'];
        if (!control.value) {
            return null;
        }
        return validityTyep.find(control.value) ? null : { 'invalidValidiType': true };
    }
    static smsContent(control) {
        let reg_exp = /^[a-zA-Z0-9\\s\\s\s\\_\-\#\\n\\:\\.]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'smsContent': true };
    }
    static itemDesc(control) {
        let reg_exp = /^[0-9a-zA-Z]+[0-9a-zA-Z\\s\\s\s\\(\\)\\#\\.,_\-\\&\\@\\n\\:]+[0-9a-zA-Z]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'itemDesc': true };
    }
    static nonZeroAmount(control) {
        if (!control.value) {
            return null;
        }
        return control.value > 0 ? null : { 'nonZeroAmount': true };
    }
    static nonZeroAmountForDueUpto(control) {
        let reg_exp = /^[0-9a-zA-Z]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'nonZeroAmountForDueUpto': true };
    }
    static eitherMobileOrEmail(control) {
        console.log(control);
        let reg_exp = /^[0-9]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'numbersOnly': true };
    }
    static gstNo(control) {
        let reg_exp = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/; ///^([0-9]){2}([a-zA-Z0-9]){13}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'gstNo': true };
    }
    static customerCity(control) {
        let reg_exp = /^[a-zA-Z][a-zA-Z\s-]+[a-zA-Z]$/; ///^([0-9]){2}([a-zA-Z0-9]){13}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerCity': true };
    }
    static customerPin(control) {
        // let reg_exp =  /^(\+\d{1,3}[- ]?)?\d{10}$/; // ^[\d\s\-]+$/ ; //
        let reg_exp = /^[0-9]{6}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerPin': true };
    }
    static customerState(control) {
        let reg_exp = /^[a-zA-Z][a-zA-Z\s-]+[a-zA-Z]$/; ///^([0-9]){2}([a-zA-Z0-9]){13}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerState': true };
    }
    static customerCountry(control) {
        let reg_exp = /^[a-zA-Z][a-zA-Z\s-]+[a-zA-Z]$/; ///^([0-9]){2}([a-zA-Z0-9]){13}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerCountry': true };
    }
    static customerAddress(control) {
        // const mRegExp :RegExp = /^([0-9a-zA-Z \(\)\s#\.]+|[#,-]*)+$/i;
        const mRegExp = /^([0-9a-zA-Z \(\)\s#\/\.]+|[#,-]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customerAddress': true };
    }
    static customerPhone(control) {
        // let reg_exp =  /^(\+\d{1,3}[- ]?)?\d{10}$/; // ^[\d\s\-]+$/ ; //
        let reg_exp = /^[7-9][0-9]{9}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerPhone': true };
    }
}
//# sourceMappingURL=validated.js.map