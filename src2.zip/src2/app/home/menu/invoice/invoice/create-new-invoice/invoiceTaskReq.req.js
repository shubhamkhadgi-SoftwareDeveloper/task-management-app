export class InvoiceTaskReq {
}
//# sourceMappingURL=invoiceTaskReq.req.js.map