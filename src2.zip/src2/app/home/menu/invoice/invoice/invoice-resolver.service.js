import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Router } from '@angular/router';
import { InvoiceSearchReq } from './invoice-search.req';
import { InvoiceService } from './invoice.service';
import { DatePipe } from '@angular/common';
let InvoiceResolverService = class InvoiceResolverService {
    constructor(sInvoiceService, sRouter, datepipe) {
        this.sInvoiceService = sInvoiceService;
        this.sRouter = sRouter;
        this.datepipe = datepipe;
    }
    resolve(route, state) {
        let mInvoiceSearchReq = new InvoiceSearchReq();
        return this.sInvoiceService.fetchAllInvoice(mInvoiceSearchReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
InvoiceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [InvoiceService,
        Router,
        DatePipe])
], InvoiceResolverService);
export { InvoiceResolverService };
//# sourceMappingURL=invoice-resolver.service.js.map