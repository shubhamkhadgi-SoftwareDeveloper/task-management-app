export class RecurringOcurredDetailsReq {
}
//# sourceMappingURL=recurring-ocurred-details.req.js.map