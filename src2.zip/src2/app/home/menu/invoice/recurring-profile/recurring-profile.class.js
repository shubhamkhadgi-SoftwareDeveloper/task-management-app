import { DatePipe } from "@angular/common";
export class RecurringProfile {
    constructor() {
        this.isAllRecurringProfileCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.selectedInvoices = [];
        this.refferArray = [];
        this.searchByLabel = "Search By";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: null });
        this.searchBy.push({ label: 'Recurring Profile #', value: 'searchInvNo' });
        this.searchBy.push({ label: 'Email ID', value: 'searchInvEmail' });
        this.cRecurringStatusList = [];
        this.cRecurringStatusList.push({ label: 'Active', value: 'ACTI' });
        this.cRecurringStatusList.push({ label: 'Inactive', value: 'INAC' });
        this.cRecurringFrequencyList = [];
        this.cRecurringFrequencyList.push({ label: 'Daily', value: 'Daily' });
        this.cRecurringFrequencyList.push({ label: 'Monthly', value: 'Monthly' });
        this.cRecurringFrequencyList.push({ label: 'Quarterly', value: 'Quarterly' });
        this.cRecurringFrequencyList.push({ label: 'Yearly', value: 'Yearly' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            showDropdowns: true,
            dateLimit: {
                days: 30
            }
        };
        this.maxSearchDateTo = new Date();
        var datePipe = new DatePipe('en-US');
        let startDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        let endDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.fromToDate = startDate + '-' + endDate;
        this.currDate = new Date();
        this.isAnyRecurringProfCreated = true;
    }
}
//# sourceMappingURL=recurring-profile.class.js.map