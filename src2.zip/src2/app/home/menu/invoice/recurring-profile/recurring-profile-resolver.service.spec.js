import { TestBed, inject } from '@angular/core/testing';
import { RecurringProfileResolverService } from './recurring-profile-resolver.service';
describe('RecurringProfileResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RecurringProfileResolverService]
        });
    });
    it('should be created', inject([RecurringProfileResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=recurring-profile-resolver.service.spec.js.map