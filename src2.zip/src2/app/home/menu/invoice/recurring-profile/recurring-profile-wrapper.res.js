export class RecurringProfileWrapperRes {
}
//# sourceMappingURL=recurring-profile-wrapper.res.js.map