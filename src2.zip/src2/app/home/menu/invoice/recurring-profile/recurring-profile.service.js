import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let RecurringProfileService = class RecurringProfileService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseRecurringProfileUrl = 'recurringProfile/';
        this.cFetchReccuringInvListUrl = this.cBaseRecurringProfileUrl + 'fetchReccuringInvList';
        this.cUpdateRecInvStatusUrl = this.cBaseRecurringProfileUrl + 'updRecInvStatus';
        this.cExportExcelRecInvUrl = this.cBaseRecurringProfileUrl + 'exportExcelRecInv';
        this.cFetchRecOccurredDetailsOnSearchUrl = this.cBaseRecurringProfileUrl + 'fetchRecOccurredDetailsOnSeach';
        this.cDelRecInvStatusUrl = this.cBaseRecurringProfileUrl + 'delRecInv';
        this.cExportExcelInvUrl = this.cBaseRecurringProfileUrl + 'exportExcelInv';
    }
    fetchReccuringInvList(pRecurringProfileReq) {
        return this.pApiRequestService.httpPostRequest(pRecurringProfileReq, this.cFetchReccuringInvListUrl);
    }
    updateRecInvStatus(pRecurringProfileUpdReq) {
        return this.pApiRequestService.httpPostRequest(pRecurringProfileUpdReq, this.cUpdateRecInvStatusUrl);
    }
    exportExcelRecInv(pRecurringProfileReq) {
        return this.pApiRequestService.exportFileRequest(pRecurringProfileReq, this.cExportExcelRecInvUrl, 'RecurringInvoiceDetails.xlsx');
    }
    fetchRecOccurredDetailsOnSearch(pRecurringOcurredDetailsReq) {
        return this.pApiRequestService.httpPostRequest(pRecurringOcurredDetailsReq, this.cFetchRecOccurredDetailsOnSearchUrl);
    }
    deleteRecInv(pRecurringProfileReq) {
        return this.pApiRequestService.httpPostRequest(pRecurringProfileReq, this.cDelRecInvStatusUrl);
    }
    exportExcelInv(pRecurringOcurredDetailsReq) {
        return this.pApiRequestService.exportFileRequest(pRecurringOcurredDetailsReq, this.cExportExcelInvUrl, 'InvoiceDetails.xlsx');
    }
};
RecurringProfileService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], RecurringProfileService);
export { RecurringProfileService };
//# sourceMappingURL=recurring-profile.service.js.map