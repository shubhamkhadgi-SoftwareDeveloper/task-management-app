export class RecurringProfileRes {
}
//# sourceMappingURL=recurring-profile.res.js.map