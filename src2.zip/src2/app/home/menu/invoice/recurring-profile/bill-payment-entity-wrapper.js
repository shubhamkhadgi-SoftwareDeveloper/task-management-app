export class BillPaymentWrapper {
}
//# sourceMappingURL=bill-payment-entity-wrapper.js.map