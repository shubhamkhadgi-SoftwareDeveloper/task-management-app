export class RecurringProfileUpdReq {
}
//# sourceMappingURL=recurring-profile-upd.req.js.map