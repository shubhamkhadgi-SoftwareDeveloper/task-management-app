export class RecurringOcurredDetails {
}
//# sourceMappingURL=recurring-ocurred-details.res.js.map