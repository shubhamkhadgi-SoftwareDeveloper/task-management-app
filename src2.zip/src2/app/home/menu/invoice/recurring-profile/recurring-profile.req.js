export class RecurringProfileReq {
    constructor() {
        this.pageNumber = 1;
        this.pageSize = 25;
    }
}
//# sourceMappingURL=recurring-profile.req.js.map