export class RecurringDetailSearch {
}
//# sourceMappingURL=recurring-detail-search.req.js.map