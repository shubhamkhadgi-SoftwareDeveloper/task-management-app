import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { RecurringProfileWrapperRes } from '../recurring-profile-wrapper.res';
import { InvoiceService } from '../../../invoice/invoice/invoice.service';
import { Invoice } from '../../../invoice/invoice/invoice.class';
import { RecurringOcurredDetailsSearchReq } from './recurring-ocurred-details-search-req';
import { RecurringDetailSearch } from './recurring-detail-search.req';
import { Router } from '@angular/router';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '.././../../../../common-services/error-handler.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from '../../../../../common-services/landing-page-msg.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { BsModalService } from 'ngx-bootstrap/modal';
import { RecurringProfileService } from '../recurring-profile.service';
import { RecurringOcurredDetailsReq } from '../recurring-ocurred-details.req';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { DOCUMENT } from "@angular/common";
import { InvoiceDataService } from "../../invoice/InvoiceDataService";
let RecurringOccurrencesDetailsComponent = class RecurringOccurrencesDetailsComponent {
    //***********************************************Constructor*******************************************//
    constructor(pApiRequestService, pMerchInfoService, pInvoiceDataService, route, pInvoiceService, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, pFormBuilder, pModalService, sRecurringProfileService, sDocument) {
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pInvoiceDataService = pInvoiceDataService;
        this.route = route;
        this.pInvoiceService = pInvoiceService;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.pFormBuilder = pFormBuilder;
        this.pModalService = pModalService;
        this.sRecurringProfileService = sRecurringProfileService;
        this.sDocument = sDocument;
        this.backBtnEvent = new EventEmitter();
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.previewInvoiceEvent = new EventEmitter();
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.searchflag = 'searchform';
        this.cCommonResponse = new CommonResponse();
        this.cRecurringOcurredDetailsSearchReq = new RecurringOcurredDetailsSearchReq();
        this.searchByLabel = 'Search By';
        this.searchBy = [];
        //this.searchBy.push({ label: 'Search By', value: null });
        this.searchBy.push({ label: 'Invoice #', value: 'searchInvNo' });
        this.searchBy.push({ label: 'Email ID', value: 'searchCustEmail' });
        this.searchBy.push({ label: 'Mobile No #', value: 'searchCustMobile' });
        this.cRecPayStatusList = [];
        this.cRecPayStatusList.push({ label: 'Successful', value: 'Successful' });
        this.cRecPayStatusList.push({ label: 'Pending', value: 'Pending' });
        this.cRecPayStatusList.push({ label: 'Cancelled', value: 'Cancelled' });
        this.cRecPayStatusList.push({ label: 'Expired', value: 'Expired' });
        this.cInvoice = new Invoice();
        this.cRecurringDetailSearch = new RecurringDetailSearch();
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
            showDropdowns: true,
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchByValue'].disable();
        window.scrollTo(0, 0);
        this.onSearchClick();
    }
    //**************************************************Mouse Event***********************************************//
    // History Panel
    mouseleaveActionEvent() {
        this.actionPanel = false;
    }
    mouseenterTimePanelEvent() {
        this.timePanel = true;
    }
    mouseleaveTimePanelEvent() {
        this.timePanel = false;
    }
    //*****************************Validations********************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchBy: [''],
            searchByValue: [''],
            fromToDate: [''],
            searchSubAccId: [''],
            searchInvCurr: [''],
            searchPayStatus: [''],
            searchMerchId: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    //***********************************************Button Click Event*******************************************//
    onExportClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        this.isExportClick = !this.isExportClick;
    }
    onExportExcelClick() {
        this.isExportClick = !this.isExportClick;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        this.cRecurringDetailSearch.regId = this.cRecurringOcurredDetailsReq.regId;
        this.cRecurringDetailSearch.billId = this.cRecurringOcurredDetailsReq.billId;
        //this.pApiRequestService.exportFileRequest( this.cRecurringDetailSearch, 'exportExcelInv', 'InvoiceDetails.xlsx' )
        this.sRecurringProfileService.exportExcelInv(this.cRecurringDetailSearch)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSearchPanelClick() {
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onSearchByClick() {
        this.isSearchByClick = !this.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.isSearchByClick = false;
    }
    onSearchByOptionClick() {
        this.isSearchByClick = !this.isSearchByClick;
        if (this.cRecurringDetailSearch.searchBy == 'searchInvNo') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringDetailSearch.searchBy == 'searchCustEmail') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringDetailSearch.searchBy == 'searchCustMobile') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, InvoiceSettingsValidator.mobile]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onCalenderIconClick(dpReccurProf) {
        dpReccurProf.click();
    }
    onSearchClick() {
        this.cRecurringDetailSearch.regId = this.cRecurringOcurredDetailsReq.regId;
        this.cRecurringDetailSearch.billId = this.cRecurringOcurredDetailsReq.billId;
        if (this.mForm.valid) {
            if (this.searchflag == 'searchform') {
                this.cRecurringDetailSearch.pageNumber = 1;
            }
            //this.pApiRequestService.httpPostRequest( this.cRecurringDetailSearch, 'fetchRecOccurredDetailsOnSeach' )
            this.sRecurringProfileService.fetchRecOccurredDetailsOnSearch(this.cRecurringDetailSearch)
                .subscribe(rResponse => this.OccurredCountSuccess(rResponse), error => { console.log('error'); });
            this.searchflag = 'searchform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onCancelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.cRecurringDetailSearch = new RecurringDetailSearch();
        this.cRecurringDetailSearch.searchBy = 'Search By';
        this.calOptions = {
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
            showDropdowns: true,
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.onSearchClick();
    }
    onBackDetailClick() {
        this.cPreviewInvoiceDetailRes = null;
        this.cInvoiceDetailRes = null;
        if (this.cInvoice.isInvoiceDetailClick) {
            this.cInvoice.isInvoiceDetailClick = false;
        }
        else {
            this.backBtnEvent.emit(false);
        }
    }
    onInvoiceDetailClick(pInvoiceNo, regId) {
        this.cInvoiceDetailRes = null;
        this.pInvoiceService.fetchInvoiceDetail({ 'invoiceNo': pInvoiceNo, 'regId': regId })
            .subscribe(pResponse => this.fetchInvoiceDetailSuccess(pResponse), error => { console.log("error-->" + JSON.stringify(error)); });
    }
    PreviewClick(pRegId, pInvoiceNo, pPaymentStatus) {
        this.pInvoiceDataService.regId = pRegId;
        this.pInvoiceDataService.invoiceNo = pInvoiceNo;
        this.pInvoiceDataService.paymentStatus = pPaymentStatus;
        this.route.navigate(['home/menu/invoice/invoice/previewInvoice']);
    }
    onActionClick(pIndex, pInvoiceLogList) {
        this.actionIndex = pIndex;
        this.actionPanel = true;
        this.invoiceDateTime = [];
        if (pInvoiceLogList != null) {
            let mSplitInvLog = pInvoiceLogList.split(",");
            for (let pInvLog of mSplitInvLog) {
                pInvLog = pInvLog.trim();
                let mDateTime = { date: "", time: "" };
                mDateTime.date = pInvLog.substr(0, pInvLog.length - 8).trim();
                mDateTime.time = pInvLog.substr(pInvLog.length - 8, pInvLog.length).trim();
                this.invoiceDateTime.push(mDateTime);
            }
        }
    }
    onSendMailClick(event) {
        this.pInvoiceService.resendInvoice(event)
            .subscribe(pResponse => this.resendInvoiceSuccess(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    onSingleCancelClick(pBillAndRegId) {
        this.cInvoice.isSelActionClick = false;
        this.pInvoiceService.cancelInvoice({ "billId": [pBillAndRegId] })
            .subscribe(pResponse => this.cancelInvoiceSuccess(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cRecurringDetailSearch.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cRecurringDetailSearch.searchToDate = value.end.format("DD-MM-YYYY");
        this.fromToDate = this.cRecurringDetailSearch.searchFromDate + ' - ' + this.cRecurringDetailSearch.searchToDate;
    }
    onPopupCancelClick(pBillAndRegId, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cBillAndRegId = pBillAndRegId;
    }
    onCancelConfirmClick() {
        this.onSingleCancelClick(this.cBillAndRegId);
    }
    /************************Server Call Event******************************************/
    OccurredCountSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cRecurringOccDetails = mCommonResponse.data['mBillPayment'];
                this.totalcount = mCommonResponse.data.totalCount;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cRecurringOccDetails = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else {
                this.cRecurringOccDetails = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.cRecurringOccDetails = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.isSearchPanelClick = false;
            }
        }
    }
    fetchInvoiceDetailSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cInvoiceDetailRes = mCommonResponse.data;
                if (this.sCheck.isNotNullObject(this.cInvoiceDetailRes) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity)) {
                    this.cInvoice.isInvoiceDetailClick = true;
                    this.cInvoice.isActiveForInvoiceDetail = true;
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    previewInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPreviewInvoiceDetailRes = mCommonResponse.data;
                this.cInvoice.isInvoiceDetailClick = true;
                this.cInvoice.isActiveForInvoiceDetail = false;
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    resendInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.onSearchClick();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
    }
    cancelInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.onSearchClick();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.cModalRef.hide();
    }
    onPageChange(event) {
        this.cRecurringDetailSearch.pageSize = event.cPageSize;
        this.cRecurringDetailSearch.pageNumber = event.cPageNo;
        this.searchflag = 'pageChange';
        this.onSearchClick();
    }
};
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Array)
], RecurringOccurrencesDetailsComponent.prototype, "cRecurringOccDetails", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", RecurringProfileWrapperRes)
], RecurringOccurrencesDetailsComponent.prototype, "cRecurringProfileWrapperRes", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], RecurringOccurrencesDetailsComponent.prototype, "backBtnEvent", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Boolean)
], RecurringOccurrencesDetailsComponent.prototype, "isActiveForInvoiceDetail", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], RecurringOccurrencesDetailsComponent.prototype, "previewInvoiceEvent", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", RecurringOcurredDetailsReq)
], RecurringOccurrencesDetailsComponent.prototype, "cRecurringOcurredDetailsReq", void 0);
RecurringOccurrencesDetailsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-recurring-occurred-details',
        templateUrl: './recurring-occurrences-details.component.html',
        styleUrls: ['./recurring-occurrences-details.component.css'],
        providers: [InvoiceService],
        animations: [
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 })
        ]
    }),
    tslib_1.__param(14, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService,
        MerchInfoService,
        InvoiceDataService,
        Router,
        InvoiceService,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        FormBuilder,
        BsModalService,
        RecurringProfileService,
        Document])
], RecurringOccurrencesDetailsComponent);
export { RecurringOccurrencesDetailsComponent };
//# sourceMappingURL=recurring-occurrences-details.component.js.map