export class RecurringOcurredDetailsSearchReq {
}
//# sourceMappingURL=recurring-ocurred-details-search-req.js.map