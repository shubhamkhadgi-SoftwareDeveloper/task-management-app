import { async, TestBed } from '@angular/core/testing';
import { RecurringOccurrencesDetailsComponent } from './recurring-occurrences-details.component';
describe('RecurringOccurrencesDetailsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RecurringOccurrencesDetailsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(RecurringOccurrencesDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=recurring-occurrences-details.component.spec.js.map