import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { RecurringProfileReq } from './recurring-profile.req';
import { RecurringProfileService } from './recurring-profile.service';
import { DatePipe } from '@angular/common';
let RecurringProfileResolverService = class RecurringProfileResolverService {
    constructor(sRecurringProfileService, datepipe) {
        this.sRecurringProfileService = sRecurringProfileService;
        this.datepipe = datepipe;
        this.today = new Date();
        this.cRecurringProfileReq = new RecurringProfileReq();
    }
    resolve(route, state) {
        this.cRecurringProfileReq.searchFromDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.cRecurringProfileReq.searchToDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        return this.sRecurringProfileService.fetchReccuringInvList(this.cRecurringProfileReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
RecurringProfileResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [RecurringProfileService,
        DatePipe])
], RecurringProfileResolverService);
export { RecurringProfileResolverService };
//# sourceMappingURL=recurring-profile-resolver.service.js.map