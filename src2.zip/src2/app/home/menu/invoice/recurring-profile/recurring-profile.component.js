import * as tslib_1 from "tslib";
import { Component, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ErrorHandlerService } from './../../../../common-services/error-handler.service';
import { TitleService } from './../../../../common-services/title.service';
import { RecurringProfile } from './recurring-profile.class';
import { RecurringProfileReq } from './recurring-profile.req';
import { RecurringProfileUpdReq } from './recurring-profile-upd.req';
import { BillPaymentWrapper } from './bill-payment-entity-wrapper';
import { RecurringOcurredDetailsReq } from './recurring-ocurred-details.req';
import { RecurringProfileWrapperRes } from './recurring-profile-wrapper.res';
import { Invoice } from '../../invoice/invoice/invoice.class';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { BulkInvoiceReq } from '../../invoice/invoice/bulk-invoice-req';
import { RecurringProfileService } from './recurring-profile.service';
import { InvoiceService } from '../invoice/invoice.service';
import { trigger, style, transition, animate, state } from '@angular/animations';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { DOCUMENT } from "@angular/common";
import { InvoiceDataService } from "../invoice/InvoiceDataService";
import { DatePipe } from '@angular/common';
let RecurringProfileComponent = class RecurringProfileComponent {
    //***********************************************Constructor*******************************************//
    constructor(pApiRequestService, pInvoiceDataService, pMerchInfoService, sCheck, pModalService, route, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, pFormBuilder, sErrorHandler, sTitleService, sRecurringProfileService, sInvoiceService, sDocument, datepipe) {
        this.pApiRequestService = pApiRequestService;
        this.pInvoiceDataService = pInvoiceDataService;
        this.pMerchInfoService = pMerchInfoService;
        this.sCheck = sCheck;
        this.pModalService = pModalService;
        this.route = route;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.sTitleService = sTitleService;
        this.sRecurringProfileService = sRecurringProfileService;
        this.sInvoiceService = sInvoiceService;
        this.sDocument = sDocument;
        this.datepipe = datepipe;
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.cIsWritePrivilege = false;
        this.cSubAccountList = [];
        this.searchflag = 'searchform';
        this.isSearchPanelClick = false;
        this.flag = false;
        this.today = new Date();
        this.addInvoice = false;
        this.cCommonResponse = new CommonResponse();
        this.cRecurringProfile = new RecurringProfile();
        this.cRecurringProfileReq = new RecurringProfileReq();
        this.cRecurringProfileUpdReq = new RecurringProfileUpdReq();
        this.cRecurringOcurredDetailsReq = new RecurringOcurredDetailsReq();
        this.mBillPaymentWrapper = new BillPaymentWrapper();
        this.cRecurringProfileWrapperRes = new RecurringProfileWrapperRes();
        this.cInvoice = new Invoice();
        this.cBulkInvoiceReq = new BulkInvoiceReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.RecurringProfile);
        this.sTitleService.setTitle(this.sTitleService.RecurringProfile);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchByValue'].disable();
        this.cRecurringProfileReq.searchFromDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.cRecurringProfileReq.searchToDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.cRecurringProfile.totalCount = mCommonResponse.data['totalCount'];
                this.cRecordTo = mCommonResponse.data['pageCount'];
                this.cBillPaymentWrapper = mCommonResponse.data['billPaymentWrapperList'];
                this.cRecurringProfile.isAnyRecurringProfCreated = true;
            }
            else {
                this.cRecurringProfile.landingPageMsg = "No record found from " + this.datepipe.transform(new Date(), 'dd-MM-yyyy') + " to " + this.datepipe.transform(new Date(), 'dd-MM-yyyy');
                this.cRecurringProfile.isAnyRecurringProfCreated = false;
            }
        });
    }
    //***********************************************Mouse Event*******************************************//
    //Select Action
    mouseleaveSelectActionEvent() {
        this.cRecurringProfile.isSelectActionClick = false;
    }
    //*****************************Validations********************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchBy: [''],
            searchByValue: [''],
            searchMerchId: [''],
            searchsubAccId: [''],
            searchInvCurr: [''],
            searchInvStatus: [''],
            searchInvFreq: [''],
            fromToDate: [''],
        });
    }
    //for new recurring inv
    onOpenNewPopupClick(template) {
        if (!this.pMerchInfoService.isChildrenAccount() && !this.pMerchInfoService.isSubAccount()) {
            this.pInvoiceDataService.regId = String(this.pMerchInfoService.getRegId());
            this.pInvoiceDataService.subAccId = this.cInvoice.subAccId;
            this.pInvoiceDataService.isRecurring = 'Y';
            this.pInvoiceDataService.invoiceNo = '';
            this.pInvoiceDataService.editRequest = false;
            this.route.navigate(['home/menu/invoice/invoice/createNewInvoice']);
        }
        else {
            this.cModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
            this.createForm1();
        }
    }
    createForm1() {
        this.mForm1 = this.pFormBuilder.group({
            SubAccId: [''],
            regId: ['', [Validators.required]]
        });
        this.cInvoice.regId = null;
        this.cInvoice.subAccId = null;
        this.cSubAccountList = [];
        if (this.pMerchInfoService.isChildrenAccount()) {
            this.cChildrenAccountList = [];
            this.cChildrenAccountList = this.pMerchInfoService.getChildrenAccountList();
        }
        else {
            this.cInvoice.regId = this.pMerchInfoService.getRegId().toString();
        }
        if (this.pMerchInfoService.isSubAccount()) {
            this.cSubAccountList = this.pMerchInfoService.getSubAccountList();
        }
    }
    onChangeMerchantId(event) {
        this.cInvoice.subAccId = null;
        this.getSubAccListForChildrenAcc(this.cInvoice.regId);
    }
    getSubAccListForChildrenAcc(regId) {
        this.pApiRequestService.httpPostRequest({ "regId": parseInt(regId) }, 'common/fetchAllMerchInfo')
            .subscribe(pResponse => {
            this.fetchSubaccListSuccess(pResponse);
        }, error => { console.log('error'); });
    }
    fetchSubaccListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess && this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cSubAccountList = [];
                mCommonResponse.data.subAccounts.forEach(subAccount => {
                    this.cSubAccountList.push({ label: subAccount.subAccountId, value: subAccount.subAccountId });
                });
            }
        }
    }
    proceedToCreateInvoice() {
        if (this.mForm1.valid) {
            this.pInvoiceDataService.regId = this.cInvoice.regId;
            this.pInvoiceDataService.subAccId = this.cInvoice.subAccId;
            this.pInvoiceDataService.isRecurring = 'Y';
            this.route.navigate(['home/menu/invoice/invoice/createNewInvoice']);
            this.cModalRef.hide();
        }
        else
            CustomValidator.validateAllFields(this.mForm1);
    }
    onDeletePopupClick(pBillId, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cBillId = pBillId;
    }
    PreviewClick(pRegId, pInvoiceNo, pPaymentStatus) {
        this.pInvoiceDataService.regId = pRegId;
        this.pInvoiceDataService.invoiceNo = pInvoiceNo;
        this.pInvoiceDataService.paymentStatus = pPaymentStatus;
        this.route.navigate(['home/menu/invoice/invoice/previewInvoice']);
    }
    onUploadClick() {
        this.cBulkInvoiceReq.isRecurring = true;
        this.sInvoiceService.uploadInvoiceExcelData(this.cInvoice.uploadFile, this.cBulkInvoiceReq, 'Recurring bulk Response.xlsx')
            .subscribe(rResponse => this.onUploadSuccess(rResponse), error => this.onUploadError(error));
        this.cInvoice.uploadFileName = "";
        this.cInvoice.uploadFile = null;
    }
    onOpenModalClick(template) {
        this.cInvoice.closeButton = true;
        this.cModalRef = this.pModalService.show(template, { ignoreBackdropClick: true });
        this.cInvoice.isBulkInvoiceExcelUpload = false;
    }
    onUploadSuccess(pResponse) {
        this.cModalRef.hide();
        this.sAlertMessageService.popupAlertMsg("File Uploaded Successfully");
        this.sRecurringProfileService.fetchReccuringInvList(this.cRecurringProfileReq)
            .subscribe(rResponse => this.fetchRecInvListSuccess(rResponse), error => { console.log('error'); });
    }
    onDownloadExcelClick() {
        this.cBulkInvoiceReq.isRecurring = true;
        this.sInvoiceService.downloadSimpleInvSample(this.cBulkInvoiceReq, 'RecurringProfileDetails.xlsx')
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onChooseFile(event) {
        let fileList = event.target.files;
        if (fileList.length > 0) {
            if (fileList[0].type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
                this.cInvoice.uploadFile = fileList[0];
                this.cInvoice.uploadFileName = fileList[0].name;
                this.cInvoice.isBulkInvoiceExcelUpload = true;
            }
            else {
                this.cModalRef.hide();
                this.sAlertMessageService.popupAlertMsg("Please upload valid .XLSX file.");
            }
        }
    }
    //***********************************************Button Click Event********************************************//
    onSelectActionClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        this.cRecurringProfile.isExportClick = false;
        this.cRecurringProfile.isSelectActionClick = !this.cRecurringProfile.isSelectActionClick;
    }
    onSearchPanelClick() {
        this.cRecurringProfile.isSelectActionClick = false;
        this.cRecurringProfile.isExportClick = false;
        this.cRecurringProfile.selectedInvoices = [];
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onExportClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        this.cRecurringProfile.isSelectActionClick = false;
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isExportClick = !this.cRecurringProfile.isExportClick;
    }
    onSearchByClick(value) {
        if (this.cRecurringProfileReq.searchBy == 'searchInvNo') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringProfileReq.searchBy == 'searchInvEmail') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringProfile.searchByLabel == 'null') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onDropdownCloseClick() {
        this.cRecurringProfile.isSearchByClick = false;
    }
    onSearchByOptionClick(pOption) {
        this.cRecurringProfile.isSearchByClick = !this.cRecurringProfile.isSearchByClick;
        this.cRecurringProfileReq.searchBy = pOption.value;
        this.cRecurringProfile.searchByLabel = pOption.label;
        this.cRecurringProfileReq.searchByValue = null;
        if (this.cRecurringProfile.searchByLabel == 'Profile #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringProfile.searchByLabel == 'Email ID') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRecurringProfile.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onBackClick() {
        this.cRecurringProfile.isOccurredCountClick = !this.cRecurringProfile.isOccurredCountClick;
        //this.cInvoice.isInvoiceDetailClick = false;
    }
    onCancelClick() {
        this.cRecurringProfileReq = null;
        this.cRecurringProfileReq = new RecurringProfileReq();
        this.cRecurringProfileReq.regId = this.pMerchInfoService.getRegId();
        this.cRecurringProfileReq.searchFromDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.cRecurringProfileReq.searchToDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.cRecurringProfile = new RecurringProfile();
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.onSearchClick();
    }
    onOccerClick($event) {
        this.cRecurringProfile.isOccurredCountClick = !this.cRecurringProfile.isOccurredCountClick;
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.searchflag == 'searchform') {
                this.cRecurringProfileReq.pageNumber = 1;
            }
            console.log(this.cRecurringProfileReq);
            if (this.sCheck.isNullString(this.cRecurringProfileReq.searchFromDate) && this.sCheck.isNullString(this.cRecurringProfileReq.searchToDate)) {
                this.cRecurringProfileReq.searchFromDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
                this.cRecurringProfileReq.searchToDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
            }
            this.sRecurringProfileService.fetchReccuringInvList(this.cRecurringProfileReq)
                .subscribe(rResponse => this.fetchRecInvListSuccess(rResponse), error => { console.log('error'); });
            this.searchflag = 'searchform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    updStatus(pEvent, pRecStatus, pBillId) {
        if (pRecStatus === 'ACTI') {
            this.cRecStatus = 'INAC';
        }
        if (pRecStatus === 'INAC') {
            this.cRecStatus = 'ACTI';
        }
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.selectedInvoices.push(pBillId.toString());
        this.cRecurringProfileUpdReq.billIdsList = this.cRecurringProfile.selectedInvoices;
        this.cRecurringProfileUpdReq.recurringStatus = this.cRecStatus;
        if (this.cRecurringProfile.selectedInvoices != null && this.cRecurringProfile.selectedInvoices.length > 0) {
            this.sRecurringProfileService.updateRecInvStatus(this.cRecurringProfileUpdReq)
                .subscribe(pResponse => this.onActionSuccess(pResponse, 'updStatus'), error => { console.log('error'); });
        }
        this.cRecurringProfile.selectedInvoices = [];
    }
    onExportExcelClick() {
        this.cRecurringProfile.isExportClick = !this.cRecurringProfile.isExportClick;
        this.cRecurringProfileReq.regId = this.pMerchInfoService.getRegId();
        this.sRecurringProfileService.exportExcelRecInv(this.cRecurringProfileReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onAllRecurringProfileCheck(pEvent) {
        if (pEvent) {
            this.cRecurringProfile.selectedInvoices = [];
            for (let pRecInv of this.cBillPaymentWrapper) {
                this.cRecurringProfile.selectedInvoices.push(pRecInv.billPaymentDetailsList.billId.toString());
            }
        }
        else {
            this.cRecurringProfile.selectedInvoices = [];
        }
    }
    onRecurringProfileCheck(pEvent) {
        if (pEvent) {
            if (this.cRecurringProfile.selectedInvoices.length === this.cBillPaymentWrapper.length) {
                this.cRecurringProfile.isAllRecurringProfileCheck = true;
            }
        }
        else {
            this.cRecurringProfile.isAllRecurringProfileCheck = false;
        }
    }
    onActionPopupClick(pBillId, pTemplate, oprtn) {
        //For enable,disable,delete popup
        if (this.sCheck.isNotNullNumber(pBillId))
            this.cBillId = pBillId;
        else if (this.sCheck.isNotNullString(oprtn)) {
            var temp = false;
            for (let BillPaymentEntity of this.cRecurringProfile.selectedInvoices) {
                for (let wrapper of this.cBillPaymentWrapper) {
                    if (wrapper.billPaymentDetailsList.billId == BillPaymentEntity && oprtn == "del") {
                        if (wrapper.occuredCount != 0) {
                            this.sAlertMessageService.popupAlertMsg("Invoice(s) can't be deleted.");
                            this.cRecurringProfile.selectedInvoices = [];
                            this.flag = false;
                            temp = false;
                            break;
                        }
                        else
                            this.flag = true;
                    }
                    else if (wrapper.billPaymentDetailsList.billId == BillPaymentEntity && oprtn == "ACTI") { //enable
                        if (wrapper.billPaymentDetailsList.recurringStatus == "ACTI") {
                            this.sAlertMessageService.popupAlertMsg("Select invoice(s) with same status.");
                            this.cRecurringProfile.selectedInvoices = [];
                            this.flag = false;
                            temp = false;
                            break;
                        }
                        else
                            this.flag = true;
                    }
                    else if (wrapper.billPaymentDetailsList.billId == BillPaymentEntity && oprtn == "INAC") {
                        if (wrapper.billPaymentDetailsList.recurringStatus == "INAC") {
                            this.sAlertMessageService.popupAlertMsg("Select invoice(s) with same status.");
                            this.cRecurringProfile.selectedInvoices = [];
                            this.flag = false;
                            temp = false;
                            break;
                        }
                        else
                            this.flag = true;
                    }
                }
                if (temp == false && this.flag == false) {
                    break;
                }
            }
        }
        if (this.flag == true)
            this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onConfirmDeleteClick() {
        if (this.sCheck.isNotNullNumber(this.cBillId)) {
            this.onSingleDeleteInvClick(this.cBillId);
        }
        else {
            this.onDeleteInvClick();
        }
        this.cBillId = null;
    }
    onDeleteInvClick() {
        this.cRecurringProfile.isSelectActionClick = !this.cRecurringProfile.isSelectActionClick;
        this.cRecurringProfileReq.billIdsList = this.cRecurringProfile.selectedInvoices;
        if (this.cRecurringProfile.selectedInvoices != null && this.cRecurringProfile.selectedInvoices.length > 0 && this.flag) {
            this.sRecurringProfileService.deleteRecInv(this.cRecurringProfileReq)
                .subscribe(pResponse => this.onActionSuccess(pResponse, 'delete'), error => { console.log('error'); });
        }
        this.cRecurringProfile.selectedInvoices = [];
        this.cModalRef.hide();
    }
    onSingleDeleteInvClick(pBillId) {
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.selectedInvoices.push(pBillId.toString());
        this.cRecurringProfileReq.billIdsList = this.cRecurringProfile.selectedInvoices;
        if (this.cRecurringProfile.selectedInvoices != null && this.cRecurringProfile.selectedInvoices.length > 0) {
            this.sRecurringProfileService.deleteRecInv(this.cRecurringProfileReq)
                .subscribe(pResponse => this.onActionSuccess(pResponse, 'delete'), error => { console.log('error'); });
        }
        this.cRecurringProfile.selectedInvoices = [];
        this.cModalRef.hide();
    }
    onActiveInvClick() {
        this.cRecurringProfile.isSelectActionClick = !this.cRecurringProfile.isSelectActionClick;
        this.cRecurringProfileUpdReq.billIdsList = this.cRecurringProfile.selectedInvoices;
        this.cRecurringProfileUpdReq.recurringStatus = 'ACTI';
        if (this.cRecurringProfile.selectedInvoices != null && this.cRecurringProfile.selectedInvoices.length > 0) {
            this.sRecurringProfileService.updateRecInvStatus(this.cRecurringProfileUpdReq)
                .subscribe(pResponse => this.onActionSuccess(pResponse, 'updStatus'), error => { console.log('error'); });
        }
        this.cRecurringProfile.selectedInvoices = null;
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isAllRecurringProfileCheck = false;
        this.cModalRef.hide();
    }
    onInActiveInvClick() {
        this.cRecurringProfile.isSelectActionClick = !this.cRecurringProfile.isSelectActionClick;
        this.cRecurringProfileUpdReq.billIdsList = this.cRecurringProfile.selectedInvoices;
        this.cRecurringProfileUpdReq.recurringStatus = 'INAC';
        if (this.cRecurringProfile.selectedInvoices != null && this.cRecurringProfile.selectedInvoices.length > 0) {
            this.sRecurringProfileService.updateRecInvStatus(this.cRecurringProfileUpdReq)
                .subscribe(pResponse => this.onActionSuccess(pResponse, 'updStatus'), error => { console.log('error'); });
        }
        this.cRecurringProfile.selectedInvoices = null;
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isAllRecurringProfileCheck = false;
        this.cModalRef.hide();
    }
    declineActionTask() {
        this.cModalRef.hide();
        this.cRecurringProfile.selectedInvoices = null;
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isAllRecurringProfileCheck = false;
    }
    onOccurredCountClick(pBillId, pStartDate, pFreq, pOccurrence, pRegId) {
        this.cRecurringOcurredDetailsReq.regId = pRegId;
        this.cRecurringOcurredDetailsReq.billId = pBillId;
        this.sRecurringProfileService.fetchRecOccurredDetailsOnSearch(this.cRecurringOcurredDetailsReq)
            .subscribe(rResponse => this.OccurredCountSuccess(rResponse), error => { console.log('error'); });
        this.cRecurringProfileWrapperRes.billId = pBillId;
        this.cRecurringProfileWrapperRes.frequency = pFreq;
        this.cRecurringProfileWrapperRes.occurrences = pOccurrence;
        this.cRecurringProfileWrapperRes.startDate = pStartDate;
    }
    onCalenderIconClick(dpReccurProf) {
        dpReccurProf.click();
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cRecurringProfileReq.searchFromDate = value.start.format("DD-MM-YYYY hh:mm:ss");
        this.cRecurringProfileReq.searchToDate = value.end.format("DD-MM-YYYY hh:mm:ss");
        this.cRecurringProfileReq.displaySearchFromDate = value.start.format("DD-MM-YYYY");
        this.cRecurringProfileReq.displaySearchToDate = value.end.format("DD-MM-YYYY");
        this.cRecurringProfile.fromToDate = this.cRecurringProfileReq.displaySearchFromDate + ' - ' + this.cRecurringProfileReq.displaySearchToDate;
    }
    //***********************************************Server Call Event**********************************************//
    fetchRecInvListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cRecurringProfile.totalCount = mCommonResponse.data['totalCount'];
                this.cRecordTo = mCommonResponse.data['pageCount'];
                this.cBillPaymentWrapper = mCommonResponse.data['billPaymentWrapperList'];
                this.cRecurringProfile.isAnyRecurringProfCreated = true;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cRecurringProfile.landingPageMsg = this.sLandingPageMsgService.noRecurringProfMsg;
                this.cRecurringProfile.totalCount = null;
                this.cBillPaymentWrapper = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
                this.cRecurringProfile.isAnyRecurringProfCreated = false;
            }
            else {
                this.cRecurringProfile.landingPageMsg = this.sLandingPageMsgService.noRecurringProfMsg;
                this.cRecurringProfile.totalCount = null;
                this.cBillPaymentWrapper = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
                this.cRecurringProfile.isAnyRecurringProfCreated = false;
            }
        }
        else {
            this.cRecurringProfile.landingPageMsg = this.sLandingPageMsgService.noRecurringProfMsg;
            this.cRecurringProfile.totalCount = null;
            this.cBillPaymentWrapper = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.isSearchPanelClick = false;
            }
            this.cRecurringProfile.isAnyRecurringProfCreated = false;
        }
    }
    onActionSuccess(pResponse, action) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cRecurringProfile.totalCount = mCommonResponse.data['totalCount'];
                    this.cRecordTo = mCommonResponse.data['pageCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['billPaymentWrapperList'])) {
                        this.cBillPaymentWrapper = mCommonResponse.data['billPaymentWrapperList'];
                    }
                }
            }
        }
        if (mCommonResponse.isSuccess) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
        else if (mCommonResponse.isFail) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isSelectActionClick = false;
        if (action == 'delete')
            this.cModalRef.hide();
    }
    OccurredCountSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(this.cCommonResponse)) {
                if (this.sCheck.isNotNullObject(this.cCommonResponse.data)) {
                    this.cInvoice.pageTotalCount = this.cCommonResponse.data['totalCount'];
                    if (this.sCheck.isNotNullList(this.cCommonResponse.data['mBillPayment'])) {
                        this.cRecurringOccurredDetails = this.cCommonResponse.data['mBillPayment'];
                    }
                    this.cRecurringProfile.isOccurredCountClick = true;
                }
            }
        }
    }
    onPageChange(event) {
        this.cRecurringProfileReq.pageSize = event.cPageSize;
        this.cRecurringProfileReq.pageNumber = event.cPageNo;
        this.cRecurringProfile.selectedInvoices = [];
        this.cRecurringProfile.isAllRecurringProfileCheck = false;
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.searchflag = 'pageChange';
        this.onSearchClick();
    }
    onUploadError(pError) {
        this.cModalRef.hide();
        this.sAlertMessageService.popupAlertMsg("No records updated/ or you are not uploading proper file./or you are uploading blank file..");
    }
};
RecurringProfileComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-recurring-profile',
        templateUrl: './recurring-profile.component.html',
        styleUrls: ['./recurring-profile.component.css'],
        animations: [
            trigger('openClose', [
                state('open', style({
                    height: '64px',
                    opacity: 1,
                    paddingTop: '20px'
                })),
                state('closed', style({
                    height: '0px',
                    opacity: 1,
                    paddingTop: '0px'
                })),
                transition('* => *', [
                    animate('0.25s')
                ])
            ]),
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 })
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(17, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService,
        InvoiceDataService,
        MerchInfoService,
        ConditionalCheckService,
        BsModalService,
        Router,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        FormBuilder,
        ErrorHandlerService,
        TitleService,
        RecurringProfileService,
        InvoiceService,
        Document,
        DatePipe])
], RecurringProfileComponent);
export { RecurringProfileComponent };
//# sourceMappingURL=recurring-profile.component.js.map