import { TestBed, inject } from '@angular/core/testing';
import { TasksItemsResolverService } from './tasks-items-resolver.service';
describe('TasksItemsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [TasksItemsResolverService]
        });
    });
    it('should be created', inject([TasksItemsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=tasks-items-resolver.service.spec.js.map