import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { InvoiceTaskAndItemsReq } from './invoiceTaskAndItems.req';
import { TasksItemsService } from './tasks-items.service';
let TasksItemsResolverService = class TasksItemsResolverService {
    constructor(pTasksItemsService) {
        this.pTasksItemsService = pTasksItemsService;
        this.cTaskAndItemsReq = new InvoiceTaskAndItemsReq();
    }
    resolve(route, state) {
        return this.pTasksItemsService.fetchAllInvoiceSettings(this.cTaskAndItemsReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
TasksItemsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [TasksItemsService])
], TasksItemsResolverService);
export { TasksItemsResolverService };
//# sourceMappingURL=tasks-items-resolver.service.js.map