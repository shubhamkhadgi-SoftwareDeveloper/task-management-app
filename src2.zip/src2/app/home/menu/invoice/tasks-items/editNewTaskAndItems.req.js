export class EditNewTaskAndItemsReq {
}
//# sourceMappingURL=editNewTaskAndItems.req.js.map