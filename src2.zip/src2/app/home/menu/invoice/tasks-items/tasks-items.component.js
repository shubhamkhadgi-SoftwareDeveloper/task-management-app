import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef, Inject } from '@angular/core';
import { CommonResponse, CustomResponseCode } from '../../../../common-response/common-response.res';
import { InvoiceTaskAndItems } from './tasks-items.class';
import { InvoiceTaskAndItemsReq } from './invoiceTaskAndItems.req';
import { EditNewTaskAndItemsReq } from './editNewTaskAndItems.req';
import { TasksItemsService } from './tasks-items.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { FormBuilder, Validators } from '@angular/forms';
import { InvoiceSettingsValidator } from '../invoice-settings/invoice-settings-validator';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { TitleService } from './../../../../common-services/title.service';
import { trigger, state, transition, animate, style } from '@angular/animations';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { DOCUMENT } from "@angular/common";
let TasksItemsComponent = class TasksItemsComponent {
    //***********************************************Life Hooks Event*******************************************//
    constructor(pTasksItemsService, cdr, pMerchInfoService, pModalService, pFormBuilder, sCheck, sAlertMessageService, sErrorHandler, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService, sDocument) {
        this.pTasksItemsService = pTasksItemsService;
        this.cdr = cdr;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.sDocument = sDocument;
        this.itemNameArray = [];
        this.cIsWritePrivilege = false;
        this.cCurrencyLeftFlag = false;
        this.cEditCall = false;
        this.cCurrencyIndex = 0;
        this.isSearchPanelClick = false;
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.cCurrencyList = [];
        this.createForm();
        this.cTaskAndItemsReq = new InvoiceTaskAndItemsReq();
        this.cTaskAndItems = new InvoiceTaskAndItems();
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.TasksItems);
        this.sTitleService.setTitle(this.sTitleService.TasksItems);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    ngOnInit() {
        this.createSearchForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                this.fetchAllTaskAndItemsSuccess(mCommonResponse);
                this.cTaskAndItems.isAnyTasksCreated = true;
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.isAnyTasksCreated = false;
            }
        });
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            itemName: ['', [
                    Validators.required,
                    Validators.maxLength(30),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.letterNumberAndSpaceOnly,
                ]],
            itemDescription: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharDesc,
                    InvoiceSettingsValidator.promotionDescription,
                    InvoiceSettingsValidator.isConsecuSpecialChar
                ]],
            rates: this.buildArray()
        });
    }
    createSearchForm() {
        this.mSearchForm = this.pFormBuilder.group({
            searchByName: ['', [InvoiceSettingsValidator.letterNumberAndSpaceOnly]],
        });
    }
    buildArray() {
        this.rates = this.pFormBuilder.array([
            this.buildGroup()
        ]);
        return this.rates;
    }
    buildGroup() {
        return this.pFormBuilder.group({
            currency: [null],
            price: ['']
        });
    }
    buildGroup1() {
        return this.pFormBuilder.group({
            currency: [null, Validators.required],
            price: ['', [Validators.required, Validators.min(1), Validators.max(999999999.99)]]
        });
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9.]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    onPriceClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            this.currAmtArray.controls[index].get('price').markAsTouched();
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
            this.currAmtArray.controls[index].get('currency').clearValidators();
            this.currAmtArray.controls[index].get('currency').setValidators([Validators.required]);
            this.currAmtArray.controls[index].get('currency').markAsTouched();
            this.currAmtArray.controls[index].get('currency').updateValueAndValidity();
        }
    }
    onBlur(event, index) {
        if (event) {
            if (this.currAmtArray.controls[index].get('price').value != '' && this.currAmtArray.controls[index].get('price').value != null) {
                let value = +this.currAmtArray.controls[index].get('price').value;
                this.currAmtArray.controls[index].get('price').setValue(value.toFixed(2));
            }
        }
    }
    onCurrencyClick(event, index) {
        if (event) {
            this.currAmtArray.controls[index].get('price').clearValidators();
            this.currAmtArray.controls[index].get('price').setValidators([Validators.required, Validators.min(1), Validators.max(999999999.99), CustomValidator.onlyNumbersAndDot]);
            //  this.currAmtArray.controls[index].get('price').markAsTouched();
            this.currAmtArray.controls[index].get('price').updateValueAndValidity();
        }
    }
    checkeTaskAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.pTasksItemsService.checkeTaskAvailability(this.cEditNewTaskAndItemsReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkeTaskAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkeTaskAvailability': true };
                }
            }
            else {
                return { 'checkeTaskAvailability': true };
            }
        });
    }
    onItemNameClick() {
        this.mForm.controls['itemName'].setAsyncValidators(this.checkeTaskAvailability.bind(this));
    }
    //***********************************************Getter Function********************************************//
    get currAmtArray() { return this.mForm.get('rates'); }
    //***********************************************Button Click Event********************************************//
    onAddCurrencyClick() {
        if (!this.cEditCall) {
            if (this.currAmtArray.value[this.cCurrencyIndex]['price'] != null && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '' && this.currAmtArray.value[this.cCurrencyIndex]['price'] != '0.00') {
                this.rates.push(this.buildGroup1());
                this.cCurrencyIndex = this.cCurrencyIndex + 1;
                this.cRatesLength = this.rates.length;
                this.cCurrencyLeftFlag = false;
            }
            else {
                if (this.sCheck.isNotNullObject(this.currAmtArray.value[this.cCurrencyIndex]))
                    this.currAmtArray.controls[this.cCurrencyIndex].get('price').markAsTouched();
                this.currAmtArray.controls[this.cCurrencyIndex].get('price').updateValueAndValidity();
            }
        }
        else {
            this.rates.push(this.buildGroup1());
            this.cCurrencyIndex = this.cCurrencyIndex + 1;
            this.cRatesLength = this.rates.length;
            this.cCurrencyLeftFlag = false;
            this.cEditCall = false;
        }
    }
    onCurrencyClickNewRow(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        this.cCurrencyIndex = index;
        if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') != -1) {
            this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value'), 1);
            this.cCurrencyLeftFlag = false;
        }
        if (this.cCurrencyList.length != 0 && this.sCheck.isNotNullString(this.currAmtArray.value[index]['currency'])) {
            this.cCurrencyLeftFlag = true;
        }
        console.log("in onCurrencyClickNewRowevent index=" + index + " flag = " + this.currAmtArray.value[index]['currency']);
    }
    onDeleteCurrencyClick(index) {
        let curr = this.currAmtArray.value[index]['currency'];
        if (curr != null && curr != '') {
            if (this.arrayObjectIndexOf(this.cCurrencyList, curr, 'value') == -1) {
                this.cCurrencyList.push({ "label": curr, "value": curr });
            }
        }
        this.cRatesLength = this.rates.length;
        if (this.cCurrencyList.length != 0 && this.sCheck.isNotNullObject(this.currAmtArray.value[index - 1]) && this.sCheck.isNotNullString(this.currAmtArray.value[index - 1]['currency']) && this.sCheck.isNotNullNumber(this.currAmtArray.value[index - 1]['price']) && this.currAmtArray.value[index - 1]['price'] != '0.00') {
            this.cCurrencyLeftFlag = true;
        }
        if (this.cRatesLength == 1 || this.cRatesLength == 0) {
            this.rates.push(this.createItem(null, ''));
            this.cCurrencyLeftFlag = false;
        }
        this.rates.removeAt(index);
        this.cRatesLength = this.rates.length;
        this.cCurrencyIndex = this.cCurrencyIndex - 1;
    }
    onSelectActionClick() {
        this.isSearchPanelClick = false;
        this.cTaskAndItems.isSelectActionClick = !this.cTaskAndItems.isSelectActionClick;
    }
    onSearchPanelClick() {
        this.cTaskAndItems.isSelectActionClick = false;
        this.cTaskAndItems.selectedTaskAndItems = [];
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
            if (window.matchMedia('(max-width:990px)').matches) {
                setTimeout(() => {
                    this.sDocument.getElementsByClassName('custom-search')[0].classList.add('slideL');
                    if (this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                        this.sDocument.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
                    }
                });
            }
        }
    }
    onSearchClick() {
        if (this.mSearchForm.valid) {
            this.pTasksItemsService.fetchAllInvoiceSettings(this.cTaskAndItemsReq)
                .subscribe(rResponse => this.fetchAllTaskAndItemsSuccess(rResponse), error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.mSearchForm);
        }
    }
    onSearchByClick() {
        this.cTaskAndItems.isSearchByClick = !this.cTaskAndItems.isSearchByClick;
    }
    onCancelClick() {
        this.cTaskAndItemsReq = null;
        this.cTaskAndItemsReq = new InvoiceTaskAndItemsReq();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.onSearchClick();
    }
    onDeleteClick(pTemplate) {
        this.cTaskAndItems.isSelectActionClick = !this.cTaskAndItems.isSelectActionClick;
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    onDeleteItemClick(pTaskAndItems, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm model-order-popup cancel-popup', ignoreBackdropClick: true });
        this.cTaskAndItemsProcEntityTemp = pTaskAndItems;
    }
    onConfirmDeleteClick() {
        if (this.cTaskAndItems.selectedTaskAndItems != null && this.cTaskAndItems.selectedTaskAndItems.length > 0 && this.cTaskAndItemsProcEntityTemp == null) {
            this.pTasksItemsService.deleteInvoiceTaskAndItems(this.cTaskAndItems.selectedTaskAndItems)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => { console.log('error'); });
        }
        else if (this.cTaskAndItemsProcEntityTemp.itemId != null) {
            let arraylist = [];
            arraylist.push(this.cTaskAndItemsProcEntityTemp.itemId.toString());
            this.pTasksItemsService.deleteInvoiceTaskAndItems(arraylist)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => { console.log('error'); });
            this.cTaskAndItemsProcEntityTemp = null;
        }
        this.cModalRef.hide();
    }
    declineDeleteTask() {
        this.cModalRef.hide();
        this.cTaskAndItemsProcEntityTemp = null;
        this.cTaskAndItems.isAllTasksAndItemsCheck = false;
        this.cTaskAndItems.selectedTaskAndItems = [];
    }
    onOpenNewPopupClick(template) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.cModalRef = this.pModalService.show(template, { class: 'modal-sm scrollable', ignoreBackdropClick: true });
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.createForm();
    }
    onOpenEditPopupClick(template, obj) {
        this.cCurrencyList = this.pMerchInfoService.getCurrencyList().map(x => Object.assign({}, x));
        this.createForm();
        this.cCurrLength = this.cCurrencyList.length;
        this.cEditCall = true;
        this.cEditNewTaskAndItemsReq = new EditNewTaskAndItemsReq();
        this.cEditNewTaskAndItemsReq.itemName = obj.itemName;
        this.cEditNewTaskAndItemsReq.itemDescription = obj.itemDescription;
        this.cEditNewTaskAndItemsReq.itemId = obj.itemId;
        this.cEditNewTaskAndItemsReq.itemUnitCost = obj.itemUnitCost;
        this.cEditNewTaskAndItemsReq.regId = obj.regId;
        this.clearArray();
        if (obj.currency != null && obj.currency != '') {
            for (let i = 0; i < obj.currency.length; i++) {
                if (obj.currency[i] != '' && obj.price[i] != '') {
                    this.cCurrencyList.splice(this.arrayObjectIndexOf(this.cCurrencyList, obj.currency[i], 'value'), 1);
                    this.rates.push(this.createItem(obj.currency[i], obj.price[i]));
                    this.cRatesLength = this.rates.length;
                }
                else {
                    this.rates.push(this.createItem('', ''));
                    this.cRatesLength = 0;
                }
            }
        }
        else {
            this.rates.push(this.createItem('', ''));
            this.cRatesLength = 0;
        }
        this.cModalRef = this.pModalService.show(template, { class: 'modal-sm scrollable', ignoreBackdropClick: true });
        if (this.cCurrencyList.length != 0 && obj.currency != null && obj.currency != '')
            this.cCurrencyLeftFlag = true;
        else
            this.cCurrencyLeftFlag = false;
    }
    clearArray() {
        while (this.rates.length) {
            this.rates.removeAt(0);
        }
    }
    createItem(curr, price) {
        return this.pFormBuilder.group({
            currency: [curr],
            price: [price]
        });
    }
    onCreateTasksItemsClick(value) {
        if (this.mForm.valid) {
            this.cCurrencyIndex = 0;
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            if (this.itemNameArray.indexOf(this.cEditNewTaskAndItemsReq.itemName) > -1) {
                this.cEditNewTaskAndItemsReq.itemId = 0;
            }
            this.pTasksItemsService.addInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    onUpdateTasksItemsClick(value) {
        if (this.mForm.valid) {
            let b = "";
            let c = "";
            let d = "";
            for (let a of value.rates) {
                b = a.currency;
                c = a.price;
                if (b != '' && c != '' && c != '0') {
                    d = d + "#" + b + "$" + c;
                }
                else {
                    d = "#" + "$";
                }
            }
            this.cEditNewTaskAndItemsReq.itemUnitCost = d;
            this.pTasksItemsService.updateInvoiceTaskAndItems(this.cEditNewTaskAndItemsReq)
                .subscribe(pResponse => this.taskSuccess(pResponse), error => this.onSearchClick());
            this.cModalRef.hide();
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    //***********************************************CheckBox Check Event*******************************************//
    onAllTasksAndItemsCheck(pEvent) {
        if (pEvent) {
            this.cTaskAndItems.selectedTaskAndItems = [];
            for (let pInvoiceTaskAndItems of this.cTaskAndItemsProcEntity) {
                this.cTaskAndItems.selectedTaskAndItems.push(pInvoiceTaskAndItems.itemId.toString());
            }
        }
        else {
            this.cTaskAndItems.selectedTaskAndItems = [];
        }
    }
    onTasksAndItemsCheck(pEvent) {
        if (pEvent) {
            if (this.cTaskAndItems.selectedTaskAndItems.length === this.cTaskAndItemsProcEntity.length) {
                this.cTaskAndItems.isAllTasksAndItemsCheck = true;
            }
        }
        else {
            this.cTaskAndItems.isAllTasksAndItemsCheck = false;
        }
    }
    //***********************************************Mouse Event*******************************************//
    //Select Action
    mouseleaveSelectActionEvent() {
        this.cTaskAndItems.isSelectActionClick = false;
    }
    mouseenterRatesEvent(pIndex) {
        this.cTaskAndItems.ratesIndex = pIndex;
        this.cTaskAndItems.isRatesClick = true;
    }
    mouseleaveRatesEvent(pIndex) {
        this.cTaskAndItems.ratesIndex = pIndex;
        this.cTaskAndItems.isRatesClick = false;
    }
    //***********************************************Server Call Event**********************************************//
    fetchAllTaskAndItemsSuccess(pResponse) {
        this.itemNameArray = [];
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cTaskAndItems.totalCount = mCommonResponse.data['totalCount'];
                    this.cTaskAndItemsProcEntity = mCommonResponse.data['invoiceTaskItemList'];
                    for (let procEntity of this.cTaskAndItemsProcEntity) {
                        if (procEntity.itemUnitCost != null) {
                            let unitCost = procEntity.itemUnitCost.split("#");
                            unitCost.splice(0, 1);
                            procEntity.currency = [];
                            procEntity.price = [];
                            for (let cost of unitCost) {
                                let unit = cost.split("$");
                                procEntity.currency.push(unit[0]);
                                procEntity.price.push(unit[1]);
                            }
                            this.itemNameArray.push(procEntity.itemName);
                        }
                    }
                    if (!this.sResponsiveService.isCancelResponsive()) {
                        this.isSearchPanelClick = false;
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
                this.cTaskAndItems.totalCount = null;
                this.cTaskAndItemsProcEntity = null;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.isSearchPanelClick = false;
                }
            }
        }
        else {
            console.log(this.sErrorMessagesService.responseNull);
            this.cTaskAndItems.landingPageMsg = this.sLandingPageMsgService.noTaskMsg;
            this.cTaskAndItems.totalCount = null;
            this.cTaskAndItemsProcEntity = null;
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.isSearchPanelClick = false;
            }
        }
    }
    taskSuccess(pResponse) {
        //this.cCurrencyLeftFlag=false;
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cTaskAndItems.selectedTaskAndItems = [];
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
        this.onSearchClick();
    }
    onPageChange(event) {
        this.cTaskAndItemsReq.searchPageSize = event.cPageSize;
        this.cTaskAndItemsReq.searchPageNo = event.cPageNo;
        this.cTaskAndItems.selectedTaskAndItems = [];
        this.cTaskAndItems.isAllTasksAndItemsCheck = false;
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.onSearchClick();
    }
    //***********************************************Functions*******************************************//
    arrayObjectIndexOf(pArray, pSearchTerm, pProperty) {
        for (var i = 0, len = pArray.length; i < len; i++) {
            if (pArray[i][pProperty] === pSearchTerm)
                return i;
        }
        return -1;
    }
    close() {
        this.cCurrencyLeftFlag = false;
        this.cModalRef.hide();
    }
};
TasksItemsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-tasks-items',
        templateUrl: './tasks-items.component.html',
        styleUrls: ['./tasks-items.component.css'],
        animations: [
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 300 }),
            trigger('openClose', [
                state('open', style({
                    height: '64px',
                    opacity: 1,
                    paddingTop: '20px'
                })),
                state('closed', style({
                    height: '0px',
                    opacity: 1,
                    paddingTop: '0px'
                })),
                transition('* => *', [
                    animate('0.25s')
                ])
            ])
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(14, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [TasksItemsService,
        ChangeDetectorRef,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ConditionalCheckService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService,
        Document])
], TasksItemsComponent);
export { TasksItemsComponent };
//# sourceMappingURL=tasks-items.component.js.map