import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { APP_CONTEXT } from 'app/entities/app-context';
let TasksItemsService = class TasksItemsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = APP_CONTEXT.INVOICE_SERVICE_CONTEXT + 'tasksItems/';
        this.cFetchAllInvoiceTaskAndItemsUrl = this.cBaseUrl + 'fetchAllInvoiceTaskAndItems';
        this.cAddInvoiceTaskAndItemsUrl = this.cBaseUrl + 'addInvoiceTaskAndItems';
        this.cDeleteInvoiceTaskAndItemsUrl = this.cBaseUrl + 'deleteInvoiceTaskAndItems';
        this.cUpdateInvoiceTaskAndItemsUrl = this.cBaseUrl + 'updateInvoiceTaskAndItems';
        this.cCheckeTaskAvailabilityUrl = this.cBaseUrl + 'checkeTaskAvailability';
    }
    fetchAllInvoiceSettings(pInvoiceTaskAndItemsReq) {
        return this.pApiRequestService.httpPostRequest(pInvoiceTaskAndItemsReq, this.cFetchAllInvoiceTaskAndItemsUrl);
    }
    addInvoiceTaskAndItems(pEditNewTaskAndItemsReq) {
        return this.pApiRequestService.httpPostRequest(pEditNewTaskAndItemsReq, this.cAddInvoiceTaskAndItemsUrl);
    }
    deleteInvoiceTaskAndItems(pItemIds) {
        return this.pApiRequestService.httpPostRequest({ 'itemId': pItemIds }, this.cDeleteInvoiceTaskAndItemsUrl);
    }
    updateInvoiceTaskAndItems(pEditNewTaskAndItemsReq) {
        return this.pApiRequestService.httpPostRequest(pEditNewTaskAndItemsReq, this.cUpdateInvoiceTaskAndItemsUrl);
    }
    checkeTaskAvailability(pEditNewTaskAndItemsReq) {
        return this.pApiRequestService.asyncHttpPostRequest(pEditNewTaskAndItemsReq, this.cCheckeTaskAvailabilityUrl);
    }
};
TasksItemsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], TasksItemsService);
export { TasksItemsService };
//# sourceMappingURL=tasks-items.service.js.map