export class InvoiceTaskAndItems {
    constructor() {
        this.selectedTaskAndItems = [];
        this.isSearchPanelClick = false;
        this.isAllTasksAndItemsCheck = false;
        this.isSelectActionClick = false;
        this.isRatesClick = false;
        this.isSearchByClick = false;
        this.currencyList = [];
        this.isAnyTasksCreated = true;
    }
}
//# sourceMappingURL=tasks-items.class.js.map