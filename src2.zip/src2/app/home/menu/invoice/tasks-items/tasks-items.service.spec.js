import { TestBed, inject } from '@angular/core/testing';
import { TasksItemsService } from './tasks-items.service';
describe('TasksItemsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [TasksItemsService]
        });
    });
    it('should be created', inject([TasksItemsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=tasks-items.service.spec.js.map