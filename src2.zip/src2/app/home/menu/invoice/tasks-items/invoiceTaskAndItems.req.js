export class InvoiceTaskAndItemsReq {
    constructor() {
        this.searchPageSize = 25;
        this.searchPageNo = 1;
    }
}
//# sourceMappingURL=invoiceTaskAndItems.req.js.map