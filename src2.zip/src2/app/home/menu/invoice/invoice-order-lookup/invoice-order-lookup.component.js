import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
let InvoiceOrderLookupComponent = class InvoiceOrderLookupComponent {
    constructor() { }
    ngOnInit() {
    }
};
InvoiceOrderLookupComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-invoice-order-lookup',
        templateUrl: './invoice-order-lookup.component.html',
        styleUrls: ['./invoice-order-lookup.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [])
], InvoiceOrderLookupComponent);
export { InvoiceOrderLookupComponent };
//# sourceMappingURL=invoice-order-lookup.component.js.map