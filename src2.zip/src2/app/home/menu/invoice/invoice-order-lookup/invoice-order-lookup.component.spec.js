import { async, TestBed } from '@angular/core/testing';
import { InvoiceOrderLookupComponent } from './invoice-order-lookup.component';
describe('InvoiceOrderLookupComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InvoiceOrderLookupComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(InvoiceOrderLookupComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=invoice-order-lookup.component.spec.js.map