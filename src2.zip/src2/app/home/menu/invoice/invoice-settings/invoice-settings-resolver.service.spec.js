import { TestBed, inject } from '@angular/core/testing';
import { InvoiceSettingsResolverService } from './invoice-settings-resolver.service';
describe('InvoiceSettingsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [InvoiceSettingsResolverService]
        });
    });
    it('should be created', inject([InvoiceSettingsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=invoice-settings-resolver.service.spec.js.map