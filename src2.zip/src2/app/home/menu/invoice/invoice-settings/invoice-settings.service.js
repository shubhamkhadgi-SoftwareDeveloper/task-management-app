import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let InvoiceSettingsService = class InvoiceSettingsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'invoiceSettings/';
        this.cFetchAllInvoiceSettings = this.cBaseUrl + 'fetchAllInvoiceSettings';
        this.cUpdateInvoiceSettings = this.cBaseUrl + 'updateInvoiceSettings';
    }
    fetchAllInvoiceSettings(pInvoiceSettingsReq) {
        return this.pApiRequestService.httpPostRequest(pInvoiceSettingsReq, this.cFetchAllInvoiceSettings);
    }
    updateInvoiceSettings(pInvoiceSettingsReq, pInvoiceSettingsAlias) {
        return this.pApiRequestService.httpPostRequest({ "invoiceSettingsReq": pInvoiceSettingsReq, "invoiceSettingsAlias": pInvoiceSettingsAlias }, this.cUpdateInvoiceSettings);
    }
};
InvoiceSettingsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], InvoiceSettingsService);
export { InvoiceSettingsService };
//# sourceMappingURL=invoice-settings.service.js.map