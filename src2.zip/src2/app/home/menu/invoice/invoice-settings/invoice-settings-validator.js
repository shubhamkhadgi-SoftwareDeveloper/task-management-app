export class InvoiceSettingsValidator {
    static numbersOnly(control) {
        let reg_exp = /^[0-9.]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'numbersOnly': true };
    }
    static letterAndNumberOnly(control) {
        let reg_exp = /^[a-zA-Z0-9]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'letterAndNumberOnly': true };
    }
    static letterNumberAndSpaceOnly(control) {
        let reg_exp = /^[a-zA-Z0-9\. ]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'letterNumberAndSpaceOnly': true };
    }
    static integerNumberOnly(control) {
        let reg_exp = /^[0-9]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'integerNumberOnly': true };
    }
    // Flat Value
    static flatValue(control) {
        let reg_exp = /^((\d)*(\.)?(\d){0,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'flatValue': true };
    }
    //***********************************Begin Special Character**************************************//
    static isBeginSpecialChar(control) {
        let reg_exp = /^[a-zA-Z0-9\s]/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isBeginSpecialChar': true };
    }
    //***********************************End Special Character**************************************//
    static isEndSpecialChar(control) {
        let reg_exp = /[a-zA-Z0-9\s]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialChar': true };
    }
    static isEndSpecialCharForSubject(control) {
        let reg_exp = /[a-zA-Z0-9\s.]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialCharForSubject': true };
    }
    static isEndSpecialCharForSMS(control) {
        let reg_exp = /[a-zA-Z0-9\s.]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value.replace(/\s/g, "")) ? null : { 'isEndSpecialCharForSMS': true };
    }
    static isEndSpecialCharForAddr(control) {
        let reg_exp = /[a-zA-Z0-9\.\n\s]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value.replace(/\s/g, "")) ? null : { 'isEndSpecialCharForAddr': true };
    }
    static isEndSpecialCharForTerms(control) {
        let reg_exp = /[a-zA-Z0-9\.\s]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialCharForTerms': true };
    }
    static isEndSpecialCharDesc(control) {
        let reg_exp = /[a-zA-Z0-9\s\>\)\.\:]$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isEndSpecialCharDesc': true };
    }
    //***********************************Consecutive Special Character**************************************// 
    static isConsecuSpecialChar(control) {
        let reg_exp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\/\/|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isConsecuSpecialChar': true };
    }
    static isConsecuSpecialCharDesc(control) {
        let reg_exp = /^(?:(?!(\*\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isConsecuSpecialCharDesc': true };
    }
    static isConsecuSpecialCharInvoice(control) {
        let reg_exp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'isConsecuSpecialCharInvoice': true };
    }
    //***********************************Email**************************************//
    static email(control) {
        let reg_exp = /^[\s]*([a-zA-Z0-9]+[\-\._]?)+[a-zA-Z0-9]+@{1}[a-zA-Z\d]+[a-zA-Z\d_\-]+(\.[a-zA-Z_\\-]+)+[\s]*$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'email': true };
    }
    static emailSub(control) {
        let reg_exp = /^[a-zA-Z0-9\s._-]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'emailSub': true };
    }
    //***********************************Other**************************************//
    static customerCareMailSignature(control) {
        let reg_exp = /^[a-zA-Z0-9\s_.,+\/\-\&\>\<\/\:\@\""\=\?\(\)]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customerCareMailSignature': true };
    }
    static letterSpaceUnderscoreColon(control) {
        let reg_exp = /^[a-zA-Z0-9\s_.,+\/\-\/\:\@\""\=\?\(\)]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'letterSpaceUnderscoreColon': true };
    }
    static smsContent(control) {
        let reg_exp = /^[a-zA-Z0-9\#\s._-]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'smsContent': true };
    }
    static termsConditionInv(control) {
        let reg_exp = /^[0-9a-zA-Z\s\(\)\#@\.,_\-&\n\/:]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'termsConditionInv': true };
    }
    static customAddress(control) {
        let reg_exp = /^[0-9a-zA-Z\s\'\/#,.\-\(\)]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customAddress': true };
    }
    static webStoreName(control) {
        let reg_exp = /^[a-zA-Z0-9\s\-\&]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'webStoreName': true };
    }
    static mobile(control) {
        let reg_exp = /^[0-9]{10}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'mobile': true };
    }
    static disputeMessages(control) {
        let reg_exp = /^[0-9a-zA-Z\s\(\)\.\-&\n]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'disputeMessages': true };
    }
    //***********************************Promotions**************************************//  
    static snipName(control) {
        let reg_exp = /^^[a-zA-Z0-9\s\_\-\/\&]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'snipName': true };
    }
    static promotionName(control) {
        let reg_exp = /^[a-zA-Z0-9\\s\\s\s\\_\-\\n\\:]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'promotionName': true };
    }
    static promotionDescription(control) {
        let reg_exp = /^[0-9a-zA-Z\s\s\s\(\)\#\.,_\-\&\@\n\:\>\<]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'promotionDescription': true };
    }
    static promotionAnalyticsCode(control) {
        let reg_exp = /^UA-\d{1,10}\-\d{1,2}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'promotionAnalyticsCode': true };
    }
    static promoTermsAndConditions(control) {
        let reg_exp = /^[0-9a-zA-Z\s\s\s\(\)\#\.,\-\&\n]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'promoTermsAndConditions': true };
    }
    static promotionBins(control) {
        let reg_exp = /^\d{6}(?:[,]\d{6})*\s*$/i;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'promotionBins': true };
    }
    //***********************************Account Information**************************************//  
    static customPANCard(control) {
        let reg_exp = /^(([a-zA-Z]{5})+([0-9]{4})+([a-zA-Z]{1}))+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customPANCard': true };
    }
    static customGSTNum(control) {
        let reg_exp = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/; ///^([0-9]){2}([a-zA-Z0-9]){13}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'customGSTNum': true };
    }
    /*static customFromToDate ( control : AbstractControl ) : {[key : string] : boolean } {
        let reg_exp = /^[0-9\s-]+$/;
        if ( !control.value ) {
        return null;
        }
        return reg_exp.test(control.value) ? null : {'customFromToDate' : true};
    }*/
    static phone(control) {
        let reg_exp = /^[0-9]{3,10}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'mobile': true };
    }
    static hours(control) {
        let reg_exp = /^([1-9]|1[0-9]|2[0-4])$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'hours': true };
    }
    static minutes(control) {
        let reg_exp = /^([1-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9]|6[0])$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'minutes': true };
    }
    static days(control) {
        let reg_exp = /^(?:36[0-5]|3[0-5][0-9]|[12][0-9][0-9]|[1-9][0-9]|[1-9])$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'days': true };
    }
}
//# sourceMappingURL=invoice-settings-validator.js.map