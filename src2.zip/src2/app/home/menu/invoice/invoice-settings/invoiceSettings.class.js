export class InvoiceSettings {
    constructor() {
        this.isEditClick = true;
        this.isSaveClick = "EDIT";
        this.settingInvValidityType = [];
        this.settingInvValidityType.push({ label: 'Minutes', value: 'minutes' });
        this.settingInvValidityType.push({ label: 'Hours', value: 'hours' });
        this.settingInvValidityType.push({ label: 'Days', value: 'days' });
        this.settingInvValidityType.push({ label: 'Select Duration', value: 'null' });
    }
}
//# sourceMappingURL=invoiceSettings.class.js.map