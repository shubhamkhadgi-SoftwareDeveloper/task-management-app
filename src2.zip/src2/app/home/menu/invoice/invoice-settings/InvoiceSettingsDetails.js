export class InvoiceSettingsDetails {
}
//# sourceMappingURL=InvoiceSettingsDetails.js.map