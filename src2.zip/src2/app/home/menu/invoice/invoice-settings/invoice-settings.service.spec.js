import { TestBed, inject } from '@angular/core/testing';
import { InvoiceSettingsService } from './invoice-settings.service';
describe('InvoiceSettingsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [InvoiceSettingsService]
        });
    });
    it('should be created', inject([InvoiceSettingsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=invoice-settings.service.spec.js.map