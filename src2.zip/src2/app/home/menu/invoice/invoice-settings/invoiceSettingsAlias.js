export class InvoiceSettingsAlias {
    constructor() {
        this.aliasMerRefNo = "Reference #";
        this.aliasMerRefNo1 = "Reference 1 #";
        this.aliasMerRefNo2 = "Reference 2 #";
        this.aliasMerRefNo3 = "Reference 3 #";
        this.aliasMerRefNo4 = "Reference 4 #";
        this.aliasTermsConditions = "Terms & Conditions";
        this.aliasInvoiceId = "Proforma Invoice No.";
        this.aliasCustomerName = "Customer Name";
        this.aliasItems = "Items";
        this.aliasDescription = "Description";
        this.aliasUnitCost = "Unit Cost";
        this.aliasNetAmount = "Total Amount Due (All Inclusive)";
    }
}
//# sourceMappingURL=invoiceSettingsAlias.js.map