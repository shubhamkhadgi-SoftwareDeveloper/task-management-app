import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { InvoiceSettingsReq } from "./invoiceSettings.req";
import { InvoiceSettingsService } from './invoice-settings.service';
let InvoiceSettingsResolverService = class InvoiceSettingsResolverService {
    constructor(sInvoiceSettingsService) {
        this.sInvoiceSettingsService = sInvoiceSettingsService;
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
    }
    resolve(route, state) {
        return this.sInvoiceSettingsService.fetchAllInvoiceSettings(this.cInvoiceSettingsReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
InvoiceSettingsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [InvoiceSettingsService])
], InvoiceSettingsResolverService);
export { InvoiceSettingsResolverService };
//# sourceMappingURL=invoice-settings-resolver.service.js.map