export class InvoiceSettingsReq {
    constructor() {
        this.settingInvNew = "Y";
        this.settingInvQuick = "Y";
        this.settingInvSubjectEdit = "Y";
        this.settingEmailDescriptionEdit = "Y";
        this.settingInvValidityEdit = "Y";
        this.settingInvExpiryVisible = "Y";
        this.settingInvTermsEdit = "Y";
        this.settingInvMerCopy = "Y";
        this.settingInvValidityType = "days";
        this.settingInvUserCopy = "Y";
        this.settingInvSMSEdit = "Y";
        this.settingInvRecurring = "Y";
        this.settingInvTaskItem = "task";
        this.settingInvItemEdit = "Y";
        this.settingMinInvAmount = "Y";
        this.settingMinInvAmountEdit = "Y";
        this.settingInvAdvance = "Y";
        this.settingInvSMS = "Y";
        this.settingInvWhatsApp = "Y";
        this.settingInvSMSContent = " Pls pay your LegalEntity_Name bill # Invoice_ID of Invoice_Amount online at Pay_Link .";
    }
}
//# sourceMappingURL=invoiceSettings.req.js.map