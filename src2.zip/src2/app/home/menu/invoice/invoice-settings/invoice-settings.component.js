import * as tslib_1 from "tslib";
import { Component, Inject } from '@angular/core';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { InvoiceSettingsReq } from "./invoiceSettings.req";
import { InvoiceSettings } from "./invoiceSettings.class";
import { InvoiceSettingsAlias } from './invoiceSettingsAlias';
import { InvoiceSettingsService } from './invoice-settings.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { FormBuilder, Validators } from '@angular/forms';
import { InvoiceSettingsValidator } from './invoice-settings-validator';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { DOCUMENT, Location } from "@angular/common";
import { ActivatedRoute } from '@angular/router';
import { TitleService } from './../../../../common-services/title.service';
import { slideInRightOnEnterAnimation, slideOutRightOnLeaveAnimation } from 'angular-animations';
let InvoiceSettingsComponent = class InvoiceSettingsComponent {
    //***********************************************Life Hooks Event*********************************************//
    constructor(sInvoiceSettingsService, sAlertMessageService, sCheck, sErrorHandler, sErrorMessagesService, pFormBuilder, sActivatedRoute, sPrivilegeService, sTitleService, sResponsiveService, pLocation, sDocument) {
        this.sInvoiceSettingsService = sInvoiceSettingsService;
        this.sAlertMessageService = sAlertMessageService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.pFormBuilder = pFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.sResponsiveService = sResponsiveService;
        this.pLocation = pLocation;
        this.sDocument = sDocument;
        this.cIsWritePrivilege = false;
        this.cInvoiceSettingName = '';
        this.missingplaceholder = false;
        this.bothplaceholder1 = false;
        this.bothplaceholder3 = false;
        this.createForm();
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
        this.cInvoiceSettings = new InvoiceSettings();
        this.cInvoiceSettingsAlias = new InvoiceSettingsAlias();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.InvoiceSettings);
        this.sTitleService.setTitle(this.sTitleService.InvoiceSettings);
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.cIsWritePrivilege) {
                    this.mForm.disable();
                    this.mForm1.disable();
                    this.mForm2.disable();
                    this.mForm3.disable();
                    this.mForm4.disable();
                    this.mForm5.disable();
                    this.mForm6.disable();
                }
                this.cInvoiceSettingsProcEntity = mCommonResponse.data['invoiceSettings'];
                this.cInvoiceSettingsAlias = mCommonResponse.data['invoiceSettingsAlias'];
                this.cInvoiceSettingsReq = this.cInvoiceSettingsProcEntity;
                if (this.sCheck.isNotNullString(this.cInvoiceSettingsProcEntity.settingInvValidityType)) {
                    this.cInvoiceSettingsReq.settingInvValidityType = this.cInvoiceSettingsProcEntity.settingInvValidityType.toLocaleLowerCase();
                    this.mForm1.controls['settingInvValidityType'].setValue(this.cInvoiceSettingsReq.settingInvValidityType);
                    if (this.cInvoiceSettingsReq.settingInvValidityType == 'minutes') {
                        this.mForm1.controls['settingInvValidity'].setValue('');
                        this.mForm1.controls['settingInvValidity'].clearValidators();
                        this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.minutes);
                    }
                    if (this.cInvoiceSettingsReq.settingInvValidityType == 'hours') {
                        this.mForm1.controls['settingInvValidity'].setValue('');
                        this.mForm1.controls['settingInvValidity'].clearValidators();
                        this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.hours);
                    }
                    if (this.cInvoiceSettingsReq.settingInvValidityType == 'days') {
                        this.mForm1.controls['settingInvValidity'].setValue('');
                        this.mForm1.controls['settingInvValidity'].clearValidators();
                        this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.days);
                    }
                }
                if (!this.sCheck.isNotNullNumber(this.cInvoiceSettingsProcEntity.settingInvValidity)) {
                    this.cInvoiceSettingsReq.settingInvValidityEdit = 'Y';
                    this.mForm1.controls['settingInvValidityEdit'].disable();
                }
                if (this.sCheck.isNotNullString(this.cInvoiceSettingsProcEntity.settingMinInvAmount) && this.cInvoiceSettingsProcEntity.settingMinInvAmount == 'N') {
                    this.mForm2.controls['settingMinInvAmountEdit'].disable();
                }
                else {
                    this.mForm2.controls['settingMinInvAmountEdit'].enable();
                }
                if (this.sCheck.isNotNullString(this.cInvoiceSettingsProcEntity.settingEmailDescription)) {
                    this.mForm3.controls['settingEmailDescriptionEdit'].enable();
                }
                else {
                    this.mForm3.controls['settingEmailDescriptionEdit'].disable();
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        });
        // this.mForm3.controls['settingInvMailFrom'].disable();
        if (this.sResponsiveService.isMaxWidth767Device()) {
            document.getElementsByClassName('tab-link')[0].classList.add('slideleft');
        }
        document.getElementsByClassName('footer')[0].classList.add('setting-footer-s');
    }
    //*********************************************** Validation ********************************************//
    createForm() {
        this.mForm1 = this.pFormBuilder.group({
            settingInvNew: [''],
            settingInvItemEdit: [''],
            settingInvQuick: [''],
            settingInvRecurring: [''],
            settingInvAdvance: [''],
            settingInvValidity: ['', Validators.min(1)],
            settingInvValidityType: [''],
            settingInvValidityEdit: [''],
            settingInvExpiryVisible: ['']
        });
        this.mForm2 = this.pFormBuilder.group({
            settingMinInvAmount: [''],
            settingMinInvAmountEdit: ['']
        });
        this.mForm3 = this.pFormBuilder.group({
            settingInvMailFrom: ['', [
                    Validators.maxLength(70),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.email
                ]],
            settingInvSubject: ['', [
                    Validators.maxLength(100),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForSubject,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.emailSub
                ]],
            settingInvSubjectEdit: [''],
            settingEmailDescription: ['', [
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.letterSpaceUnderscoreColon,
                    InvoiceSettingsValidator.isConsecuSpecialCharDesc
                ]],
            settingEmailDescriptionEdit: [''],
            settingInvMerCopy: [''],
            settingInvUserCopy: [''],
        });
        this.mForm4 = this.pFormBuilder.group({
            settingInvSMSContent: ['', [
                    Validators.required,
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForSMS,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.smsContent
                ]],
            settingInvSMSEdit: [''],
            settingInvSMS: [''],
            settingInvWhatsApp: ['']
        });
        this.mForm5 = this.pFormBuilder.group({
            settingBizAddress: ['', [
                    Validators.maxLength(300),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForAddr,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.customAddress
                ]],
            settingBizPhone: ['', [
                    Validators.minLength(4),
                    Validators.maxLength(20)
                ]],
            settingBizEmail: ['', [
                    Validators.maxLength(70),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialChar,
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.email
                ]],
        });
        this.mForm6 = this.pFormBuilder.group({
            settingInvTerms: ['', [
                    Validators.maxLength(500),
                    InvoiceSettingsValidator.isBeginSpecialChar,
                    InvoiceSettingsValidator.isEndSpecialCharForTerms,
                    InvoiceSettingsValidator.isConsecuSpecialCharInvoice,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            settingInvTermsEdit: [''],
        });
        this.mForm = this.pFormBuilder.group({
            aliasCustomerName: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasMerRefNo: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasMerRefNo1: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasInvoiceId: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasTermsConditions: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasItems: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasDescription: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasUnitCost: ['', [
                    Validators.required,
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasNetAmount: ['', [
                    Validators.required,
                    Validators.maxLength(35),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasMerRefNo2: ['', [
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasMerRefNo3: ['', [
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]],
            aliasMerRefNo4: ['', [
                    Validators.maxLength(25),
                    InvoiceSettingsValidator.isConsecuSpecialChar,
                    InvoiceSettingsValidator.termsConditionInv
                ]]
        });
    }
    onlyNumbersAllowed(pEvent) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    //***********************************************Button Click Event*******************************************//
    onSearchClick() {
        this.sInvoiceSettingsService.fetchAllInvoiceSettings(this.cInvoiceSettingsReq)
            .subscribe(rResponse => this.fetchAllInvoiceSettingsSuccess(rResponse), error => { console.log('error'); });
    }
    onSaveClick(pForm) {
        console.log(this.cInvoiceSettingsReq);
        if (this.sCheck.isNotNullString(this.cInvoiceSettingsReq.settingInvValidityType) && this.sCheck.isNullString(String(this.cInvoiceSettingsReq.settingInvValidity))) {
            this.cInvoiceSettingsReq.settingInvValidityType = null;
        }
        if (!(this.cInvoiceSettingsReq.settingInvNew == 'N' && this.cInvoiceSettingsReq.settingInvQuick == 'N')) {
            if (pForm.valid) {
                // this.cInvoiceSettingsReq.settingInvValidityType = pForm.value.settingInvValidityType;
                console.log("sending request" + JSON.stringify(this.cInvoiceSettingsReq));
                this.sInvoiceSettingsService.updateInvoiceSettings(this.cInvoiceSettingsReq, this.cInvoiceSettingsAlias)
                    .subscribe(pResponse => this.saveInvoiceSettingsSuccess(pResponse, pForm), error => { console.log('error'); });
            }
            else {
                CustomValidator.validateAllFields(pForm);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg("Either of Simple or Itemized invoice type must be enabled.");
            this.onSearchClick();
        }
    }
    onCancelClick() {
        this.bothplaceholder1 = false;
        this.bothplaceholder3 = false;
        this.missingplaceholder = false;
        this.cInvoiceSettingsReq = new InvoiceSettingsReq();
        this.onSearchClick();
    }
    // public onEmailIDClick() {
    //     this.cInvoiceSettings.isEditClick = !this.cInvoiceSettings.isEditClick;
    //     if (this.cInvoiceSettings.isSaveClick == "EDIT") {
    //         this.cInvoiceSettings.isSaveClick = "SAVE";
    //         this.mForm3.controls['settingInvMailFrom'].enable();
    //     }
    //     else if (this.cInvoiceSettings.isSaveClick == "SAVE") {
    //         this.cInvoiceSettings.isSaveClick = "EDIT";
    //         this.mForm3.controls['settingInvMailFrom'].disable();
    //     }
    // }
    onSwitchChange(event, switchValue) {
        if (event.target.checked) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
        }
        else {
            this.cInvoiceSettingsReq[switchValue] = 'N';
        }
    }
    onSwitchChangePartialPayment(event, switchValue) {
        if (event.target.checked) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
            this.mForm2.controls['settingMinInvAmountEdit'].enable();
        }
        else {
            console.log("disabled");
            this.cInvoiceSettingsReq[switchValue] = 'N';
            this.cInvoiceSettingsReq.settingMinInvAmountEdit == 'N';
            this.mForm2.controls['settingMinInvAmountEdit'].setValue("N");
            this.mForm2.controls['settingMinInvAmountEdit'].disable();
            //multiple partial payment  this.mForm2.controls['multiplepartialpayment'].disable();
        }
    }
    onInputFieldClick(event, value, switchValue) {
        if (event && (value == '' || value == null)) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
            this.mForm.controls[switchValue].disable();
        }
        else {
            this.mForm.controls[switchValue].enable();
        }
    }
    onInputFieldTcClick(event, value, switchValue) {
        if (event && (value == '' || value == null)) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
            this.mForm6.controls[switchValue].disable();
        }
        else {
            this.mForm6.controls[switchValue].enable();
        }
    }
    onInputFieldEmailClick(event, value, switchValue) {
        if (event && (value == '' || value == null)) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
            this.mForm3.controls[switchValue].disable();
        }
        else {
            this.mForm3.controls[switchValue].enable();
        }
    }
    onInputField(event, value, switchValue) {
        if (event && (value == '' || value == null)) {
            this.cInvoiceSettingsReq[switchValue] = 'Y';
            this.mForm1.controls[switchValue].disable();
        }
        else {
            this.mForm1.controls[switchValue].enable();
        }
    }
    onInvValidityClick(event, value) {
        if (event && value != null) {
            this.mForm1.controls['settingInvValidityType'].setValidators(Validators.required);
            this.mForm1.controls['settingInvValidityType'].markAsTouched({ onlySelf: true });
            this.mForm1.controls['settingInvValidityType'].updateValueAndValidity();
        }
    }
    onBackClick() {
        document.getElementsByClassName('tab-link')[0].classList.remove('slideleft');
        document.getElementsByClassName('footer')[0].classList.remove('setting-footer-h');
    }
    onTabHeadingClick(pSettingName) {
        this.onSearchClick();
        this.cInvoiceSettingName = pSettingName;
        if (this.sResponsiveService.isMaxWidth767Device()) {
            if (document.getElementsByClassName('tab-link')[0].classList.contains('slideright')) {
                document.getElementsByClassName('tab-link')[0].classList.remove('slideright');
                document.getElementsByClassName('tab-link')[0].classList.add('slideleft');
                document.getElementsByClassName('footer')[0].classList.add('setting-footer-h');
            }
            else {
                document.getElementsByClassName('tab-link')[0].classList.add('slideleft');
                document.getElementsByClassName('footer')[0].classList.add('setting-footer-h');
            }
        }
    }
    setInvValidityType(event) {
        this.cInvoiceSettingsReq.settingInvValidityType = event.value;
        if (this.cInvoiceSettingsReq.settingInvValidityType == 'minutes') {
            this.mForm1.controls['settingInvValidity'].setValue('');
            this.mForm1.controls['settingInvValidity'].clearValidators();
            this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.minutes);
        }
        if (this.cInvoiceSettingsReq.settingInvValidityType == 'hours') {
            this.mForm1.controls['settingInvValidity'].setValue('');
            this.mForm1.controls['settingInvValidity'].clearValidators();
            this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.hours);
        }
        if (this.cInvoiceSettingsReq.settingInvValidityType == 'days') {
            this.mForm1.controls['settingInvValidity'].setValue('');
            this.mForm1.controls['settingInvValidity'].clearValidators();
            this.mForm1.controls['settingInvValidity'].setValidators(InvoiceSettingsValidator.days);
        }
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllInvoiceSettingsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(this.cCommonResponse)) {
                if (this.sCheck.isNotNullObject(this.cCommonResponse.data)) {
                    this.cInvoiceSettingsProcEntity = this.cCommonResponse.data['invoiceSettings'];
                    this.cInvoiceSettingsAlias = this.cCommonResponse.data['invoiceSettingsAlias'];
                    this.cInvoiceSettingsReq = this.cInvoiceSettingsProcEntity;
                    if (this.sCheck.isNotNullString(this.cInvoiceSettingsProcEntity.settingInvValidityType)) {
                        this.cInvoiceSettingsReq.settingInvValidityType = this.cInvoiceSettingsProcEntity.settingInvValidityType.toLocaleLowerCase();
                        this.mForm1.controls['settingInvValidityType'].setValue(this.cInvoiceSettingsReq.settingInvValidityType);
                    }
                    else {
                        this.cInvoiceSettingsReq.settingInvValidityType = null;
                        this.mForm1.controls['settingInvValidityType'].setValue(null);
                    }
                }
            }
        }
        // this.mForm3.controls['settingInvMailFrom'].disable();
        this.cInvoiceSettings.isSaveClick = "EDIT";
    }
    saveInvoiceSettingsSuccess(pResponse, pForm) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (mCommonResponse.isSuccess) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                    console.log("message" + mCommonResponse.messageDesc);
                    this.mForm1.controls['settingInvValidityType'].clearValidators();
                    this.mForm1.controls['settingInvValidityType'].updateValueAndValidity();
                    this.onSearchClick();
                }
                else if (mCommonResponse.isValidationFail) {
                    this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, pForm);
                }
                else if (mCommonResponse.isFail) {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
                else {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        }
    }
    checkPlaceHolder() {
        console.log("place holder check");
        let str = this.cInvoiceSettingsReq.settingInvSMSContent;
        if (!(str.includes("Invoice_Amount") && str.includes('Pay_Link')))
            this.missingplaceholder = true;
        else
            this.missingplaceholder = false;
        if ((str.includes("LegalEntity_Name") && str.includes('Webstore_Name')))
            this.bothplaceholder1 = true;
        else
            this.bothplaceholder1 = false;
        if ((str.includes("Invoice_ID") && str.includes('Invoice_RefNumber')))
            this.bothplaceholder3 = true;
        else
            this.bothplaceholder3 = false;
        if (str == '') {
            this.bothplaceholder3 = false;
            this.bothplaceholder1 = false;
            this.missingplaceholder = false;
        }
    }
    onBackclick() {
        this.pLocation.back();
    }
};
InvoiceSettingsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-invoice-settings',
        templateUrl: './invoice-settings.component.html',
        styleUrls: ['./invoice-settings.component.css'],
        animations: [
            slideInRightOnEnterAnimation(),
            slideOutRightOnLeaveAnimation()
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(11, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [InvoiceSettingsService,
        AlertMessageService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        FormBuilder,
        ActivatedRoute,
        PrivilegeService,
        TitleService,
        ResponsiveService,
        Location,
        Document])
], InvoiceSettingsComponent);
export { InvoiceSettingsComponent };
//# sourceMappingURL=invoice-settings.component.js.map