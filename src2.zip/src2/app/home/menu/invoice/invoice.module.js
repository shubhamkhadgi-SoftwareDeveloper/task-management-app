import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonAndThirdPartyModule } from '../../../common-modules/common-and-third-party.module';
import { InvoiceRoutingModule, InvoiceRoutedComponents } from './invoice.routing';
import { EditInvoiceComponent } from './invoice/edit-invoice/edit-invoice.component';
import { BulkUploadComponent } from './bulk-upload/bulk-upload.component';
import { BulkUploadDetailComponent } from './bulk-upload/bulk-upload-detail/bulk-upload-detail.component';
import { CopyPasteControlModule } from '../../../common-modules/copy-paste-control.module';
let InvoiceModule = class InvoiceModule {
};
InvoiceModule = tslib_1.__decorate([
    NgModule({
        imports: [
            CommonAndThirdPartyModule,
            InvoiceRoutingModule,
            CopyPasteControlModule,
        ],
        declarations: [InvoiceRoutedComponents, EditInvoiceComponent, BulkUploadComponent, BulkUploadDetailComponent]
    })
], InvoiceModule);
export { InvoiceModule };
//# sourceMappingURL=invoice.module.js.map