export class BulkInvoiceReq {
    //new
    constructor() {
        this.isRecurring = false;
    }
}
//# sourceMappingURL=bulk-invoice-req.js.map