import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from '../../../../../common-services/landing-page-msg.service';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
import { ErrorHandlerService } from '.././../../../../common-services/error-handler.service';
import { BulkUploadDetailReq } from '../bulk-upload-detailReq';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { BulkUploadService } from '../bulk-upload.service';
import { CommonResponse } from '.././../../../../common-response/common-response.res';
import { InvoiceService } from '../../../invoice/invoice/invoice.service';
import { Router } from '@angular/router';
import { Invoice } from '../../../invoice/invoice/invoice.class';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
let BulkUploadDetailComponent = class BulkUploadDetailComponent {
    constructor(document, pFormBuilder, pModalService, sCheck, pMerchInfoService, pBulkUploadService, sResponsiveService, sAlertMessageService, sErrorHandler, sErrorMessagesService, route, pInvoiceService, sLandingPageMsgService) {
        this.document = document;
        this.pFormBuilder = pFormBuilder;
        this.pModalService = pModalService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.pBulkUploadService = pBulkUploadService;
        this.sResponsiveService = sResponsiveService;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.route = route;
        this.pInvoiceService = pInvoiceService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.backBtnEvent = new EventEmitter();
        this.previewInvoiceEvent = new EventEmitter();
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.searchflag = 'searchform';
        this.isExportClick = false;
        this.calOptionsWithoutTime = {
            autoApply: false,
            autoUpdateInput: true,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: false,
            opens: 'left',
        };
        this.cCommonResponse = new CommonResponse();
        this.searchByLabel = 'Search By';
        this.cInvoice = new Invoice();
        this.cBulkUploadDetailReq = new BulkUploadDetailReq();
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: null });
        this.searchBy.push({ label: 'Invoice #', value: 'searchByInvoiceNo' });
        this.searchBy.push({ label: 'Email ID', value: 'searchByEmail' });
        this.searchBy.push({ label: 'Mobile No #', value: 'searchByMobile' });
        this.cRecPayStatusList = [];
        this.cRecPayStatusList.push({ label: 'Paid', value: 'Successful' });
        this.cRecPayStatusList.push({ label: 'Pending', value: 'Pending' });
        this.cRecPayStatusList.push({ label: 'Cancelled', value: 'Cancelled' });
        this.cRecPayStatusList.push({ label: 'Expired', value: 'Expired' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
            showDropdowns: true,
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
    }
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchByValue'].disable();
        window.scrollTo(0, 0);
        this.onSearchClick();
    }
    ;
    //*****************************Validations********************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchBy: [null],
            searchByValue: [''],
            fromToDate: [''],
            searchSubAccId: [''],
            searchInvCurr: [''],
            searchPayStatus: [''],
            searchMerchId: [''],
        });
    }
    onSearchByOptionClick() {
        this.isSearchByClick = !this.isSearchByClick;
        if (this.cBulkUploadDetailReq.searchBy == 'searchByInvoiceNo') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.numbersOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cBulkUploadDetailReq.searchBy == 'searchByEmail') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cBulkUploadDetailReq.searchBy == 'searchByMobile') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, InvoiceSettingsValidator.mobile]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cInvoice.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onExportExcelClick() {
        this.isExportClick = !this.isExportClick;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        console.log("sending request to export" + this.batchId);
        this.cBulkUploadDetailReq.searchByBatchId = this.batchId;
        console.log("sending request to export" + this.cBulkUploadDetailReq.searchByBatchId);
        this.pBulkUploadService.exportExcelInv(this.cBulkUploadDetailReq, this.batchId)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSearchPanelClick() {
        console.log("Search Before ", this.isSearchPanelClick);
        if (!this.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
            console.log("Search After ", this.isSearchPanelClick);
        }
        else {
            this.isSearchPanelClick = true;
        }
    }
    ;
    onBackDetailClick() {
        this.cPreviewInvoiceDetailRes = null;
        this.cInvoiceDetailRes = null;
        if (this.cInvoice.isInvoiceDetailClick) {
            this.cInvoice.isInvoiceDetailClick = false;
        }
        else {
            this.backBtnEvent.emit(false);
        }
    }
    isSearchResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.add('absolute');
            this.document.body.classList.add('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.add('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            }
            if (this.document.getElementsByClassName('daterangepicker').length > 0) {
                this.document.getElementsByClassName('slideL')[0].appendChild(this.document.getElementsByClassName('daterangepicker')[0]);
            }
            return true;
        }
        else {
            return false;
        }
    }
    isCancelResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.remove('absolute');
            this.document.body.classList.remove('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.remove('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.remove('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    selectedDate(value) {
        this.cBulkUploadDetailReq.searchDateForm = value.start.format("DD-MM-YYYY");
        this.cBulkUploadDetailReq.searchDateTo = value.end.format("DD-MM-YYYY");
        this.fromToDate = this.cBulkUploadDetailReq.searchDateForm + ' - ' + this.cBulkUploadDetailReq.searchDateTo;
    }
    onDropdownCloseClick() {
        this.isSearchByClick = false;
    }
    onSearchByClick() {
        this.isSearchByClick = !this.isSearchByClick;
    }
    onSearchClick() {
        this.cBulkUploadDetailReq.searchByBatchId = this.batchId;
        if (this.mForm.valid) {
            if (this.searchflag == 'searchform') {
                this.cBulkUploadDetailReq.searchPageNo = 1;
            }
            this.pBulkUploadService.fetchBatchRecords(this.cBulkUploadDetailReq)
                .subscribe(rResponse => this.fetchBatchRecordSuccess(rResponse), error => { console.log('error'); });
        }
    }
    fetchBatchRecordSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(pResponse)) {
            mCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    if (this.sCheck.isNotNullList(mCommonResponse.data['invoiceList'])) {
                        this.pInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                        console.log(this.pInvoiceProcEntity);
                        this.isSearchPanelClick = false;
                    }
                    else {
                        this.pInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                        this.isSearchPanelClick = false;
                        this.landingPageMsg = "No records found ";
                    }
                }
            }
        }
    }
    onCancelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.cBulkUploadDetailReq = new BulkUploadDetailReq();
        this.cBulkUploadDetailReq.searchBy = 'Search By';
        this.calOptions = {
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
            showDropdowns: true,
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.onSearchClick();
    }
    onCancelPopClick() {
        this.cBillAndRegId = null;
        this.cModalRef.hide();
    }
    onPageChange(event) {
        this.cBulkUploadDetailReq.searchPageSize = event.cPageSize;
        this.cBulkUploadDetailReq.searchPageNo = event.cPageNo;
        this.searchflag = 'pageChange';
        this.onSearchClick();
    }
    onPageClick() {
        this.isSearchPanelClick = false;
    }
    onSendMailClick(event) {
        this.pInvoiceService.resendInvoice(event)
            .subscribe(pResponse => this.resendInvoiceSuccess(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    resendInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.onSearchClick();
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
    }
    onInvoiceDetailClick(pInvoiceNo, regId) {
        this.cInvoiceDetailRes = null;
        this.pInvoiceService.fetchInvoiceDetail({ 'invoiceNo': pInvoiceNo, 'regId': regId })
            .subscribe(pResponse => this.fetchInvoiceDetailSuccess(pResponse), error => { console.log("error-->" + JSON.stringify(error)); });
    }
    fetchInvoiceDetailSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cInvoiceDetailRes = mCommonResponse.data;
                if (this.sCheck.isNotNullObject(this.cInvoiceDetailRes) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity) && this.sCheck.isNotNullObject(this.cInvoiceDetailRes.transactionDetails.transactionDetailsProcEntity.transactionDetailsProcEntity)) {
                    console.log(this.cInvoiceDetailRes);
                    console.log(this.cInvoiceDetailRes.transactionDetails);
                    this.cInvoice.isInvoiceDetailClick = true;
                    this.cInvoice.isActiveForInvoiceDetail = true;
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    previewInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPreviewInvoiceDetailRes = mCommonResponse.data;
                this.cInvoice.isInvoiceDetailClick = true;
                this.cInvoice.isActiveForInvoiceDetail = false;
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onSingleCancelClick(pBillAndRegId) {
        this.cInvoice.isSelActionClick = false;
        this.pInvoiceService.cancelInvoice({ "billId": [pBillAndRegId] })
            .subscribe(pResponse => this.cancelInvoiceSuccess(pResponse), error => { this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.errorResponse); });
    }
    cancelInvoiceSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.cBulkUploadDetailReq.searchByBatchId = this.batchId;
                this.pBulkUploadService.fetchBatchRecords(this.cBulkUploadDetailReq)
                    .subscribe(rResponse => this.fetchBatchRecordSuccess(rResponse), error => { console.log('error'); });
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.cInvoice.selectedInvoice = [];
        this.cInvoice.isAllInvoiceCheck = false;
        this.cModalRef.hide();
    }
    onPopupCancelClick(pBillAndRegId, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cBillAndRegId = pBillAndRegId;
    }
    onCancelConfirmClick() {
        this.onSingleCancelClick(this.cBillAndRegId);
    }
    PreviewClick(pRegId, pInvoiceNo, pPaymentStatus) {
        this.pInvoiceDataService.regId = pRegId;
        this.pInvoiceDataService.invoiceNo = pInvoiceNo;
        this.pInvoiceDataService.paymentStatus = pPaymentStatus;
        this.route.navigate(['home/menu/invoice/invoice/previewInvoice']);
    }
    onCalenderIconClick(dpReccurProf) {
        dpReccurProf.click();
    }
};
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Array)
], BulkUploadDetailComponent.prototype, "pInvoiceProcEntity", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Number)
], BulkUploadDetailComponent.prototype, "batchCount", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", Number)
], BulkUploadDetailComponent.prototype, "batchId", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String)
], BulkUploadDetailComponent.prototype, "createdDate", void 0);
tslib_1.__decorate([
    Input(),
    tslib_1.__metadata("design:type", String)
], BulkUploadDetailComponent.prototype, "batchStatus", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], BulkUploadDetailComponent.prototype, "backBtnEvent", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], BulkUploadDetailComponent.prototype, "previewInvoiceEvent", void 0);
BulkUploadDetailComponent = tslib_1.__decorate([
    Component({
        selector: 'app-bulk-upload-detail',
        templateUrl: './bulk-upload-detail.component.html',
        styleUrls: ['./bulk-upload-detail.component.css'],
        preserveWhitespaces: true,
        animations: [
            expandOnEnterAnimation({ duration: 400 }),
            collapseOnLeaveAnimation({ duration: 400 })
        ]
    }),
    tslib_1.__param(0, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [Document,
        FormBuilder,
        BsModalService,
        ConditionalCheckService,
        MerchInfoService,
        BulkUploadService,
        ResponsiveService,
        AlertMessageService,
        ErrorHandlerService,
        ErrorMessagesService,
        Router,
        InvoiceService,
        LandingPageMsgService])
], BulkUploadDetailComponent);
export { BulkUploadDetailComponent };
//# sourceMappingURL=bulk-upload-detail.component.js.map