import { async, TestBed } from '@angular/core/testing';
import { BulkUploadDetailComponent } from './bulk-upload-detail.component';
describe('BulkUploadDetailComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BulkUploadDetailComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(BulkUploadDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=bulk-upload-detail.component.spec.js.map