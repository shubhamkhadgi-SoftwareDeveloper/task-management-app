import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { DatePipe } from '@angular/common';
let BulkUploadService = class BulkUploadService {
    constructor(pApiRequestService, pdatepipe) {
        this.pApiRequestService = pApiRequestService;
        this.pdatepipe = pdatepipe;
        this.cBulkInvoiceBaseUrl = 'bulkUpload/';
        this.cFetchBatchList = this.cBulkInvoiceBaseUrl + 'fetchBulkUploadData';
        this.cUploadInvoiceExcelDataUrl = this.cBulkInvoiceBaseUrl + 'uploadInvoiceExcelData';
        this.cDownloadBulkInvoiceResUrl = this.cBulkInvoiceBaseUrl + 'downloadInvSampleData';
        this.cDownloadBulkFailedInvoiceResUrl = this.cBulkInvoiceBaseUrl + 'downloadFailedBulkData';
        this.cFetchBatchRecordList = this.cBulkInvoiceBaseUrl + 'fetchBatchData';
        this.cExportBatchRecordList = this.cBulkInvoiceBaseUrl + 'exportBatchData';
    }
    fetchAllBatchInvoices(pBulkUploadSearch) {
        return this.pApiRequestService.httpPostRequest(pBulkUploadSearch, this.cFetchBatchList);
    }
    uploadBulkInvoiceExcel(pUploadFile, pBulkInvoiceReq) {
        return this.pApiRequestService.fileUploadRequest(pUploadFile, pBulkInvoiceReq, this.cUploadInvoiceExcelDataUrl);
    }
    downloadSampleFileExcel(pBulkUploadSearch, id) {
        return this.pApiRequestService.exportFileRequest(pBulkUploadSearch, this.cDownloadBulkInvoiceResUrl, 'Batch' + id + '_' + this.pdatepipe.transform(new Date(), 'dd/MM/yyyy h:mm:ss') + 'Records.xlsx');
    }
    downloadFailedExcelReport(BulkInvoiceRes) {
        return this.pApiRequestService.exportFileRequest(BulkInvoiceRes, this.cDownloadBulkFailedInvoiceResUrl, 'failedinvoice' + this.pdatepipe.transform(new Date(), 'dd/MM/yyyy h:mm:ss') + '.xlsx');
    }
    fetchBatchRecords(pBulkUploadDetailSearchReq) {
        return this.pApiRequestService.httpPostRequest(pBulkUploadDetailSearchReq, this.cFetchBatchRecordList);
    }
    exportExcelInv(pRecurringOcurredDetailsReq, id) {
        return this.pApiRequestService.exportFileRequest(pRecurringOcurredDetailsReq, this.cExportBatchRecordList, 'Batch' + id + 'Records.xlsx');
    }
};
BulkUploadService = tslib_1.__decorate([
    Injectable({
        providedIn: 'root'
    }),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService,
        DatePipe])
], BulkUploadService);
export { BulkUploadService };
//# sourceMappingURL=bulk-upload.service.js.map