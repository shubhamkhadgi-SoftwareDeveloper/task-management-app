export class BulkInvoiceRes {
    constructor() {
        this.isReccuring = false;
        this.uploadFailed = false;
        this.uploadSuccess = false;
        //new
    }
}
//# sourceMappingURL=bulk-invoice-res.js.map