import { TestBed } from '@angular/core/testing';
import { BulkUploadResolverService } from './bulk-upload-resolver.service';
describe('BulkUploadResolverService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));
    it('should be created', () => {
        const service = TestBed.get(BulkUploadResolverService);
        expect(service).toBeTruthy();
    });
});
//# sourceMappingURL=bulk-upload-resolver.service.spec.js.map