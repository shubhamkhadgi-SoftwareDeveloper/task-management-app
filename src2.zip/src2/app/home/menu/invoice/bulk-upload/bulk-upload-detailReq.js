export class BulkUploadDetailReq {
    constructor() {
        this.searchPageSize = 25;
        this.searchPageNo = 1;
        this.searchIsRecurring = false;
    }
}
//# sourceMappingURL=bulk-upload-detailReq.js.map