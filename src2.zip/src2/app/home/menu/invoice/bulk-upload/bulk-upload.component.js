import * as tslib_1 from "tslib";
import { Component, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { trigger, style, transition, animate } from '@angular/animations';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from './../../../../common-response/common-response.res';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { BulkUploadSearchReq } from './bulk-upload-searchReqDTO.req';
import { CommonDtoReq } from './commonDtoReq.req';
import { FormBuilder } from '@angular/forms';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { BulkUploadService } from './bulk-upload.service';
import { BulkUpload } from './bulk-upload.class';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { BulkInvoiceReq } from './bulk-invoice-req';
import { BulkInvoiceRes } from './bulk-invoice-res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BulkUploadDetailReq } from './bulk-upload-detailReq';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { TitleService } from './../../../../common-services/title.service';
import { DatePipe } from '@angular/common';
let BulkUploadComponent = class BulkUploadComponent {
    constructor(document, sActivatedRoute, sCheck, pFormBuilder, sModalService, sAlertMessageService, pModalService, sErrorMessagesService, sLandingPageMsgService, sErrorHandler, pBulkUploadService, pMerchInfoService, sPrivilegeService, sTitleService, datepipe) {
        this.document = document;
        this.sActivatedRoute = sActivatedRoute;
        this.sCheck = sCheck;
        this.pFormBuilder = pFormBuilder;
        this.sModalService = sModalService;
        this.sAlertMessageService = sAlertMessageService;
        this.pModalService = pModalService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sErrorHandler = sErrorHandler;
        this.pBulkUploadService = pBulkUploadService;
        this.pMerchInfoService = pMerchInfoService;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.datepipe = datepipe;
        this.templateUpload = false;
        this.templateSuccess = false;
        this.templateFailed = false;
        this.isBatchList = false;
        this.cRecordTo = 25;
        this.cRecordFrom = 1;
        this.progressBar = 0;
        this.cIsWritePrivilege = false;
        this.today = new Date();
        this.isSearchPanelClick = false;
        this.isShowSearchButton = false;
        this.pBulkUploadSearchReq = new BulkUploadSearchReq();
        this.pCommonReq = new CommonDtoReq();
        this.cBulkUpload = new BulkUpload();
        this.cBulkInvoiceReq = new BulkInvoiceReq();
        this.cBulkInvoiceRes = new BulkInvoiceRes();
        this.pBulkUploadDetailSearchReq = new BulkUploadDetailReq();
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.BulkUpload);
        this.sTitleService.setTitle(this.sTitleService.BulkUpload);
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
    }
    ;
    ngOnInit() {
        this.createSearchForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cBatchList = mCommonResponse.data['batchUploadList'];
                    this.cBulkUpload.batchListCount = mCommonResponse.data['count'];
                    console.log("this is count and list" + this.cBatchList);
                    if (this.cBulkUpload.batchListCount > 0) {
                        this.isBatchList = true;
                        this.isShowSearchButton = true;
                        console.log(this.cBatchList);
                    }
                    else {
                        this.landingPageMsg = "No record found from " + this.datepipe.transform(new Date(), 'dd-MM-yyyy') + " to " + this.datepipe.transform(new Date(), 'dd-MM-yyyy');
                    }
                }
                else if (this.sCheck.isNotNullObject(this.cResponse.messageDesc)) {
                    this.sAlertMessageService.popupAlertMsg(this.cResponse.messageDesc);
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = "Fetching operation failed.";
                this.cBatchList = null;
                this.cBulkUpload.batchListCount = 0;
            }
        });
    }
    ;
    createSearchForm() {
        this.mSearchForm = this.pFormBuilder.group({
            searchByName: ['', [CustomValidator.batchFileName]],
            fromToDate: [],
        });
    }
    OnSearchClick() {
        if (this.pBulkUploadSearchReq.searchByValue != null && this.mSearchForm.valid && this.pBulkUploadSearchReq.searchByValue.trim() != "") {
            this.pBulkUploadSearchReq.searchBy = "batchFileName";
            this.FetchBatchList(this.pBulkUploadSearchReq);
        }
        else if (this.pBulkUploadSearchReq.searchStartDate != null && this.pBulkUploadSearchReq.searchEndDate != null)
            this.FetchBatchList(this.pBulkUploadSearchReq);
        else
            CustomValidator.validateAllFields(this.mSearchForm);
    }
    FetchBatchList(pBulkUploadSearchReq) {
        console.log(pBulkUploadSearchReq);
        this.pBulkUploadService.fetchAllBatchInvoices(pBulkUploadSearchReq).subscribe(rResponse => this.FetchBatchSuccess(rResponse), error => { console.log('error'); });
        this.pBulkUploadSearchReq.searchStartDate = null;
        this.pBulkUploadSearchReq.searchEndDate = null;
    }
    FetchBatchSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        this.isShowSearchButton = true;
        if (mCommonResponse.isSuccess) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cBatchList = mCommonResponse.data['batchUploadList'];
                this.cBulkUpload.batchListCount = mCommonResponse.data['count'];
                console.log("this is count and list" + this.cBatchList);
                this.isBatchList = false;
                if (this.cBatchList.length != 0 && this.cBulkUpload.batchListCount > 0) {
                    this.isBatchList = true;
                    console.log(this.cBatchList);
                }
                else {
                    var msg = "No Records Found";
                    this.landingPageMsg = msg;
                }
            }
            else if (this.sCheck.isNotNullObject(this.cResponse.messageDesc)) {
                this.sAlertMessageService.popupAlertMsg(this.cResponse.messageDesc);
            }
        }
        else if (mCommonResponse.isFail) {
            this.cBatchList = null;
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.isSearchPanelClick = false;
    }
    onSearchPanelClick() {
        if (!this.isSearchResponsive()) {
            this.isSearchPanelClick = !this.isSearchPanelClick;
        }
        else {
            this.isSearchPanelClick = true;
        }
    }
    ;
    onBackClick() {
        this.cBulkUpload.showDetails = !this.cBulkUpload.showDetails;
        //this.cInvoice.isInvoiceDetailClick = false;
    }
    onCancelClick() {
        if (!this.isCancelResponsive()) {
            this.isSearchPanelClick = false;
        }
        else {
            this.isSearchPanelClick = false;
        }
        this.mSearchForm.controls["searchByName"].clearValidators();
        this.pBulkUploadSearchReq.searchStartDate = null;
        this.pBulkUploadSearchReq.searchEndDate = null;
        this.cBulkUpload.calOptions = {
            maxDate: new Date(),
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            showDropdowns: true,
            singleDatePicker: false,
            opens: 'right'
        };
        this.pBulkUploadSearchReq.batchType = 'invoice';
        this.pBulkUploadSearchReq.searchStartDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.pBulkUploadSearchReq.searchEndDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        this.pBulkUploadSearchReq.displaySearchFromDate = this.datepipe.transform(new Date(), "dd-MM-yyyy");
        this.pBulkUploadSearchReq.displaySearchToDate = this.datepipe.transform(new Date(), "dd-MM-yyyy");
        this.cBulkUpload.fromToDate = this.pBulkUploadSearchReq.displaySearchFromDate + ' - ' + this.pBulkUploadSearchReq.displaySearchToDate;
        this.pBulkUploadSearchReq.searchByValue = null;
        this.isBatchList = false;
        this.FetchBatchList(this.pBulkUploadSearchReq);
    }
    ;
    isSearchResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.add('absolute');
            this.document.body.classList.add('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.add('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            }
            if (this.document.getElementsByClassName('daterangepicker').length > 0) {
                this.document.getElementsByClassName('slideL')[0].appendChild(this.document.getElementsByClassName('daterangepicker')[0]);
            }
            return true;
        }
        else {
            return false;
        }
    }
    ;
    isCancelResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.remove('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.remove('absolute');
            this.document.body.classList.remove('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.remove('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.remove('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.remove('slidepop');
            }
            return true;
        }
        else {
            return false;
        }
    }
    ;
    onPageChange(event) {
        console.log("paging event");
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.pBulkUploadSearchReq.pageNumber = event.cPageNo;
        this.pBulkUploadSearchReq.numberOfRecords = event.cPageSize;
        console.log("record from" + this.cRecordFrom);
        console.log("record to" + this.cRecordTo);
        console.log("page num" + this.pBulkUploadSearchReq.pageNumber);
        console.log("pagesize" + this.pBulkUploadSearchReq.pageSize);
        this.FetchBatchList(this.pBulkUploadSearchReq);
    }
    bulkUploadPopUp(template) {
        this.cBulkInvoiceRes.uploadSuccess = false;
        this.cBulkInvoiceRes.uploadFailed = false;
        this.cModalRef = this.sModalService.show(template, { class: 'modal-sm invoice-bulk-upload', keyboard: false, ignoreBackdropClick: true });
    }
    updateProgressBar() {
        this.progressBar++;
        console.log('---->>>> ', this.progressBar);
        if (this.progressBar == 99) {
            this.progressBar = 0;
        }
    }
    onChooseFile(event) {
        this.progressBar = 0;
        this.progressVar = setInterval(() => {
            this.updateProgressBar();
        }, 100);
        let fileList = event.target.files;
        if (fileList.length > 0) {
            if (fileList[0].type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
                this.cBulkUpload.uploadFile = fileList[0];
                this.cBulkUpload.uploadFileName = fileList[0].name;
                this.cBulkInvoiceReq.isRecurring = false;
                this.pBulkUploadService.uploadBulkInvoiceExcel(this.cBulkUpload.uploadFile, this.cBulkInvoiceReq) //InvoiceDetails.xlsx
                    .subscribe(rResponse => this.onUploadSuccess(rResponse), error => this.onUploadError(error));
                this.cBulkUpload.uploadFileName = "";
                this.cBulkUpload.uploadFile = null;
            }
            else {
                this.cModalRef.hide();
                this.sAlertMessageService.popupAlertMsg("Please upload valid .XLSX file.");
                clearInterval(this.progressVar);
                this.progressBar = 0;
            }
        }
    }
    onDownloadExcelFileClick() {
        this.pBulkUploadService.downloadSampleFileExcel(this.pCommonReq, this.pMerchInfoService.getRegId())
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    onDownloadFailedExcelFileClick() {
        this.pBulkUploadService.downloadFailedExcelReport(this.cBulkInvoiceRes)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    onUploadSuccess(pResponse) {
        if (pResponse) {
            clearInterval(this.progressVar);
            this.progressBar = 0;
        }
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cResponse = pResponse;
            console.log(this.cResponse);
            if (this.sCheck.isNotNullObject(this.cResponse)) {
                if (this.cResponse.code === 0 && this.cResponse.message == 'Success') {
                    if (this.sCheck.isNotNullObject(this.cResponse.data)) {
                        this.cBulkInvoiceRes = this.cResponse.data;
                        if (this.sCheck.isNotNullList(this.cResponse.data['batchId'])) {
                            this.cBulkInvoiceRes.batchId = this.cResponse.data['batchId'];
                            console.log("batchId" + this.cBulkInvoiceRes.batchId);
                        }
                        if (this.sCheck.isNotNullObject(this.cResponse.data['errorDescription'])) {
                            this.cBulkInvoiceRes.errorDescription = this.cResponse.data['errorDescription'];
                            console.log("error description of upload" + this.cBulkInvoiceRes.errorDescription);
                        }
                        if (this.sCheck.isNotNullObject(this.cResponse.data['totalCount'])) {
                            this.cBulkInvoiceRes.totalCount = this.cResponse.data['totalCount'];
                            console.log("total count" + this.cBulkInvoiceRes.totalCount);
                        }
                        if (this.sCheck.isNotNullString(this.cResponse.data['errorDesc'])) {
                            this.cBulkInvoiceRes.failureMsg = this.cResponse.data['errorDesc'];
                            this.sAlertMessageService.popupAlertMsg(this.cBulkInvoiceRes.failureMsg);
                        }
                        if (this.cResponse.data['reccuring']) {
                            this.cBulkInvoiceRes.isReccuring = this.cResponse.data['reccuring'];
                            console.log("reccuring " + this.cBulkInvoiceRes.isReccuring);
                        }
                        if (this.cResponse.data['uploadSuccess']) {
                            this.cBulkInvoiceRes.uploadSuccess = this.cResponse.data['uploadSuccess'];
                            console.log("uploadSuccess " + this.cBulkInvoiceRes.uploadSuccess);
                        }
                        if (this.cResponse.data['uploadFailed']) {
                            this.cBulkInvoiceRes.uploadFailed = this.cResponse.data['uploadFailed'];
                            console.log("uploadFailed " + this.cBulkInvoiceRes.uploadFailed);
                        }
                        if (this.sCheck.isNotNullString(this.cResponse.data['fileName'])) {
                            this.cBulkInvoiceRes.fileName = this.cResponse.data['fileName'];
                            console.log("filename " + this.cBulkInvoiceRes.fileName);
                        }
                        if (this.sCheck.isNotNullString(this.cResponse.data['successMsg'])) {
                            this.cBulkInvoiceRes.successMsg = this.cResponse.data['successMsg'];
                            this.cBulkInvoiceRes.uploadFailed = false;
                            this.cBulkInvoiceRes.uploadSuccess = true;
                        }
                        if (this.sCheck.isNotNullString(this.cResponse.data['batchId'])) {
                            this.cBulkInvoiceRes.batchId = this.cResponse.data['batchId'];
                            console.log("batchId " + this.cBulkInvoiceRes.batchId);
                        }
                        if (this.sCheck.isNotNullObject(this.cResponse.data['failedCount'])) {
                            this.cBulkInvoiceRes.failedCount = this.cResponse.data['failedCount'];
                            console.log("failed count" + this.cBulkInvoiceRes.failedCount);
                            if (this.cBulkInvoiceRes.failedCount != 0) {
                                this.cBulkInvoiceRes.uploadFailed = true;
                                this.cBulkInvoiceRes.uploadSuccess = false;
                            }
                        }
                    }
                }
                else {
                    if (this.sCheck.isNotNullObject(this.cResponse.messageDesc)) {
                        this.cModalRef.hide();
                        this.sAlertMessageService.popupAlertMsg(this.cResponse.messageDesc);
                    }
                }
            }
            this.pBulkUploadSearchReq.batchType = 'invoice';
            this.pBulkUploadSearchReq.searchByValue = null;
            this.pBulkUploadSearchReq.searchStartDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
            this.pBulkUploadSearchReq.searchEndDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
            this.FetchBatchList(this.pBulkUploadSearchReq);
        }
    }
    onUploadError(pError) {
        clearInterval(this.progressVar);
        this.progressBar = 0;
        this.sAlertMessageService.popupAlertMsg("No records updated/ or you are not uploading proper file./or you are uploading blank file..");
    }
    onRecordsClick(batchId, recordCount, createdDate, batchStatus) {
        console.log("sending batch data request");
        this.pBulkUploadDetailSearchReq.searchByBatchId = batchId;
        this.cBulkUpload.currBatchId = batchId;
        this.cBulkUpload.createdDate = createdDate;
        this.cBulkUpload.currStatus = batchStatus;
        this.cBulkUpload.batchCount = recordCount;
        this.pBulkUploadService.fetchBatchRecords(this.pBulkUploadDetailSearchReq)
            .subscribe(rResponse => this.fetchBatchRecordSuccess(rResponse), error => { console.log('error'); });
    }
    fetchBatchRecordSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(pResponse)) {
            mCommonResponse = pResponse;
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    if (this.sCheck.isNotNullList(mCommonResponse.data['invoiceList'])) {
                        this.cInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['pendingCount']))
                            this.pendingCount = mCommonResponse.data['pendingCount'];
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['expiredCount']))
                            this.expiredCount = mCommonResponse.data['expiredCount'];
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['successfulCount']))
                            this.successfulCount = mCommonResponse.data['successfulCount'];
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['cancelCount']))
                            this.cancelCount = mCommonResponse.data['cancelCount'];
                        console.log(this.cInvoiceProcEntity);
                    }
                    this.cBulkUpload.showDetails = true;
                }
            }
        }
    }
    onOccerClick($event) {
        this.cBulkUpload.showDetails = !this.cBulkUpload.showDetails;
    }
    onExportExcelClick(id) {
        console.log("sending request to export" + id);
        this.pBulkUploadDetailSearchReq.searchByBatchId = id;
        console.log("sending request to export" + this.pBulkUploadDetailSearchReq.searchByBatchId);
        this.pBulkUploadService.exportExcelInv(this.pBulkUploadDetailSearchReq, id)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onDetailClick(batchId, recordCount, filename, createdDate, pTemplate) {
        this.cModalRef = this.pModalService.show(pTemplate, { keyboard: false, ignoreBackdropClick: true });
        this.pBulkUploadDetailSearchReq.searchByBatchId = batchId;
        this.cBulkUpload.batchCount = recordCount;
        this.cBulkUpload.currBatchId = batchId;
        this.cBulkUpload.createdDate = createdDate;
        this.cBulkUpload.fileName = filename;
        this.pBulkUploadService.fetchBatchRecords(this.pBulkUploadDetailSearchReq)
            .subscribe(rResponse => this.fetchBatchRecord(rResponse), error => { console.log('error'); });
    }
    fetchBatchRecord(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(pResponse)) {
            mCommonResponse = pResponse;
            this.cBulkUpload.issued = 0;
            this.successfulCount = 0;
            this.expiredCount = 0;
            this.pendingCount = 0;
            this.cancelCount = 0;
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    if (this.sCheck.isNotNullList(mCommonResponse.data['invoiceList'])) {
                        this.cInvoiceProcEntity = mCommonResponse.data['invoiceList'];
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['pendingCount'])) {
                            this.pendingCount = mCommonResponse.data['pendingCount'];
                            this.cBulkUpload.issued += this.pendingCount;
                        }
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['expiredCount'])) {
                            this.expiredCount = mCommonResponse.data['expiredCount'];
                            this.cBulkUpload.issued += this.expiredCount;
                        }
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['successfulCount'])) {
                            this.successfulCount = mCommonResponse.data['successfulCount'];
                            this.cBulkUpload.issued += this.successfulCount;
                        }
                        if (this.sCheck.isNotNullNumber(mCommonResponse.data['cancelCount'])) {
                            this.cancelCount = mCommonResponse.data['cancelCount'];
                            this.cBulkUpload.issued += this.cancelCount;
                        }
                        console.log(this.cInvoiceProcEntity);
                        console.log(this.cBulkUpload.issued);
                    }
                }
            }
        }
    }
    selectedDate(value) {
        this.pBulkUploadSearchReq.batchType = 'invoice';
        this.pBulkUploadSearchReq.searchStartDate = value.start.format("DD-MM-YYYY hh:mm:ss");
        this.pBulkUploadSearchReq.searchEndDate = value.end.format("DD-MM-YYYY hh:mm:ss");
        this.pBulkUploadSearchReq.displaySearchFromDate = value.start.format("DD-MM-YYYY");
        this.pBulkUploadSearchReq.displaySearchToDate = value.end.format("DD-MM-YYYY");
        this.cBulkUpload.fromToDate = this.pBulkUploadSearchReq.displaySearchFromDate + ' - ' + this.pBulkUploadSearchReq.displaySearchToDate;
    }
    closePopup() {
        this.cModalRef.hide();
        this.pBulkUploadSearchReq.searchStartDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.pBulkUploadSearchReq.searchEndDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        this.FetchBatchList(this.pBulkUploadSearchReq);
    }
};
BulkUploadComponent = tslib_1.__decorate([
    Component({
        selector: 'app-bulk-upload',
        templateUrl: './bulk-upload.component.html',
        styleUrls: ['./bulk-upload.component.css'],
        animations: [
            trigger('slideInOut', [
                transition('false => true', [
                    style({ transform: 'translateY(-50%)' }),
                    animate('400ms ease-in', style({ transform: 'translateY(0%)' }))
                ]),
                transition('true => false', [
                    animate('400ms ease-in', style({ transform: 'translateY(-50%)' }))
                ])
            ])
        ],
        preserveWhitespaces: true,
    }),
    tslib_1.__param(0, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [Document,
        ActivatedRoute,
        ConditionalCheckService,
        FormBuilder,
        BsModalService,
        AlertMessageService,
        BsModalService,
        ErrorMessagesService,
        LandingPageMsgService,
        ErrorHandlerService,
        BulkUploadService,
        MerchInfoService,
        PrivilegeService,
        TitleService,
        DatePipe])
], BulkUploadComponent);
export { BulkUploadComponent };
//# sourceMappingURL=bulk-upload.component.js.map