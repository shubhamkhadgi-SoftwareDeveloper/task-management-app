import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { BulkUploadService } from './bulk-upload.service';
import { BulkUploadSearchReq } from './bulk-upload-searchReqDTO.req';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { DatePipe } from '@angular/common';
let BulkUploadResolverService = class BulkUploadResolverService {
    constructor(sBulkUploadService, pMerchInfoService, datepipe) {
        this.sBulkUploadService = sBulkUploadService;
        this.pMerchInfoService = pMerchInfoService;
        this.datepipe = datepipe;
        this.today = new Date();
        this.pBulkUploadSearchReq = new BulkUploadSearchReq();
    }
    resolve(route, state) {
        this.pBulkUploadSearchReq.batchType = 'INVOICE';
        this.pBulkUploadSearchReq.searchStartDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 0, 0, 0), 'dd-MM-yyyy HH:mm:ss');
        this.pBulkUploadSearchReq.searchEndDate = this.datepipe.transform(new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate(), 23, 59, 59), 'dd-MM-yyyy HH:mm:ss');
        console.log(this.pBulkUploadSearchReq);
        return this.sBulkUploadService.fetchAllBatchInvoices(this.pBulkUploadSearchReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                console.log("pCommonResponse");
                return pCommonResponse;
            }
            else {
                console.log("failed");
                return null;
            }
        });
    }
};
BulkUploadResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [BulkUploadService,
        MerchInfoService,
        DatePipe])
], BulkUploadResolverService);
export { BulkUploadResolverService };
//# sourceMappingURL=bulk-upload-resolver.service.js.map