export class BulkUploadSearchReq {
    constructor() {
        this.numberOfRecords = 25;
        this.pageNumber = 1;
        this.batchType = 'invoice';
    }
}
//# sourceMappingURL=bulk-upload-searchReqDTO.req.js.map