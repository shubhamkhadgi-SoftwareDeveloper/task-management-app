export class CommonDtoReq {
    constructor() {
        this.regId = null;
        this.isRecurring = false;
    }
}
//# sourceMappingURL=commonDtoReq.req.js.map