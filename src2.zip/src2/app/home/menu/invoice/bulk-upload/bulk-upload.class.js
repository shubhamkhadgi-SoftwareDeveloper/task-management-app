import { DatePipe } from '@angular/common';
export class BulkUpload {
    constructor() {
        this.issued = 0;
        this.batchListCount = 0;
        this.showDetails = false;
        this.status = [];
        this.status.push({ label: 'Completed', value: 'Completed' });
        this.status.push({ label: 'Processing', value: 'Processing' });
        this.status.push({ label: 'Failed', value: 'Failed' });
        //new
        this.calOptions = {
            autoApply: false,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme-link",
            showDropdowns: true,
            maxDate: new Date(),
            opens: 'left',
            dateLimit: {
                days: 30
            }
        };
        var datePipe = new DatePipe('en-US');
        let startDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        let endDate = datePipe.transform(new Date(), 'dd-MM-yyyy');
        this.fromToDate = startDate + '-' + endDate;
    }
}
//# sourceMappingURL=bulk-upload.class.js.map