import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ResponsiveService } from './../../common-services/responsive.service';
import { ConditionalCheckService } from './../../common-services/conditional-check.service';
import { PrivilegeService } from './../../common-services/privilege.service';
import { CurrentLoginMerchantService } from '../../common-services/current-login-merchant.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Menu } from './menu.class';
let MenuComponent = class MenuComponent {
    constructor(pRouter, sResponsiveService, sCheck, sPrivilegeService, sCurrentLoginMerchantService, sanitizer) {
        this.pRouter = pRouter;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sPrivilegeService = sPrivilegeService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.sanitizer = sanitizer;
        this.isToggleBtnClick = false;
        this.menuMinMaxEvent = new EventEmitter();
        this.menuNameEvent = new EventEmitter();
        this.openFor = 'Dashboard';
        this.activeUrl = '';
        this.cMenuList = JSON.parse(sessionStorage.getItem("menuList"));
        this.svg = `<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="19px" height="19px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
          viewBox="0 0 19 19" xmlns:xlink="http://www.w3.org/1999/xlink">
                                  <g id="my-account-icon-svg" class="svg-icons">
                                     <g>

                                             <rect class="no-fill my-aaccount-stroke" x="7.29" y="7.29" width="4.43" height="4.43"/>
                                           <path class="secondary" d="M9.66 0c-5.24,-0.09 -9.57,4.09 -9.66,9.34 -0.05,2.97 1.28,5.65 3.39,7.42 0.13,-0.12 0.28,-0.23 0.45,-0.32l2.83 -1.54c0.37,-0.21 0.61,-0.6 0.61,-1.02l0 -1.16c0,0 -0.84,-1 -1.15,-2.38 -0.27,-0.17 -0.44,-0.46 -0.44,-0.8l0 -1.27c0,-0.28 0.12,-0.53 0.31,-0.7l0 -1.84c0,0 -0.37,-2.86 3.5,-2.86 3.87,0 3.5,2.86 3.5,2.86l0 1.84c0.19,0.17 0.31,0.42 0.31,0.7l0 1.27c0,0.43 -0.28,0.79 -0.67,0.91 -0.22,0.67 -0.53,1.32 -0.95,1.9 -0.1,0.15 -0.2,0.27 -0.28,0.37l0 1.19c0,0.44 0.24,0.84 0.64,1.04l3.03 1.51c0.18,0.09 0.35,0.21 0.5,0.34 2.05,-1.71 3.37,-4.26 3.42,-7.14 0.09,-5.24 -4.09,-9.57 -9.34,-9.66z"/>
                                     </g>
                                              <path class="primary" d="M6.67 14.9l-2.83 1.54c-0.17,0.09 -0.32,0.2 -0.46,0.33 1.66,1.39 3.79,2.23 6.12,2.23 2.31,0 4.43,-0.83 6.08,-2.2 -0.15,-0.13 -0.31,-0.25 -0.5,-0.34l-3.03 -1.51c-0.4,-0.2 -0.64,-0.6 -0.64,-1.04l0 -1.19c0.08,-0.1 0.18,-0.22 0.28,-0.37 0.42,-0.58 0.73,-1.23 0.95,-1.9 0.39,-0.12 0.67,-0.48 0.67,-0.91l0 -1.27c0,-0.28 -0.12,-0.53 -0.31,-0.7l0 -1.84c0,0 0.37,-2.86 -3.5,-2.86 -3.87,0 -3.5,2.86 -3.5,2.86l0 1.84c-0.19,0.17 -0.31,0.42 -0.31,0.7l0 1.27c0,0.34 0.17,0.63 0.44,0.8 0.31,1.38 1.15,2.38 1.15,2.38l0 1.16c0,0.42 -0.24,0.81 -0.61,1.02z"/>
                                  </g>

                              </svg>`;
        this.cMenuList['Dashboard'][0].svg = this.svg;
        this.cMenu = new Menu();
    }
    ngOnInit() {
        if (this.sResponsiveService.isMaxWidth767Device()) {
            this.menuMinMaxEvent.emit(this.sResponsiveService.isMenuResponsive());
        }
        this.sResponsiveService.removeBodyClass('login-bg');
        //Check reseller and modify menu
        let resellerCode = "CCAV";
        if (sessionStorage.getItem("resellerCode") != undefined && sessionStorage.getItem("resellerCode") != null) {
            resellerCode = sessionStorage.getItem("resellerCode");
        }
        if (resellerCode.toUpperCase() != 'CCAV') {
            this.sResponsiveService.addBodyClass('reseller');
        }
        this.menuNameEvent.emit('Dashboard');
    }
    setOpenClass(pModuleName) {
        if (this.openFor === pModuleName) {
            this.openFor = '';
        }
        else {
            this.openFor = pModuleName;
        }
        if (this.cIsMinView) {
            this.cIsMinView = !this.cIsMinView;
            this.openFor = pModuleName;
            this.menuMinMaxEvent.emit(this.cIsMinView);
        }
        this.menuNameEvent.emit(pModuleName);
    }
    setActiveUrl(pUrlName) {
        this.activeUrl = pUrlName;
        if (this.sResponsiveService.isMaxWidth767Device()) {
            this.menuMinMaxEvent.emit(this.sResponsiveService.isMenuResponsive());
        }
    }
    //For reseller view
    onMaxMinViewClick() {
        this.cIsMinView = !this.cIsMinView;
        this.menuMinMaxEvent.emit(this.cIsMinView);
    }
    renderSVG(pMenuName) {
        for (let menuName in this.cMenu.svgObj) {
            if (menuName === pMenuName) {
                return this.sanitizer.bypassSecurityTrustHtml(this.cMenu.svgObj[menuName]);
            }
        }
    }
    onMouseEnter() {
        if (this.cIsMinView && !this.isToggleBtnClick) {
            this.isToggleBtnClick = !this.isToggleBtnClick;
            this.sResponsiveService.hoverMenu('add');
        }
    }
    onMouseLeave() {
        if (this.cIsMinView && this.isToggleBtnClick) {
            this.isToggleBtnClick = !this.isToggleBtnClick;
            this.sResponsiveService.hoverMenu('remove');
        }
    }
};
tslib_1.__decorate([
    Input('isMinView'),
    tslib_1.__metadata("design:type", Boolean)
], MenuComponent.prototype, "cIsMinView", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], MenuComponent.prototype, "menuMinMaxEvent", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], MenuComponent.prototype, "menuNameEvent", void 0);
MenuComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-menu',
        templateUrl: './menu.component.html',
        styleUrls: ['./menu.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [Router,
        ResponsiveService,
        ConditionalCheckService,
        PrivilegeService,
        CurrentLoginMerchantService,
        DomSanitizer])
], MenuComponent);
export { MenuComponent };
//# sourceMappingURL=menu.component.js.map