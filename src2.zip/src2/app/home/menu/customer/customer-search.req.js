export class CustomerSearchReq {
    /* public isSelActionClick : boolean = false;
     public isSearchByClick : boolean = false;
     public selectedCustomer: string[] = [];
     public isAllCustomerCheck : boolean = false;
     public isAnyCustomerCreate : boolean;
     public isSearchPanelClick : boolean = false;*/
    constructor() {
        this.searchPageSize = 25;
        this.searchPageNo = 1;
        this.searchIsRecurring = false;
    }
}
//# sourceMappingURL=customer-search.req.js.map