export class Customer {
    constructor() {
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.selectedCustomer = [];
        this.isAllCustomerCheck = false;
        this.isAnyCustomerCreate = false;
        this.isSearchPanelClick = false;
        this.isCustomerDetailClick = false;
        this.editPopupFlag = false;
        this.searchByLabel = 'Search By';
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: null });
        this.searchBy.push({ label: 'Name', value: 'searchByName' });
        this.searchBy.push({ label: 'Email ID', value: 'searchByEmail' });
        this.searchBy.push({ label: 'Mobile #', value: 'searchByMobile' });
    }
}
//# sourceMappingURL=customer.class.js.map