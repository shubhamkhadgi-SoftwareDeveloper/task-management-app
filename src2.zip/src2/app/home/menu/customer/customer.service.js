import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../common-services/api-request.service';
let CustomerService = class CustomerService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'customers/';
        this.cFetchCustomers = this.cBaseUrl + 'fetchAllCustomers';
        this.cAddCustomers = this.cBaseUrl + 'addCustomerDetails';
        this.cDeleteCustomer = this.cBaseUrl + 'deleteCustomerDetails';
        this.cSearchCountry = this.cBaseUrl + 'searchCountry';
        this.cSearchCustomerByName = this.cBaseUrl + 'searchCustomer';
        this.cGetCustomerDetails = this.cBaseUrl + 'getCustomerDetails';
        this.cCheckEmailAvailability = this.cBaseUrl + 'checkEmailAvailability';
        this.cCheckMobileAvailability = this.cBaseUrl + 'checkMobileAvailability';
        this.cUpdateCustInvStatus = this.cBaseUrl + 'setCustomerStatus';
        this.checkDuplicateGSTN = this.cBaseUrl + 'checkDuplicateGSTN';
        this.fetchPincode = this.cBaseUrl + 'fetchPincodeData';
    }
    addCustomerDetails(pAddNewCustomerDetailsReq) {
        return this.pApiRequestService.httpPostRequest(pAddNewCustomerDetailsReq, this.cAddCustomers);
    }
    fetchAllCustomers(pCustomerSearchReq) {
        return this.pApiRequestService.httpPostRequest(pCustomerSearchReq, this.cFetchCustomers);
    }
    deleteCustomer(pCustomerSearchReq) {
        return this.pApiRequestService.httpPostRequest(pCustomerSearchReq, this.cDeleteCustomer);
    }
    checkCountryAvailable(pCustomerSearchReq) {
        return this.pApiRequestService.httpPostRequest(pCustomerSearchReq, this.cSearchCountry);
    }
    checkCustomerAvailable(searchCustomerByName) {
        return this.pApiRequestService.httpPostRequest({ "searchCustomerByName": searchCustomerByName }, this.cSearchCustomerByName);
    }
    getCustomerDetails(pCustId) {
        return this.pApiRequestService.httpPostRequest(pCustId, this.cGetCustomerDetails);
    }
    checkEmailAvailability(pEmail) {
        return this.pApiRequestService.asyncHttpPostRequest(pEmail, this.cCheckEmailAvailability);
    }
    checkMobileAvailability(pEmail) {
        return this.pApiRequestService.asyncHttpPostRequest(pEmail, this.cCheckMobileAvailability);
    }
    isDuplicateGSTN(GSTN) {
        return this.pApiRequestService.asyncHttpPostRequest(GSTN, this.checkDuplicateGSTN);
    }
    updateCustInvStatus(pAddNewCustomerDetailsReq) {
        return this.pApiRequestService.httpPostRequest(pAddNewCustomerDetailsReq, this.cUpdateCustInvStatus);
    }
    fetchPincodedata(pincode) {
        return this.pApiRequestService.asyncHttpPostRequest(pincode, this.fetchPincode);
    }
};
CustomerService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], CustomerService);
export { CustomerService };
//# sourceMappingURL=customer.service.js.map