import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Router } from '@angular/router';
import { CustomerService } from './customer.service';
let CustomerResolverService = class CustomerResolverService {
    constructor(sCustomerService, sRouter) {
        this.sCustomerService = sCustomerService;
        this.sRouter = sRouter;
    }
    resolve(route, state) {
        //let mInvoiceSearchReq = new CustomerSearchReq();
        return this.sCustomerService.fetchAllCustomers({ 'searchPageNo': 1, 'searchPageSize': 25 }).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
CustomerResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [CustomerService,
        Router])
], CustomerResolverService);
export { CustomerResolverService };
//# sourceMappingURL=customer-resolver.service.js.map