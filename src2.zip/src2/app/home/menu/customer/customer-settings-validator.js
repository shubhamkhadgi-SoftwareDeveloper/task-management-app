export class CustomerSettingsValidator {
    static mobile(control) {
        let reg_exp = /^[0-9]{10}$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'mobile': true };
    }
}
//# sourceMappingURL=customer-settings-validator.js.map