export class AddNewCustomerDetailsReq {
    constructor() {
        this.isBillingDetails = false;
        this.isShowBillingDetails = false;
        this.isDeliveryDetails = false;
        this.isShowDeliveryDetails = false;
        this.isSameAsBillingDetails = false;
        this.isShowSameAsBillingDetails = false;
        this.createCustomerButton = true;
        this.addBillingAddressButton = false;
        this.addShippingAddressButton = false;
        this.isBillingDetailsSelected = false;
        this.isShippingDetailsSelected = false;
        this.showCustomerDetails = true;
        this.custStatus = 'ACTI';
        /*billing detsils*/
    }
}
//# sourceMappingURL=AddNewCustomerDetailsReq.js.map