import * as tslib_1 from "tslib";
import { Component, Inject, ChangeDetectorRef } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse, CustomResponseCode } from './../../../common-response/common-response.res';
import { CustomerService } from './customer.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Customer } from './customer.class';
import { ConditionalCheckService } from './../../../common-services/conditional-check.service';
import { TransactionsService } from '../transactions/transactions/transactions.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ResponsiveService } from '../../../common-services/responsive.service';
import { PrivilegeService } from '../../../common-services/privilege.service';
import { AlertMessageService } from '../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../common-services/error-messages.service';
import { ErrorHandlerService } from './../../../common-services/error-handler.service';
import { LandingPageMsgService } from './../../../common-services/landing-page-msg.service';
import { CustomValidator } from '../../../custom-validator/custom-validator';
import { AddNewCustomerDetailsReq } from '../customer/AddNewCustomerDetailsReq';
import { CustomerSearchReq } from './customer-search.req';
import { CustomerSettingsValidator } from '../customer/customer-settings-validator';
import { BBValidator } from "./validated";
import { trigger, style, transition, animate, state } from '@angular/animations';
import { expandOnEnterAnimation, collapseOnLeaveAnimation } from 'angular-animations';
let CustomerComponent = class CustomerComponent {
    constructor(document, sActivatedRoute, pFormBuilder, sCheck, pTransactionsService, pModalService, sErrorHandler, sErrorMessagesService, sResponsiveService, sAlertMessageService, sCustomerService, sPrivilegeService, sLandingPageMsgService, cdr) {
        this.document = document;
        this.sActivatedRoute = sActivatedRoute;
        this.pFormBuilder = pFormBuilder;
        this.sCheck = sCheck;
        this.pTransactionsService = pTransactionsService;
        this.pModalService = pModalService;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sAlertMessageService = sAlertMessageService;
        this.sCustomerService = sCustomerService;
        this.sPrivilegeService = sPrivilegeService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.cdr = cdr;
        this.cIsWritePrivilege = false;
        this.isCountryClicked = false;
        this.searchflag = 'seachform';
        this.isSearchPanelClick = false;
        this.checkOne = false;
        this.checkAll = false;
        this.cRecordFrom = 1;
        this.cRecordTo = 25;
        this.customer = new Customer();
        this.cCountryList = [];
        this.cCountry = [];
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.cCustomerSearchReq = new CustomerSearchReq();
        this.cIsWritePrivilege = this.sPrivilegeService.isWritePrivilege(this.sPrivilegeService.Customer);
    }
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchName'].disable();
        this.fetchCountryList();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullList(mCommonResponse.data['customerList'])) {
                this.cCustomerList = mCommonResponse.data['customerList'];
                this.customer.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.customer.isAnyCustomerCreate = true;
                this.customer.isCustomerDetailClick = false;
            }
            else {
                this.customer.landingPgeMsg = this.sLandingPageMsgService.noCustomerCreateMsg;
                this.customer.isAnyCustomerCreate = false;
            }
        });
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    /*ngAfterViewInit(){
        this.cdr.detectChanges();
    }*/
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            searchName: [''],
            searchEmailId: [''],
            searchMobileNo: [''],
            searchPageNo: [1],
            searchPageSize: [25],
            searchByName: ['']
        });
    }
    createForm1() {
        this.mForm1 = this.pFormBuilder.group({
            custName: ['', [Validators.required,
                    Validators.minLength(3),
                    Validators.maxLength(60),
                    BBValidator.CusomerName,
                    BBValidator.leastOneChar,
                    BBValidator.isBeginSpecialChar,
                    BBValidator.isEndSpecialChar,
                    BBValidator.isConsecuSpecialChar]],
            custEmail: ['', [BBValidator.email,
                    Validators.maxLength(70)]],
            custMobileNo: ['', [BBValidator.customerPhone]],
            custGstin: ['', [BBValidator.gstNo]],
            isBillingDetails: [],
            custBillingCity: ['', [BBValidator.customerCity,
                    Validators.maxLength(30)]],
            custBillingZip: ['', [BBValidator.customerPin,
                    Validators.maxLength(6)]],
            custBillingState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custBillingCountry: [],
            isDeliveryDetails: [],
            isSameAsBillingDetails: [],
            custDeliveryAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300), BBValidator.customerAddress]],
            custDeliveryCity: ['', [BBValidator.customerCity, Validators.maxLength(30)]],
            custDeliveryState: ['', [BBValidator.customerState, Validators.maxLength(30)]],
            custDeliveryZip: ['', [BBValidator.customerPin, Validators.maxLength(6)]],
            custDeliveryCountry: [],
            createCustomerButton: [],
            addBillingAddressButton: [],
            custBillingAddress: ['', [Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]],
            orderBillCountry: []
        });
    }
    onOpenNewPopupClick(template) {
        this.cModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.createForm1();
    }
    onOpenEditPopupClick(template, obj) {
        this.createForm1();
        this.cAddNewCustomerDetailsReq = new AddNewCustomerDetailsReq();
        this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
        this.cAddNewCustomerDetailsReq.custName = obj.custName;
        this.cAddNewCustomerDetailsReq.custEmail = obj.custEmail;
        this.cAddNewCustomerDetailsReq.custMobileNo = obj.custMobileNo;
        this.cAddNewCustomerDetailsReq.custGstin = obj.custGstin;
        this.cAddNewCustomerDetailsReq.isBillingDetails = obj.isBillingDetails;
        this.cAddNewCustomerDetailsReq.custBillingAddress = obj.custBillingAddress;
        this.cAddNewCustomerDetailsReq.custBillingCity = obj.custBillingCity;
        this.cAddNewCustomerDetailsReq.custBillingZip = obj.custBillingZip;
        this.cAddNewCustomerDetailsReq.custBillingState = obj.custBillingState;
        this.cAddNewCustomerDetailsReq.custBillingCountry = obj.custBillingCountry;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = obj.isDeliveryDetails;
        this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = obj.isSameAsBillingDetails;
        this.cAddNewCustomerDetailsReq.custDeliveryAddress = obj.custDeliveryAddress;
        this.cAddNewCustomerDetailsReq.custDeliveryCity = obj.custDeliveryCity;
        this.cAddNewCustomerDetailsReq.custDeliveryState = obj.custDeliveryState;
        this.cAddNewCustomerDetailsReq.custDeliveryZip = obj.custDeliveryZip;
        this.cAddNewCustomerDetailsReq.custDeliveryCountry = obj.custDeliveryCountry;
        this.cAddNewCustomerDetailsReq.action = 'edit';
        this.cAddNewCustomerDetailsReq.custId = obj.custId;
        this.cModalRef = this.pModalService.show(template, { class: 'modal-sm', ignoreBackdropClick: true });
    }
    fetchCountryList() {
        this.pTransactionsService.fetchCountryList()
            .subscribe(rResponse => this.fetchCountryListSuccess(rResponse), error => { console.log('error '); });
    }
    fetchCountryListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (this.sCheck.isNotNullObject(pResponse.data)) {
                this.cCountry = pResponse.data;
                this.cCountryList.push({ label: 'Select country', value: '0' });
                for (let pCountry of this.cCountry) {
                    this.cCountryList.push({ label: pCountry, value: pCountry });
                }
            }
        }
    }
    getCountryList() {
        return this.cCountryList;
    }
    onSubmit(value) {
        if (this.cAddNewCustomerDetailsReq.isBillingDetails) {
            this.onaddShippingAddressButton();
        }
        if (this.cAddNewCustomerDetailsReq.isDeliveryDetails) {
            this.validateDeliveryDetails();
        }
        if ((typeof value.custEmail == 'undefined' || value.custEmail == '') && (typeof value.custMobileNo == 'undefined' || value.custMobileNo == '')) {
            this.mForm1.controls['custEmail'].enable();
            this.mForm1.controls['custEmail'].setValue(null);
            this.mForm1.controls['custEmail'].dirty;
            this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
            this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email,
                Validators.maxLength(70)]);
            this.mForm1.controls['custEmail'].updateValueAndValidity();
            this.mForm1.controls['custMobileNo'].enable();
            this.mForm1.controls['custMobileNo'].setValue(null);
            this.mForm1.controls['custMobileNo'].dirty;
            this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
            this.mForm1.controls['custMobileNo'].setValidators([Validators.required, BBValidator.customerPhone]);
            this.mForm1.controls['custMobileNo'].updateValueAndValidity();
        }
        if (typeof value.custGstin !== 'undefined' && value.custGstin !== '') {
            this.mForm1.controls['custGstin'].setValidators([BBValidator.gstNo]);
            this.mForm1.controls['custGstin'].updateValueAndValidity();
        }
        if ((typeof value.custEmail !== 'undefined' && value.custEmail !== '') || (typeof value.custMobileNo !== 'undefined' && value.custMobileNo !== '')) {
            this.mForm1.controls['custEmail'].setValidators([BBValidator.email, Validators.maxLength(70)]);
            this.mForm1.controls['custEmail'].updateValueAndValidity();
            this.mForm1.controls['custMobileNo'].setValidators([BBValidator.customerPhone]);
            this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            if (this.mForm1.pending) {
                let setInitialStatus = () => {
                    if (this.mForm1.pending) {
                        t = setTimeout(setInitialStatus, 5);
                    }
                    else {
                        if (this.mForm1.valid) {
                            this.sCustomerService.addCustomerDetails(this.cAddNewCustomerDetailsReq)
                                .subscribe(pResponse => {
                                this.onAddCustomer(pResponse);
                            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
                        }
                        clearTimeout(t);
                    }
                };
                let t = setTimeout(setInitialStatus, 5);
            }
        }
        if (this.mForm1.valid) {
            this.sCustomerService.addCustomerDetails(this.cAddNewCustomerDetailsReq)
                .subscribe(pResponse => {
                this.onAddCustomer(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        else {
            this.validateAllFields(this.mForm1);
        }
    }
    validateDeliveryDetails() {
        if (!this.cAddNewCustomerDetailsReq.custDeliveryAddress ||
            !this.cAddNewCustomerDetailsReq.custDeliveryState ||
            !this.cAddNewCustomerDetailsReq.custDeliveryCity ||
            !this.cAddNewCustomerDetailsReq.custDeliveryZip ||
            (!this.cAddNewCustomerDetailsReq.custDeliveryCountry || this.cAddNewCustomerDetailsReq.custDeliveryCountry == '0')) {
            if (!this.cAddNewCustomerDetailsReq.custDeliveryAddress) {
                this.mForm1.controls['custDeliveryAddress'].enable();
                this.mForm1.controls['custDeliveryAddress'].setValue(null);
                this.mForm1.controls['custDeliveryAddress'].dirty;
                this.mForm1.controls['custDeliveryAddress'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryAddress'].setValidators([Validators.required, Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]);
                this.mForm1.controls['custDeliveryAddress'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryState) {
                this.mForm1.controls['custDeliveryState'].enable();
                this.mForm1.controls['custDeliveryState'].setValue(null);
                this.mForm1.controls['custDeliveryState'].dirty;
                this.mForm1.controls['custDeliveryState'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryState'].setValidators([Validators.required, BBValidator.customerState, Validators.maxLength(30)]);
                this.mForm1.controls['custDeliveryState'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryCity) {
                this.mForm1.controls['custDeliveryCity'].enable();
                this.mForm1.controls['custDeliveryCity'].setValue(null);
                this.mForm1.controls['custDeliveryCity'].dirty;
                this.mForm1.controls['custDeliveryCity'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryCity'].setValidators([Validators.required, BBValidator.customerCity,
                    Validators.maxLength(30)]);
                this.mForm1.controls['custDeliveryCity'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryZip) {
                this.mForm1.controls['custDeliveryZip'].enable();
                this.mForm1.controls['custDeliveryZip'].setValue(null);
                this.mForm1.controls['custDeliveryZip'].dirty;
                this.mForm1.controls['custDeliveryZip'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryZip'].setValidators([Validators.required, BBValidator.customerPin,
                    Validators.maxLength(6)]);
                this.mForm1.controls['custDeliveryZip'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custDeliveryCountry || this.cAddNewCustomerDetailsReq.custDeliveryCountry == '0') {
                this.mForm1.controls['custDeliveryCountry'].enable();
                this.mForm1.controls['custDeliveryCountry'].setValue(null);
                this.mForm1.controls['custDeliveryCountry'].dirty;
                this.mForm1.controls['custDeliveryCountry'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custDeliveryCountry'].setValidators([Validators.required]);
                this.mForm1.controls['custDeliveryCountry'].updateValueAndValidity();
            }
        }
    }
    onAddCustomer(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.customer.isAnyCustomerCreate = true;
                this.cModalRef.hide();
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                this.fetchAllCustomers();
                this.mForm1.reset();
            }
            else if (mCommonResponse.isValidationFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.sErrorHandler.setServerError(mCommonResponse.fieldErrors, this.mForm1);
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
                this.cModalRef.hide();
            }
        }
        else {
            this.cModalRef.hide();
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            this.cModalRef.hide();
        }
    }
    fetchAllCustomers() {
        this.sCustomerService.fetchAllCustomers(this.cCustomerSearchReq)
            .subscribe(pResponse => this.fetchAllCustomerSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchAllCustomerSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.customer.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cCustomerList = mCommonResponse.data['customerList'];
                if (this.sCheck.isNullList(mCommonResponse.data['customerList'])) {
                    this.onFailFetchAllCustomer('');
                }
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.customer.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchAllCustomer(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchAllCustomer(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchAllCustomer(pResMsg) {
        this.customer.landingPgeMsg = this.sLandingPageMsgService.invoiceNoRecMsg;
        this.customer.pageTotalCount = null;
        this.cCustomerList = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
    }
    onDeletingAllCustomer(pResMsg) {
        this.customer.landingPgeMsg = this.sLandingPageMsgService.noCustomerCreateMsg;
        this.customer.pageTotalCount = null;
        this.cCustomerList = null;
        this.customer.isAnyCustomerCreate = false;
        this.customer.isSearchPanelClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onPageChange(event) {
        this.cCustomerSearchReq.searchPageSize = event.cPageSize;
        this.cCustomerSearchReq.searchPageNo = event.cPageNo;
        this.searchflag = 'pageChange';
        this.cRecordFrom = event.cRecordFrom;
        this.cRecordTo = event.cRecordTo;
        this.onSearchClick();
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.searchflag == 'seachform') {
                this.cCustomerSearchReq.searchPageNo = 1;
            }
            this.sCustomerService.fetchAllCustomers(this.cCustomerSearchReq)
                .subscribe(pResponse => this.fetchAllCustomerSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
            this.searchflag = 'seachform';
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onCustomerCheck(pEvent) {
        if (pEvent) {
            if (this.customer.selectedCustomer.length > 0 && this.customer.selectedCustomer.length != this.cCustomerList.length) {
                this.customer.isAllCustomerCheck = false;
                this.checkOne = true;
            }
            else if (this.customer.selectedCustomer.length === this.cCustomerList.length) {
                this.customer.isAllCustomerCheck = true;
                this.checkOne = true;
            }
            else if (this.customer.selectedCustomer.length === 0) {
                this.customer.isAllCustomerCheck = false;
                this.checkOne = false;
            }
            this.totalSelectedCustomer = this.customer.selectedCustomer.length;
        }
    }
    deSelect() {
        this.customer.selectedCustomer = [];
        this.customer.isAllCustomerCheck = false;
        this.customer.selectedCustomer.length == 0;
        this.checkOne = false;
    }
    ;
    onCancelPanelClick() {
        this.totalSelectedCustomer = this.customer.selectedCustomer.length;
        this.cCustomerSearchReq = null;
        this.cCustomerSearchReq = new CustomerSearchReq();
        this.customer.isAnyCustomerCreate = true;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
        this.mForm.controls['searchByValue'].setValue(null);
        this.mForm.controls['searchByValue'].clearValidators();
        this.mForm.controls['searchByValue'].disable();
        this.mForm.controls['searchByValue'].updateValueAndValidity();
        this.onSearchClick();
    }
    onDeleteClick() {
        this.customer.isSelActionClick = !this.customer.isSelActionClick;
        if (this.customer.selectedCustomer != null && this.customer.selectedCustomer.length > 0) {
            this.checkOne = false;
            this.sCustomerService.deleteCustomer({ "custId": this.customer.selectedCustomer })
                .subscribe(pResponse => this.deleteCustomerSuccess(pResponse), error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
        ;
    }
    deleteCustomerSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (mCommonResponse.data['ListEmpty'] == 'Yes') {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                    this.onDeletingAllCustomer('');
                }
                else {
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                    this.onSearchClick();
                }
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
        this.customer.selectedCustomer = [];
        this.totalSelectedCustomer = 0;
        this.customer.isAllCustomerCheck = false;
    }
    onAllCustomerCheck(pEvent) {
        this.checkOne = !this.checkOne;
        if (pEvent) {
            this.customer.selectedCustomer = [];
            for (let pCustomer of this.cCustomerList) {
                this.customer.selectedCustomer.push(pCustomer.custId + "");
                this.totalSelectedCustomer = this.customer.selectedCustomer.length;
            }
        }
        else {
            this.customer.selectedCustomer = [];
            this.totalSelectedCustomer = 0;
        }
    }
    onSelActionClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.customer.isSearchPanelClick = false;
        }
        this.customer.isSelActionClick = !this.customer.isSelActionClick;
    }
    onBackClick() {
        this.customer.isCustomerDetailClick = false;
    }
    onSearchPanelClick() {
        this.customer.isSelActionClick = false;
        this.customer.selectedCustomer = [];
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.customer.isSearchPanelClick = !this.customer.isSearchPanelClick;
        }
    }
    onSearchByOptionClick(event) {
        this.customer.isSearchByClick = !this.customer.isSearchByClick;
        this.cCustomerSearchReq.searchBy = event.value;
        this.customer.searchByLabel = event.label;
        if (this.customer.searchByLabel == 'Name') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].enabled;
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.letterAndSpaceOnly]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.customer.searchByLabel == 'Email ID') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomValidator.email]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.customer.searchByLabel == 'Mobile #') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([Validators.required, CustomerSettingsValidator.mobile]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.customer.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.customer.isSearchByClick = !this.customer.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.customer.isSearchByClick = false;
    }
    onBillingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
            this.cAddNewCustomerDetailsReq.isBillingDetails = true;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isBillingDetails = false;
            this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        }
    }
    onaddBillingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custName ||
            (!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
            if (!this.cAddNewCustomerDetailsReq.custName) {
                this.mForm1.controls['custName'].enable();
                this.mForm1.controls['custName'].setValue(null);
                this.mForm1.controls['custName'].dirty;
                this.mForm1.controls['custName'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custName'].setValidators([Validators.required]);
                this.mForm1.controls['custName'].updateValueAndValidity();
            }
            if ((!this.cAddNewCustomerDetailsReq.custEmail && !this.cAddNewCustomerDetailsReq.custMobileNo)) {
                this.mForm1.controls['custEmail'].enable();
                this.mForm1.controls['custEmail'].setValue(null);
                this.mForm1.controls['custEmail'].dirty;
                this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email,
                    Validators.maxLength(70)]);
                this.mForm1.controls['custEmail'].updateValueAndValidity();
                this.mForm1.controls['custMobileNo'].enable();
                this.mForm1.controls['custMobileNo'].setValue(null);
                this.mForm1.controls['custMobileNo'].dirty;
                this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custMobileNo'].setValidators([Validators.required]);
                this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            }
        }
        else if (this.cAddNewCustomerDetailsReq.custName || this.cAddNewCustomerDetailsReq.custEmail || this.cAddNewCustomerDetailsReq.custMobileNo) {
            if ((typeof this.cAddNewCustomerDetailsReq.custMobileNo == 'undefined' || this.cAddNewCustomerDetailsReq.custMobileNo == '') &&
                (typeof this.cAddNewCustomerDetailsReq.custEmail == 'undefined' || this.cAddNewCustomerDetailsReq.custEmail == '')) {
                this.mForm1.controls['custEmail'].enable();
                this.mForm1.controls['custEmail'].setValue(null);
                this.mForm1.controls['custEmail'].dirty;
                this.mForm1.controls['custEmail'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custEmail'].setValidators([Validators.required, BBValidator.email, Validators.maxLength(70)]);
                this.mForm1.controls['custEmail'].updateValueAndValidity();
                this.mForm1.controls['custMobileNo'].enable();
                this.mForm1.controls['custMobileNo'].setValue(null);
                this.mForm1.controls['custMobileNo'].dirty;
                this.mForm1.controls['custMobileNo'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custMobileNo'].setValidators([Validators.required, BBValidator.customerPhone]);
                this.mForm1.controls['custMobileNo'].updateValueAndValidity();
            }
            if (this.mForm1.controls['custName'].valid &&
                ((this.cAddNewCustomerDetailsReq.custEmail ? this.mForm1.controls['custEmail'].valid : this.mForm1.controls['custEmail'].valid || this.mForm1.controls['custMobileNo'].valid) &&
                    (this.cAddNewCustomerDetailsReq.custMobileNo ? this.mForm1.controls['custMobileNo'].valid : this.mForm1.controls['custEmail'].valid || this.mForm1.controls['custMobileNo'].valid))) {
                this.mForm1.get('custEmail').clearValidators();
                this.mForm1.get('custEmail').clearAsyncValidators();
                this.mForm1.get('custEmail').updateValueAndValidity();
                this.mForm1.get('custMobileNo').clearValidators();
                this.mForm1.get('custMobileNo').clearAsyncValidators();
                this.mForm1.get('custMobileNo').updateValueAndValidity();
                this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
                this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
                this.cAddNewCustomerDetailsReq.createCustomerButton = true;
                this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            }
        }
    }
    onBackToCustomerDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.showCustomerDetails = true;
        this.cAddNewCustomerDetailsReq.isBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
        this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        this.cAddNewCustomerDetailsReq.isShowBillingDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
        this.mForm1.controls['custName'].setValidators([Validators.required]);
        this.mForm1.controls['custEmail'].setValidators([BBValidator.email, Validators.maxLength(70)]);
        this.mForm1.controls['custMobileNo'].setValidators([BBValidator.customerPhone]);
    }
    onBackToBillingDtl() {
        this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = true;
        this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = false;
        this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.isShowDeliveryDetails = false;
        this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        this.cAddNewCustomerDetailsReq.addBillingAddressButton = true;
    }
    onShippingDetailsCheck(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = true;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = true;
            this.cAddNewCustomerDetailsReq.createCustomerButton = false;
        }
        else {
            this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
            this.cAddNewCustomerDetailsReq.addBillingAddressButton = false;
            this.cAddNewCustomerDetailsReq.isDeliveryDetails = false;
            this.cAddNewCustomerDetailsReq.createCustomerButton = true;
        }
    }
    onFetchPinCodeData(pEvent) {
        var pincode = this.mForm1.controls['custBillingZip'].value;
        console.log("in pinocode method " + String(pincode).length);
        if (pEvent) {
            if (pincode != null && String(pincode).length == 6) {
                this.sCustomerService.fetchPincodedata(Number(pincode)).subscribe(pResponse => this.onFetchPinCodeDataSuccess(pResponse), error => { console.log('error'); });
            }
        }
    }
    onaddShippingAddressButton() {
        if (!this.cAddNewCustomerDetailsReq.custBillingAddress ||
            !this.cAddNewCustomerDetailsReq.custBillingState ||
            !this.cAddNewCustomerDetailsReq.custBillingCity ||
            !this.cAddNewCustomerDetailsReq.custBillingZip ||
            (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0')) {
            if (!this.cAddNewCustomerDetailsReq.custBillingAddress) {
                this.mForm1.controls['custBillingAddress'].enable();
                this.mForm1.controls['custBillingAddress'].setValue(null);
                this.mForm1.controls['custBillingAddress'].dirty;
                this.mForm1.controls['custBillingAddress'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingAddress'].setValidators([Validators.required, Validators.minLength(1),
                    Validators.maxLength(300),
                    BBValidator.customerAddress]);
                this.mForm1.controls['custBillingAddress'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingState) {
                this.mForm1.controls['custBillingState'].enable();
                this.mForm1.controls['custBillingState'].setValue(null);
                this.mForm1.controls['custBillingState'].dirty;
                this.mForm1.controls['custBillingState'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingState'].setValidators([Validators.required, BBValidator.customerState, Validators.maxLength(30)]);
                this.mForm1.controls['custBillingState'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCity) {
                this.mForm1.controls['custBillingCity'].enable();
                this.mForm1.controls['custBillingCity'].setValue(null);
                this.mForm1.controls['custBillingCity'].dirty;
                this.mForm1.controls['custBillingCity'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCity'].setValidators([Validators.required, BBValidator.customerCity,
                    Validators.maxLength(30)]);
                this.mForm1.controls['custBillingCity'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingZip) {
                this.mForm1.controls['custBillingZip'].enable();
                this.mForm1.controls['custBillingZip'].setValue(null);
                this.mForm1.controls['custBillingZip'].dirty;
                this.mForm1.controls['custBillingZip'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingZip'].setValidators([Validators.required, BBValidator.customerPin,
                    Validators.maxLength(6)]);
                this.mForm1.controls['custBillingZip'].updateValueAndValidity();
            }
            if (!this.cAddNewCustomerDetailsReq.custBillingCountry || this.cAddNewCustomerDetailsReq.custBillingCountry == '0') {
                this.mForm1.controls['custBillingCountry'].enable();
                this.mForm1.controls['custBillingCountry'].setValue(null);
                this.mForm1.controls['custBillingCountry'].dirty;
                this.mForm1.controls['custBillingCountry'].markAsTouched({ onlySelf: true });
                this.mForm1.controls['custBillingCountry'].setValidators([Validators.required]);
                this.mForm1.controls['custBillingCountry'].updateValueAndValidity();
            }
        }
        else if (this.cAddNewCustomerDetailsReq.custBillingAddress || this.cAddNewCustomerDetailsReq.custBillingState ||
            this.cAddNewCustomerDetailsReq.custBillingCity || this.cAddNewCustomerDetailsReq.custBillingZip ||
            this.cAddNewCustomerDetailsReq.custBillingCountry) {
            if (this.mForm1.controls['custBillingAddress'].valid && this.mForm1.controls['custBillingState'].valid && this.mForm1.controls['custBillingCity'].valid
                && this.mForm1.controls['custBillingZip'].valid && this.mForm1.controls['custBillingCountry'].valid) {
                this.cAddNewCustomerDetailsReq.isShippingDetailsSelected = true;
                this.cAddNewCustomerDetailsReq.isBillingDetailsSelected = false;
                this.cAddNewCustomerDetailsReq.showCustomerDetails = false;
                this.cAddNewCustomerDetailsReq.addShippingAddressButton = false;
                this.cAddNewCustomerDetailsReq.createCustomerButton = true;
            }
        }
    }
    onSameAsBillingDetails(pEvent) {
        if (pEvent) {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = this.cAddNewCustomerDetailsReq.custBillingAddress;
            this.cAddNewCustomerDetailsReq.custDeliveryCity = this.cAddNewCustomerDetailsReq.custBillingCity;
            this.cAddNewCustomerDetailsReq.custDeliveryState = this.cAddNewCustomerDetailsReq.custBillingState;
            this.cAddNewCustomerDetailsReq.custDeliveryZip = this.cAddNewCustomerDetailsReq.custBillingZip;
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = this.cAddNewCustomerDetailsReq.custBillingCountry;
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = true;
        }
        else {
            this.cAddNewCustomerDetailsReq.custDeliveryAddress = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCity = '';
            this.cAddNewCustomerDetailsReq.custDeliveryState = '';
            this.cAddNewCustomerDetailsReq.custDeliveryZip = '';
            this.cAddNewCustomerDetailsReq.custDeliveryCountry = '';
            this.cAddNewCustomerDetailsReq.isSameAsBillingDetails = false;
        }
    }
    editCancleClick() {
        this.cModalRef.hide();
        this.customer.selectedCustomer = [];
    }
    onCountryClick() {
        this.isCountryClicked = true;
    }
    onCountryNameClick() {
        this.mForm1.controls['custBillingCountry'].setAsyncValidators(this.checkCountryAvailable.bind(this));
    }
    checkCountryAvailable(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.checkCountryAvailable(this.cAddNewCustomerDetailsReq)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (this.sCheck.isNotNullObject(pCommonResponse.data)) {
                    this.cCountry = pCommonResponse.data;
                    this.cCountryList.push({ label: 'Select country', value: '0' });
                    for (let pCountry of this.cCountry) {
                        this.cCountryList.push({ label: pCountry, value: pCountry });
                    }
                }
            }
        });
    }
    onSearchPanelClick2() {
        this.totalSelectedCustomer = 0;
        if (!this.isSearchResponsive()) {
            this.customer.isSearchPanelClick = !this.customer.isSearchPanelClick;
        }
        else {
            this.customer.isSearchPanelClick = true;
        }
    }
    ;
    isSearchResponsive() {
        if (window.matchMedia('(max-width:1024px)').matches) {
            this.document.getElementsByClassName('header')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('sidebar-wrapper')[0].classList.add('z-index-0');
            this.document.getElementsByClassName('header')[0].classList.add('absolute');
            this.document.body.classList.add('overflow-y-hidden');
            this.document.getElementsByClassName('footer')[0].classList.add('display-none');
            this.document.getElementsByClassName('custom-search')[0].classList.add('slideL');
            if (this.document.getElementsByClassName('custom-search')[0].parentElement.classList.contains('row')) {
                this.document.getElementsByClassName('custom-search')[0].parentElement.classList.add('slidepop');
            }
            if (this.document.getElementsByClassName('daterangepicker').length > 0) {
                this.document.getElementsByClassName('slideL')[0].appendChild(this.document.getElementsByClassName('daterangepicker')[0]);
            }
            return true;
        }
        else {
            return false;
        }
    }
    onEmailIdClick() {
        this.mForm1.controls['custEmail'].setAsyncValidators(this.checkEmailAvailability.bind(this));
    }
    onMobileNoClick() {
        this.mForm1.controls['custMobileNo'].setAsyncValidators(this.checkMobileAvailability.bind(this));
    }
    checkEmailAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.checkEmailAvailability(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkEmailAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkEmailAvailability': true };
                }
            }
            else {
                return { 'checkEmailAvailability': true };
            }
        });
    }
    checkMobileAvailability(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.checkMobileAvailability(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'checkMobileAvailability': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'checkMobileAvailability': true };
                }
            }
            else {
                return { 'checkMobileAvailability': true };
            }
        });
    }
    onGSTINClick() {
        this.mForm1.controls['custGstin'].setAsyncValidators(this.isDuplicateGSTN.bind(this));
    }
    isDuplicateGSTN(control) {
        if (!control.value) {
            return null;
        }
        return this.sCustomerService.isDuplicateGSTN(control.value)
            .map(pCommonResponse => {
            if (this.sCheck.isNotNullObject(pCommonResponse)) {
                if (pCommonResponse.code === CustomResponseCode.SUCCESS) {
                    let mIsAvailable = pCommonResponse.data;
                    if (mIsAvailable) {
                        return { 'isDuplicateGSTN': true };
                    }
                    else {
                        return null;
                    }
                }
                else if (pCommonResponse.code === CustomResponseCode.FAIL) {
                    return { 'isDuplicateGSTN': true };
                }
            }
            else {
                return { 'isDuplicateGSTN': true };
            }
        });
    }
    updStatus(pEvent, pCustStatus, pcustId) {
        if (pCustStatus === 'ACTI') {
            this.cCustStatus = 'INAC';
        }
        if (pCustStatus === 'INAC') {
            this.cCustStatus = 'ACTI';
        }
        console.log(pCustStatus, this.cCustStatus, pcustId);
        this.cAddNewCustomerDetailsReq.custId = pcustId;
        this.cAddNewCustomerDetailsReq.custStatus = this.cCustStatus;
        this.sCustomerService.updateCustInvStatus(this.cAddNewCustomerDetailsReq)
            .subscribe(pResponse => this.onActionSuccess(pResponse), error => { console.log('error'); });
    }
    onActionSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.customer.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['customerList'])) {
                        this.cCustomerList = mCommonResponse.data['customerList'];
                    }
                }
            }
        }
        if (mCommonResponse.isSuccess) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
        else if (mCommonResponse.isFail) {
            this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onFetchPinCodeDataSuccess(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                //this.cPinCodeData=mCommonResponse.data['PincodeDataProcEntity'][0] as PinCodeData;
                // console.log("this.cPinCodeData.cityName"+this.cPinCodeData.cityName)
                this.cAddNewCustomerDetailsReq.custBillingCity = mCommonResponse.data[0]['stateName'];
                this.cAddNewCustomerDetailsReq.custBillingState = mCommonResponse.data[0]['cityName'];
                this.cAddNewCustomerDetailsReq.custBillingCountry = mCommonResponse.data[0]['countryName'];
            }
        }
    }
};
CustomerComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-customer',
        templateUrl: './customer.component.html',
        styleUrls: ['./customer.component.css'],
        preserveWhitespaces: true,
        animations: [
            expandOnEnterAnimation({ duration: 700 }),
            collapseOnLeaveAnimation({ duration: 500 }),
            trigger('openClose', [
                state('open', style({
                    height: '64px',
                    opacity: 1,
                    paddingTop: '20px'
                })),
                state('closed', style({
                    height: '0px',
                    opacity: 1,
                    paddingTop: '0px'
                })),
                transition('* => *', [
                    animate('0.25s')
                ])
            ])
        ]
    }),
    tslib_1.__param(0, Inject(DOCUMENT)),
    tslib_1.__metadata("design:paramtypes", [Document,
        ActivatedRoute,
        FormBuilder,
        ConditionalCheckService,
        TransactionsService,
        BsModalService,
        ErrorHandlerService,
        ErrorMessagesService,
        ResponsiveService,
        AlertMessageService,
        CustomerService,
        PrivilegeService,
        LandingPageMsgService,
        ChangeDetectorRef])
], CustomerComponent);
export { CustomerComponent };
//# sourceMappingURL=customer.component.js.map