export class ResultTwoData {
}
//# sourceMappingURL=ResultTwo.js.map