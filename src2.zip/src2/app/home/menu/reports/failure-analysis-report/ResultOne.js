export class ResultOneData {
}
//# sourceMappingURL=ResultOne.js.map