import { async, TestBed } from '@angular/core/testing';
import { FailureAnalysisDetailsComponent } from './failure-analysis-details.component';
describe('FailureAnalysisDetailsComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FailureAnalysisDetailsComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(FailureAnalysisDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=failure-analysis-details.component.spec.js.map