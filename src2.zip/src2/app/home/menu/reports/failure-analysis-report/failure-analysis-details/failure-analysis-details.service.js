import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { FailureAnalysisReportStatusWiseReq } from "../failure-analysis-details-status-wise.req";
import { FailureAnalysisReportService } from "../failure-analysis-report.service";
let FailureRefundAnalysisReportResolverService = class FailureRefundAnalysisReportResolverService {
    constructor(sRouter, pMerchInfoService, sCheck, sFailureAnalysisReportService) {
        this.sRouter = sRouter;
        this.pMerchInfoService = pMerchInfoService;
        this.sCheck = sCheck;
        this.sFailureAnalysisReportService = sFailureAnalysisReportService;
    }
    resolve(route, state) {
        let mFailureAnalysisReportStatusWiseReq = new FailureAnalysisReportStatusWiseReq();
        mFailureAnalysisReportStatusWiseReq.regId = this.pMerchInfoService.getRegId().toString();
        mFailureAnalysisReportStatusWiseReq.orderOprionType = route.queryParams.cardTypeDesc;
        mFailureAnalysisReportStatusWiseReq.orderCardType = route.queryParams.orderCardType;
        mFailureAnalysisReportStatusWiseReq.orderCardName = route.queryParams.orderCardName;
        mFailureAnalysisReportStatusWiseReq.fromDate = route.queryParams.fromDate;
        mFailureAnalysisReportStatusWiseReq.toDate = route.queryParams.toDate;
        if (this.sCheck.isNotNullObject(route.queryParams.subAccId) && route.queryParams.subAccId !== 'undefined') {
            mFailureAnalysisReportStatusWiseReq.subAccId = route.queryParams.subAccId;
        }
        return this.sFailureAnalysisReportService.fetchFailureAnalysisStatusWiseList(mFailureAnalysisReportStatusWiseReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
FailureRefundAnalysisReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router,
        MerchInfoService,
        ConditionalCheckService,
        FailureAnalysisReportService])
], FailureRefundAnalysisReportResolverService);
export { FailureRefundAnalysisReportResolverService };
//# sourceMappingURL=failure-analysis-details.service.js.map