import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ApiRequestService } from '../../../../../common-services/api-request.service';
import { LandingPageMsgService } from './../../../../../common-services/landing-page-msg.service';
import { FailureAnalysisReportSuccessFull } from '../FailureAnalysisReportSuccess.class';
import { FailureAnalysisReportStatusWiseReq } from '../failure-analysis-details-status-wise.req';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { FailureAnalysisReportService } from '../failure-analysis-report.service';
import { TransactionDetailsReq } from '../../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
let FailureAnalysisDetailsComponent = class FailureAnalysisDetailsComponent {
    constructor(cdr, cApiRequestService, cLocation, sActivatedRoute, sAlertMessageService, sErrorMessagesService, sResponsiveService, sCheck, pMerchInfoService, sFailureAnalysisReportService, sLandingPageMsgService, pFormBuilder, sErrorHandler, pTransactionsService) {
        this.cdr = cdr;
        this.cApiRequestService = cApiRequestService;
        this.cLocation = cLocation;
        this.sActivatedRoute = sActivatedRoute;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.sFailureAnalysisReportService = sFailureAnalysisReportService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.pTransactionsService = pTransactionsService;
        this.searchflag = 'seachform';
        this.isSearchByClick = false;
        this.isTransactionDetailClick = false;
        this.cFailureAnalysisReportSuccessFull = new FailureAnalysisReportSuccessFull();
        this.cFailureAnalysisReportStatusWiseReq = new FailureAnalysisReportStatusWiseReq();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (mCommonResponse.data != null) {
                    this.cFailureAnalysisReportSuccessFull.totalCount = mCommonResponse.data['TotalCounts'];
                    this.cFailureAnalysisDetailsResponseProc = mCommonResponse.data['FailureAnalysisOrderDetailsProcEntity'];
                }
                else {
                    this.sAlertMessageService.popupAlertMsg("No Failure Analysis Report were found!");
                }
            }
            else {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        });
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParam(param));
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: ['', []],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    fetchQueryParam(pParam) {
        this.cFailureAnalysisReportStatusWiseReq.regId = this.pMerchInfoService.getRegId().toString();
        this.cFailureAnalysisReportStatusWiseReq.orderCardType = pParam.orderCardType;
        this.cFailureAnalysisReportStatusWiseReq.orderCardName = pParam.orderCardName;
        this.cFailureAnalysisReportStatusWiseReq.orderOprionType = pParam.cardTypeDesc;
        this.ctype = pParam.cardTypeDesc;
        this.cName = pParam.orderCardName;
        this.ooType = pParam.orderCardType;
        this.fromDate = this.cFailureAnalysisReportStatusWiseReq.fromDate = pParam.fromDate;
        this.toDate = this.cFailureAnalysisReportStatusWiseReq.toDate = pParam.toDate;
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.mForm.controls['searchByValue'].disable();
        this.sResponsiveService.openSearch();
    }
    onSearchClick() {
        if (this.mForm.valid) {
            this.sFailureAnalysisReportService.fetchFailureAnalysisStatusWiseList(this.cFailureAnalysisReportStatusWiseReq)
                .subscribe(rResponse => this.fetchAllFailureReport(rResponse), error => { console.log('error'); });
            this.searchflag = 'seachform';
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    onCancelClick() {
        this.cFailureAnalysisReportSuccessFull.fromToDate = null;
        this.cFailureAnalysisReportStatusWiseReq.orderNo = null;
        this.cFailureAnalysisReportStatusWiseReq.searchByValue = null;
        this.cFailureAnalysisReportStatusWiseReq.fromDate = null;
        this.cFailureAnalysisReportStatusWiseReq.toDate = null;
        this.cFailureAnalysisReportSuccessFull.isSearchByClick = false;
        this.cFailureAnalysisReportStatusWiseReq.fromDate = this.fromDate;
        this.cFailureAnalysisReportStatusWiseReq.toDate = this.toDate;
        this.cFailureAnalysisReportSuccessFull.fromToDate = this.cFailureAnalysisReportStatusWiseReq.fromDate + ' - ' + this.cFailureAnalysisReportStatusWiseReq.toDate;
        this.onSearchClick();
        this.sResponsiveService.closeSearch();
    }
    onSingleOrderIDClick(pTrackingId) {
        if (pTrackingId != null) {
            this.cTransactionDetailsReq.trackingId = pTrackingId;
            this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
                .subscribe(pResponse => {
                window.scrollTo(0, 0);
                this.fetchTransactionDetailsSuccess(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    onSearchByClick() {
        this.cFailureAnalysisReportSuccessFull.isSearchByClick = !this.cFailureAnalysisReportSuccessFull.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cFailureAnalysisReportSuccessFull.isSearchByClick = !this.cFailureAnalysisReportSuccessFull.isSearchByClick;
        this.cFailureAnalysisReportStatusWiseReq.searchBy = pOption.value;
        this.cFailureAnalysisReportSuccessFull.searchByLabel = pOption.label;
        this.cFailureAnalysisReportStatusWiseReq.searchByValue = null;
        if (this.cFailureAnalysisReportSuccessFull.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cFailureAnalysisReportSuccessFull.searchByLabel == 'CCAvenue Ref.#') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cFailureAnalysisReportSuccessFull.searchByLabel == 'Order #') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].setValidators([Validators.required]);
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onDropdownCloseClick() {
        this.cFailureAnalysisReportSuccessFull.isSearchByClick = false;
    }
    onBackClick() {
        if (this.cFailureAnalysisReportSuccessFull.isOrderIDClick) {
            this.cFailureAnalysisReportSuccessFull.isOrderIDClick = false;
            this.sResponsiveService.closeDetails();
        }
        else {
            this.cFailureAnalysisReportSuccessFull.isOrderIDClick = true;
            this.cFailureAnalysisReportSuccessFull.isOrder = true;
            this.cLocation.back();
        }
    }
    onDetailBackClick() {
        this.cFailureAnalysisReportSuccessFull.isOrder = true;
        this.sResponsiveService.closeDetails();
    }
    //***********************************************Select Event************************************************//
    selectedDate(value) {
        this.cFailureAnalysisReportStatusWiseReq.fromDate = value.start.format("DD-MM-YYYY");
        this.cFailureAnalysisReportStatusWiseReq.toDate = value.end.format("DD-MM-YYYY");
        this.cFailureAnalysisReportSuccessFull.fromToDate = this.cFailureAnalysisReportStatusWiseReq.fromDate + ' - ' + this.cFailureAnalysisReportStatusWiseReq.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllFailureReport(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cFailureAnalysisReportSuccessFull.totalCount = mCommonResponse.data['TotalCounts'];
                if (this.sCheck.isNotNullList(mCommonResponse.data['FailureAnalysisOrderDetailsProcEntity'])) {
                    this.cFailureAnalysisDetailsResponseProc = mCommonResponse.data['FailureAnalysisOrderDetailsProcEntity'];
                    this.sResponsiveService.closeSearch();
                }
            }
            else {
                this.cFailureAnalysisDetailsResponseProc = null;
            }
        }
        this.cFailureAnalysisReportSuccessFull.selectedSI = [];
        this.cFailureAnalysisReportSuccessFull.isSelectActionClick = false;
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.isTransactionDetailClick = true;
            }
            if (this.isTransactionDetailClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onPageChange(event) {
        this.cFailureAnalysisReportStatusWiseReq.searchPageSize = event.cPageSize;
        this.cFailureAnalysisReportStatusWiseReq.pageNumber = event.cPageNo;
        this.cFailureAnalysisReportSuccessFull.selectedSI = [];
        this.cFailureAnalysisReportSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
};
FailureAnalysisDetailsComponent = tslib_1.__decorate([
    Component({
        selector: 'app-failure-analysis-details',
        templateUrl: './failure-analysis-details.component.html',
        styleUrls: ['./failure-analysis-details.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        ApiRequestService,
        Location,
        ActivatedRoute,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        ConditionalCheckService,
        MerchInfoService,
        FailureAnalysisReportService,
        LandingPageMsgService,
        FormBuilder,
        ErrorHandlerService,
        TransactionsService])
], FailureAnalysisDetailsComponent);
export { FailureAnalysisDetailsComponent };
//# sourceMappingURL=failure-analysis-details.component.js.map