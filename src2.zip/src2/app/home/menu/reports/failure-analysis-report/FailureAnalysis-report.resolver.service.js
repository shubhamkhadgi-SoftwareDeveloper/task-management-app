import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { FailureAnalysisReportReqDTO } from './FailureAnalysisReport.req';
import { FailureAnalysisReportService } from './failure-analysis-report.service';
let FailureAnalysisResolverService = class FailureAnalysisResolverService {
    constructor(cFailureAnalysisReportService) {
        this.cFailureAnalysisReportService = cFailureAnalysisReportService;
    }
    resolve(route, state) {
        let mFailureAnalysisReportReqDTO = new FailureAnalysisReportReqDTO();
        return this.cFailureAnalysisReportService.getAllFailureAnalysisList(mFailureAnalysisReportReqDTO).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
FailureAnalysisResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [FailureAnalysisReportService])
], FailureAnalysisResolverService);
export { FailureAnalysisResolverService };
//# sourceMappingURL=FailureAnalysis-report.resolver.service.js.map