import { TestBed, inject } from '@angular/core/testing';
import { FailureAnalysisReportService } from './failure-analysis-report.service';
describe('FailureAnalysisReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FailureAnalysisReportService]
        });
    });
    it('should be created', inject([FailureAnalysisReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=failure-analysis-report.service.spec.js.map