import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let FailureAnalysisReportService = class FailureAnalysisReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseFailureAnalysisReportUrl = 'failureAnalysisReport/';
        this.cGetFailureAnalysisReportOrderDetailsUrl = this.cBaseFailureAnalysisReportUrl + 'getFailureAnalysisReportListOrderDetails';
        this.cGetAllFailureAnalysisUrl = this.cBaseFailureAnalysisReportUrl + 'getFailureAnalysisReportList';
        this.cGetFailureAnalysisReportListByIdUrl = this.cBaseFailureAnalysisReportUrl + 'getFailureAnalysisReportListById';
    }
    fetchFailureAnalysisStatusWiseList(mFailureAnalysisReportStatusWiseReq) {
        return this.pApiRequestService.httpPostRequest(mFailureAnalysisReportStatusWiseReq, this.cGetFailureAnalysisReportOrderDetailsUrl);
    }
    getAllFailureAnalysisList(pFailureAnalysisReportReqDTO) {
        return this.pApiRequestService.httpPostRequest(pFailureAnalysisReportReqDTO, this.cGetAllFailureAnalysisUrl);
    }
    getFailureAnalysisReportListByIdUrl(pFailureAnalysisReportReqDTO) {
        return this.pApiRequestService.httpPostRequest(pFailureAnalysisReportReqDTO, this.cGetFailureAnalysisReportListByIdUrl);
    }
};
FailureAnalysisReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], FailureAnalysisReportService);
export { FailureAnalysisReportService };
//# sourceMappingURL=failure-analysis-report.service.js.map