export class FailureAnalysisReportStatusWiseReq {
    constructor() {
        this.pageNumber = 1;
        this.pageSize = 25;
        this.searchPageSize = 25;
        this.exportFlag = false;
        var myVariable = new Date();
        var makeDate = new Date(myVariable);
        //this.searchToDate = makeDate.toLocaleDateString();
        //makeDate.setMonth( makeDate.getMonth() - 1 );
        //this.searchFromDate = makeDate.toLocaleDateString();
    }
}
//# sourceMappingURL=failure-analysis-details-status-wise.req.js.map