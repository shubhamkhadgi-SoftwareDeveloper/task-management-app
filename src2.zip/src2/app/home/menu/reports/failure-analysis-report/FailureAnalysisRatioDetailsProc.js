export class FailureAnalysisRatioDetailsProcEntity {
}
//# sourceMappingURL=FailureAnalysisRatioDetailsProc.js.map