import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute } from '@angular/router';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { FailureAnalysisReportReqDTO } from './FailureAnalysisReport.req';
import { FailureAnalysisReportResDto } from './FailureAnalysisReport.res';
import { FailureAnalysisReportSuccessFull } from './FailureAnalysisReportSuccess.class';
import { FailureAnalysisReportResponseProc } from './FailureAnalysisReportProcEntity';
import { TitleService } from './../../../../common-services/title.service';
import { ResultOneData } from './ResultOne';
import { ResultTwoData } from './ResultTwo';
import { FailureAnalysisReportService } from './failure-analysis-report.service';
let FailureAnalysisReportComponent = class FailureAnalysisReportComponent {
    constructor(cdr, modalService, pApiRequestService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService, sFailureAnalysisReportService) {
        this.cdr = cdr;
        this.modalService = modalService;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.sFailureAnalysisReportService = sFailureAnalysisReportService;
        this.cIsWritePrivilege = false;
        this.resById = [];
        this.resultOne = [];
        this.resultTwo = [];
        this.cFailureAnalysisReportResponseProcArr = [];
        this.cFailureAnalysisRatioDetailsProcEntityArr = [];
        this.pageCount = 0;
        this.percentage = [];
        this.cashCardsArr = [];
        this.creditCardArr = [];
        this.debitCardArr = [];
        this.walletArr = [];
        this.netBankingArr = [];
        this.EMIArr = [];
        this.IVRSArr = [];
        this.mobPaymentsArr = [];
        this.payLaterArr = [];
        this.RemitanceArr = [];
        this.unifiedArr = [];
        this.checkOutArr = [];
        this.chartAreaData = [];
        this.chartDonutOptions = { formatter: function (y, data) {
                return y + '%';
            }, resize: true,
        };
        this.cFailureAnalysisReportReqDTO = new FailureAnalysisReportReqDTO();
        this.cFailureAnalysisReportSuccessFull = new FailureAnalysisReportSuccessFull();
        this.cFailureAnalysisReportResponseProc = new FailureAnalysisReportResponseProc();
        this.cResultOneData = new ResultOneData();
        this.cResultTwoData = new ResultTwoData();
        this.cFailureAnalysisReportResDto = new FailureAnalysisReportResDto();
        this.sTitleService.setTitle(this.sTitleService.FailureAnalysisReport);
    }
    ngOnInit() {
        this.createForm();
        if (this.fromDate != null) {
            this.cFailureAnalysisReportSuccessFull.fromToDate = this.fromDate + ' - ' + this.toDate;
        }
        else {
            this.cFailureAnalysisReportSuccessFull.fromToDate = this.cFailureAnalysisReportReqDTO.fromDate + ' - ' + this.cFailureAnalysisReportReqDTO.toDate;
        }
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cFailureAnalysisReportSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['FailureAnalysisRatioThreeProcEntity'])) {
                        this.resById = mCommonResponse.data['FailureAnalysisRatioThreeProcEntity'];
                        this.resultOne = mCommonResponse.data['resultOne'];
                        this.resultTwo = mCommonResponse.data['resultTwo'];
                        this.sResponsiveService.closeSearch();
                        for (var x = 0; x < this.resultOne.length; x++) {
                            this.failureCount = this.resultOne[x].failure_count;
                        }
                        for (var x = 0; x < this.resultTwo.length; x++) {
                            this.percentage[x] = (+this.resultTwo[x].tot_failure_count / +this.failureCount) * 100;
                            this.resultTwo[x].pay_opt_desc = this.resultTwo[x].pay_opt_desc;
                            this.resultTwo[x].fullPercentage = this.percentage[x];
                        }
                        var j = 0, k = 0;
                        var l = 0, m = 0;
                        var n = 0, o = 0;
                        var p = 0, q = 0;
                        var r = 0, s = 0;
                        var t = 0, v = 0;
                        this.pieChartCalculation();
                        for (var i = 0; i < this.resById.length; i++) {
                            if (this.resById[i].pay_opt_desc === 'Cash Card' && this.resById[i].order_card_name != null) {
                                this.cashCardsArr[v++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Credit Card' && this.resById[i].order_card_name != null) {
                                this.creditCardArr[j++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Debit Card' && this.resById[i].order_card_name != null) {
                                this.debitCardArr[k++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Wallet' && this.resById[i].order_card_name != null) {
                                this.walletArr[l++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Net Banking' && this.resById[i].order_card_name != null) {
                                this.netBankingArr[m++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'EMI' && this.resById[i].order_card_name != null) {
                                this.EMIArr[n++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'IVRS' && this.resById[i].order_card_name != null) {
                                this.IVRSArr[o++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Mobile Payments' && this.resById[i].order_card_name != null) {
                                this.mobPaymentsArr[p++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Pay Later' && this.resById[i].order_card_name != null) {
                                this.payLaterArr[q++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Remitance' && this.resById[i].order_card_name != null) {
                                this.RemitanceArr[r++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Unified Payments' && this.resById[i].order_card_name != null) {
                                this.unifiedArr[s++] = this.resById[i];
                            }
                            if (this.resById[i].pay_opt_desc === 'Checkout' && this.resById[i].order_card_name != null) {
                                this.checkOutArr[t++] = this.resById[i];
                            }
                        }
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                    }
                }
                else {
                    this.resById = null;
                }
            }
        });
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: ['', [Validators.required]],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    fetchFailureAnalysisReport() {
        this.sFailureAnalysisReportService.getAllFailureAnalysisList(this.cFailureAnalysisReportReqDTO)
            .subscribe(rResponse => this.fetchAllFailureAnalysisReport(rResponse), error => { console.log('error'); });
    }
    fetchAllFailureAnalysisReport(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cFailureAnalysisReportSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                if (this.sCheck.isNotNullList(mCommonResponse.data['FailureAnalysisRatioThreeProcEntity'])) {
                    this.resById = mCommonResponse.data['FailureAnalysisRatioThreeProcEntity'];
                    this.resultOne = mCommonResponse.data['resultOne'];
                    this.resultTwo = mCommonResponse.data['resultTwo'];
                    this.sResponsiveService.closeSearch();
                    for (var x = 0; x < this.resultOne.length; x++) {
                        this.failureCount = this.resultOne[x].failure_count;
                    }
                    for (var x = 0; x < this.resultTwo.length; x++) {
                        this.percentage[x] = (+this.resultTwo[x].tot_failure_count / +this.failureCount) * 100;
                        this.resultTwo[x].pay_opt_desc = this.resultTwo[x].pay_opt_desc;
                        this.resultTwo[x].fullPercentage = this.percentage[x];
                    }
                    var j = 0;
                    var k = 0;
                    var l = 0;
                    var m = 0;
                    var n = 0;
                    var o = 0;
                    var p = 0;
                    var q = 0;
                    var r = 0;
                    var s = 0;
                    var t = 0;
                    var v = 0;
                    this.pieChartCalculation();
                    for (var i = 0; i < this.resById.length; i++) {
                        if (this.resById[i].pay_opt_desc == 'Cash Card' && this.resById[i].order_card_name != null) {
                            this.cashCardsArr[v++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Credit Card' && this.resById[i].order_card_name != null) {
                            this.creditCardArr[j++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Debit Card' && this.resById[i].order_card_name != null) {
                            this.debitCardArr[k++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Wallet' && this.resById[i].order_card_name != null) {
                            this.walletArr[l++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Net Banking' && this.resById[i].order_card_name != null) {
                            this.netBankingArr[m++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'EMI' && this.resById[i].order_card_name != null) {
                            this.EMIArr[n++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'IVRS' && this.resById[i].order_card_name != null) {
                            this.IVRSArr[o++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Mobile Payments' && this.resById[i].order_card_name != null) {
                            this.mobPaymentsArr[p++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Pay Later' && this.resById[i].order_card_name != null) {
                            this.payLaterArr[q++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Remitance' && this.resById[i].order_card_name != null) {
                            this.RemitanceArr[r++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Unified Payments' && this.resById[i].order_card_name != null) {
                            this.unifiedArr[s++] = this.resById[i];
                        }
                        if (this.resById[i].pay_opt_desc == 'Checkout' && this.resById[i].order_card_name != null) {
                            this.checkOutArr[t++] = this.resById[i];
                        }
                    }
                    this.pageCount = mCommonResponse.data['pageTotalCount'];
                }
            }
            else {
                this.resById = null;
                this.sResponsiveService.closeSearch();
            }
        }
        this.cFailureAnalysisReportSuccessFull.selectedSI = [];
        this.cFailureAnalysisReportSuccessFull.isSelectActionClick = false;
    }
    pieChartCalculation() {
        if (this.sCheck.isNotNullObject(this.resultTwo)) {
            for (var i = 0; i < this.resultTwo.length; i++) {
                if (this.resultTwo[i].pay_opt_desc == 'Cash Card') {
                    this.cashCardsPer = this.resultTwo[i].fullPercentage;
                    this.resultTwo[i].colorCode = "#526382";
                    if (this.cashCardsPer != null) {
                        this.cashCardsPer = +this.cashCardsPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Credit Card') {
                    this.creditPer = this.resultTwo[i].fullPercentage;
                    this.resultTwo[i].colorCode = "#64d691";
                    if (this.creditPer != null) {
                        this.creditPer = +this.creditPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Debit Card') {
                    this.debitPer = this.resultTwo[i].fullPercentage;
                    if (this.debitPer != null) {
                        this.debitPer = +this.debitPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Wallet') {
                    this.walletPer = this.resultTwo[i].fullPercentage;
                    if (this.walletPer != null) {
                        this.walletPer = +this.walletPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Net Banking') {
                    this.NetbankingPer = this.resultTwo[i].fullPercentage;
                    if (this.NetbankingPer != null) {
                        this.NetbankingPer = +this.NetbankingPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'EMI') {
                    this.EMIPer = this.resultTwo[i].fullPercentage;
                    if (this.EMIPer != null) {
                        this.EMIPer = +this.EMIPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'IVRS') {
                    this.IVRPer = this.resultTwo[i].fullPercentage;
                    if (this.IVRPer != null) {
                        this.IVRPer = +this.IVRPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Mobile Payments') {
                    this.mobPaymentPer = this.resultTwo[i].fullPercentage;
                    if (this.mobPaymentPer != null) {
                        this.mobPaymentPer = +this.mobPaymentPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Pay Later') {
                    this.payLaterPer = this.resultTwo[i].fullPercentage;
                    if (this.payLaterPer != null) {
                        this.payLaterPer = +this.payLaterPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Remitance') {
                    this.RemitancePer = this.resultTwo[i].fullPercentage;
                    if (this.RemitancePer != null) {
                        this.RemitancePer = +this.RemitancePer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Unified Payments') {
                    this.unifiedPer = this.resultTwo[i].fullPercentage;
                    if (this.unifiedPer != null) {
                        this.unifiedPer = +this.unifiedPer.toFixed(2);
                    }
                }
                if (this.resultTwo[i].pay_opt_desc === 'Checkout') {
                    this.checkOutPer = this.resultTwo[i].fullPercentage;
                    if (this.checkOutPer != null) {
                        this.checkOutPer = +this.checkOutPer.toFixed(2);
                    }
                }
            }
            var i = 0;
            this.chartAreaData = [];
            if (this.sCheck.isNotNullNumber(this.cashCardsPer)) {
                this.chartAreaData[i++] = { label: "Cash Cards", value: this.cashCardsPer, color: "#526382" };
            }
            if (this.sCheck.isNotNullNumber(this.creditPer)) {
                this.chartAreaData[i++] = { label: "Credit Cards", value: this.creditPer, color: "#64d691" };
            }
            if (this.sCheck.isNotNullNumber(this.debitPer)) {
                this.chartAreaData[i++] = { label: "Debit Cards", value: this.debitPer, color: "#10c4b5" };
            }
            if (this.sCheck.isNotNullNumber(this.walletPer)) {
                this.chartAreaData[i++] = { label: "Wallet", value: this.walletPer, color: "#6eba8c" };
            }
            if (this.sCheck.isNotNullNumber(this.NetbankingPer)) {
                this.chartAreaData[i++] = { label: "Net-Banking", value: this.NetbankingPer, color: "#227972" };
            }
            if (this.sCheck.isNotNullNumber(this.EMIPer)) {
                this.chartAreaData[i++] = { label: "EMI", value: this.EMIPer, color: "#c46e6e" };
            }
            if (this.sCheck.isNotNullNumber(this.IVRPer)) {
                this.chartAreaData[i++] = { label: "IVRs", value: this.IVRPer, color: "#771B1B" };
            }
            if (this.sCheck.isNotNullNumber(this.mobPaymentPer)) {
                this.chartAreaData[i++] = { label: "Mobile Payment", value: this.mobPaymentPer, color: "#0F0D49" };
            }
            if (this.sCheck.isNotNullNumber(this.payLaterPer)) {
                this.chartAreaData[i++] = { label: "Pay Later", value: this.payLaterPer, color: "#D78A54" };
            }
            if (this.sCheck.isNotNullNumber(this.RemitancePer)) {
                this.chartAreaData[i++] = { label: "Remitence", value: this.RemitancePer, color: "#286D01" };
            }
            if (this.sCheck.isNotNullNumber(this.unifiedPer)) {
                this.chartAreaData[i++] = { label: "Unified Payments", value: this.unifiedPer, color: "#F4D03F" };
            }
            if (this.sCheck.isNotNullNumber(this.checkOutPer)) {
                this.chartAreaData[i++] = { label: "Check Out", value: this.checkOutPer, color: "#2C3E50" };
            }
            /*this.data = {
                labels: ['', '', '', '', '', '', '', '', '', '', '', ''],
                datasets: [
                    {
                        data: [, , this., this., this., this., this., this., this., this., this., this.],
                        backgroundColor: [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                        ],
                        hoverBackgroundColor: [
                            "#526384",
                            "#64d691",
                            "#10c4b5",
                            "#6eba8c",
                            "#227972",
                            "#c46e6e",
                            "#771B1B",
                            "#0F0D49",
                            "#D78A54",
                            "#286D01",
                            "#F4D03F",
                            "#2C3E50",
                        ]
                    }]
            }
            this.options = {
                legend: {
                    display: false
                },
                tooltips: {
                    callbacks: {
                        title: function( tooltipItem, data ) {
                            return data['labels'][tooltipItem[0]['index']];
                        },
                        label: function( tooltipItem, data ) {
                            return data['datasets'][0]['data'][tooltipItem['index']] + '%';
                        },
                    }
                }
            };*/
        }
        else {
            this.data = null;
        }
    }
    onPageChange(event) {
        this.cFailureAnalysisReportReqDTO.searchPageSize = event.cPageSize;
        this.cFailureAnalysisReportReqDTO.pageNumber = event.cPageNo;
        this.cFailureAnalysisReportSuccessFull.selectedSI = [];
        this.cFailureAnalysisReportSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchClick() {
        this.resById = null;
        this.resultOne = null;
        this.resultTwo = null;
        this.cashCardsArr = [];
        this.debitCardArr = [];
        this.creditCardArr = [];
        this.walletArr = [];
        this.netBankingArr = [];
        this.EMIArr = [];
        this.IVRSArr = [];
        this.mobPaymentsArr = [];
        this.payLaterArr = [];
        this.RemitanceArr = [];
        this.unifiedArr = [];
        this.checkOutArr = [];
        if (this.mForm.valid) {
            this.sFailureAnalysisReportService.getAllFailureAnalysisList(this.cFailureAnalysisReportReqDTO)
                .subscribe(rResponse => this.fetchAllFailureAnalysisReport(rResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onSearchPanelClick() {
        this.sResponsiveService.openSearch();
    }
    selectedDate(value) {
        this.cFailureAnalysisReportReqDTO.fromDate = value.start.format("DD-MM-YYYY");
        this.cFailureAnalysisReportReqDTO.toDate = value.end.format("DD-MM-YYYY");
        this.cFailureAnalysisReportSuccessFull.fromToDate = this.cFailureAnalysisReportReqDTO.fromDate + ' - ' + this.cFailureAnalysisReportReqDTO.toDate;
    }
    onCancelClick() {
        this.cFailureAnalysisReportReqDTO = null;
        this.cFailureAnalysisReportReqDTO = new FailureAnalysisReportReqDTO();
        this.cFailureAnalysisReportReqDTO.regIds = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cFailureAnalysisReportSuccessFull.isSearchPanelClick = false;
        }
        this.cFailureAnalysisReportSuccessFull = new FailureAnalysisReportSuccessFull();
        this.cFailureAnalysisReportSuccessFull.fromToDate = this.cFailureAnalysisReportReqDTO.fromDate + ' - ' + this.cFailureAnalysisReportReqDTO.toDate;
        this.fetchFailureAnalysisReport();
        this.sResponsiveService.closeSearch();
    }
    onSingleOrderIDClick(orderOptType, orderCardType, orderCardName) {
        if (orderOptType != null && orderCardType != null && orderCardName != null) {
            this.cFailureAnalysisReportReqDTO.orderOprionType = orderOptType;
            this.cFailureAnalysisReportReqDTO.orderCardType = orderCardType;
            this.cFailureAnalysisReportReqDTO.orderCardName = orderCardName;
            this.sFailureAnalysisReportService.getFailureAnalysisReportListByIdUrl(this.cFailureAnalysisReportReqDTO)
                .subscribe(pResponse => this.fetchSubAccountById(pResponse), error => { console.log('error'); });
        }
        else {
            this.sAlertMessageService.popupAlertMsg("No Failure Analysis Report were found!");
        }
    }
    /*public onOccurredCountClick(orderOptType,orderCardType,orderCardName) {
        console.log("Called>>");
        if(orderOptType != null && orderCardType != null && orderCardName != null){
            this.cFailureAnalysisReportReqDTO.orderOprionType = orderOptType;
            this.cFailureAnalysisReportReqDTO.orderCardType = orderCardType;
            this.cFailureAnalysisReportReqDTO.orderCardName = orderCardName;
            this.pApiRequestService.httpPostRequest(this.cFailureAnalysisReportReqDTO,'getFailureAnalysisReportListOrderDetails')
            .subscribe(pResponse => this.fetchSubAccountByOccuredCount(pResponse) ,error => {console.log('error'); });
        }else{
            this.sAlertMessageService.popupAlertMsg("No Failure Analysis Report were found!");
        }
    }*/
    fetchSubAccountById(pResponse) {
        window.scrollTo(0, 0);
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (pResponse.code === 0 && pResponse.message === 'Success') {
                this.cFailureAnalysisRatioDetailsProcEntityArr = pResponse.data['failureAnalysisRatioDetailsProcEntity'];
            }
            else {
                this.cFailureAnalysisRatioDetailsProcEntityArr = [];
            }
            if (this.sCheck.isNotNullObject(this.cFailureAnalysisReportResDto)) {
                this.cFailureAnalysisReportSuccessFull.isOrderIDClick = true;
                this.cFailureAnalysisReportSuccessFull.isOrder = true;
                this.sResponsiveService.addBodyClass("overlay");
            }
            else {
                this.sAlertMessageService.popupAlertMsg("No Failure Analysis Report were found!");
            }
        }
    }
    fetchSubAccountByOccuredCount(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cFailureAnalysisReportResDto = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cFailureAnalysisReportResDto)) {
                this.cFailureAnalysisReportSuccessFull.isOrderIDClick2 = true;
            }
            else {
                this.sAlertMessageService.popupAlertMsg("No Failure Analysis Report were found!");
            }
        }
    }
    onBackClick() {
        this.sResponsiveService.closeSearch();
        this.cFailureAnalysisReportSuccessFull.isOrderIDClick = false;
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
};
FailureAnalysisReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-failure-analysis-report',
        templateUrl: './failure-analysis-report.component.html',
        styleUrls: ['./failure-analysis-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        BsModalService,
        ApiRequestService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService,
        FailureAnalysisReportService])
], FailureAnalysisReportComponent);
export { FailureAnalysisReportComponent };
//# sourceMappingURL=failure-analysis-report.component.js.map