export class FailureAnalysisReportResDto {
    constructor() {
    }
}
//# sourceMappingURL=FailureAnalysisReport.res.js.map