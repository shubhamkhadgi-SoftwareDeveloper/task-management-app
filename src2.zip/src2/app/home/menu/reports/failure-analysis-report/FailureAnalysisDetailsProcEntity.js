export class FailureAnalysisDetailsResponseProc {
}
//# sourceMappingURL=FailureAnalysisDetailsProcEntity.js.map