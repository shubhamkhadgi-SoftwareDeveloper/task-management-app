export class FailureAnalysisReportResponseProc {
}
//# sourceMappingURL=FailureAnalysisReportProcEntity.js.map