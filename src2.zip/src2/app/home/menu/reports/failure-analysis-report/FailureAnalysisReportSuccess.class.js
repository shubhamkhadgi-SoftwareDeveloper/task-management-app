import { DatePipe } from '@angular/common';
export class FailureAnalysisReportSuccessFull {
    constructor() {
        this.isAllSISuccessCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.landingPageMsg = "You don't have any Failure Analysis Report report yet!";
        this.landingPageMsg2 = "No Failure Analysis Report were found!";
        this.selectedSI = [];
        this.isOrder = false;
        this.isOrderIDClick = false;
        this.isOrderIDClick2 = false;
        this.searchByLabel = "Search By";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref.#', value: 'trackingId' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            // timePicker: true,
            //timePicker12Hour: true,
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        let currDate = new Date();
        let yesterDaysDate = new Date();
        yesterDaysDate.setDate(currDate.getDate() - 1);
        var datePipe = new DatePipe('en-US');
        this.fromDate = datePipe.transform(yesterDaysDate, 'd-MM-y');
        this.toDate = datePipe.transform(currDate, 'd-MM-y');
        this.fromToDate = this.fromDate + '-' + this.toDate;
    }
}
//# sourceMappingURL=FailureAnalysisReportSuccess.class.js.map