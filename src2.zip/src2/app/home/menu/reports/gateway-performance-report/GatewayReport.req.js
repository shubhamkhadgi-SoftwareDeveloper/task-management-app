export class GatewayReportReq {
    constructor() {
        this.searchMerchantArr = [];
    }
}
//# sourceMappingURL=GatewayReport.req.js.map