import { async, TestBed } from '@angular/core/testing';
import { GatewayPerformanceReportComponent } from './gateway-performance-report.component';
describe('GatewayPerformanceReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [GatewayPerformanceReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(GatewayPerformanceReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=gateway-performance-report.component.spec.js.map