export class GatewayPerformanceReport {
    constructor() {
        this.isSearchPanelClick = false;
        this.isNoRecordAfterSearch = true;
        this.isExportClick = false;
        this.isSearchByClick = false;
        this.activeColumn = [0, 1, 2, 3];
        this.constColumn = 0;
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.searchBy = [];
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=gateway-performance-report.js.map