import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let GatewayPerformanceReportService = class GatewayPerformanceReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'gatewayPerformanceReport/';
        this.cgetGatewayPerformanceReportListUrl = this.cBaseUrl + 'getGatewayPerformanceReportList';
        this.cexportGatewayPerformanceReportUrl = this.cBaseUrl + 'exportGatewayPerformanceReport';
    }
    getGatewayPerformanceReportList(cGatewayReportReq) {
        return this.pApiRequestService.httpPostRequest(cGatewayReportReq, this.cgetGatewayPerformanceReportListUrl);
    }
    exportGatewayPerformanceReport(cGatewayReportReq) {
        return this.pApiRequestService.exportFileRequest(cGatewayReportReq, this.cexportGatewayPerformanceReportUrl, "GatewayPerformanceReport.xlsx");
    }
};
GatewayPerformanceReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], GatewayPerformanceReportService);
export { GatewayPerformanceReportService };
//# sourceMappingURL=gateway-performance-report.service.js.map