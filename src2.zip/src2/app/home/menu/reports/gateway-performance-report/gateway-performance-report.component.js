import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { DatePipe } from '@angular/common';
import { GatewayReportReq } from "app/home/menu/reports/gateway-performance-report/GatewayReport.req";
import { GatewayPerformanceReport } from './gateway-performance-report';
import { GatewayReportResponseProc } from './GatewayReportResponseProc';
import { GatewayPerformanceReportService } from './gateway-performance-report.service';
import { TitleService } from './../../../../common-services/title.service';
let GatewayPerformanceReportComponent = class GatewayPerformanceReportComponent {
    constructor(pDatePipe, modalService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, slandingPageMsgService, sActivatedRoute, cGatewayPerformanceReportService, sPrivilegeService, sTitleService) {
        this.pDatePipe = pDatePipe;
        this.modalService = modalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.slandingPageMsgService = slandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.cGatewayPerformanceReportService = cGatewayPerformanceReportService;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.cGatewayReportResponseProc = [];
        this.cGatewayReportResponse = [];
        this.landingPageMsg = null;
        this.toDate = '';
        this.fromDate = '';
        this.cGatewayPerformanceReport = new GatewayPerformanceReport();
        this.cGatewayReportReq = new GatewayReportReq();
        this.cGatewayReportGrandTotal = new GatewayReportResponseProc();
        this.sTitleService.setTitle(this.sTitleService.GatewayPerformanceReport);
    }
    ngOnInit() {
        var tempDate = new Date();
        var makeDate = new Date(tempDate);
        this.searchToDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
        makeDate.setMonth(makeDate.getMonth() - 1);
        this.searchFromDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
        this.cGatewayPerformanceReport.fromToDate = this.searchFromDate + ' - ' + this.searchToDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject((mCommonResponse.data))) {
                    if (this.sCheck.isNotNullObject(mCommonResponse.data['gateWayList'])) {
                        this.cGatewayReportResponseProc = mCommonResponse.data['gateWayList'];
                        for (let i = 0; i < this.cGatewayReportResponseProc.length - 1; i++) {
                            this.cGatewayReportResponse[i] = this.cGatewayReportResponseProc[i];
                        }
                        if (this.cGatewayReportResponseProc != null) {
                            this.cGatewayReportGrandTotal = this.cGatewayReportResponseProc[this.cGatewayReportResponseProc.length - 1];
                        }
                    }
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.landingPageMsg = 'No records found';
                }
            }
            else {
                this.landingPageMsg = 'No records found';
                console.log(mCommonResponse.messageDesc);
            }
        });
    }
    //***********************************************Server Call Event*******************************************//
    fetchGatewayReportSuccess(pResponse) {
        this.cGatewayReportResponseProc = [];
        this.cGatewayReportResponse = [];
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cGatewayReportResponseProc = mCommonResponse.data['gateWayList'];
                for (let i = 0; i < this.cGatewayReportResponseProc.length - 1; i++) {
                    this.cGatewayReportResponse[i] = this.cGatewayReportResponseProc[i];
                }
                this.cGatewayReportGrandTotal = this.cGatewayReportResponseProc[this.cGatewayReportResponseProc.length - 1];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cGatewayPerformanceReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                console.log(mCommonResponse.messageDesc);
                this.cGatewayReportResponseProc = null;
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchGatewayReport(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchGatewayReport(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cGatewayReportResponseProc = null;
            this.landingPageMsg = 'No Record Found';
            this.onFailFetchGatewayReport(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchGatewayReport(pResMsg) {
        console.log(pResMsg);
        this.cGatewayReportResponseProc = null;
        this.cGatewayReportGrandTotal = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cGatewayPerformanceReport.isSearchPanelClick = false;
        }
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cGatewayPerformanceReport.isExportClick = false;
    }
    //***********************************************Button Click Event*******************************************//
    onPreviousClick() {
        if (this.cGatewayPerformanceReport.activeColumn[0] != 0) {
            this.cGatewayPerformanceReport.activeColumn.splice(this.cGatewayPerformanceReport.activeColumn.length - 1, 1);
            this.cGatewayPerformanceReport.activeColumn.splice(0, 0, this.cGatewayPerformanceReport.activeColumn[0] - 1);
        }
    }
    onNextClick() {
        if (this.cGatewayPerformanceReport.activeColumn[this.cGatewayPerformanceReport.activeColumn.length - 1] < 6) {
            this.cGatewayPerformanceReport.activeColumn.push(this.cGatewayPerformanceReport.activeColumn[this.cGatewayPerformanceReport.activeColumn.length - 1] + 1);
            this.cGatewayPerformanceReport.activeColumn.splice(0, 1);
        }
    }
    onExportClick() {
        this.cGatewayPerformanceReport.isSearchPanelClick = false;
        this.cGatewayPerformanceReport.isExportClick = !this.cGatewayPerformanceReport.isExportClick;
    }
    onSearchPanelClick() {
        this.cGatewayPerformanceReport.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cGatewayPerformanceReport.isSearchPanelClick = !this.cGatewayPerformanceReport.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cGatewayPerformanceReport.fromToDate = '';
            this.cGatewayReportReq = null;
            this.cGatewayReportReq = new GatewayReportReq();
            this.cGatewayPerformanceReport.isSearchPanelClick = false;
            var tempDate = new Date();
            var makeDate = new Date(tempDate);
            this.searchToDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
            this.cGatewayReportReq.searchToDate = this.searchToDate;
            makeDate.setMonth(makeDate.getMonth() - 1);
            this.searchFromDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
            this.cGatewayReportReq.searchFromDate = this.searchFromDate;
            // this.cGatewayPerformanceReport.fromToDate=this.cGatewayReportReq.searchFromDate+'-'+this.cGatewayReportReq.searchToDate;
            this.onSearchClick();
        }
    }
    onSearchClick() {
        if (this.cGatewayReportReq.searchMerchantArr.length <= 0)
            this.cGatewayReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
        this.cGatewayPerformanceReportService.getGatewayPerformanceReportList(this.cGatewayReportReq)
            .subscribe(pResponse => { this.fetchGatewayReportSuccess(pResponse); }, error => { console.log('error'); });
    }
    onDropdownCloseClick() {
        this.cGatewayPerformanceReport.isSearchByClick = false;
    }
    onExportExcelClick() {
        if ((this.cGatewayReportReq.searchFromDate == 'undefined' || this.cGatewayReportReq.searchFromDate == null) && (this.cGatewayReportReq.searchToDate == 'undefined' || this.cGatewayReportReq.searchToDate == null)) {
            var tempDate = new Date();
            var makeDate = new Date(tempDate);
            this.searchToDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
            this.cGatewayReportReq.searchToDate = this.searchToDate;
            makeDate.setMonth(makeDate.getMonth() - 1);
            this.searchFromDate = this.pDatePipe.transform(makeDate, 'dd/MM/yyyy');
            this.cGatewayReportReq.searchFromDate = this.searchFromDate;
        }
        if (this.cGatewayReportReq.searchMerchantArr.length <= 0)
            this.cGatewayReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
        this.cGatewayPerformanceReport.isExportClick = !this.cGatewayPerformanceReport.isExportClick;
        this.cGatewayPerformanceReportService.exportGatewayPerformanceReport(this.cGatewayReportReq)
            .subscribe(pResponse => {
        }, error => { console.log('error'); });
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cGatewayReportReq.searchFromDate = value.start.format("DD/MM/YYYY");
        this.cGatewayReportReq.searchToDate = value.end.format("DD/MM/YYYY");
        this.cGatewayPerformanceReport.fromToDate = this.cGatewayReportReq.searchFromDate + ' - ' + this.cGatewayReportReq.searchToDate;
    }
};
GatewayPerformanceReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-gateway-performance-report',
        templateUrl: './gateway-performance-report.component.html',
        styleUrls: ['./gateway-performance-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [DatePipe,
        BsModalService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        GatewayPerformanceReportService,
        PrivilegeService,
        TitleService])
], GatewayPerformanceReportComponent);
export { GatewayPerformanceReportComponent };
//# sourceMappingURL=gateway-performance-report.component.js.map