import { TestBed, inject } from '@angular/core/testing';
import { GatewayPerformanceReportService } from './gateway-performance-report.service';
describe('GatewayPerformanceReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [GatewayPerformanceReportService]
        });
    });
    it('should be created', inject([GatewayPerformanceReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=gateway-performance-report.service.spec.js.map