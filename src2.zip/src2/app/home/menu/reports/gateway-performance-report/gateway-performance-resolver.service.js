import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { Injectable } from '@angular/core';
import { GatewayReportReq } from './GatewayReport.req';
import { GatewayPerformanceReportService } from './gateway-performance-report.service';
let GatePerformanceResolverService = class GatePerformanceResolverService {
    constructor(pMerchInfoService, sGatewayPerformanceReportService) {
        this.pMerchInfoService = pMerchInfoService;
        this.sGatewayPerformanceReportService = sGatewayPerformanceReportService;
    }
    resolve(route, state) {
        let mGatewayReportReq = new GatewayReportReq();
        return this.sGatewayPerformanceReportService.getGatewayPerformanceReportList(mGatewayReportReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
GatePerformanceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [MerchInfoService,
        GatewayPerformanceReportService])
], GatePerformanceResolverService);
export { GatePerformanceResolverService };
//# sourceMappingURL=gateway-performance-resolver.service.js.map