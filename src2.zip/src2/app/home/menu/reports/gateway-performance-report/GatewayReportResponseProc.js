export class GatewayReportResponseProc {
}
//# sourceMappingURL=GatewayReportResponseProc.js.map