export class AbortedSuccessFull {
    constructor() {
        this.isAllSISuccessCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.landingPageMsg = "No Aborted Transaction were found!";
        this.selectedSI = [];
        this.isOrder = false;
        this.isOrderIDClick = false;
        this.searchByLabel = "Search By";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref.#', value: 'trackingId' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY hh:mm:ss' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.currDate = new Date();
    }
}
//# sourceMappingURL=AbortedSuccessFull.class.js.map