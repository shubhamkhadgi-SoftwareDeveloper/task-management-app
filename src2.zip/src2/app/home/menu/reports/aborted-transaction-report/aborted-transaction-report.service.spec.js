import { TestBed, inject } from '@angular/core/testing';
import { AbortedTransationService } from './aborted-transation-report.service';
describe('AbortedTransationService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AbortedTransationService]
        });
    });
    it('should be created', inject([AbortedTransationService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=aborted-transaction-report.service.spec.js.map