import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let AbortedTransationService = class AbortedTransationService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'abortedTransactionReport/';
        this.cGetAllAbortedTransationUrl = this.cBaseUrl + 'getAbortedTransList';
        this.cExportExcelAbortedTransListUrl = this.cBaseUrl + 'exportExcelAbortedTransList';
    }
    getAllAbortedTransation(pAbortedTranstReq) {
        return this.pApiRequestService.httpPostRequest(pAbortedTranstReq, this.cGetAllAbortedTransationUrl);
    }
    exportExcelAbortedTransList(pAbortedTranstReq) {
        return this.pApiRequestService.exportFileRequest(pAbortedTranstReq, this.cExportExcelAbortedTransListUrl, "AbortedTransactionDetails.xlsx");
    }
};
AbortedTransationService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], AbortedTransationService);
export { AbortedTransationService };
//# sourceMappingURL=aborted-transation-report.service.js.map