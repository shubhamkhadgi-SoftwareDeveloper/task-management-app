import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { AbortedTranstReq } from "./AbortedTrans.req";
import { AbortedTransRes } from "./AbortedTrans.res";
import { AbortedSuccessFull } from './AbortedSuccessFull.class';
import { AbortedTansResponseProc } from './AbortedTransProc';
import { AbortedTransationService } from './aborted-transation-report.service';
import { TransactionDetailsReq } from '../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../transactions/transactions/transactions.service';
import { TitleService } from './../../../../common-services/title.service';
let AbortedTransactionReportComponent = class AbortedTransactionReportComponent {
    constructor(pAbortedTransationService, cdr, modalService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService, pTransactionsService) {
        this.pAbortedTransationService = pAbortedTransationService;
        this.cdr = cdr;
        this.modalService = modalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.pTransactionsService = pTransactionsService;
        this.cardNumber = null;
        this.orderTax = -1.00;
        this.searchflag = 'seachform';
        this.cIsWritePrivilege = false;
        this.cAbortedTansResponseProcArr = [];
        this.cAbortedTansResponseProcById = [];
        this.pageCount = 0;
        this.isSearchByClick = false;
        this.hypen = "-";
        this.cAbortedTranstReq = new AbortedTranstReq();
        this.cAbortedSuccessFull = new AbortedSuccessFull();
        this.cAbortedTansResponseProc = new AbortedTansResponseProc();
        this.cAbortedTransRes = new AbortedTransRes();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
        this.sTitleService.setTitle(this.sTitleService.AbortedTransactionReport);
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.cAbortedSuccessFull.fromToDate = this.cAbortedTranstReq.fromDate + ' - ' + this.cAbortedTranstReq.toDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cAbortedSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['AbortedTransProcEntity'])) {
                        this.cAbortedTansResponseProcArr = mCommonResponse.data['AbortedTransProcEntity'];
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                        this.cAbortedSuccessFull.fromToDate = this.cAbortedTranstReq.fromDate + ' - ' + this.cAbortedTranstReq.toDate;
                    }
                }
                else {
                    this.landingPageMsg = "No Aborted Transaction were found!";
                    this.fromDate = null;
                    this.toDate = null;
                    this.cAbortedTansResponseProcArr = null;
                }
            }
        });
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [],
            fromToDate: ['', [Validators.required]],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cAbortedSuccessFull.isExportClick = false;
        this.onDropdownCloseClick();
        this.mForm.controls['searchByValue'].disable();
        this.sResponsiveService.openSearch();
    }
    onDropdownCloseClick() {
        this.cAbortedSuccessFull.isSearchByClick = false;
    }
    onSearchByOptionClick(pOption) {
        this.cAbortedSuccessFull.isSearchByClick = !this.cAbortedSuccessFull.isSearchByClick;
        this.cAbortedTranstReq.searchBy = pOption.value;
        this.cAbortedSuccessFull.searchByLabel = pOption.label;
        this.cAbortedTranstReq.searchByValue = null;
        if (this.cAbortedSuccessFull.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cAbortedSuccessFull.searchByLabel == 'Order #' || this.cAbortedSuccessFull.searchByLabel == 'CCAvenue Ref.#') {
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.cAbortedSuccessFull.isExportClick = false;
        this.cAbortedSuccessFull.isSearchByClick = !this.cAbortedSuccessFull.isSearchByClick;
    }
    onExportClick() {
        this.cAbortedSuccessFull.isSearchByClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cAbortedSuccessFull.isSearchPanelClick = false;
        }
        this.cAbortedSuccessFull.isSelectActionClick = false;
        this.cAbortedSuccessFull.selectedSI = [];
        this.cAbortedSuccessFull.isExportClick = !this.cAbortedSuccessFull.isExportClick;
    }
    onCancelClick() {
        this.sResponsiveService.closeSearch();
        this.cAbortedTranstReq = null;
        this.cAbortedTranstReq = new AbortedTranstReq();
        this.cAbortedTranstReq.regId = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cAbortedSuccessFull.isSearchPanelClick = false;
        }
        this.cAbortedSuccessFull = new AbortedSuccessFull();
        this.cAbortedTranstReq.searchByValue = null;
        this.cAbortedSuccessFull.fromToDate = this.cAbortedTranstReq.fromDate + ' - ' + this.cAbortedTranstReq.toDate;
        this.onSearchClick();
    }
    onExportExcelClick() {
        this.cAbortedSuccessFull.isExportClick = !this.cAbortedSuccessFull.isExportClick;
        this.cAbortedTranstReq.regId = this.pMerchInfoService.getRegId();
        this.pAbortedTransationService.exportExcelAbortedTransList(this.cAbortedTranstReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            this.pAbortedTransationService.getAllAbortedTransation(this.cAbortedTranstReq)
                .subscribe(rResponse => this.fetchAllAbortedTrans(rResponse), error => { console.log('error'); });
            this.searchflag = 'seachform';
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    onSingleOrderIDClick(pTrackingId) {
        if (pTrackingId != null) {
            this.cTransactionDetailsReq.trackingId = pTrackingId;
            this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
                .subscribe(pResponse => {
                window.scrollTo(0, 0);
                this.fetchTransactionDetailsSuccess(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    onBackClick() {
        this.sResponsiveService.closeSearch();
        this.cAbortedSuccessFull.isOrderIDClick = false;
    }
    //***********************************************Select Event************************************************//
    selectedDate(value) {
        this.cAbortedSuccessFull.isSearchByClick = false;
        this.cAbortedTranstReq.fromDate = value.start.format('DD-MM-YYYY');
        this.cAbortedTranstReq.toDate = value.end.format('DD-MM-YYYY');
        this.cAbortedSuccessFull.fromToDate = this.cAbortedTranstReq.fromDate + ' - ' + this.cAbortedTranstReq.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllAbortedTrans(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cAbortedSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                if (this.sCheck.isNotNullList(mCommonResponse.data['AbortedTransProcEntity'])) {
                    this.cAbortedTansResponseProcArr = mCommonResponse.data['AbortedTransProcEntity'];
                    this.pageCount = mCommonResponse.data['pageTotalCount'];
                    this.sResponsiveService.closeSearch();
                }
            }
            else {
                this.landingPageMsg = "No Aborted Transaction were found!";
                this.fromDate = null;
                this.toDate = null;
                this.sResponsiveService.closeSearch();
                this.cAbortedTansResponseProcArr = null;
            }
        }
        this.cAbortedSuccessFull.selectedSI = [];
        this.cAbortedSuccessFull.isSelectActionClick = false;
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.cAbortedSuccessFull.isOrderIDClick = true;
            }
            if (this.cAbortedSuccessFull.isOrderIDClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onPageChange(event) {
        this.cAbortedTranstReq.searchPageSize = event.cPageSize;
        this.cAbortedTranstReq.pageNumber = event.cPageNo;
        this.cAbortedSuccessFull.selectedSI = [];
        this.cAbortedSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
};
AbortedTransactionReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-aborted-transaction-report',
        templateUrl: './aborted-transaction-report.component.html',
        styleUrls: ['./aborted-transaction-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [AbortedTransationService,
        ChangeDetectorRef,
        BsModalService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService,
        TransactionsService])
], AbortedTransactionReportComponent);
export { AbortedTransactionReportComponent };
//# sourceMappingURL=aborted-transaction-report.component.js.map