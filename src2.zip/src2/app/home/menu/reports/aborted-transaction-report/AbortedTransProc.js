export class AbortedTansResponseProc {
}
//# sourceMappingURL=AbortedTransProc.js.map