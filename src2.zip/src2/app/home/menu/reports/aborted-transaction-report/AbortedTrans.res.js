export class AbortedTransRes {
    constructor() {
        this.cAbortedTansResponseProc = [];
    }
}
//# sourceMappingURL=AbortedTrans.res.js.map