import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { AbortedTranstReq } from './AbortedTrans.req';
import { AbortedTransationService } from './aborted-transation-report.service';
let AbortedTransationResolverService = class AbortedTransationResolverService {
    constructor(cAbortedTransationService) {
        this.cAbortedTransationService = cAbortedTransationService;
    }
    resolve(route, state) {
        let mAbortedTranstReq = new AbortedTranstReq();
        return this.cAbortedTransationService.getAllAbortedTransation(mAbortedTranstReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
AbortedTransationResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [AbortedTransationService])
], AbortedTransationResolverService);
export { AbortedTransationResolverService };
//# sourceMappingURL=aborted-transaction-resolver.service.js.map