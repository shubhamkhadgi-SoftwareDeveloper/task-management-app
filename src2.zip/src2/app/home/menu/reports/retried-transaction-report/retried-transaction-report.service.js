import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let RetriedTransactionReportService = class RetriedTransactionReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cRetriedTransactionReportBaseUrl = 'retriedTransactionReport/';
        this.cFetchRetriedTransactionListUrl = this.cRetriedTransactionReportBaseUrl + 'fetchRetriedTransactionList';
        this.cExportRetriedTransactionUrl = this.cRetriedTransactionReportBaseUrl + 'exportRetriedTransaction';
    }
    fetchRetriedTransactionList(pRetriedTransactionReportReq) {
        return this.pApiRequestService.httpPostRequest(pRetriedTransactionReportReq, this.cFetchRetriedTransactionListUrl);
    }
    exportRetriedTransaction(pRetriedTransactionReportReq) {
        return this.pApiRequestService.exportFileRequest(pRetriedTransactionReportReq, this.cExportRetriedTransactionUrl, 'RetriedTransaction.xlsx');
    }
};
RetriedTransactionReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], RetriedTransactionReportService);
export { RetriedTransactionReportService };
//# sourceMappingURL=retried-transaction-report.service.js.map