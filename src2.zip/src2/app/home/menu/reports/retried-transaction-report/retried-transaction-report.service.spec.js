import { TestBed, inject } from '@angular/core/testing';
import { RetriedTransactionReportService } from './retried-transaction-report.service';
describe('RetriedTransactionReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RetriedTransactionReportService]
        });
    });
    it('should be created', inject([RetriedTransactionReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=retried-transaction-report.service.spec.js.map