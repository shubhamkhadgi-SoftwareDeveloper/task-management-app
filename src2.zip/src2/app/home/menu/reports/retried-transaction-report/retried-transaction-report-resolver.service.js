import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { RetriedTransactionReportReq } from './retried-transaction-report-req';
import { RetriedTransactionReportService } from './retried-transaction-report.service';
let RetriedTransactionReportResolverService = class RetriedTransactionReportResolverService {
    constructor(sRetriedTransactionReportService, sRouter) {
        this.sRetriedTransactionReportService = sRetriedTransactionReportService;
        this.sRouter = sRouter;
    }
    resolve(route, state) {
        let mRetriedTransactionReportReq = new RetriedTransactionReportReq();
        return this.sRetriedTransactionReportService.fetchRetriedTransactionList(mRetriedTransactionReportReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
RetriedTransactionReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [RetriedTransactionReportService,
        Router])
], RetriedTransactionReportResolverService);
export { RetriedTransactionReportResolverService };
//# sourceMappingURL=retried-transaction-report-resolver.service.js.map