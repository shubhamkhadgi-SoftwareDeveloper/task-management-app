import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { RetriedTransactionReportProcEntityWrapper } from '../../../../proc-entities/retried-transaction-report-proc-entity-wrapper';
import { RetriedTransactionReport } from './retried-transaction-report.class';
import { RetriedTransactionReportReq } from './retried-transaction-report-req';
import { RetriedTransactionReportService } from './retried-transaction-report.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { TitleService } from './../../../../common-services/title.service';
import { TransactionDetailsReq } from '../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../transactions/transactions/transactions.service';
let RetriedTransactionReportComponent = class RetriedTransactionReportComponent {
    constructor(cdr, sFormBuilder, sActivatedRoute, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sCheck, pMerchInfoService, sErrorHandler, sRetriedTransactionReportService, sTitleService, pTransactionsService) {
        this.cdr = cdr;
        this.sFormBuilder = sFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.sErrorHandler = sErrorHandler;
        this.sRetriedTransactionReportService = sRetriedTransactionReportService;
        this.sTitleService = sTitleService;
        this.pTransactionsService = pTransactionsService;
        this.cSearchFlag = false;
        this.isTransactionDetailClick = false;
        this.cRetriedTransactionReport = new RetriedTransactionReport();
        this.cRetriedTransactionReportReq = new RetriedTransactionReportReq();
        this.cRetriedTransactionReportDetailProcEntityWrapper = new RetriedTransactionReportProcEntityWrapper();
        this.sTitleService.setTitle(this.sTitleService.RetriedTransactionReport);
        this.cTransactionDetailsReq = new TransactionDetailsReq();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.cRetriedTransactionReport.fromToDate = this.cRetriedTransactionReportReq.searchFromDate + ' - ' + this.cRetriedTransactionReportReq.searchToDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cRetriedTransactionReport.totalCount = mCommonResponse.data.totalCount;
                    this.cRetriedTransactionReportProcEntityWrapper = mCommonResponse.data['RetriedTransactionReportList'];
                    this.cRetriedTransactionReport.isAnyRetriedTransaction = true;
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.cRetriedTransactionReport.landingPageMsg = 'No retried transaction found';
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cRetriedTransactionReport.landingPageMsg = 'No retried transaction found';
                this.cRetriedTransactionReport.isAnyRetriedTransaction = false;
            }
        });
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.cSearchForm = this.sFormBuilder.group({
            searchByValue: [''],
            fromToDate: ['', [Validators.required]],
            status: [''],
            searchMerchantArr: [''],
            searchSubAccountIdList: [''],
        });
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cRetriedTransactionReport.isSearchPanelClick = !this.cRetriedTransactionReport.isSearchPanelClick;
    }
    onSearchByClick() {
        this.cRetriedTransactionReport.isSearchByClick = !this.cRetriedTransactionReport.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.cRetriedTransactionReport.isSearchByClick = false;
    }
    onSearchByOptionClick(pOption) {
        this.cRetriedTransactionReport.isSearchByClick = !this.cRetriedTransactionReport.isSearchByClick;
        this.cRetriedTransactionReportReq.searchBy = pOption.value;
        this.cRetriedTransactionReport.searchByLabel = pOption.label;
        this.cRetriedTransactionReportReq.searchByValue = null;
        if (this.cRetriedTransactionReportReq.searchBy == 'searchTrackingId') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRetriedTransactionReportReq.searchBy == 'searchOrderNo') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.letterAndNumberOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            if (this.cSearchFlag) {
                this.cRetriedTransactionReportReq.pageNumber = 1;
            }
            this.sRetriedTransactionReportService.fetchRetriedTransactionList(this.cRetriedTransactionReportReq)
                .subscribe(pResponse => { this.fetchRetriedTransactionListSuccess(pResponse); }, error => { console.log('error'); });
            this.cSearchFlag = true;
        }
        else {
            CustomValidator.validateAllFields(this.cSearchForm);
        }
    }
    onCancelClick() {
        this.cRetriedTransactionReport.searchByLabel = "Search by";
        let pageSize = this.cRetriedTransactionReportReq.pageSize;
        this.cRetriedTransactionReportReq = null;
        this.cRetriedTransactionReportReq = new RetriedTransactionReportReq();
        this.cRetriedTransactionReportReq.pageSize = pageSize;
        this.cRetriedTransactionReport.fromToDate = null;
        this.cRetriedTransactionReport.fromToDate = this.cRetriedTransactionReportReq.searchFromDate + ' - ' + this.cRetriedTransactionReportReq.searchToDate;
        this.cRetriedTransactionReport.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.cSearchForm.controls['searchByValue'].setValue(null);
        this.cSearchForm.controls['searchByValue'].clearValidators();
        this.cSearchForm.controls['searchByValue'].disable();
        this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cRetriedTransactionReport.isSearchPanelClick = false;
        }
        this.onSearchClick();
    }
    onOrderNoClick(pTrackingId) {
        this.cTransactionDetailsReq.trackingId = pTrackingId;
        this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
            .subscribe(pResponse => {
            window.scrollTo(0, 0);
            this.fetchTransactionDetailsSuccess(pResponse);
        }, error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onExportClick() {
        this.cRetriedTransactionReport.isSearchPanelClick = false;
        this.cRetriedTransactionReport.isSearchByClick = false;
        this.cRetriedTransactionReport.isExportClick = !this.cRetriedTransactionReport.isExportClick;
    }
    onExportExcelClick() {
        this.cRetriedTransactionReport.isExportClick = !this.cRetriedTransactionReport.isExportClick;
        this.sRetriedTransactionReportService.exportRetriedTransaction(this.cRetriedTransactionReportReq)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    onBackClick() {
        this.isTransactionDetailClick = true;
        this.sResponsiveService.closeDetails();
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cRetriedTransactionReport.isExportClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cRetriedTransactionReportReq.searchFromDate = value.start.format("DD/MM/YYYY");
        this.cRetriedTransactionReportReq.searchToDate = value.end.format("DD/MM/YYYY");
        this.cRetriedTransactionReport.fromToDate = this.cRetriedTransactionReportReq.searchFromDate + '-' + this.cRetriedTransactionReportReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchRetriedTransactionListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cRetriedTransactionReport.totalCount = mCommonResponse.data.totalCount;
                this.cRetriedTransactionReportProcEntityWrapper = mCommonResponse.data['RetriedTransactionReportList'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cRetriedTransactionReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cRetriedTransactionReport.landingPageMsg = 'No retried transaction found';
                this.onFailFetchRetriedTransactionList(mCommonResponse.messageDesc);
            }
            else {
                this.cRetriedTransactionReport.landingPageMsg = 'No retried transaction found';
                this.onFailFetchRetriedTransactionList(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cRetriedTransactionReport.landingPageMsg = 'No retried transaction found';
            this.onFailFetchRetriedTransactionList(this.sErrorMessagesService.responseNull);
        }
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.isTransactionDetailClick = true;
            }
            if (this.isTransactionDetailClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onFailFetchRetriedTransactionList(pResMsg) {
        console.log(pResMsg);
        this.cRetriedTransactionReport.totalCount = null;
        this.cRetriedTransactionReportProcEntityWrapper = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cRetriedTransactionReport.isSearchPanelClick = false;
        }
    }
    onPageChange(event) {
        this.cRetriedTransactionReportReq.pageSize = event.cPageSize;
        this.cRetriedTransactionReportReq.pageNumber = event.cPageNo;
        this.cSearchFlag = false;
        this.onSearchClick();
    }
};
RetriedTransactionReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-retried-transaction-report',
        templateUrl: './retried-transaction-report.component.html',
        styleUrls: ['./retried-transaction-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        FormBuilder,
        ActivatedRoute,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ConditionalCheckService,
        MerchInfoService,
        ErrorHandlerService,
        RetriedTransactionReportService,
        TitleService,
        TransactionsService])
], RetriedTransactionReportComponent);
export { RetriedTransactionReportComponent };
//# sourceMappingURL=retried-transaction-report.component.js.map