import { TestBed, inject } from '@angular/core/testing';
import { RetriedTransactionReportResolverService } from './retried-transaction-report-resolver.service';
describe('RetriedTransactionReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RetriedTransactionReportResolverService]
        });
    });
    it('should be created', inject([RetriedTransactionReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=retried-transaction-report-resolver.service.spec.js.map