export class RetriedTransactionReport {
    constructor() {
        this.isSearchByClick = false;
        this.searchBy = [];
        this.searchBy.push({ label: 'Search by', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'searchOrderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref. #', value: 'searchTrackingId' });
        this.status = [];
        this.status.push({ label: 'Select', value: '' });
        this.status.push({ label: 'Unsuccessful', value: 'Unsuccessful' });
        this.status.push({ label: 'Cancelled', value: 'Cancelled' });
        this.status.push({ label: 'Aborted', value: 'Aborted' });
        this.status.push({ label: 'Auto-Cancelled', value: 'Auto-Cancelled' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.isAnyRetriedTransaction = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.searchByLabel = "Search by";
        this.fromToDate = '';
    }
}
//# sourceMappingURL=retried-transaction-report.class.js.map