export class RetriedTransactionReportReq {
    constructor() {
        this.pageNumber = 1;
        this.pageSize = 25;
        this.orderExportFlag = false;
        var today = new Date();
        var dd = today.getDate();
        var ddS = today.getDate().toString();
        var mm = today.getMonth() + 1;
        var mmS = mm.toString();
        var yyyy = today.getFullYear();
        if (dd < 10) {
            ddS = '0' + dd;
        }
        if (mm < 10) {
            mmS = '0' + mm;
        }
        var todayDate = ddS + '/' + mmS + '/' + yyyy;
        this.searchFromDate = todayDate;
        this.searchToDate = todayDate;
    }
}
//# sourceMappingURL=retried-transaction-report-req.js.map