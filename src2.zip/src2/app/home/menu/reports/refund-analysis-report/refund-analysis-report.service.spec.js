import { TestBed, inject } from '@angular/core/testing';
import { RefundAnalysisReportService } from './refund-analysis-report.service';
describe('RefundAnalysisReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RefundAnalysisReportService]
        });
    });
    it('should be created', inject([RefundAnalysisReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=refund-analysis-report.service.spec.js.map