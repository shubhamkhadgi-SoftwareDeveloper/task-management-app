import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { RefundAnalysisReport } from './refund-analysis-report.class';
import { RefundAnalysisReportReq } from './refund-analysis-report-req';
import { RefundAnalysisReportService } from './refund-analysis-report.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { TitleService } from './../../../../common-services/title.service';
let RefundAnalysisReportComponent = class RefundAnalysisReportComponent {
    constructor(sFormBuilder, sActivatedRoute, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sCheck, pMerchInfoService, sErrorHandler, sRefundAnalysisReportService, sTitleService) {
        this.sFormBuilder = sFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.sErrorHandler = sErrorHandler;
        this.sRefundAnalysisReportService = sRefundAnalysisReportService;
        this.sTitleService = sTitleService;
        this.cRefundAnalysisReportProcEntity = [];
        this.cRefundAnalysisReport = new RefundAnalysisReport();
        this.cRefundAnalysisReportReq = new RefundAnalysisReportReq();
        //      this.cRefundAnalysisReportProcEntity = new RefundAnalysisReportProcEntity();
        this.sTitleService.setTitle(this.sTitleService.RefundAnalysisReport);
    }
    ngOnInit() {
        this.createForm();
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportReq.searchFromDate + ' - ' + this.cRefundAnalysisReportReq.searchToDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (mCommonResponse.data != null) {
                    this.cRefundAnalysisReportProcEntity = mCommonResponse.data['RefundAnalysisReportList'];
                    this.cRefundAnalysisReportPaymentProcEntity = mCommonResponse.data['RefundAnalysisPaymentReportList'];
                    this.cRefundAnalysisReport.isAnyRefundAnalysisReport = true;
                }
                else {
                    this.onFailFetchRefundAnalysisList(mCommonResponse.messageDesc);
                }
            }
            else {
                this.onFailFetchRefundAnalysisList(mCommonResponse.messageDesc);
            }
        });
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.cSearchForm = this.sFormBuilder.group({
            fromToDate: ['', [Validators.required]],
            searchMerchantIdArr: [''],
            searchSubAccountIdList: [''],
        });
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cRefundAnalysisReport.isSearchPanelClick = !this.cRefundAnalysisReport.isSearchPanelClick;
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            this.sRefundAnalysisReportService.fetchRefundAnalysisReportList(this.cRefundAnalysisReportReq)
                .subscribe(pResponse => { this.fetchRefundAnalysisReportListSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.cSearchForm);
        }
    }
    onCurrencyClick() {
        this.cRefundAnalysisReport.isSearchPanelClick = false;
    }
    onSearchOnCurrencyClick(pEvent) {
        if (pEvent) {
            this.onSearchClick();
        }
    }
    onCancelClick() {
        this.cRefundAnalysisReportReq = null;
        this.cRefundAnalysisReportReq = new RefundAnalysisReportReq();
        this.cRefundAnalysisReport.fromToDate = null;
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportReq.searchFromDate + ' - ' + this.cRefundAnalysisReportReq.searchToDate;
        this.cRefundAnalysisReport.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cRefundAnalysisReport.isSearchPanelClick = false;
        }
        this.onSearchClick();
    }
    onBackClick() {
        this.sResponsiveService.closeDetails();
    }
    onExportClick() {
        this.cRefundAnalysisReport.isSearchPanelClick = false;
        this.cRefundAnalysisReport.isSearchByClick = false;
        this.cRefundAnalysisReport.isExportClick = !this.cRefundAnalysisReport.isExportClick;
    }
    onExportExcelClick() {
        this.cRefundAnalysisReport.isExportClick = !this.cRefundAnalysisReport.isExportClick;
        this.sRefundAnalysisReportService.exportRefundAnalysisReportDetails(this.cRefundAnalysisReportReq)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cRefundAnalysisReport.isExportClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cRefundAnalysisReportReq.searchFromDate = value.start.format("DD/MM/YYYY");
        this.cRefundAnalysisReportReq.searchToDate = value.end.format("DD/MM/YYYY");
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportReq.searchFromDate + '-' + this.cRefundAnalysisReportReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchRefundAnalysisReportListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cRefundAnalysisReportProcEntity = mCommonResponse.data['RefundAnalysisReportList'];
                this.cRefundAnalysisReportPaymentProcEntity = mCommonResponse.data['RefundAnalysisPaymentReportList'];
                this.cRefundAnalysisReport.isAnyRefundAnalysisReport = true;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cRefundAnalysisReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchRefundAnalysisList(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchRefundAnalysisList(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchRefundAnalysisList(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchRefundAnalysisList(pResMsg) {
        this.cRefundAnalysisReport.isAnyRefundAnalysisReport = false;
        this.cRefundAnalysisReport.landingPageMsg = 'No refund analysis report found';
        console.log(pResMsg);
        this.cRefundAnalysisReportProcEntity = null;
        this.cRefundAnalysisReportPaymentProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cRefundAnalysisReport.isSearchPanelClick = false;
        }
    }
};
RefundAnalysisReportComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-refund-analysis-report',
        templateUrl: './refund-analysis-report.component.html',
        styleUrls: ['./refund-analysis-report.component.css'],
    }),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        ActivatedRoute,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ConditionalCheckService,
        MerchInfoService,
        ErrorHandlerService,
        RefundAnalysisReportService,
        TitleService])
], RefundAnalysisReportComponent);
export { RefundAnalysisReportComponent };
//# sourceMappingURL=refund-analysis-report.component.js.map