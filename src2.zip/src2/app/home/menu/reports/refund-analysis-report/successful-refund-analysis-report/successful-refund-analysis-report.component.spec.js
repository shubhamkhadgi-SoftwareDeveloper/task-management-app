import { async, TestBed } from '@angular/core/testing';
import { SuccessfulRefundAnalysisReportComponent } from './successful-refund-analysis-report.component';
describe('SuccessfulRefundAnalysisReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SuccessfulRefundAnalysisReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(SuccessfulRefundAnalysisReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=successful-refund-analysis-report.component.spec.js.map