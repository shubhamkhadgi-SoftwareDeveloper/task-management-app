import { TestBed, inject } from '@angular/core/testing';
import { SuccessfulRefundAnalysisReportResolverService } from './successful-refund-analysis-report-resolver.service';
describe('SuccessfulRefundAnalysisReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SuccessfulRefundAnalysisReportResolverService]
        });
    });
    it('should be created', inject([SuccessfulRefundAnalysisReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=successful-refund-analysis-report-resolver.service.spec.js.map