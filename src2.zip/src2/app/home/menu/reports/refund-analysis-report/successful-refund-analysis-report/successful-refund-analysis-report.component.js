import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from '../../../../../common-services/landing-page-msg.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { RefundAnalysisReport } from '../refund-analysis-report.class';
import { RefundAnalysisReportStatusWiseReq } from '../refund-analysis-report-status-wise-req';
import { RefundAnalysisReportService } from '../refund-analysis-report.service';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { InvoiceSettingsValidator } from '../../../invoice/invoice-settings/invoice-settings-validator';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { TransactionDetailsReq } from '../../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
let SuccessfulRefundAnalysisReportComponent = class SuccessfulRefundAnalysisReportComponent {
    constructor(sFormBuilder, pTransactionsService, cLocation, sActivatedRoute, sAlertMessageService, sErrorMessagesService, sResponsiveService, sCheck, pMerchInfoService, sErrorHandler, sLandingPageMsgService, sRefundAnalysisReportService) {
        this.sFormBuilder = sFormBuilder;
        this.pTransactionsService = pTransactionsService;
        this.cLocation = cLocation;
        this.sActivatedRoute = sActivatedRoute;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.sErrorHandler = sErrorHandler;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sRefundAnalysisReportService = sRefundAnalysisReportService;
        this.orderTax = -1.00;
        this.cRefundAmount = 0.00;
        this.cSearchFlag = false;
        this.isTransactionDetailClick = false;
        this.cRefundAnalysisReport = new RefundAnalysisReport();
        this.cRefundAnalysisReportStatusWiseReq = new RefundAnalysisReportStatusWiseReq();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportStatusWiseReq.searchFromDate + '-' + this.cRefundAnalysisReportStatusWiseReq.searchToDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (mCommonResponse.data != null) {
                    this.cRefundAnalysisReport.totalCount = mCommonResponse.data['totalCount'];
                    this.cRefundAnalysisReportStatusWiseProcEntity = mCommonResponse.data['RefundAnalysisReportStatusWiseList'];
                }
                else {
                    this.cRefundAnalysisReport.landingPageMsg = 'No successful refund analysis report found';
                    this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
                }
            }
            else {
                this.cRefundAnalysisReport.landingPageMsg = 'No successful refund analysis report found';
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
        });
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParam(param));
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.cSearchForm = this.sFormBuilder.group({
            fromToDate: ['', [Validators.required]],
            searchByValue: [''],
        });
    }
    fetchQueryParam(pParam) {
        this.cRefundAnalysisReportStatusWiseReq.regId = this.pMerchInfoService.getRegId().toString();
        this.cRefundAnalysisReportStatusWiseReq.cardTypeDesc = pParam.cardTypeDesc;
        this.cRefundAnalysisReportStatusWiseReq.orderCardName = pParam.orderCardName;
        this.fromDate = this.cRefundAnalysisReportStatusWiseReq.searchFromDate = pParam.frmDate;
        this.toDate = this.cRefundAnalysisReportStatusWiseReq.searchToDate = pParam.toDate;
        this.cRefundAnalysisReportStatusWiseReq.orderCurr = pParam.orderCurr;
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cRefundAnalysisReport.isSearchPanelClick = !this.cRefundAnalysisReport.isSearchPanelClick;
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            if (this.cSearchFlag) {
                this.cRefundAnalysisReportStatusWiseReq.pageNumber = 1;
            }
            this.cRefundAnalysisReportStatusWiseReq.refundFlag = 'S';
            this.sRefundAnalysisReportService.fetchRefundAnalysisStatusWiseList(this.cRefundAnalysisReportStatusWiseReq)
                .subscribe(pResponse => { this.fetchRefundAnalysisReportStatusWiseListSuccess(pResponse); }, error => { console.log('error'); });
            this.cSearchFlag = true;
        }
        else {
            CustomValidator.validateAllFields(this.cSearchForm);
        }
    }
    onCancelClick() {
        this.cRefundAnalysisReport.searchByLabel = "Search by";
        this.cRefundAnalysisReportStatusWiseReq.searchByValue = null;
        this.cRefundAnalysisReportStatusWiseReq.trackingId = null;
        this.cRefundAnalysisReportStatusWiseReq.orderNo = null;
        this.cRefundAnalysisReportStatusWiseReq.orderBillEmail = null;
        this.cRefundAnalysisReportStatusWiseReq.orderBillTel = null;
        this.cRefundAnalysisReportStatusWiseReq.searchFromDate = null;
        this.cRefundAnalysisReportStatusWiseReq.searchToDate = null;
        this.cRefundAnalysisReportStatusWiseReq.searchFromDate = this.fromDate;
        this.cRefundAnalysisReportStatusWiseReq.searchToDate = this.toDate;
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportStatusWiseReq.searchFromDate + '-' + this.cRefundAnalysisReportStatusWiseReq.searchToDate;
        this.cSearchForm.controls['searchByValue'].setValue(null);
        this.cSearchForm.controls['searchByValue'].clearValidators();
        this.cSearchForm.controls['searchByValue'].disable();
        this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        this.onSearchClick();
    }
    onSearchByClick() {
        this.cRefundAnalysisReport.isSearchByClick = !this.cRefundAnalysisReport.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cRefundAnalysisReport.isSearchByClick = !this.cRefundAnalysisReport.isSearchByClick;
        this.cRefundAnalysisReportStatusWiseReq.searchBy = pOption.value;
        this.cRefundAnalysisReport.searchByLabel = pOption.label;
        this.cRefundAnalysisReportStatusWiseReq.searchByValue = null;
        if (this.cRefundAnalysisReportStatusWiseReq.searchBy == 'searchTrackingId') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRefundAnalysisReportStatusWiseReq.searchBy == 'searchOrderNo') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.letterAndNumberOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRefundAnalysisReportStatusWiseReq.searchBy == 'searchEmailId') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.email, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cRefundAnalysisReportStatusWiseReq.searchBy == 'searchMobileNo') {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([InvoiceSettingsValidator.mobile, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onOrderNumberClick(pTrackingId) {
        if (pTrackingId != null) {
            this.cTransactionDetailsReq.trackingId = pTrackingId;
            this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
                .subscribe(pResponse => {
                window.scrollTo(0, 0);
                this.fetchTransactionDetailsSuccess(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    onBackClick() {
        this.cLocation.back();
    }
    onDetailBackClick() {
        this.isTransactionDetailClick = false;
        this.sResponsiveService.closeDetails();
    }
    onExportClick() {
        this.cRefundAnalysisReport.isSearchPanelClick = false;
        this.cRefundAnalysisReport.isSearchByClick = false;
        this.cRefundAnalysisReport.isExportClick = !this.cRefundAnalysisReport.isExportClick;
    }
    onExportExcelClick() {
        this.cRefundAnalysisReportStatusWiseReq.refundFlag = 'S';
        this.cRefundAnalysisReport.isExportClick = !this.cRefundAnalysisReport.isExportClick;
        this.sRefundAnalysisReportService.exportRefundAnalysisDetails(this.cRefundAnalysisReportStatusWiseReq)
            .subscribe(pResponse => { console.log('successfull'); }, error => { console.log('error'); });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cRefundAnalysisReport.isExportClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cRefundAnalysisReportStatusWiseReq.searchFromDate = value.start.format("DD/MM/YYYY");
        this.cRefundAnalysisReportStatusWiseReq.searchToDate = value.end.format("DD/MM/YYYY");
        this.cRefundAnalysisReport.fromToDate = this.cRefundAnalysisReportStatusWiseReq.searchFromDate + '-' + this.cRefundAnalysisReportStatusWiseReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchRefundAnalysisReportStatusWiseListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cRefundAnalysisReport.totalCount = mCommonResponse.data['totalCount'];
                this.cRefundAnalysisReportStatusWiseProcEntity = mCommonResponse.data['RefundAnalysisReportStatusWiseList'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cRefundAnalysisReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.onFailFetchRefundAnalysisList(mCommonResponse.messageDesc);
            }
            else {
                this.onFailFetchRefundAnalysisList(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.onFailFetchRefundAnalysisList(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchRefundAnalysisList(pResMsg) {
        this.cRefundAnalysisReport.landingPageMsg = 'No successful refund analysis report found';
        this.sAlertMessageService.popupAlertMsg(pResMsg);
        this.cRefundAnalysisReport.totalCount = null;
        this.cRefundAnalysisReportStatusWiseProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cRefundAnalysisReport.isSearchPanelClick = false;
        }
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.isTransactionDetailClick = true;
            }
            if (this.isTransactionDetailClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onPageChange(event) {
        this.cRefundAnalysisReportStatusWiseReq.pageSize = event.cPageSize;
        this.cRefundAnalysisReportStatusWiseReq.pageNumber = event.cPageNo;
        this.cSearchFlag = false;
        this.onSearchClick();
    }
};
SuccessfulRefundAnalysisReportComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-successful-refund-analysis-report',
        templateUrl: './successful-refund-analysis-report.component.html',
        styleUrls: ['./successful-refund-analysis-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [FormBuilder,
        TransactionsService,
        Location,
        ActivatedRoute,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        ConditionalCheckService,
        MerchInfoService,
        ErrorHandlerService,
        LandingPageMsgService,
        RefundAnalysisReportService])
], SuccessfulRefundAnalysisReportComponent);
export { SuccessfulRefundAnalysisReportComponent };
//# sourceMappingURL=successful-refund-analysis-report.component.js.map