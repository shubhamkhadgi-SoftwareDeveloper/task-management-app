import { TestBed, inject } from '@angular/core/testing';
import { PendingRefundAnalysisReportResolverService } from './pending-refund-analysis-report-resolver.service';
describe('PendingRefundAnalysisReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PendingRefundAnalysisReportResolverService]
        });
    });
    it('should be created', inject([PendingRefundAnalysisReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=pending-refund-analysis-report-resolver.service.spec.js.map