import { async, TestBed } from '@angular/core/testing';
import { PendingRefundAnalysisReportComponent } from './pending-refund-analysis-report.component';
describe('PendingRefundAnalysisReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PendingRefundAnalysisReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(PendingRefundAnalysisReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=pending-refund-analysis-report.component.spec.js.map