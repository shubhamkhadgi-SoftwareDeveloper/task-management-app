import { async, TestBed } from '@angular/core/testing';
import { InitiatedRefundAnalysisReportComponent } from './initiated-refund-analysis-report.component';
describe('InitiatedRefundAnalysisReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [InitiatedRefundAnalysisReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(InitiatedRefundAnalysisReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=initiated-refund-analysis-report.component.spec.js.map