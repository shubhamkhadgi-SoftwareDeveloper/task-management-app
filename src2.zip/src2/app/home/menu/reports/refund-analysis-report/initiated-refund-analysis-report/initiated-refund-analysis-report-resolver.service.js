import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { RefundAnalysisReportStatusWiseReq } from '../refund-analysis-report-status-wise-req';
import { RefundAnalysisReportService } from '../refund-analysis-report.service';
let InitiatedRefundAnalysisReportResolverService = class InitiatedRefundAnalysisReportResolverService {
    constructor(sRouter, pMerchInfoService, sRefundAnalysisReportService) {
        this.sRouter = sRouter;
        this.pMerchInfoService = pMerchInfoService;
        this.sRefundAnalysisReportService = sRefundAnalysisReportService;
    }
    resolve(route, state) {
        let mRefundAnalysisReportStatusWiseReq = new RefundAnalysisReportStatusWiseReq();
        mRefundAnalysisReportStatusWiseReq.regId = this.pMerchInfoService.getRegId().toString();
        mRefundAnalysisReportStatusWiseReq.cardTypeDesc = route.queryParams.cardTypeDesc;
        mRefundAnalysisReportStatusWiseReq.orderCardName = route.queryParams.orderCardName;
        mRefundAnalysisReportStatusWiseReq.searchFromDate = route.queryParams.frmDate;
        mRefundAnalysisReportStatusWiseReq.searchToDate = route.queryParams.toDate;
        mRefundAnalysisReportStatusWiseReq.orderCurr = route.queryParams.orderCurr;
        mRefundAnalysisReportStatusWiseReq.refundFlag = 'I';
        return this.sRefundAnalysisReportService.fetchRefundAnalysisStatusWiseList(mRefundAnalysisReportStatusWiseReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
InitiatedRefundAnalysisReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router,
        MerchInfoService,
        RefundAnalysisReportService])
], InitiatedRefundAnalysisReportResolverService);
export { InitiatedRefundAnalysisReportResolverService };
//# sourceMappingURL=initiated-refund-analysis-report-resolver.service.js.map