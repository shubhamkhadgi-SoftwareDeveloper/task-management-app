import { TestBed, inject } from '@angular/core/testing';
import { InitiatedRefundAnalysisReportResolverService } from './initiated-refund-analysis-report-resolver.service';
describe('InitiatedRefundAnalysisReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [InitiatedRefundAnalysisReportResolverService]
        });
    });
    it('should be created', inject([InitiatedRefundAnalysisReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=initiated-refund-analysis-report-resolver.service.spec.js.map