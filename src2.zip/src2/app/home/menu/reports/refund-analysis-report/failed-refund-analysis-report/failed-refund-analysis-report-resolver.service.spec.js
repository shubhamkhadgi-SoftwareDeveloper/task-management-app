import { TestBed, inject } from '@angular/core/testing';
import { FailedRefundAnalysisReportResolverService } from './failed-refund-analysis-report-resolver.service';
describe('FailedRefundAnalysisReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [FailedRefundAnalysisReportResolverService]
        });
    });
    it('should be created', inject([FailedRefundAnalysisReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=failed-refund-analysis-report-resolver.service.spec.js.map