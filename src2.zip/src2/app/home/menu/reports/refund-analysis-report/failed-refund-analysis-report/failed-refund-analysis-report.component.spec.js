import { async, TestBed } from '@angular/core/testing';
import { FailedRefundAnalysisReportComponent } from './failed-refund-analysis-report.component';
describe('FailedRefundAnalysisReportComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FailedRefundAnalysisReportComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(FailedRefundAnalysisReportComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=failed-refund-analysis-report.component.spec.js.map