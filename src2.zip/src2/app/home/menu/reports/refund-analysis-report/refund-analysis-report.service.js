import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let RefundAnalysisReportService = class RefundAnalysisReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cRefundAnalysisReportBaseUrl = 'refundAnalysisReport/';
        this.cFetchRefundAnalysisReportListUrl = this.cRefundAnalysisReportBaseUrl + 'fetchRefundAnalysisReportList';
        this.cFetchRefundAnalysisStatusWiseListUrl = this.cRefundAnalysisReportBaseUrl + 'fetchRefundAnalysisStatusWiseList';
        this.cExportRefundAnalysisReportDetailsUrl = this.cRefundAnalysisReportBaseUrl + 'exportRefundAnalysisReportDetails';
        this.cExportRefundAnalysisDetailsUrl = this.cRefundAnalysisReportBaseUrl + 'exportRefundAnalysisDetails';
    }
    fetchRefundAnalysisReportList(pRefundAnalysisReportReq) {
        return this.pApiRequestService.httpPostRequest(pRefundAnalysisReportReq, this.cFetchRefundAnalysisReportListUrl);
    }
    fetchRefundAnalysisStatusWiseList(pRefundAnalysisReportStatusWiseReq) {
        return this.pApiRequestService.httpPostRequest(pRefundAnalysisReportStatusWiseReq, this.cFetchRefundAnalysisStatusWiseListUrl);
    }
    exportRefundAnalysisReportDetails(pRefundAnalysisReportReq) {
        return this.pApiRequestService.exportFileRequest(pRefundAnalysisReportReq, this.cExportRefundAnalysisReportDetailsUrl, 'RefundDetails.xlsx');
    }
    exportRefundAnalysisDetails(pRefundAnalysisReportStatusWiseReq) {
        let refundFlag;
        if (pRefundAnalysisReportStatusWiseReq.refundFlag == 'I') {
            refundFlag = 'InitiatedRefundDetails.xlsx';
        }
        else if (pRefundAnalysisReportStatusWiseReq.refundFlag == 'S') {
            refundFlag = 'SuccessfulRefundDetails.xlsx';
        }
        else if (pRefundAnalysisReportStatusWiseReq.refundFlag == 'P') {
            refundFlag = 'PendingRefundDetails.xlsx';
        }
        else if (pRefundAnalysisReportStatusWiseReq.refundFlag == 'F') {
            refundFlag = 'FailedRefundDetails.xlsx';
        }
        return this.pApiRequestService.exportFileRequest(pRefundAnalysisReportStatusWiseReq, this.cExportRefundAnalysisDetailsUrl, refundFlag);
    }
};
RefundAnalysisReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], RefundAnalysisReportService);
export { RefundAnalysisReportService };
//# sourceMappingURL=refund-analysis-report.service.js.map