import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { RefundAnalysisReportReq } from './refund-analysis-report-req';
import { RefundAnalysisReportService } from './refund-analysis-report.service';
let RefundAnalysisReportResolverService = class RefundAnalysisReportResolverService {
    constructor(sRouter, sRefundAnalysisReportService) {
        this.sRouter = sRouter;
        this.sRefundAnalysisReportService = sRefundAnalysisReportService;
    }
    resolve(route, state) {
        let mRefundAnalysisReportReq = new RefundAnalysisReportReq();
        return this.sRefundAnalysisReportService.fetchRefundAnalysisReportList(mRefundAnalysisReportReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
RefundAnalysisReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router,
        RefundAnalysisReportService])
], RefundAnalysisReportResolverService);
export { RefundAnalysisReportResolverService };
//# sourceMappingURL=refund-analysis-report-resolver.service.js.map