import { TestBed, inject } from '@angular/core/testing';
import { RefundAnalysisReportResolverService } from './refund-analysis-report-resolver.service';
describe('RefundAnalysisReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [RefundAnalysisReportResolverService]
        });
    });
    it('should be created', inject([RefundAnalysisReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=refund-analysis-report-resolver.service.spec.js.map