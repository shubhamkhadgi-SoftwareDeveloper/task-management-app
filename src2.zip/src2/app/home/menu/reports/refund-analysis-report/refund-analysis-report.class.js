export class RefundAnalysisReport {
    constructor() {
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.isAnyRefundAnalysisReport = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.fromToDate = '';
        this.searchByLabel = "Search by";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search by', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'searchOrderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref. #', value: 'searchTrackingId' });
        this.searchBy.push({ label: 'Email ID', value: 'searchEmailId' });
        this.searchBy.push({ label: 'Phone #', value: 'searchMobileNo' });
    }
}
//# sourceMappingURL=refund-analysis-report.class.js.map