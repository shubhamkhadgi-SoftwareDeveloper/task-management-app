export class SalesReportByPaymentTypeReq {
    constructor() {
        var today = new Date();
        var dd = today.getDate();
        var ddS = today.getDate().toString();
        var mm = today.getMonth() + 1;
        var mmS = mm.toString();
        var yyyy = today.getFullYear();
        if (dd < 10) {
            ddS = '0' + dd;
        }
        if (mm < 10) {
            mmS = '0' + mm;
        }
        var todayDate = ddS + '/' + mmS + '/' + yyyy;
        var makeDate = new Date(today);
        this.searchToDate = todayDate;
        today.setMonth(makeDate.getMonth() - 1);
        var dd1 = today.getDate();
        var ddS1 = today.getDate().toString();
        var mm1 = today.getMonth() + 1;
        var mmS1 = mm1.toString();
        var yyyy1 = today.getFullYear();
        if (dd1 < 10) {
            ddS1 = '0' + dd1;
        }
        if (mm1 < 10) {
            mmS1 = '0' + mm1;
        }
        var todayDate1 = ddS1 + '/' + mmS1 + '/' + yyyy1;
        this.searchFromDate = todayDate1;
    }
}
//# sourceMappingURL=sales-report-by-payment-type-req.js.map