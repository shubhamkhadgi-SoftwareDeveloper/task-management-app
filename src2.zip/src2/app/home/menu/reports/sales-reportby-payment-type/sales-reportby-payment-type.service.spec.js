import { TestBed, inject } from '@angular/core/testing';
import { SalesReportbyPaymentTypeService } from './sales-reportby-payment-type.service';
describe('SalesReportbyPaymentTypeService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SalesReportbyPaymentTypeService]
        });
    });
    it('should be created', inject([SalesReportbyPaymentTypeService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=sales-reportby-payment-type.service.spec.js.map