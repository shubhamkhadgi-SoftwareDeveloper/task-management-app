import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { SalesReportByPaymentTypeProcEntity } from '../../../../proc-entities/sales-report-by-payment-type-proc-entity';
import { SalesReportByPaymentTypeReq } from './sales-report-by-payment-type-req';
import { SalesReportbyPaymentTypeService } from './sales-reportby-payment-type.service';
import { SalesReportByPaymentType } from './sales-report-by-payment-type.class';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { TitleService } from './../../../../common-services/title.service';
let SalesReportbyPaymentTypeComponent = class SalesReportbyPaymentTypeComponent {
    //public chartDonutOptions:any;
    constructor(cdr, sFormBuilder, sActivatedRoute, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sCheck, pMerchInfoService, sErrorHandler, sSalesReportbyPaymentTypeService, sTitleService) {
        this.cdr = cdr;
        this.sFormBuilder = sFormBuilder;
        this.sActivatedRoute = sActivatedRoute;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sCheck = sCheck;
        this.pMerchInfoService = pMerchInfoService;
        this.sErrorHandler = sErrorHandler;
        this.sSalesReportbyPaymentTypeService = sSalesReportbyPaymentTypeService;
        this.sTitleService = sTitleService;
        this.cPaymentName = null;
        this.cCurrency = null;
        this.cMonthYear = null;
        this.chartAreaData = [];
        this.chartDonutOptions = { formatter: function (y, data) {
                return y + '%';
            }, resize: true,
        };
        this.cSalesReportByPaymentType = new SalesReportByPaymentType();
        this.cSalesReportByPaymentTypeReq = new SalesReportByPaymentTypeReq();
        this.cSalesByPayTypeList = new Map;
        this.cSalesReportByPaymentTypeDetail = new SalesReportByPaymentTypeProcEntity();
        this.sTitleService.setTitle(this.sTitleService.SalesReportbyPaymentType);
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.createForm();
        this.cSalesReportByPaymentType.fromToDate = this.cSalesReportByPaymentTypeReq.searchFromDate + ' - ' + this.cSalesReportByPaymentTypeReq.searchToDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cSalesByPayTypeList = mCommonResponse.data['SalesReportByPaymentTypeList'];
                    this.cSalesReportByPaymentType.isAnySalesReportByPayType = true;
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
                this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                this.cSalesReportByPaymentType.isAnySalesReportByPayType = false;
            }
        });
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.cSearchForm = this.sFormBuilder.group({
            fromToDate: ['', [Validators.required]],
            orderCurrency: [''],
            searchMerchantIdArr: [''],
            searchSubAccountIdList: [''],
        });
    }
    //***********************************************Button Click Event*******************************************//
    onSearchPanelClick() {
        this.cSalesReportByPaymentType.isSearchPanelClick = !this.cSalesReportByPaymentType.isSearchPanelClick;
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            this.sSalesReportbyPaymentTypeService.fetchSalesReportByPayTypeList(this.cSalesReportByPaymentTypeReq)
                .subscribe(pResponse => { this.fetchSalesReportByPayTypeListSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            CustomValidator.validateAllFields(this.cSearchForm);
        }
    }
    onCancelClick() {
        this.cSalesReportByPaymentTypeReq = null;
        this.cSalesReportByPaymentTypeReq = new SalesReportByPaymentTypeReq();
        this.cSalesReportByPaymentType.fromToDate = null;
        this.cSalesReportByPaymentType.fromToDate = this.cSalesReportByPaymentTypeReq.searchFromDate + ' - ' + this.cSalesReportByPaymentTypeReq.searchToDate;
        this.cSalesReportByPaymentType.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            dateLimit: {
                days: 30
            },
            maxDate: new Date(),
        };
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSalesReportByPaymentType.isSearchPanelClick = false;
        }
        this.onSearchClick();
    }
    onPaymentTypeClick(paymentName, currency, monthYear) {
        this.cPaymentName = paymentName;
        this.cCurrency = currency;
        this.cMonthYear = monthYear;
        Object.keys(this.cSalesByPayTypeList).forEach(key => {
            for (let obj of this.cSalesByPayTypeList[key]) {
                if (obj.currency == this.cCurrency && obj.paymentName == this.cPaymentName && obj.monthYear == this.cMonthYear) {
                    this.cSalesReportByPaymentTypeDetail = obj;
                    this.pieChartCalculation(this.cSalesReportByPaymentTypeDetail);
                    this.sResponsiveService.openDetails();
                }
            }
        });
    }
    onBackClick() {
        this.sResponsiveService.closeDetails();
    }
    //***********************************************Pie Chart*******************************************//
    pieChartCalculation(pSalesReportByPaymentTypeProcEntity) {
        let totalAmount = 0;
        totalAmount = (pSalesReportByPaymentTypeProcEntity.salesAmount + pSalesReportByPaymentTypeProcEntity.refundAmount + pSalesReportByPaymentTypeProcEntity.chargebackAmount);
        var i = 0;
        this.chartAreaData = [];
        if (this.sCheck.isNotNullNumber(pSalesReportByPaymentTypeProcEntity.salesAmount)) {
            this.chartAreaData[i++] = { label: 'Sales', value: (pSalesReportByPaymentTypeProcEntity.salesAmount / totalAmount * 100).toFixed(2), color: "#64d691" };
        }
        if (this.sCheck.isNotNullNumber(pSalesReportByPaymentTypeProcEntity.refundAmount)) {
            this.chartAreaData[i++] = { label: 'Refund', value: (pSalesReportByPaymentTypeProcEntity.refundAmount / totalAmount * 100).toFixed(2), color: "#526382" };
        }
        if (pSalesReportByPaymentTypeProcEntity.chargebackAmount != 0) {
            this.chartAreaData[i++] = { label: 'Chargeback', value: (pSalesReportByPaymentTypeProcEntity.chargebackAmount / totalAmount * 100).toFixed(2), color: "#6495ED" };
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cSalesReportByPaymentTypeReq.searchFromDate = value.start.format("DD/MM/YYYY");
        this.cSalesReportByPaymentTypeReq.searchToDate = value.end.format("DD/MM/YYYY");
        this.cSalesReportByPaymentType.fromToDate = this.cSalesReportByPaymentTypeReq.searchFromDate + '-' + this.cSalesReportByPaymentTypeReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchSalesReportByPayTypeListSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cSalesByPayTypeList = mCommonResponse.data['SalesReportByPaymentTypeList'];
                this.cSalesReportByPaymentType.isAnySalesReportByPayType = true;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cSalesReportByPaymentType.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                this.onFailFetchSalesReportByPayTypeList(mCommonResponse.messageDesc);
            }
            else {
                this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                this.onFailFetchSalesReportByPayTypeList(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
            this.onFailFetchSalesReportByPayTypeList(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchSalesReportByPayTypeList(pResMsg) {
        console.log(pResMsg);
        this.cSalesReportByPaymentTypeProcEntity = null;
        this.cSalesReportByPaymentType.isAnySalesReportByPayType = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSalesReportByPaymentType.isSearchPanelClick = false;
        }
    }
    fetchSalesReportByPayTypeDetailSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cSalesReportByPaymentTypeDetail = mCommonResponse.data['SalesReportByPaymentTypeList'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cSalesReportByPaymentType.isSearchPanelClick = false;
                }
                this.pieChartCalculation(this.cSalesReportByPaymentTypeDetail);
            }
            else if (mCommonResponse.isFail) {
                this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                this.onFailFetchSalesReportByPayTypeDetail(mCommonResponse.messageDesc);
            }
            else {
                this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
                this.onFailFetchSalesReportByPayTypeDetail(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cSalesReportByPaymentType.landingPageMsg = 'No sales report by payment type found';
            this.onFailFetchSalesReportByPayTypeDetail(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchSalesReportByPayTypeDetail(pResMsg) {
        console.log(pResMsg);
        this.cSalesReportByPaymentTypeProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSalesReportByPaymentType.isSearchPanelClick = false;
        }
    }
};
SalesReportbyPaymentTypeComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-sales-reportby-payment-type',
        templateUrl: './sales-reportby-payment-type.component.html',
        styleUrls: ['./sales-reportby-payment-type.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        FormBuilder,
        ActivatedRoute,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ConditionalCheckService,
        MerchInfoService,
        ErrorHandlerService,
        SalesReportbyPaymentTypeService,
        TitleService])
], SalesReportbyPaymentTypeComponent);
export { SalesReportbyPaymentTypeComponent };
//# sourceMappingURL=sales-reportby-payment-type.component.js.map