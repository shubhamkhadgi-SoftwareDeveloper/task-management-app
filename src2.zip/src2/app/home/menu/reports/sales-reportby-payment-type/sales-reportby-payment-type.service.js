import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let SalesReportbyPaymentTypeService = class SalesReportbyPaymentTypeService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cSalesReportbyPaymentTypeBaseUrl = 'salesReportbyPaymentType/';
        this.cFetchSalesReportByPayTypeListUrl = this.cSalesReportbyPaymentTypeBaseUrl + 'fetchSalesReportByPayTypeList';
    }
    fetchSalesReportByPayTypeList(pSalesReportByPaymentTypeReq) {
        return this.pApiRequestService.httpPostRequest(pSalesReportByPaymentTypeReq, this.cFetchSalesReportByPayTypeListUrl);
    }
};
SalesReportbyPaymentTypeService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], SalesReportbyPaymentTypeService);
export { SalesReportbyPaymentTypeService };
//# sourceMappingURL=sales-reportby-payment-type.service.js.map