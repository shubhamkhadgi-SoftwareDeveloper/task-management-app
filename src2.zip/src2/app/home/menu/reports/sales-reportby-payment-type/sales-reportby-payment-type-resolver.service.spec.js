import { TestBed, inject } from '@angular/core/testing';
import { SalesReportbyPaymentTypeResolverService } from './sales-reportby-payment-type-resolver.service';
describe('SalesReportbyPaymentTypeResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SalesReportbyPaymentTypeResolverService]
        });
    });
    it('should be created', inject([SalesReportbyPaymentTypeResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=sales-reportby-payment-type-resolver.service.spec.js.map