import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SalesReportByPaymentTypeReq } from './sales-report-by-payment-type-req';
import { SalesReportbyPaymentTypeService } from './sales-reportby-payment-type.service';
let SalesReportbyPaymentTypeResolverService = class SalesReportbyPaymentTypeResolverService {
    constructor(sRouter, sSalesReportbyPaymentTypeService) {
        this.sRouter = sRouter;
        this.sSalesReportbyPaymentTypeService = sSalesReportbyPaymentTypeService;
    }
    resolve(route, state) {
        let mSalesReportByPaymentTypeReq = new SalesReportByPaymentTypeReq();
        return this.sSalesReportbyPaymentTypeService.fetchSalesReportByPayTypeList(mSalesReportByPaymentTypeReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
SalesReportbyPaymentTypeResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router,
        SalesReportbyPaymentTypeService])
], SalesReportbyPaymentTypeResolverService);
export { SalesReportbyPaymentTypeResolverService };
//# sourceMappingURL=sales-reportby-payment-type-resolver.service.js.map