export class SalesReportByPaymentType {
    constructor() {
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD/MM/YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            dateLimit: {
                days: 30
            },
            maxDate: new Date(),
        };
        this.isSearchPanelClick = false;
        this.isAnySalesReportByPayType = false;
        this.fromToDate = '';
    }
}
//# sourceMappingURL=sales-report-by-payment-type.class.js.map