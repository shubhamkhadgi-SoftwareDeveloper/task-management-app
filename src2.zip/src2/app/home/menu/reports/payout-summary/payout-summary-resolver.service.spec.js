import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryResolverService } from './payout-summary-resolver.service';
describe('PayoutSummaryResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryResolverService]
        });
    });
    it('should be created', inject([PayoutSummaryResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-resolver.service.spec.js.map