import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { PayoutSummary } from './payout-summary';
import { PayoutSummaryReq } from './payout-summary-req';
import { PayoutSummaryService } from './payout-summary.service';
let PayoutSummaryResolverService = class PayoutSummaryResolverService {
    constructor(pDatePipe, cPayoutSummaryService) {
        this.pDatePipe = pDatePipe;
        this.cPayoutSummaryService = cPayoutSummaryService;
        this.toPayDate = '';
        this.fromPayDate = '';
        this.cPayoutSummary = new PayoutSummary();
    }
    resolve(route, state) {
        let mPayoutSummaryReq = new PayoutSummaryReq();
        mPayoutSummaryReq.tdPayoutId = route.queryParams.tdPayoutId;
        if (mPayoutSummaryReq.tdPayoutId == null || mPayoutSummaryReq.tdPayoutId == 0) {
            this.datebefore = new Date();
            this.datebefore.setDate(this.datebefore.getDate() - 14);
            this.toPayDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.fromPayDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
            this.cPayoutSummary.fromToDate = this.toPayDate + '-' + this.fromPayDate;
        }
        mPayoutSummaryReq.vActivity = '';
        return this.cPayoutSummaryService.fetchPayoutSummary(mPayoutSummaryReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PayoutSummaryResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DatePipe,
        PayoutSummaryService])
], PayoutSummaryResolverService);
export { PayoutSummaryResolverService };
//# sourceMappingURL=payout-summary-resolver.service.js.map