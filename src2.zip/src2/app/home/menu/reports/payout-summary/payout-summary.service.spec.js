import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryService } from './payout-summary.service';
describe('PayoutSummaryService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryService]
        });
    });
    it('should be created', inject([PayoutSummaryService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary.service.spec.js.map