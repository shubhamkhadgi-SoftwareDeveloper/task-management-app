import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { PayoutSummaryReq } from './../payout-summary-req';
import { PayoutSummaryChargebackService } from './payout-summary-chargeback.service';
let PayoutSummaryChargebackResolverService = class PayoutSummaryChargebackResolverService {
    constructor(cPayoutSummaryChargebackService) {
        this.cPayoutSummaryChargebackService = cPayoutSummaryChargebackService;
    }
    resolve(route, state) {
        let mPayoutSummaryReq = new PayoutSummaryReq();
        mPayoutSummaryReq.tdPayoutId = route.queryParams.tdPayoutId;
        mPayoutSummaryReq.orderStatus = 'Chargeback';
        return this.cPayoutSummaryChargebackService.fetchSalesOrRefundOrChargebackDetails(mPayoutSummaryReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PayoutSummaryChargebackResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [PayoutSummaryChargebackService])
], PayoutSummaryChargebackResolverService);
export { PayoutSummaryChargebackResolverService };
//# sourceMappingURL=payout-summary-chargeback-resolver.service.js.map