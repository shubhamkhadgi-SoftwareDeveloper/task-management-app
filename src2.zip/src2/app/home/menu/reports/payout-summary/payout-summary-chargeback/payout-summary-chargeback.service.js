import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from './../../../../../common-services/api-request.service';
let PayoutSummaryChargebackService = class PayoutSummaryChargebackService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'payoutSummary/';
        this.cfetchSalesOrRefundOrChargebackDetailsUrl = this.cBaseUrl + 'fetchSalesOrRefundOrChargebackDetails';
        this.cexportPayoutSummaryOnConditionUrl = this.cBaseUrl + 'exportPayoutSummaryOnCondition';
        this.cFetchRefundDetailsListUrl = this.cBaseUrl + 'fetchRefundDetailsList';
    }
    fetchSalesOrRefundOrChargebackDetails(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cfetchSalesOrRefundOrChargebackDetailsUrl);
    }
    exportPayoutSummaryOnCondition(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutSummaryOnConditionUrl, "PayoutChargebackSummary.xlsx");
    }
    fetchRefundDetailsList(pPayoutSummaryChargeBackReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryChargeBackReq, this.cFetchRefundDetailsListUrl);
    }
};
PayoutSummaryChargebackService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], PayoutSummaryChargebackService);
export { PayoutSummaryChargebackService };
//# sourceMappingURL=payout-summary-chargeback.service.js.map