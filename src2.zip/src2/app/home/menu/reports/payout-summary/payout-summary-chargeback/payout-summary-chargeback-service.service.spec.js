import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryChargebackService } from './payout-summary-chargeback.service';
describe('PayoutSummaryChargebackServiceService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryChargebackService]
        });
    });
    it('should be created', inject([PayoutSummaryChargebackService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-chargeback-service.service.spec.js.map