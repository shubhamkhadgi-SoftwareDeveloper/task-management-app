import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { PayoutSummary } from '../payout-summary-sales/payout-summary';
import { PayoutSummaryReq } from '../payout-summary-sales/payout-summary-req';
import { PayoutSummaryChargebackService } from './payout-summary-chargeback.service';
import { PayoutSalesRefundChargebackProcEntity } from '../../../../../proc-entities/payout-sales-refund-chargeback-proc-entity';
import { PayoutSummaryWithBankProcEntity } from '../../../../../proc-entities/payout-summary-with-bank-proc-entity';
import { TransactionDetailsReq } from '../../../transactions/transactions/transactionDetails.req';
import { TransactionWrapperRes } from '../../../transactions/transactions/transactionWrapper.res';
import { TransactionDetailsProcEntity } from '../../../../../proc-entities/transaction-details-proc-entity';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
import * as $ from 'jquery';
let PayoutSummaryChargebackComponent = class PayoutSummaryChargebackComponent {
    constructor(cdr, pFormBuilder, sErrorHandler, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sPayoutSummaryChargebackService, sActivatedRoute, sTransactionsService) {
        this.cdr = cdr;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sPayoutSummaryChargebackService = sPayoutSummaryChargebackService;
        this.sActivatedRoute = sActivatedRoute;
        this.sTransactionsService = sTransactionsService;
        this.landingPageMsg = null;
        this.cPayoutSalesRefundChargebackProcEntity = [];
        this.refundAmt = 0;
        this.cTotalAmtRefunded = 0.00;
        this.cardNumber = null;
        this.cardBin = null;
        this.cardType = null;
        this.cRefundDetailsProcEntity = [];
        this.cPayoutSummaryCharge = new PayoutSummary();
        this.cPayoutSummaryChargeReq = new PayoutSummaryReq();
        this.cPayoutSummaryWithBankProcEntity = new PayoutSummaryWithBankProcEntity();
        this.cPayouChargebackDetail = new PayoutSalesRefundChargebackProcEntity();
        this.cTransactionDetail = new TransactionWrapperRes();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
        this.cTransactionDetailsProcEntity = new TransactionDetailsProcEntity();
    }
    ngOnInit() {
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParamField(param));
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cPayoutSummaryCharge.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data.PayoutSalesRefundCharge;
                    this.cPayoutSummaryWithBankProcEntity = mCommonResponse.data.PayoutSummaryList[0];
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
            }
        });
        window.scrollTo(0, 0);
    }
    fetchQueryParamField(param) {
        if (this.sCheck.isNotNullString(param.tdPayoutId)) {
            this.payId = param.tdPayoutId;
        }
    }
    onExportClick() {
        this.cPayoutSummaryCharge.isSearchPanelClick = false;
        this.cPayoutSummaryCharge.isExportClick = !this.cPayoutSummaryCharge.isExportClick;
    }
    onExportExcelClick() {
        this.cPayoutSummaryChargeReq.orderStatus = 'chargeback';
        this.cPayoutSummaryChargeReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
        this.cPayoutSummaryCharge.isExportClick = !this.cPayoutSummaryCharge.isExportClick;
        this.sPayoutSummaryChargebackService.exportPayoutSummaryOnCondition(this.cPayoutSummaryChargeReq)
            .subscribe(pResponse => {
        }, error => { console.log('error'); });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cPayoutSummaryCharge.isExportClick = false;
    }
    //***********************************************Button Click Event*******************************************//
    onPreviousClick() {
        if (this.cPayoutSummaryCharge.activeColumn[0] != 0) {
            this.cPayoutSummaryCharge.activeColumn.splice(this.cPayoutSummaryCharge.activeColumn.length - 1, 1);
            this.cPayoutSummaryCharge.activeColumn.splice(0, 0, this.cPayoutSummaryCharge.activeColumn[0] - 1);
        }
    }
    onNextClick() {
        if (this.cPayoutSummaryCharge.activeColumn[this.cPayoutSummaryCharge.activeColumn.length - 1] < 9) {
            this.cPayoutSummaryCharge.activeColumn.push(this.cPayoutSummaryCharge.activeColumn[this.cPayoutSummaryCharge.activeColumn.length - 1] + 1);
            this.cPayoutSummaryCharge.activeColumn.splice(0, 1);
        }
    }
    onSearchPanelClick() {
        this.cPayoutSummaryCharge.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cPayoutSummaryCharge.isSearchPanelClick = !this.cPayoutSummaryCharge.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummaryCharge.searchByLabel = "Search by";
            this.cPayoutSummaryCharge.isSearchPanelClick = false;
            this.cPayoutSummaryChargeReq.searchBy = null;
            this.cPayoutSummaryCharge.fromToDate = null;
            this.cPayoutSummaryChargeReq.searchFromDate = null;
            this.cPayoutSummaryChargeReq.searchToDate = null;
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
            this.cSearchForm.controls['fromToDate'].clearValidators();
            this.cSearchForm.controls['fromToDate'].updateValueAndValidity();
            this.onSearchClick();
        }
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            this.cPayoutSummaryChargeReq.orderStatus = 'Chargeback';
            this.cPayoutSummaryChargeReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
            this.sPayoutSummaryChargebackService.fetchSalesOrRefundOrChargebackDetails(this.cPayoutSummaryChargeReq)
                .subscribe(pResponse => { this.fetchPayoutChargebackSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.cSearchForm);
        }
    }
    onSearchByOptionClick(pOption) {
        this.cPayoutSummaryCharge.isSearchByClick = !this.cPayoutSummaryCharge.isSearchByClick;
        this.cPayoutSummaryChargeReq.searchBy = pOption.value;
        this.cPayoutSummaryCharge.searchByLabel = pOption.label;
        this.cPayoutSummaryChargeReq.searchByValue = null;
        if (this.cPayoutSummaryChargeReq.searchBy == 'trackingId') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cPayoutSummaryChargeReq.searchBy == 'orderNo') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.cPayoutSummaryCharge.isSearchByClick = !this.cPayoutSummaryCharge.isSearchByClick;
    }
    onChargeDetailClick(index) {
        this.sResponsiveService.openDetails();
        this.cPayouChargebackDetail = this.cPayoutSalesRefundChargebackProcEntity[index];
        this.cTransactionDetailsReq.trackingId = this.cPayouChargebackDetail.trackingId;
        this.sTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
            .subscribe(pResponse => this.fetchTransactionDetailsSuccess(pResponse, this.cPayouChargebackDetail.trackingId), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchTransactionDetailsSuccess(pResponse, trackingId) {
        window.scrollTo(0, 0);
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (pResponse.code === 0 && pResponse.message == 'Success') {
                this.cTransactionDetail = pResponse.data;
                this.cPayoutSummaryChargeReq.trackingId = trackingId;
                this.cRefundDetailsProcEntity = this.cTransactionDetail.refundDetailList;
                this.cTotalAmtRefunded = 0.00;
                if (this.sCheck.isNotNullList(this.cRefundDetailsProcEntity))
                    for (var i = 0; i < this.cRefundDetailsProcEntity.length; i++) {
                        this.cTotalAmtRefunded += this.cRefundDetailsProcEntity[i].refundAmt;
                    }
                this.cRefundDetailsProcEntity = this.cTransactionDetail.refundDetailList;
                this.cTotalAmtRefunded = 0.00;
                if (this.sCheck.isNotNullList(this.cRefundDetailsProcEntity))
                    for (var i = 0; i < this.cRefundDetailsProcEntity.length; i++) {
                        this.cTotalAmtRefunded += this.cRefundDetailsProcEntity[i].refundAmt;
                    }
                this.cTransactionDetailsProcEntity = this.cTransactionDetail['transactionDetailsProcEntity'].transactionDetailsProcEntity;
                this.cardNumber = this.cTransactionDetail['transactionDetailsProcEntity'].cardNumber;
                if (this.cTransactionDetailsProcEntity.orderBinCountry == "INDIA") {
                    this.cardBin = "Domestic";
                }
                else if (this.cTransactionDetailsProcEntity.orderBinCountry == null) {
                    this.cardBin = null;
                }
                else {
                    this.cardBin = "International";
                }
                this.cardType = null;
                if (this.cTransactionDetailsProcEntity.orderCardType == "CRDC") {
                    this.cardType = "Credit Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTCASHC") {
                    this.cardType = "Cash Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTDBCRD") {
                    this.cardType = "Debit Card";
                }
                if (this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount != null) {
                    this.refundAmt = this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount;
                }
                else {
                    this.refundAmt = 0;
                }
            }
        }
    }
    onBackClick() {
        localStorage.setItem("payId", this.payId);
        this.pLocation.back();
        this.sResponsiveService.closeDetails();
        this.cPayoutSummaryCharge.isBackClick = false;
    }
    onChargeBackClick() {
        this.sResponsiveService.closeDetails();
        this.cPayoutSummaryCharge.isBackClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cPayoutSummaryChargeReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummaryCharge.fromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummaryCharge.toDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummaryChargeReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummaryCharge.fromToDate = this.cPayoutSummaryCharge.fromDate + '-' + this.cPayoutSummaryCharge.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    onPageChange(event) {
        this.cPayoutSummaryChargeReq.searchPageSize = event.cPageSize;
        this.cPayoutSummaryChargeReq.searchPageNo = event.cPageNo;
        this.onSearchClick();
    }
    fetchPayoutChargebackSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPayoutSummaryCharge.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data['PayoutSalesRefundCharge'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cPayoutSummaryCharge.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.cPayoutSalesRefundChargebackProcEntity = null;
                this.landingPageMsg = 'No payout found ';
                this.onFailFetchPayoutCharge(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No payout found  ';
                this.cPayoutSalesRefundChargebackProcEntity = null;
                this.onFailFetchPayoutCharge(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.cPayoutSalesRefundChargebackProcEntity = null;
            this.landingPageMsg = 'No payout found ';
            this.onFailFetchPayoutCharge(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchPayoutCharge(pResMsg) {
        console.log(pResMsg);
        this.cPayoutSummaryCharge.pageTotalCount = null;
        this.cPayoutSalesRefundChargebackProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummaryCharge.isSearchPanelClick = false;
        }
    }
    //*****************************Validations********************************//
    createForm() {
        this.cSearchForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    scrollRefund() {
        let el = $('.RefundedDtl');
        $('html,body').animate({ scrollTop: (el.offset().top - 10) });
    }
};
PayoutSummaryChargebackComponent = tslib_1.__decorate([
    Component({
        selector: 'app-payout-summary-chargeback',
        templateUrl: './payout-summary-chargeback.component.html',
        styleUrls: ['./payout-summary-chargeback.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        FormBuilder,
        ErrorHandlerService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        PayoutSummaryChargebackService,
        ActivatedRoute,
        TransactionsService])
], PayoutSummaryChargebackComponent);
export { PayoutSummaryChargebackComponent };
//# sourceMappingURL=payout-summary-chargeback.component.js.map