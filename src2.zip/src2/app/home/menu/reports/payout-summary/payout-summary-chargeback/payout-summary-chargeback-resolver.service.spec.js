import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryChargebackResolverService } from './payout-summary-chargeback-resolver.service';
describe('PayoutSummaryChargebackResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryChargebackResolverService]
        });
    });
    it('should be created', inject([PayoutSummaryChargebackResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-chargeback-resolver.service.spec.js.map