import { async, TestBed } from '@angular/core/testing';
import { PayoutSummaryChargebackComponent } from './payout-summary-chargeback.component';
describe('PayoutSummaryChargebackComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PayoutSummaryChargebackComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(PayoutSummaryChargebackComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=payout-summary-chargeback.component.spec.js.map