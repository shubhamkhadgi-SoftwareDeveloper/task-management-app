export class PayoutSummary {
    constructor() {
        this.isSingleOrderIDClick = false;
        this.isSearchPanelClick = false;
        this.isNoRecordAfterSearch = true;
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.isTransExportClick = false;
        this.isSummaryExportClick = false;
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.isBackClick = false;
        this.closeButton = false;
        //public isRecurringPayCreated: boolean = false;
        this.isSearchFound = false;
        //TO DO
        this.isAllPayoutIdCheck = false;
        this.selectedPayoutIds = [];
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            dateLimit: {
                days: 14
            },
            maxDate: new Date(),
        };
        this.status.push({ label: 'Active', value: 'ACTI' });
        this.status.push({ label: 'Inactive', value: 'INAC' });
        this.status.push({ label: 'Expired', value: 'EXPD' });
        this.status.push({ label: 'Cancelled', value: 'CANC' });
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref. #', value: 'trackingId' });
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
        this.activeColumn = [0, 1, 2, 3, 4, 5, 6];
        this.constColumn = 0;
    }
}
//# sourceMappingURL=payout-summary.js.map