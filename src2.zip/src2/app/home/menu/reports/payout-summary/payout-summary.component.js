import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { Location } from '@angular/common';
import { ApiRequestService } from '../../../../common-services/api-request.service';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { PayoutSummaryReq } from './payout-summary-req';
import { PayoutSummaryDetailsProcEntity } from '../../../../proc-entities/payout-summary-details-proc-entity';
import { PayoutSummaryWithBankProcEntity } from '../../../../proc-entities/payout-summary-with-bank-proc-entity';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { PayoutSummary } from './payout-summary';
import { PayoutSummaryService } from './payout-summary.service';
import { TitleService } from './../../../../common-services/title.service';
let PayoutSummaryComponent = class PayoutSummaryComponent {
    constructor(cdr, pDatePipe, pModalService, pApiRequestService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPayoutSummaryService, pFormBuilder, sErrorHandler, sTitleService) {
        this.cdr = cdr;
        this.pDatePipe = pDatePipe;
        this.pModalService = pModalService;
        this.pApiRequestService = pApiRequestService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPayoutSummaryService = sPayoutSummaryService;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.sTitleService = sTitleService;
        this.cPayoutSummaryProcEntity = [];
        this.landingPageMsg = null;
        this.toPayDate = '';
        this.fromPayDate = '';
        this.cPayoutSummaryReq = new PayoutSummaryReq();
        this.cPayoutSummary = new PayoutSummary();
        this.cPayoutSummaryDetailsProcEntity = new PayoutSummaryDetailsProcEntity();
        this.cPayoutSummaryWithBankProcEntity = new PayoutSummaryWithBankProcEntity();
        this.sTitleService.setTitle(this.sTitleService.PayoutSummary);
    }
    ngOnInit() {
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParam(param));
        this.payId = localStorage.getItem("payId");
        if (this.sCheck.isNotNullString(this.payId)) {
            this.onPayIDClick(this.payId);
            localStorage.removeItem("payId");
        }
        this.createForm();
        this.datebefore = new Date();
        this.datebefore.setDate(this.datebefore.getDate() - 14);
        this.toPayDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.fromPayDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
        this.cPayoutSummary.fromToDate = this.toPayDate + '-' + this.fromPayDate;
        this.cPayoutSummaryReq.searchFromDate = this.toPayDate;
        this.cPayoutSummaryReq.searchToDate = this.fromPayDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cPayoutSummary.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cPayoutSummaryProcEntity = mCommonResponse.data.PayoutSummary;
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.landingPageMsg = 'No payout found from ' + this.toPayDate + ' to ' + this.fromPayDate;
                }
            }
            else {
                this.cPayoutSummaryProcEntity = null;
                this.landingPageMsg = 'No payout found from ' + this.toPayDate + ' to ' + this.fromPayDate;
            }
        });
    }
    fetchQueryParam(pParam) {
        if (this.sCheck.isNotNullNumber(pParam.tdPayoutId)) {
            this.onPayIDClick(pParam.tdPayoutId);
        }
    }
    //***********************************************Button Click Event*******************************************//
    onAllPayoutIdCheck(pEvent) {
        if (pEvent) {
            this.cPayoutSummary.selectedPayoutIds = [];
            for (var i = 0; i < this.cPayoutSummaryProcEntity.length; i++) {
                this.cPayoutSummary.selectedPayoutIds.push(this.cPayoutSummaryProcEntity[i].tdPayoutId.toString());
            }
        }
        else
            this.cPayoutSummary.selectedPayoutIds = [];
    }
    onPayoutIdCheck(pEvent) {
        if (pEvent) {
            if (this.cPayoutSummary.selectedPayoutIds.length == this.cPayoutSummaryProcEntity.length)
                this.cPayoutSummary.isAllPayoutIdCheck = true;
        }
        else
            this.cPayoutSummary.isAllPayoutIdCheck = false;
    }
    onlyNumbersAllowed(pEvent) {
        this.mForm.controls['tdPayoutId'].setValidators([CustomValidator.numbersOnly]);
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(pEvent.charCode);
        if (!pattern.test(inputChar) && pEvent.charCode != '0') {
            pEvent.preventDefault();
        }
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchCurrency: [''],
            searchSubAccId: [''],
            fromToDate: [''],
            tdPayoutId: ['']
        });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            localStorage.removeItem("fromPayDate");
            localStorage.removeItem("toPayDate");
            if ((this.cPayoutSummaryReq.searchFromDate != null && this.cPayoutSummaryReq.searchToDate != null) && (this.cPayoutSummaryReq.searchFromDate != '' && this.cPayoutSummaryReq.searchToDate != '')) {
                this.toPayDate = this.cPayoutSummaryReq.searchFromDate;
                this.fromPayDate = this.cPayoutSummaryReq.searchToDate;
                localStorage.setItem("fromPayDate", this.toPayDate);
                localStorage.setItem("toPayDate", this.fromPayDate);
            }
            else {
                this.datebefore = new Date();
                this.datebefore.setDate(this.datebefore.getDate() - 6);
                this.toPayDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
                this.fromPayDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
            }
            localStorage.removeItem("searchPayId");
            if (this.sCheck.isNotNullNumber(this.cPayoutSummaryReq.tdPayoutId)) {
                localStorage.setItem("searchPayId", this.cPayoutSummaryReq.tdPayoutId.toString());
            }
            localStorage.removeItem("searchCurr");
            if (this.sCheck.isNotNullList(this.cPayoutSummaryReq.searchCurrency)) {
                localStorage.setItem("searchCurr", JSON.stringify(this.cPayoutSummaryReq.searchCurrency));
            }
            localStorage.removeItem("searchSubAccId");
            if (this.sCheck.isNotNullList(this.cPayoutSummaryReq.searchSubAccId)) {
                localStorage.setItem("searchSubAccId", JSON.stringify(this.cPayoutSummaryReq.searchSubAccId));
            }
            this.sPayoutSummaryService.fetchPayoutSummary(this.cPayoutSummaryReq)
                .subscribe(pResponse => { this.fetchPayoutSummarySuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onBackClick() {
        if (localStorage.getItem("fromPayDate") && localStorage.getItem("toPayDate")) {
            this.cPayoutSummaryReq.searchFromDate = localStorage.getItem("fromPayDate");
            this.cPayoutSummaryReq.searchToDate = localStorage.getItem("toPayDate");
        }
        if (localStorage.getItem("searchPayId")) {
            this.cPayoutSummaryReq.tdPayoutId = Number(localStorage.getItem("searchPayId"));
        }
        if (localStorage.getItem("searchCurr")) {
            this.cPayoutSummaryReq.searchCurrency = JSON.parse(localStorage.getItem("searchCurr"));
        }
        if (localStorage.getItem("searchSubAccId")) {
            this.cPayoutSummaryReq.searchSubAccId = JSON.parse(localStorage.getItem("searchSubAccId"));
        }
        this.onSearchClick();
        this.sResponsiveService.closeDetails();
        this.cPayoutSummary.isBackClick = false;
    }
    onSearchPanelClick() {
        this.cPayoutSummary.isExportClick = false;
        this.cPayoutSummary.isTransExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cPayoutSummary.isSearchPanelClick = !this.cPayoutSummary.isSearchPanelClick;
        }
    }
    onPayIDClick(payId) {
        this.cPayoutSummaryReq.tdPayoutId = payId;
        this.sPayoutSummaryService.fetchPayoutIdDetails(this.cPayoutSummaryReq)
            .subscribe(pResponse => {
            this.fetchPayoutIdDetailsSuccess(pResponse);
            this.sResponsiveService.openDetails();
        }, error => {
            console.log(this.sErrorMessagesService.errorResponse);
            this.landingPageMsg = 'No Record Found';
        });
        this.cPayoutSummaryReq.tdPayoutId = null;
    }
    onCancelPanelClick() {
        this.payId = null;
        localStorage.removeItem("searchPayId");
        localStorage.removeItem("searchCurr");
        localStorage.removeItem("searchSubAccId");
        localStorage.removeItem("fromPayDate");
        localStorage.removeItem("toPayDate");
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.datebefore = new Date();
            this.datebefore.setDate(this.datebefore.getDate() - 14);
            this.toPayDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.fromPayDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
            this.cPayoutSummary.fromToDate = this.toPayDate + '-' + this.fromPayDate;
            this.cPayoutSummary.isSearchPanelClick = false;
            this.cPayoutSummaryReq.searchBy = '';
            this.cPayoutSummaryReq.searchFromDate = '';
            this.cPayoutSummaryReq.searchToDate = '';
            this.cPayoutSummaryReq.tdPayoutId = null;
            this.cPayoutSummary.fromToDate = '';
            this.mForm.controls['fromToDate'].clearValidators();
            this.mForm.controls['fromToDate'].updateValueAndValidity();
            this.cPayoutSummaryReq.searchSubAccId = [];
            this.cPayoutSummaryReq.searchCurrency = [];
            this.cPayoutSummary.isAllPayoutIdCheck = false;
            this.cPayoutSummary.selectedPayoutIds = [];
            this.onSearchClick();
        }
        else {
            this.datebefore = new Date();
            this.datebefore.setDate(this.datebefore.getDate() - 14);
            this.toPayDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.fromPayDate = this.pDatePipe.transform(new Date(), 'dd-MM-yyyy');
        }
    }
    onTransExportClick() {
        this.cPayoutSummary.isExportClick = false;
        this.cPayoutSummary.isSearchPanelClick = false;
        this.cPayoutSummary.isTransExportClick = !this.cPayoutSummary.isTransExportClick;
    }
    onExportClick() {
        this.cPayoutSummary.isSearchPanelClick = false;
        this.cPayoutSummary.isExportClick = !this.cPayoutSummary.isExportClick;
    }
    onSummaryExportClick() {
        this.cPayoutSummary.isSearchPanelClick = false;
        this.cPayoutSummary.isSummaryExportClick = !this.cPayoutSummary.isSummaryExportClick;
    }
    onExportExcelClick() {
        this.cPayoutSummary.isExportClick = !this.cPayoutSummary.isExportClick;
        this.sPayoutSummaryService.exportPayoutDetail(this.cPayoutSummaryReq)
            .subscribe(pResponse => { console.log('sucess'); }, error => { console.log('error'); });
    }
    onExportTransExcelClick() {
        this.cPayoutSummaryReq.payOutIds = '';
        if (this.cPayoutSummary.selectedPayoutIds.length != 0 && this.cPayoutSummary.selectedPayoutIds != []) {
            for (let obj of this.cPayoutSummary.selectedPayoutIds) {
                this.cPayoutSummaryReq.payOutIds += obj + "|";
            }
        }
        else if (this.cPayoutSummary.selectedPayoutIds.length == 0) {
            for (let payoutRec of this.cPayoutSummaryProcEntity) {
                this.cPayoutSummaryReq.payOutIds += payoutRec.tdPayoutId + "|";
            }
        }
        this.cPayoutSummary.isTransExportClick = !this.cPayoutSummary.isTransExportClick;
        this.sPayoutSummaryService.exportPayoutTransaction(this.cPayoutSummaryReq)
            .subscribe(pResponse => { console.log('sucess'); }, error => { console.log('error'); });
    }
    onExportSummaryExcelClick() {
        this.cPayoutSummary.isSummaryExportClick = !this.cPayoutSummary.isSummaryExportClick;
        this.sPayoutSummaryService.exportPayoutSummary(this.cPayoutSummaryReq)
            .subscribe(pResponse => { console.log('sucess'); }, error => { console.log('error'); });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cPayoutSummary.isExportClick = false;
    }
    //Transport Export Panel
    mouseleaveTransExportEvent() {
        this.cPayoutSummary.isTransExportClick = false;
    }
    //Summary Export Panel
    mouseleaveSummaryExportEvent() {
        this.cPayoutSummary.isSummaryExportClick = false;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cPayoutSummaryReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummaryReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummary.fromToDate = this.cPayoutSummaryReq.searchFromDate + ' - ' + this.cPayoutSummaryReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchPayoutSummarySuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPayoutSummary.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cPayoutSummaryProcEntity = mCommonResponse.data['PayoutSummary'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cPayoutSummary.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No payout found from ' + this.toPayDate + ' to ' + this.fromPayDate;
                this.onFailFetchPayoutSummary(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No payout found from ' + this.toPayDate + ' to ' + this.fromPayDate;
                this.onFailFetchPayoutSummary(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No payout found from ' + this.toPayDate + ' to ' + this.fromPayDate;
            this.onFailFetchPayoutSummary(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchPayoutSummary(pResMsg) {
        console.log(pResMsg);
        this.cPayoutSummary.pageTotalCount = null;
        this.cPayoutSummaryProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummary.isSearchPanelClick = false;
        }
    }
    fetchPayoutIdDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPayoutSummary.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cPayoutSummaryWithBankProcEntity = mCommonResponse.data['PayoutSummaryWithBank'][0];
                this.cPayoutSummaryDetailsProcEntity = mCommonResponse.data['PayoutSummaryDetails'][0];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cPayoutSummary.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchPayoutIdDetails(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchPayoutIdDetails(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No Record Found';
            this.onFailFetchPayoutIdDetails(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchPayoutIdDetails(pResMsg) {
        console.log(pResMsg);
        this.cPayoutSummary.pageTotalCount = null;
        this.cPayoutSummaryWithBankProcEntity = null;
        this.cPayoutSummaryDetailsProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummary.isSearchPanelClick = false;
        }
    }
    onPageChange(event) {
        this.cPayoutSummaryReq.searchPageSize = event.cPageSize;
        this.cPayoutSummaryReq.searchPageNo = event.cPageNo;
        this.cPayoutSummary.selectedPayoutIds = [];
        this.cPayoutSummary.isAllPayoutIdCheck = false;
        this.onSearchClick();
    }
    onPayIdClick() {
        this.mForm.controls['tdPayoutId'].setValidators([CustomValidator.numbersOnly]);
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
};
PayoutSummaryComponent = tslib_1.__decorate([
    Component({
        selector: 'app-payout-summary',
        templateUrl: './payout-summary.component.html',
        styleUrls: ['./payout-summary.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        DatePipe,
        BsModalService,
        ApiRequestService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PayoutSummaryService,
        FormBuilder,
        ErrorHandlerService,
        TitleService])
], PayoutSummaryComponent);
export { PayoutSummaryComponent };
//# sourceMappingURL=payout-summary.component.js.map