import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { PayoutSummaryReq } from './../payout-summary-req';
import { PayoutSummaryRefundsService } from './payout-summary-refunds.service';
let PayoutSummaryRefundsResolverService = class PayoutSummaryRefundsResolverService {
    constructor(cPayoutSummaryRefundsService) {
        this.cPayoutSummaryRefundsService = cPayoutSummaryRefundsService;
    }
    resolve(route, state) {
        let mPayoutSummaryReq = new PayoutSummaryReq();
        mPayoutSummaryReq.tdPayoutId = route.queryParams.tdPayoutId;
        mPayoutSummaryReq.orderStatus = 'Refunded';
        return this.cPayoutSummaryRefundsService.fetchSalesOrRefundOrChargebackDetails(mPayoutSummaryReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PayoutSummaryRefundsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [PayoutSummaryRefundsService])
], PayoutSummaryRefundsResolverService);
export { PayoutSummaryRefundsResolverService };
//# sourceMappingURL=payout-summary-refunds-resolver.service.js.map