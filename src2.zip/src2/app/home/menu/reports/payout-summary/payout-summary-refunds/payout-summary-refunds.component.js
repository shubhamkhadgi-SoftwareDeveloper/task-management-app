import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { PayoutSummary } from '../payout-summary-sales/payout-summary';
import { PayoutSummaryReq } from '../payout-summary-sales/payout-summary-req';
import { PayoutSummaryRefundsService } from './payout-summary-refunds.service';
import { TransactionDetailsReq } from '../../../transactions/transactions/transactionDetails.req';
import { TransactionWrapperRes } from '../../../transactions/transactions/transactionWrapper.res';
import { TransactionDetailsProcEntity } from '../../../../../proc-entities/transaction-details-proc-entity';
import { PayoutSalesRefundChargebackProcEntity } from '../../../../../proc-entities/payout-sales-refund-chargeback-proc-entity';
import { PayoutSummaryWithBankProcEntity } from '../../../../../proc-entities/payout-summary-with-bank-proc-entity';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
import * as $ from 'jquery';
let PayoutSummaryRefundsComponent = class PayoutSummaryRefundsComponent {
    constructor(cdr, pFormBuilder, sErrorHandler, pModalService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sPayoutSummaryRefundsService, sTransactionsService) {
        this.cdr = cdr;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.pModalService = pModalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPayoutSummaryRefundsService = sPayoutSummaryRefundsService;
        this.sTransactionsService = sTransactionsService;
        this.landingPageMsg = null;
        this.cPayoutSalesRefundChargebackProcEntity = [];
        this.refundAmt = 0;
        this.cTotalAmtRefunded = 0.00;
        this.cardNumber = null;
        this.cardBin = null;
        this.cardType = null;
        this.cRefundDetailsProcEntity = [];
        this.cPayoutSummaryRefunds = new PayoutSummary();
        this.cPayoutSummaryRefundsReq = new PayoutSummaryReq();
        this.cPayoutSummaryWithBankProcEntity = new PayoutSummaryWithBankProcEntity();
        this.cPayoutRefundTransDetail = new PayoutSalesRefundChargebackProcEntity();
        this.cTransactionDetail = new TransactionWrapperRes();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
        this.cTransactionDetailsProcEntity = new TransactionDetailsProcEntity();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    ngOnInit() {
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParamField(param));
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cPayoutSummaryRefunds.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data.PayoutSalesRefundCharge;
                    this.cPayoutSummaryWithBankProcEntity = mCommonResponse.data.PayoutSummaryList[0];
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
            }
        });
        window.scrollTo(0, 0);
    }
    fetchQueryParamField(param) {
        if (this.sCheck.isNotNullString(param.tdPayoutId)) {
            this.payId = param.tdPayoutId;
        }
    }
    //*****************************Validations********************************//
    createForm() {
        this.cSearchForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cPayoutSummaryRefunds.isExportClick = false;
    }
    //***********************************************Button Click Event*******************************************//
    onPreviousClick() {
        if (this.cPayoutSummaryRefunds.activeColumn[0] != 0) {
            this.cPayoutSummaryRefunds.activeColumn.splice(this.cPayoutSummaryRefunds.activeColumn.length - 1, 1);
            this.cPayoutSummaryRefunds.activeColumn.splice(0, 0, this.cPayoutSummaryRefunds.activeColumn[0] - 1);
        }
    }
    onNextClick() {
        if (this.cPayoutSummaryRefunds.activeColumn[this.cPayoutSummaryRefunds.activeColumn.length - 1] < 10) {
            this.cPayoutSummaryRefunds.activeColumn.push(this.cPayoutSummaryRefunds.activeColumn[this.cPayoutSummaryRefunds.activeColumn.length - 1] + 1);
            this.cPayoutSummaryRefunds.activeColumn.splice(0, 1);
        }
    }
    onSearchPanelClick() {
        this.cPayoutSummaryRefunds.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cPayoutSummaryRefunds.isSearchPanelClick = !this.cPayoutSummaryRefunds.isSearchPanelClick;
        }
    }
    onExportExcelClick() {
        this.cPayoutSummaryRefunds.isExportClick = !this.cPayoutSummaryRefunds.isExportClick;
        this.cPayoutSummaryRefundsReq.orderStatus = 'refunded';
        this.cPayoutSummaryRefundsReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
        this.sPayoutSummaryRefundsService.exportPayoutSummaryOnCondition(this.cPayoutSummaryRefundsReq)
            .subscribe(pResponse => {
        }, error => { console.log('error'); });
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummaryRefunds.searchByLabel = "Search by";
            this.cPayoutSummaryRefunds.isSearchPanelClick = false;
            this.cPayoutSummaryRefundsReq.searchBy = null;
            this.cPayoutSummaryRefundsReq.searchByValue = null;
            this.cPayoutSummaryRefunds.fromToDate = null;
            this.cPayoutSummaryRefundsReq.searchFromDate = null;
            this.cPayoutSummaryRefundsReq.searchToDate = null;
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
            this.cSearchForm.controls['fromToDate'].clearValidators();
            this.cSearchForm.controls['fromToDate'].updateValueAndValidity();
            this.onSearchClick();
        }
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            this.cPayoutSummaryRefunds.isSearchByClick = false;
            this.cPayoutSummaryRefundsReq.orderStatus = 'Refunded';
            this.cPayoutSummaryRefundsReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
            this.sPayoutSummaryRefundsService.fetchSalesOrRefundOrChargebackDetails(this.cPayoutSummaryRefundsReq)
                .subscribe(pResponse => { this.fetchPayoutRefundSuccess(pResponse); }, error => { console.log('No Record Found'); });
        }
        else {
            this.validateAllFields(this.cSearchForm);
        }
    }
    onSearchByOptionClick(pOption) {
        this.cPayoutSummaryRefunds.isSearchByClick = !this.cPayoutSummaryRefunds.isSearchByClick;
        this.cPayoutSummaryRefundsReq.searchBy = pOption.value;
        this.cPayoutSummaryRefundsReq.searchByValue = null;
        this.cPayoutSummaryRefunds.searchByLabel = pOption.label;
        if (this.cPayoutSummaryRefundsReq.searchBy == 'trackingId') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cPayoutSummaryRefundsReq.searchBy == 'orderNo') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.cPayoutSummaryRefunds.isSearchByClick = !this.cPayoutSummaryRefunds.isSearchByClick;
    }
    onRefundsDetailClick(index) {
        this.sResponsiveService.openDetails();
        this.cPayoutRefundTransDetail = this.cPayoutSalesRefundChargebackProcEntity[index];
        this.cTransactionDetailsReq.trackingId = this.cPayoutRefundTransDetail.trackingId;
        this.sTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
            .subscribe(pResponse => this.fetchTransactionDetailsSuccess(pResponse, this.cPayoutRefundTransDetail.trackingId), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchTransactionDetailsSuccess(pResponse, trackingId) {
        window.scrollTo(0, 0);
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (pResponse.code === 0 && pResponse.message == 'Success') {
                this.cTransactionDetail = pResponse.data;
                this.cPayoutSummaryRefundsReq.trackingId = trackingId;
                this.cRefundDetailsProcEntity = this.cTransactionDetail.refundDetailList;
                this.cTotalAmtRefunded = 0.00;
                if (this.sCheck.isNotNullList(this.cRefundDetailsProcEntity))
                    for (var i = 0; i < this.cRefundDetailsProcEntity.length; i++) {
                        this.cTotalAmtRefunded += this.cRefundDetailsProcEntity[i].refundAmt;
                    }
                this.cRefundDetailsProcEntity = this.cTransactionDetail.refundDetailList;
                this.cTotalAmtRefunded = 0.00;
                if (this.sCheck.isNotNullList(this.cRefundDetailsProcEntity))
                    for (var i = 0; i < this.cRefundDetailsProcEntity.length; i++) {
                        this.cTotalAmtRefunded += this.cRefundDetailsProcEntity[i].refundAmt;
                    }
                this.cTransactionDetailsProcEntity = this.cTransactionDetail['transactionDetailsProcEntity'].transactionDetailsProcEntity;
                this.cardNumber = this.cTransactionDetail['transactionDetailsProcEntity'].cardNumber;
                if (this.cTransactionDetailsProcEntity.orderBinCountry == "INDIA") {
                    this.cardBin = "Domestic";
                }
                else if (this.cTransactionDetailsProcEntity.orderBinCountry == null) {
                    this.cardBin = null;
                }
                else {
                    this.cardBin = "International";
                }
                this.cardType = null;
                if (this.cTransactionDetailsProcEntity.orderCardType == "CRDC") {
                    this.cardType = "Credit Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTCASHC") {
                    this.cardType = "Cash Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTDBCRD") {
                    this.cardType = "Debit Card";
                }
                if (this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount != null) {
                    this.refundAmt = this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount;
                }
                else {
                    this.refundAmt = 0;
                }
            }
        }
    }
    onRefundsBackClick() {
        this.sResponsiveService.closeDetails();
        this.cPayoutSummaryRefunds.isBackClick = false;
    }
    onBackClick() {
        localStorage.setItem("payId", this.payId);
        this.pLocation.back();
        this.sResponsiveService.closeDetails();
        this.cPayoutSummaryRefunds.isBackClick = false;
    }
    onExportClick() {
        this.cPayoutSummaryRefunds.isSearchPanelClick = false;
        this.cPayoutSummaryRefunds.isExportClick = !this.cPayoutSummaryRefunds.isExportClick;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cPayoutSummaryRefundsReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummaryRefunds.fromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummaryRefunds.toDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummaryRefundsReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummaryRefunds.fromToDate = this.cPayoutSummaryRefunds.fromDate + '-' + this.cPayoutSummaryRefunds.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    onPageChange(event) {
        this.cPayoutSummaryRefundsReq.searchPageSize = event.cPageSize;
        this.cPayoutSummaryRefundsReq.searchPageNo = event.cPageNo;
        this.onSearchClick();
    }
    fetchPayoutRefundSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPayoutSummaryRefunds.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data['PayoutSalesRefundCharge'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cPayoutSummaryRefunds.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No payout found ';
                this.onFailFetchPayoutRefund(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No payout found  ';
                this.onFailFetchPayoutRefund(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No payout found ';
            this.onFailFetchPayoutRefund(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchPayoutRefund(pResMsg) {
        console.log(pResMsg);
        this.cPayoutSummaryRefunds.pageTotalCount = null;
        this.cPayoutSalesRefundChargebackProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummaryRefunds.isSearchPanelClick = false;
        }
    }
    scrollRefund() {
        let el = $('.RefundedDtl');
        $('html,body').animate({ scrollTop: (el.offset().top - 10) });
    }
};
PayoutSummaryRefundsComponent = tslib_1.__decorate([
    Component({
        selector: 'app-payout-summary-refunds',
        templateUrl: './payout-summary-refunds.component.html',
        styleUrls: ['./payout-summary-refunds.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        FormBuilder,
        ErrorHandlerService,
        BsModalService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        PayoutSummaryRefundsService,
        TransactionsService])
], PayoutSummaryRefundsComponent);
export { PayoutSummaryRefundsComponent };
//# sourceMappingURL=payout-summary-refunds.component.js.map