import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from './../../../../../common-services/api-request.service';
let PayoutSummaryRefundsService = class PayoutSummaryRefundsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'payoutSummary/';
        this.cfetchSalesOrRefundOrChargebackDetailsUrl = this.cBaseUrl + 'fetchSalesOrRefundOrChargebackDetails';
        this.cexportPayoutSummaryOnConditionUrl = this.cBaseUrl + 'exportPayoutSummaryOnCondition';
        this.cFetchRefundDetailsListUrl = this.cBaseUrl + 'fetchRefundDetailsList';
    }
    fetchSalesOrRefundOrChargebackDetails(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cfetchSalesOrRefundOrChargebackDetailsUrl);
    }
    exportPayoutSummaryOnCondition(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutSummaryOnConditionUrl, "PayoutRefundedSummary.xlsx");
    }
    fetchRefundDetailsList(pPayoutSummaryRefundReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryRefundReq, this.cFetchRefundDetailsListUrl);
    }
};
PayoutSummaryRefundsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], PayoutSummaryRefundsService);
export { PayoutSummaryRefundsService };
//# sourceMappingURL=payout-summary-refunds.service.js.map