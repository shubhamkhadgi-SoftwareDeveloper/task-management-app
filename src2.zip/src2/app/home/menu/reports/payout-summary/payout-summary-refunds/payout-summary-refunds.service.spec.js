import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryRefundsService } from './payout-summary-refunds.service';
describe('PayoutSummaryRefundsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryRefundsService]
        });
    });
    it('should be created', inject([PayoutSummaryRefundsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-refunds.service.spec.js.map