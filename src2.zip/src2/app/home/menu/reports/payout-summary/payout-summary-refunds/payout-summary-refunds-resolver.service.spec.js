import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummaryRefundsResolverService } from './payout-summary-refunds-resolver.service';
describe('PayoutSummaryRefundsResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummaryRefundsResolverService]
        });
    });
    it('should be created', inject([PayoutSummaryRefundsResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-refunds-resolver.service.spec.js.map