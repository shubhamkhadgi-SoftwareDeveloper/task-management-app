export class PayoutSummary {
    constructor() {
        this.isBackClick = false;
        this.isExportClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.closeButton = false;
        this.calOptions = {
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.searchByLabel = 'Search By';
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref #', value: 'trackingId' });
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
        this.activeColumn = [0, 1, 2, 3, 4, 5, 6];
        this.constColumn = 0;
    }
}
//# sourceMappingURL=payout-summary.js.map