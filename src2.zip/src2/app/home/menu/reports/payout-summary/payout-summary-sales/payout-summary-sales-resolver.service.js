import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { PayoutSummaryReq } from './../payout-summary-req';
import { PayoutSummarySalesService } from './payout-summary-sales.service';
let PayoutSummarySalesResolverService = class PayoutSummarySalesResolverService {
    constructor(cPayoutSummarySalesService) {
        this.cPayoutSummarySalesService = cPayoutSummarySalesService;
    }
    resolve(route, state) {
        let mPayoutSummaryReq = new PayoutSummaryReq();
        mPayoutSummaryReq.tdPayoutId = route.queryParams.tdPayoutId;
        mPayoutSummaryReq.orderStatus = 'Shipped';
        return this.cPayoutSummarySalesService.fetchSalesOrRefundOrChargebackDetails(mPayoutSummaryReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
PayoutSummarySalesResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [PayoutSummarySalesService])
], PayoutSummarySalesResolverService);
export { PayoutSummarySalesResolverService };
//# sourceMappingURL=payout-summary-sales-resolver.service.js.map