import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from './../../../../../common-services/api-request.service';
let PayoutSummarySalesService = class PayoutSummarySalesService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'payoutSummary/';
        this.cfetchSalesOrRefundOrChargebackDetailsUrl = this.cBaseUrl + 'fetchSalesOrRefundOrChargebackDetails';
        this.cexportPayoutSummaryOnConditionUrl = this.cBaseUrl + 'exportPayoutSummaryOnCondition';
        this.cFetchRefundDetailsListUrl = this.cBaseUrl + 'fetchRefundDetailsList';
    }
    fetchSalesOrRefundOrChargebackDetails(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cfetchSalesOrRefundOrChargebackDetailsUrl);
    }
    exportPayoutSummaryOnCondition(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutSummaryOnConditionUrl, "PayoutSalesSummary.xlsx");
    }
    fetchRefundDetailsList(pPayoutSummarySalesReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummarySalesReq, this.cFetchRefundDetailsListUrl);
    }
};
PayoutSummarySalesService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], PayoutSummarySalesService);
export { PayoutSummarySalesService };
//# sourceMappingURL=payout-summary-sales.service.js.map