import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummarySalesService } from './payout-summary-sales.service';
describe('PayoutSummarySalesService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummarySalesService]
        });
    });
    it('should be created', inject([PayoutSummarySalesService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-sales.service.spec.js.map