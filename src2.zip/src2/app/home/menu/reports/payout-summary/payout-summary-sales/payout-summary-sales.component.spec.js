import { async, TestBed } from '@angular/core/testing';
import { PayoutSummarySalesComponent } from './payout-summary-sales.component';
describe('PayoutSummarySalesComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PayoutSummarySalesComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(PayoutSummarySalesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should be created', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=payout-summary-sales.component.spec.js.map