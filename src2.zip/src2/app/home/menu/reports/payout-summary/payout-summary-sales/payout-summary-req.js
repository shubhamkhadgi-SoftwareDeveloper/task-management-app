export class PayoutSummaryReq {
    constructor() {
        this.searchSubAccId = [];
        this.searchCurrency = [];
    }
}
//# sourceMappingURL=payout-summary-req.js.map