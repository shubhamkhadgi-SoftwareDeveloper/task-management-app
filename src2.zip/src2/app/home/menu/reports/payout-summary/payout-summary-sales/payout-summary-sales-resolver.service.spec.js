import { TestBed, inject } from '@angular/core/testing';
import { PayoutSummarySalesResolverService } from './payout-summary-sales-resolver.service';
describe('PayoutSummarySalesResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutSummarySalesResolverService]
        });
    });
    it('should be created', inject([PayoutSummarySalesResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=payout-summary-sales-resolver.service.spec.js.map