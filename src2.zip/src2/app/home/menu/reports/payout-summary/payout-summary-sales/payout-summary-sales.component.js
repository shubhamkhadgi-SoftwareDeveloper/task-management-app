import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomValidator } from '../../../../../custom-validator/custom-validator';
import { ErrorHandlerService } from '../../../../../common-services/error-handler.service';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { PayoutSalesRefundChargebackProcEntity } from '../../../../../proc-entities/payout-sales-refund-chargeback-proc-entity';
import { PayoutSummaryWithBankProcEntity } from '../../../../../proc-entities/payout-summary-with-bank-proc-entity';
import { PayoutSummary } from './../payout-summary';
import { PayoutSummaryReq } from './payout-summary-req';
import { PayoutSummarySalesService } from './payout-summary-sales.service';
import { TransactionDetailsReq } from '../../../transactions/transactions/transactionDetails.req';
import { TransactionWrapperRes } from '../../../transactions/transactions/transactionWrapper.res';
import { TransactionDetailsProcEntity } from '../../../../../proc-entities/transaction-details-proc-entity';
import { TransactionsService } from '../../../transactions/transactions/transactions.service';
import * as $ from 'jquery';
let PayoutSummarySalesComponent = class PayoutSummarySalesComponent {
    constructor(cdr, pFormBuilder, sErrorHandler, pModalService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, cPayoutSummarySalesService, sActivatedRoute, sTransactionsService) {
        this.cdr = cdr;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.pModalService = pModalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.cPayoutSummarySalesService = cPayoutSummarySalesService;
        this.sActivatedRoute = sActivatedRoute;
        this.sTransactionsService = sTransactionsService;
        this.cRefundDetailsProcEntity = [];
        this.cPayoutSalesRefundChargebackProcEntity = [];
        this.landingPageMsg = null;
        this.refundAmt = 0;
        this.cTotalAmtRefunded = 0.00;
        this.cardNumber = null;
        this.cardBin = null;
        this.cardType = null;
        this.cPayoutSalesDetail = new PayoutSalesRefundChargebackProcEntity();
        this.cPayoutSummaryWithBankProcEntity = new PayoutSummaryWithBankProcEntity();
        this.cPayoutSummarySales = new PayoutSummary();
        this.cPayoutSummarySalesReq = new PayoutSummaryReq();
        this.cTransactionDetail = new TransactionWrapperRes();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
        this.cTransactionDetailsProcEntity = new TransactionDetailsProcEntity();
    }
    ngOnInit() {
        this.sActivatedRoute.queryParams.subscribe(param => this.fetchQueryParamField(param));
        this.createForm();
        this.cSearchForm.controls['searchByValue'].disable();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cPayoutSummarySales.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data.PayoutSalesRefundCharge;
                    this.cPayoutSummaryWithBankProcEntity = mCommonResponse.data.PayoutSummaryList[0];
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                }
            }
            else {
                console.log(mCommonResponse.messageDesc);
            }
        });
        window.scrollTo(0, 0);
    }
    fetchQueryParamField(param) {
        if (this.sCheck.isNotNullString(param.tdPayoutId)) {
            this.payId = param.tdPayoutId;
        }
    }
    onBackClick() {
        localStorage.setItem("payId", this.payId);
        this.pLocation.back();
        this.sResponsiveService.closeDetails();
        this.cPayoutSummarySales.isBackClick = false;
    }
    onSalesBackClick() {
        this.sResponsiveService.closeDetails();
        this.cPayoutSummarySales.isBackClick = false;
    }
    onPaySalesExportClick() {
        this.cPayoutSummarySales.isSearchPanelClick = false;
        this.cPayoutSummarySales.isExportClick = !this.cPayoutSummarySales.isExportClick;
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cPayoutSummarySales.isExportClick = false;
    }
    //***********************************************Button Click Event*******************************************//
    onExportExcelClick() {
        this.cPayoutSummarySales.isExportClick = !this.cPayoutSummarySales.isExportClick;
        this.cPayoutSummarySalesReq.orderStatus = 'Shipped';
        this.cPayoutSummarySalesReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
        this.cPayoutSummarySalesService.exportPayoutSummaryOnCondition(this.cPayoutSummarySalesReq)
            .subscribe(pResponse => {
        }, error => { console.log('error'); });
    }
    onPreviousClick() {
        if (this.cPayoutSummarySales.activeColumn[0] != 0) {
            this.cPayoutSummarySales.activeColumn.splice(this.cPayoutSummarySales.activeColumn.length - 1, 1);
            this.cPayoutSummarySales.activeColumn.splice(0, 0, this.cPayoutSummarySales.activeColumn[0] - 1);
        }
    }
    onNextClick() {
        if (this.cPayoutSummarySales.activeColumn[this.cPayoutSummarySales.activeColumn.length - 1] < 10) {
            this.cPayoutSummarySales.activeColumn.push(this.cPayoutSummarySales.activeColumn[this.cPayoutSummarySales.activeColumn.length - 1] + 1);
            this.cPayoutSummarySales.activeColumn.splice(0, 1);
        }
    }
    onSearchPanelClick() {
        this.cPayoutSummarySales.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cPayoutSummarySales.isSearchPanelClick = !this.cPayoutSummarySales.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummarySales.searchByLabel = "Search by";
            this.cPayoutSummarySales.isSearchPanelClick = false;
            this.cPayoutSummarySalesReq.searchBy = null;
            this.cPayoutSummarySalesReq.searchByValue = null;
            this.cPayoutSummarySalesReq.searchFromDate = null;
            this.cPayoutSummarySalesReq.searchToDate = null;
            this.cPayoutSummarySales.fromToDate = null;
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
            this.cSearchForm.controls['fromToDate'].clearValidators();
            this.cSearchForm.controls['fromToDate'].updateValueAndValidity();
            this.onSearchClick();
        }
    }
    onSearchClick() {
        if (this.cSearchForm.valid) {
            if (!this.sResponsiveService.isSearchResponsive()) {
                this.cPayoutSummarySales.isSearchPanelClick = !this.cPayoutSummarySales.isSearchPanelClick;
            }
            this.cPayoutSummarySales.isSearchByClick = false;
            this.cPayoutSummarySalesReq.orderStatus = 'Shipped';
            this.cPayoutSummarySalesReq.tdPayoutId = +this.cPayoutSummaryWithBankProcEntity.tdId;
            this.cPayoutSummarySalesService.fetchSalesOrRefundOrChargebackDetails(this.cPayoutSummarySalesReq)
                .subscribe(pResponse => { this.fetchPayoutSalesSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.cSearchForm);
        }
    }
    onSearchByOptionClick(pOption) {
        this.cPayoutSummarySales.isSearchByClick = !this.cPayoutSummarySales.isSearchByClick;
        this.cPayoutSummarySalesReq.searchBy = pOption.value;
        this.cPayoutSummarySalesReq.searchByValue = null;
        this.cPayoutSummarySales.searchByLabel = pOption.label;
        if (this.cPayoutSummarySalesReq.searchBy == 'trackingId') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cPayoutSummarySalesReq.searchBy == 'orderNo') {
            this.cSearchForm.controls['searchByValue'].enable();
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].dirty;
            this.cSearchForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.cSearchForm.controls['searchByValue'].setValidators([Validators.required]);
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.cSearchForm.controls['searchByValue'].setValue(null);
            this.cSearchForm.controls['searchByValue'].clearValidators();
            this.cSearchForm.controls['searchByValue'].disable();
            this.cSearchForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.cPayoutSummarySales.isSearchByClick = !this.cPayoutSummarySales.isSearchByClick;
    }
    onSalesDetailClick(index) {
        this.sResponsiveService.openDetails();
        this.cPayoutSalesDetail = this.cPayoutSalesRefundChargebackProcEntity[index];
        this.cTransactionDetailsReq.trackingId = this.cPayoutSalesDetail.trackingId;
        this.sTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq).subscribe(pResponse => this.fetchTransactionDetailsSuccess(pResponse, this.cPayoutSalesDetail.trackingId), error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchTransactionDetailsSuccess(pResponse, trackingId) {
        window.scrollTo(0, 0);
        if (this.sCheck.isNotNullObject(pResponse)) {
            if (pResponse.code === 0 && pResponse.message == 'Success') {
                this.cTransactionDetail = pResponse.data;
                this.cPayoutSummarySalesReq.trackingId = trackingId;
                this.cRefundDetailsProcEntity = this.cTransactionDetail.refundDetailList;
                this.cTotalAmtRefunded = 0.00;
                if (this.sCheck.isNotNullList(this.cRefundDetailsProcEntity))
                    for (var i = 0; i < this.cRefundDetailsProcEntity.length; i++) {
                        this.cTotalAmtRefunded += this.cRefundDetailsProcEntity[i].refundAmt;
                    }
                this.cTransactionDetailsProcEntity = this.cTransactionDetail['transactionDetailsProcEntity'].transactionDetailsProcEntity;
                this.cardNumber = this.cTransactionDetail['transactionDetailsProcEntity'].cardNumber;
                if (this.cTransactionDetailsProcEntity.orderBinCountry == "INDIA") {
                    this.cardBin = "Domestic";
                }
                else if (this.cTransactionDetailsProcEntity.orderBinCountry == null) {
                    this.cardBin = null;
                }
                else {
                    this.cardBin = "International";
                }
                this.cardType = null;
                if (this.cTransactionDetailsProcEntity.orderCardType == "CRDC") {
                    this.cardType = "Credit Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTCASHC") {
                    this.cardType = "Cash Card";
                }
                else if (this.cTransactionDetailsProcEntity.orderCardType == "OPTDBCRD") {
                    this.cardType = "Debit Card";
                }
                if (this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount != null) {
                    this.refundAmt = this.cTransactionDetail.transactionDetailsProcEntity.transactionDetailsProcEntity.refundAmount;
                }
                else {
                    this.refundAmt = 0;
                }
            }
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cPayoutSummarySalesReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummarySales.fromDate = value.start.format("DD-MM-YYYY");
        this.cPayoutSummarySales.toDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummarySalesReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cPayoutSummarySales.fromToDate = this.cPayoutSummarySales.fromDate + '-' + this.cPayoutSummarySales.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    onPageChange(event) {
        this.cPayoutSummarySalesReq.searchPageSize = event.cPageSize;
        this.cPayoutSummarySalesReq.searchPageNo = event.cPageNo;
        this.onSearchClick();
    }
    fetchPayoutSalesSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cPayoutSummarySales.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cPayoutSalesRefundChargebackProcEntity = mCommonResponse.data['PayoutSalesRefundCharge'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cPayoutSummarySales.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No payout found ';
                this.onFailFetchPayoutSales(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No payout found  ';
                this.onFailFetchPayoutSales(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No payout found ';
            this.onFailFetchPayoutSales(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchPayoutSales(pResMsg) {
        console.log(pResMsg);
        this.cPayoutSummarySales.pageTotalCount = null;
        this.cPayoutSalesRefundChargebackProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cPayoutSummarySales.isSearchPanelClick = false;
        }
    }
    //*****************************Validations********************************//
    createForm() {
        this.cSearchForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: [''],
        });
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    scrollRefund() {
        let el = $('.RefundedDtl');
        $('html,body').animate({ scrollTop: (el.offset().top - 10) });
    }
};
PayoutSummarySalesComponent = tslib_1.__decorate([
    Component({
        selector: 'app-payout-summary-sales',
        templateUrl: './payout-summary-sales.component.html',
        styleUrls: ['./payout-summary-sales.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ChangeDetectorRef,
        FormBuilder,
        ErrorHandlerService,
        BsModalService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        PayoutSummarySalesService,
        ActivatedRoute,
        TransactionsService])
], PayoutSummarySalesComponent);
export { PayoutSummarySalesComponent };
//# sourceMappingURL=payout-summary-sales.component.js.map