export class PayoutSummaryReq {
    constructor() {
        this.searchFromDate = '';
        this.searchToDate = '';
        this.searchSubAccId = [];
        this.searchCurrency = [];
    }
}
//# sourceMappingURL=payout-summary-req.js.map