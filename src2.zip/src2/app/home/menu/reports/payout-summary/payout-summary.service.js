import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let PayoutSummaryService = class PayoutSummaryService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'payoutSummary/';
        this.cfetchPayoutSummaryUrl = this.cBaseUrl + 'fetchPayoutSummary';
        this.cfetchPayoutIdDetailsUrl = this.cBaseUrl + 'fetchPayoutIdDetails';
        this.cexportPayoutSummaryUrl = this.cBaseUrl + 'exportPayoutSummary';
        this.cexportPayoutDetailUrl = this.cBaseUrl + 'exportPayoutDetail';
        this.cexportPayoutTransactionUrl = this.cBaseUrl + 'exportPayoutTransaction';
        this.cFetchRefundDetailsListUrl = this.cBaseUrl + 'fetchRefundDetailsList';
    }
    fetchPayoutSummary(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cfetchPayoutSummaryUrl);
    }
    fetchPayoutIdDetails(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cfetchPayoutIdDetailsUrl);
    }
    exportPayoutSummary(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutSummaryUrl, "payoutSummary.xlsx");
    }
    exportPayoutDetail(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutDetailUrl, "payoutSummary.xlsx");
    }
    exportPayoutTransaction(pPayoutSummaryReq) {
        return this.pApiRequestService.exportFileRequest(pPayoutSummaryReq, this.cexportPayoutTransactionUrl, "payoutTransactionSummary.xlsx");
    }
    fetchRefundDetailsList(pPayoutSummaryReq) {
        return this.pApiRequestService.httpPostRequest(pPayoutSummaryReq, this.cFetchRefundDetailsListUrl);
    }
};
PayoutSummaryService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], PayoutSummaryService);
export { PayoutSummaryService };
//# sourceMappingURL=payout-summary.service.js.map