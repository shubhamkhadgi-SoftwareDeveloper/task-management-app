import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { DirectBankSettlementsReq } from './direct-bank-settlements-req';
import { DirectBankSettlementsService } from './direct-bank-settlements.service';
let DirectBankSettlementsResolverService = class DirectBankSettlementsResolverService {
    constructor(sDirectBankSettlementsService) {
        this.sDirectBankSettlementsService = sDirectBankSettlementsService;
    }
    resolve(route, state) {
        let mDirectBankSettlementsReq = new DirectBankSettlementsReq();
        mDirectBankSettlementsReq.vActivity = 'DirectBank';
        return this.sDirectBankSettlementsService.fetchDirectBankSettlementReport(mDirectBankSettlementsReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
DirectBankSettlementsResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DirectBankSettlementsService])
], DirectBankSettlementsResolverService);
export { DirectBankSettlementsResolverService };
//# sourceMappingURL=direct-bank-settlements-resolver-service.js.map