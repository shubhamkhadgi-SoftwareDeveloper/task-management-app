import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let DirectBankSettlementsService = class DirectBankSettlementsService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cDirectBankSettlementsBaseUrl = 'directBankSettlements/';
        this.cFetchDirectBankSettlementReportUrl = this.cDirectBankSettlementsBaseUrl + 'fetchDirectBankSettlementReport';
        this.cExportDirectBankSettlementReportUrl = this.cDirectBankSettlementsBaseUrl + 'exportDirectBankSettlementReport';
        this.cFetchDirectBankSetDetailUrl = this.cDirectBankSettlementsBaseUrl + 'fetchDirectBankSetDetail';
    }
    fetchDirectBankSettlementReport(pDirectBankSettlementsReq) {
        return this.pApiRequestService.httpPostRequest(pDirectBankSettlementsReq, this.cFetchDirectBankSettlementReportUrl);
    }
    fetchDirectBankSetDetail(pDirectBankSettlementsReq) {
        return this.pApiRequestService.httpPostRequest(pDirectBankSettlementsReq, this.cFetchDirectBankSetDetailUrl);
    }
    exportDirectBankSettlementReport(pDirectBankSettlementsReq) {
        return this.pApiRequestService.exportFileRequest(pDirectBankSettlementsReq, this.cExportDirectBankSettlementReportUrl, "DirectBankSettlementsReport.xlsx");
    }
};
DirectBankSettlementsService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], DirectBankSettlementsService);
export { DirectBankSettlementsService };
//# sourceMappingURL=direct-bank-settlements.service.js.map