export class DirectBankSettlements {
    constructor() {
        this.isSingleOrderIDClick = false;
        this.isSearchPanelClick = false;
        this.isNoRecordAfterSearch = true;
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.isBackClick = false;
        this.closeButton = false;
        //public isRecurringPayCreated: boolean = false;
        this.isSearchFound = false;
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            maxDate: new Date(),
        };
        this.status.push({ label: 'Active', value: 'ACTI' });
        this.status.push({ label: 'Inactive', value: 'INAC' });
        this.status.push({ label: 'Expired', value: 'EXPD' });
        this.status.push({ label: 'Cancelled', value: 'CANC' });
        this.searchBy = [];
        this.searchBy.push({ label: 'ID', value: 'siRefNo' });
        this.searchBy.push({ label: 'CCAvenue Ref.#', value: 'merRefNo' });
        this.searchBy.push({ label: 'Customer Name', value: 'userName' });
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=direct-bank-settlements.js.map