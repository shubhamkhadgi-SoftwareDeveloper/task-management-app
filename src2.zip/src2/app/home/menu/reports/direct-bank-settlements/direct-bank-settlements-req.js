export class DirectBankSettlementsReq {
    constructor() {
        this.searchPageSize = 25;
        this.searchPageNo = 1;
    }
}
//# sourceMappingURL=direct-bank-settlements-req.js.map