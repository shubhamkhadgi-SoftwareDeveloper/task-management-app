import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DirectBankSettlementsReq } from './direct-bank-settlements-req';
import { DirectBankSettlementsService } from './direct-bank-settlements.service';
import { DirectBankSettlementProcEntity } from '../../../../proc-entities/direct-bank-settlement-proc-entity';
import { OrderDetailsForBankSettleProcEntity } from '../../../../proc-entities/order-details-for-bank-settle-proc-entity';
import { DirectBankSettlements } from './direct-bank-settlements';
import { TitleService } from './../../../../common-services/title.service';
import { TransactionDetailsReq } from '../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../transactions/transactions/transactions.service';
let DirectBankSettlementsComponent = class DirectBankSettlementsComponent {
    //***********************************************Life Hooks Event*******************************************//  
    constructor(pModalService, sDirectBankSettlementsService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sTitleService, pTransactionsService) {
        this.pModalService = pModalService;
        this.sDirectBankSettlementsService = sDirectBankSettlementsService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sTitleService = sTitleService;
        this.pTransactionsService = pTransactionsService;
        this.cTotalAmtRefunded = 0;
        this.landingPageMsg = null;
        this.cCardsList = [];
        this.cGatewayList = [];
        this.cDirectBankSettlementProcEntity = [];
        this.cCardNameListProcEntity = [];
        this.isTransactionDetailClick = false;
        this.cDirectBankSettlements = new DirectBankSettlements();
        this.cDirectBankSettlementsReq = new DirectBankSettlementsReq();
        this.cDirectBankSettlementsReq.vActivity = 'Directbank1';
        this.cOrderIDIndex = 0;
        this.cOrderDetailsForBankSettle = new OrderDetailsForBankSettleProcEntity();
        this.cDirectBankSettlementSingleDetail = new DirectBankSettlementProcEntity();
        //        this.cDirectSettlementsTransactionLog = new DirectSettlementsTransactionLog();
        this.sTitleService.setTitle(this.sTitleService.DirectBankSettlements);
        this.cTransactionDetailsReq = new TransactionDetailsReq();
    }
    ngOnInit() {
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (mCommonResponse.isSuccess) {
                    if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                        this.cDirectBankSettlements.pageTotalCount = mCommonResponse.data.pageTotalCount;
                        this.cCardsList = mCommonResponse.data.CardsListProcEntity;
                        this.cCardTypeList = [];
                        for (let pCardType of this.cCardsList) {
                            this.cCardTypeList.push({ label: pCardType.cardTypeDesc, value: pCardType.cardType });
                        }
                        this.cGatewayList = mCommonResponse.data.GatewayList;
                        this.cBankList = [];
                        for (let pbank of this.cGatewayList) {
                            this.cBankList.push({ label: pbank.gtwName, value: pbank.gtwId });
                        }
                        this.cDirectBankSettlementProcEntity = mCommonResponse.data.directBankSettlementProcEntityList;
                        if (this.cDirectBankSettlementProcEntity.length == 0) {
                            this.landingPageMsg = this.sLandingPageMsgService.noReportsMsg;
                        }
                        this.cCardNameListProcEntity = mCommonResponse.data.CardNameListProcEntity;
                        this.cCardNameList = [];
                        for (let pCardName of this.cCardNameListProcEntity) {
                            this.cCardNameList.push({ label: pCardName.card_name, value: pCardName.card_name });
                        }
                    }
                }
                else if (mCommonResponse.isFail) {
                    this.cDirectBankSettlements.isNoRecordAfterSearch = false;
                    this.cDirectBankSettlementProcEntity = null;
                    this.landingPageMsg = this.sLandingPageMsgService.noReportsMsg;
                    console.log(this.sLandingPageMsgService.noReportsMsg);
                    this.cDirectBankSettlementsReq.searchPageSize = 0;
                    if (!this.sResponsiveService.isCancelResponsive()) {
                        this.cDirectBankSettlements.isSearchPanelClick = false;
                    }
                }
            }
        });
    }
    onSearchClick(event) {
        this.cDirectBankSettlementsReq.vActivity = event;
        this.cDirectBankSettlements.isSearchPanelClick = false;
        this.sDirectBankSettlementsService.fetchDirectBankSettlementReport(this.cDirectBankSettlementsReq)
            .subscribe(pResponse => { this.fetchDirectBankSettlementReport(pResponse); }, error => { console.log('error'); });
    }
    //***********************************************Button Click Event*******************************************//
    onExportExcelClick() {
        this.cDirectBankSettlements.isExportClick = !this.cDirectBankSettlements.isExportClick;
        this.sDirectBankSettlementsService.exportDirectBankSettlementReport(this.cDirectBankSettlementsReq)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    onExportClick() {
        this.cDirectBankSettlements.isSearchPanelClick = false;
        this.cDirectBankSettlements.isExportClick = !this.cDirectBankSettlements.isExportClick;
    }
    onSearchPanelClick() {
        this.cDirectBankSettlements.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cDirectBankSettlements.isSearchPanelClick = !this.cDirectBankSettlements.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cDirectBankSettlements.isSearchPanelClick = false;
            this.cDirectBankSettlementsReq.searchBy = null;
            this.cDirectBankSettlementsReq.searchFromDate = null;
            this.cDirectBankSettlementsReq.searchToDate = null;
            this.cDirectBankSettlementsReq.searchSubAccId = null;
            this.cDirectBankSettlementsReq.searchCurrency = null;
            this.cDirectBankSettlementsReq.searchCardType = null;
            this.cDirectBankSettlementsReq.searchCardName = null;
            this.cDirectBankSettlementsReq.searchBank = null;
        }
        this.cDirectBankSettlementsReq.searchPageSize = 25;
        this.cDirectBankSettlements.fromToDate = '';
        this.onSearchClick('DirectBank');
    }
    onSingleOrderIDClick(pTrackingId) {
        this.cTransactionDetailsReq.trackingId = pTrackingId;
        this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
            .subscribe(pResponse => {
            window.scrollTo(0, 0);
            this.fetchTransactionDetailsSuccess(pResponse);
        }, error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    onBackClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cDirectBankSettlements.isSearchPanelClick = false;
        }
        this.sResponsiveService.closeDetails();
        this.cDirectBankSettlements.isSingleOrderIDClick = false;
        this.cDirectBankSettlements.isBackClick = false;
        this.onSearchClick('DirectBank');
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cDirectBankSettlements.isExportClick = false;
    }
    //***********************************************Server Call Event*******************************************//
    fetchDirectBankSettlementReport(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                if (this.sCheck.isNotNullObject(pResponse.data)) {
                    //this.cDirectBankSettlementsReq.searchPageSize = mCommonResponse.data.pageTotalCount as number;
                    this.cDirectBankSettlements.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cCardsList = mCommonResponse.data.CardsListProcEntity;
                    this.cCardTypeList = [];
                    for (let pCardType of this.cCardsList) {
                        this.cCardTypeList.push({ label: pCardType.cardTypeDesc, value: pCardType.cardType });
                    }
                    this.cGatewayList = mCommonResponse.data.GatewayList;
                    this.cBankList = [];
                    for (let pbank of this.cGatewayList) {
                        this.cBankList.push({ label: pbank.gtwName, value: pbank.gtwId });
                    }
                    this.cDirectBankSettlementProcEntity = mCommonResponse.data.directBankSettlementProcEntityList;
                    if (this.cDirectBankSettlementProcEntity.length == 0) {
                        this.landingPageMsg = 'No Record Found';
                    }
                    this.cCardNameListProcEntity = mCommonResponse.data.CardNameListProcEntity;
                    this.cCardNameList = [];
                    for (let pCardName of this.cCardNameListProcEntity) {
                        this.cCardNameList.push({ label: pCardName.card_name, value: pCardName.card_name });
                    }
                }
            }
            else if (mCommonResponse.isFail) {
                this.cDirectBankSettlementProcEntity = null;
                this.cDirectBankSettlements.isNoRecordAfterSearch = true;
                this.landingPageMsg = 'No Record Found';
                console.log(mCommonResponse.messageDesc);
                this.cDirectBankSettlementsReq.searchPageSize = 0;
                this.cDirectBankSettlements.pageTotalCount = 0;
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cDirectBankSettlements.isSearchPanelClick = false;
                }
            }
            else {
                this.cDirectBankSettlements.isNoRecordAfterSearch = true;
                console.log(mCommonResponse.messageDesc);
                this.landingPageMsg = 'No Record Found';
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cDirectBankSettlements.isSearchPanelClick = false;
                }
            }
        }
        else {
            this.cDirectBankSettlements.isNoRecordAfterSearch = true;
            this.cDirectBankSettlementProcEntity = null;
            console.log(this.sErrorMessagesService.responseNull);
            this.landingPageMsg = 'No Record Found';
            if (!this.sResponsiveService.isCancelResponsive()) {
                this.cDirectBankSettlements.isSearchPanelClick = false;
            }
        }
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.isTransactionDetailClick = true;
            }
            if (this.isTransactionDetailClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onPageChange(event) {
        this.cDirectBankSettlementsReq.searchPageSize = event.cPageSize;
        this.cDirectBankSettlementsReq.searchPageNo = event.cPageNo;
        this.onSearchClick('DirectBank');
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cDirectBankSettlementsReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cDirectBankSettlementsReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cDirectBankSettlements.fromToDate = this.cDirectBankSettlementsReq.searchFromDate + ' - ' + this.cDirectBankSettlementsReq.searchToDate;
    }
};
DirectBankSettlementsComponent = tslib_1.__decorate([
    Component({
        selector: 'app-direct-bank-settlements',
        templateUrl: './direct-bank-settlements.component.html',
        styleUrls: ['./direct-bank-settlements.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [BsModalService,
        DirectBankSettlementsService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        TitleService,
        TransactionsService])
], DirectBankSettlementsComponent);
export { DirectBankSettlementsComponent };
//# sourceMappingURL=direct-bank-settlements.component.js.map