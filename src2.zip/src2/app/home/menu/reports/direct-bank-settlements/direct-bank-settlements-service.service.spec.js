import { TestBed, inject } from '@angular/core/testing';
import { DirectBankSettlementsService } from './direct-bank-settlements.service';
describe('DirectBankSettlementsService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DirectBankSettlementsService]
        });
    });
    it('should be created', inject([DirectBankSettlementsService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=direct-bank-settlements-service.service.spec.js.map