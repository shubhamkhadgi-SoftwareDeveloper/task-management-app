import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let InvalidRequestReportService = class InvalidRequestReportService {
    constructor() { }
};
InvalidRequestReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], InvalidRequestReportService);
export { InvalidRequestReportService };
//# sourceMappingURL=invalid-request-report.service.js.map