export class InvalidRequestReqDto {
    constructor() {
        this.pageNumber = 1;
        this.searchPageSize = 25;
        var myVariable = new Date();
        var makeDate = new Date(myVariable);
        var today = new Date();
        var dd = today.getDate();
        var ddS = today.getDate().toString();
        var mm = today.getMonth() + 1; //January is 0
        var mmS = mm.toString();
        var yyyy = today.getFullYear();
        if (dd < 10) {
            ddS = '0' + dd;
        }
        if (mm < 10) {
            mmS = '0' + mm;
        }
        var todayDate = ddS + '-' + mmS + '-' + yyyy;
        this.fromDate = todayDate;
        this.toDate = todayDate;
    }
}
//# sourceMappingURL=InvalidRequest.req.js.map