export class InvalidRequestResponseProc {
}
//# sourceMappingURL=InvalidRequestProcEntity.js.map