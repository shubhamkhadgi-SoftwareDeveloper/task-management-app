import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { InvalidRequestReqDto } from "./InvalidRequest.req";
import { InvalidRequestResDto } from "./InvalidRequest.res";
import { InvalidRequestSuccessFull } from "./InvalidRequestSuccessFull.class";
import { InvalidRequestResponseProc } from './InvalidRequestProcEntity';
import { InvalidRequestService } from "./InvalidRequest-report.service";
import { TitleService } from './../../../../common-services/title.service';
import { TransactionDetailsReq } from '../../transactions/transactions/transactionDetails.req';
import { TransactionsService } from '../../transactions/transactions/transactions.service';
let InvalidRequestReportComponent = class InvalidRequestReportComponent {
    constructor(pInvalidRequestService, cdr, modalService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, sTitleService, pTransactionsService) {
        this.pInvalidRequestService = pInvalidRequestService;
        this.cdr = cdr;
        this.modalService = modalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.sTitleService = sTitleService;
        this.pTransactionsService = pTransactionsService;
        this.cIsWritePrivilege = false;
        this.cInvalidRequestResponseProcArr = [];
        this.pageCount = 0;
        this.searchflag = 'seachform';
        this.isSearchByClick = false;
        this.cInvalidRequestReqDto = new InvalidRequestReqDto();
        this.cInvalidRequestSuccessFull = new InvalidRequestSuccessFull();
        this.cInvalidRequestResponseProc = new InvalidRequestResponseProc();
        this.cInvalidRequestResDto = new InvalidRequestResDto();
        this.sTitleService.setTitle(this.sTitleService.InvalidRequestReport);
        this.cTransactionDetailsReq = new TransactionDetailsReq();
    }
    //***********************************************Life Hooks Event*******************************************//
    ngOnInit() {
        this.cInvalidRequestSuccessFull.fromToDate = this.cInvalidRequestReqDto.fromDate + ' - ' + this.cInvalidRequestReqDto.toDate;
        this.tDate = this.cInvalidRequestReqDto.toDate;
        this.createForm();
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cInvalidRequestSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['InvalidRequestReportProcEntity'])) {
                        this.cInvalidRequestResponseProcArr = mCommonResponse.data['InvalidRequestReportProcEntity'];
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                        this.sResponsiveService.closeSearch();
                    }
                }
                else {
                    this.cInvalidRequestResponseProcArr = null;
                    this.landingPageMsg = "No Invalid Request Report were found!";
                    this.sResponsiveService.closeSearch();
                }
            }
        });
        this.fetchInvalidReport();
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Validations*******************************************//
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: ['', [Validators.required]],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    fetchInvalidReport() {
        this.pInvalidRequestService.getInvalidRequestReportList(this.cInvalidRequestReqDto)
            .subscribe(rResponse => this.fetchAllInvalidReport(rResponse), error => { console.log('error'); });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.cInvalidRequestReqDto.searchByValue != null) {
                this.cInvalidRequestReqDto.fromDate = "01-01-2000";
                this.cInvalidRequestReqDto.toDate = this.tDate;
            }
            this.pInvalidRequestService.getInvalidRequestReportList(this.cInvalidRequestReqDto)
                .subscribe(rResponse => this.fetchAllInvalidReport(rResponse), error => { console.log('error'); });
            this.searchflag = 'seachform';
        }
        else {
            CustomValidator.validateAllFields(this.mForm);
        }
    }
    onSearchPanelClick() {
        this.cInvalidRequestSuccessFull.isSearchByClick = false;
        this.mForm.controls['searchByValue'].disable();
        this.sResponsiveService.openSearch();
    }
    onSearchByOptionClick(pOption) {
        this.cInvalidRequestSuccessFull.isSearchByClick = !this.cInvalidRequestSuccessFull.isSearchByClick;
        this.cInvalidRequestReqDto.searchBy = pOption.value;
        this.cInvalidRequestSuccessFull.searchByLabel = pOption.label;
        this.cInvalidRequestReqDto.searchByValue = null;
        if (this.cInvalidRequestSuccessFull.searchByLabel == 'Search By') {
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cInvalidRequestSuccessFull.searchByLabel == 'Order #' || this.cInvalidRequestSuccessFull.searchByLabel == 'CCAvenue Ref.#') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
    }
    onSearchByClick() {
        this.cInvalidRequestSuccessFull.isExportClick = false;
        this.cInvalidRequestSuccessFull.isSearchByClick = !this.cInvalidRequestSuccessFull.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.isSearchByClick = false;
    }
    onSingleOrderIDClick(pTrackingId) {
        if (pTrackingId != null) {
            this.cTransactionDetailsReq.trackingId = pTrackingId;
            this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
                .subscribe(pResponse => {
                window.scrollTo(0, 0);
                this.fetchTransactionDetailsSuccess(pResponse);
            }, error => { console.log(this.sErrorMessagesService.errorResponse); });
        }
    }
    onCancelClick() {
        this.cInvalidRequestReqDto = null;
        this.cInvalidRequestReqDto = new InvalidRequestReqDto();
        this.cInvalidRequestReqDto.regIds = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvalidRequestSuccessFull.isSearchPanelClick = false;
        }
        this.cInvalidRequestSuccessFull = new InvalidRequestSuccessFull();
        this.cInvalidRequestReqDto.searchByValue = null;
        this.cInvalidRequestSuccessFull.fromToDate = this.cInvalidRequestReqDto.fromDate + ' - ' + this.cInvalidRequestReqDto.toDate;
        this.fetchInvalidReport();
        this.sResponsiveService.closeSearch();
    }
    onBackClick() {
        this.cInvalidRequestSuccessFull.isOrderIDClick = false;
        this.sResponsiveService.closeDetails();
    }
    onExportClick() {
        this.cInvalidRequestSuccessFull.isSearchByClick = false;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cInvalidRequestSuccessFull.isSearchPanelClick = false;
        }
        this.cInvalidRequestSuccessFull.isSelectActionClick = false;
        this.cInvalidRequestSuccessFull.selectedSI = [];
        this.cInvalidRequestSuccessFull.isExportClick = !this.cInvalidRequestSuccessFull.isExportClick;
    }
    onExportExcelClick() {
        this.cInvalidRequestSuccessFull.isExportClick = !this.cInvalidRequestSuccessFull.isExportClick;
        this.cInvalidRequestReqDto.regId = this.pMerchInfoService.getRegId();
        this.pInvalidRequestService.exportExcelAbortedTransList(this.cInvalidRequestReqDto)
            .subscribe(pResponse => { console.log('success'); }, error => { console.log('error'); });
    }
    //***********************************************Select Event************************************************//
    selectedDate(value) {
        this.cInvalidRequestReqDto.fromDate = value.start.format("DD-MM-YYYY");
        this.cInvalidRequestReqDto.toDate = value.end.format("DD-MM-YYYY");
        this.fromDate = value.start.format("DD-MM-YYYY");
        this.toDate = value.end.format("DD-MM-YYYY");
        this.cInvalidRequestSuccessFull.fromToDate = this.cInvalidRequestReqDto.fromDate + ' - ' + this.cInvalidRequestReqDto.toDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchAllInvalidReport(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.cInvalidRequestSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                if (this.sCheck.isNotNullList(mCommonResponse.data['InvalidRequestReportProcEntity'])) {
                    this.cInvalidRequestResponseProcArr = mCommonResponse.data['InvalidRequestReportProcEntity'];
                    this.pageCount = mCommonResponse.data['pageTotalCount'];
                    this.sResponsiveService.closeSearch();
                }
            }
            else {
                this.sResponsiveService.closeSearch();
                this.cInvalidRequestResponseProcArr = null;
                this.landingPageMsg = "No Invalid Request Report were found!";
            }
        }
        this.cInvalidRequestSuccessFull.selectedSI = [];
        this.cInvalidRequestSuccessFull.isSelectActionClick = false;
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.cInvalidRequestSuccessFull.isOrderIDClick = true;
            }
            if (this.cInvalidRequestSuccessFull.isOrderIDClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    onPageChange(event) {
        this.cInvalidRequestReqDto.searchPageSize = event.cPageSize;
        this.cInvalidRequestReqDto.pageNumber = event.cPageNo;
        this.cInvalidRequestSuccessFull.selectedSI = [];
        this.cInvalidRequestSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
};
InvalidRequestReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-invalid-request-report',
        templateUrl: './invalid-request-report.component.html',
        styleUrls: ['./invalid-request-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [InvalidRequestService,
        ChangeDetectorRef,
        BsModalService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        TitleService,
        TransactionsService])
], InvalidRequestReportComponent);
export { InvalidRequestReportComponent };
//# sourceMappingURL=invalid-request-report.component.js.map