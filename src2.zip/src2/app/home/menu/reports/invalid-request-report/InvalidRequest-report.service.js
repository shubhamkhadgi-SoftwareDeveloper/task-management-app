import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let InvalidRequestService = class InvalidRequestService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'invalidRequestReport/';
        this.cGetAllInvalidRequestUrl = this.cBaseUrl + 'getInvalidRequestReportList';
        this.cExportExcelInvalidRequestReportUrl = this.cBaseUrl + 'exportExcelInvalidRequestReport';
    }
    getInvalidRequestReportList(pInvalidRequestReqDto) {
        return this.pApiRequestService.httpPostRequest(pInvalidRequestReqDto, this.cGetAllInvalidRequestUrl);
    }
    exportExcelAbortedTransList(pInvalidRequestReqDto) {
        return this.pApiRequestService.exportFileRequest(pInvalidRequestReqDto, this.cExportExcelInvalidRequestReportUrl, "InvalidRequestReport.xlsx");
    }
};
InvalidRequestService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], InvalidRequestService);
export { InvalidRequestService };
//# sourceMappingURL=InvalidRequest-report.service.js.map