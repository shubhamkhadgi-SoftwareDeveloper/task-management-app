import { TestBed, inject } from '@angular/core/testing';
import { InvalidRequestReportService } from './invalid-request-report.service';
describe('InvalidRequestReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [InvalidRequestReportService]
        });
    });
    it('should be created', inject([InvalidRequestReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=invalid-request-report.service.spec.js.map