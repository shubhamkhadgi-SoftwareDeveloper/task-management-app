import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { InvalidRequestReqDto } from './InvalidRequest.req';
import { InvalidRequestService } from './InvalidRequest-report.service';
let InvalidRequestResolverService = class InvalidRequestResolverService {
    constructor(cInvalidRequestService) {
        this.cInvalidRequestService = cInvalidRequestService;
    }
    resolve(route, state) {
        let mInvalidRequestReqDto = new InvalidRequestReqDto();
        return this.cInvalidRequestService.getInvalidRequestReportList(mInvalidRequestReqDto).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
InvalidRequestResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [InvalidRequestService])
], InvalidRequestResolverService);
export { InvalidRequestResolverService };
//# sourceMappingURL=InvalidRequest-report.resolver.service.js.map