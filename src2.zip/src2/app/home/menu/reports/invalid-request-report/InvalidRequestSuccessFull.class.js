export class InvalidRequestSuccessFull {
    constructor() {
        this.isAllSISuccessCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.landingPageMsg = "No Invalid Request Record(s) were found!";
        this.selectedSI = [];
        this.isOrder = false;
        this.isOrderIDClick = false;
        this.searchByLabel = "Search By";
        this.searchBy = [];
        this.searchBy.push({ label: 'Search By', value: '' });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref.#', value: 'trackingId' });
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            //timePicker: true,
            //timePicker12Hour: true,
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.currDate = new Date();
    }
}
//# sourceMappingURL=InvalidRequestSuccessFull.class.js.map