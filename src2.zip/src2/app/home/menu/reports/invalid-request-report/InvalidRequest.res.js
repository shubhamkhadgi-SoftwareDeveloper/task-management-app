export class InvalidRequestResDto {
    constructor() {
        // this.cServiceInvoiceReportResponse = new ServiceInvoiceReportResponse();
    }
}
//# sourceMappingURL=InvalidRequest.res.js.map