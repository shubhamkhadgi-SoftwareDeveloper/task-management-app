import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let ReconciliationReportService = class ReconciliationReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'reconciliationReport/';
        this.cFetchReconciliationReportUrl = this.cBaseUrl + 'fetchReconciliationReport';
        this.cExportReconciliationReportUrl = this.cBaseUrl + 'exportReconciliationReport';
    }
    fetchReconciliationReport(pReconciliationReportReq) {
        return this.pApiRequestService.httpPostRequest(pReconciliationReportReq, this.cFetchReconciliationReportUrl);
    }
    exportReconciliationReport(pReconciliationReportReq) {
        return this.pApiRequestService.exportFileRequest(pReconciliationReportReq, this.cExportReconciliationReportUrl, "ReconciliationReport.xlsx");
    }
};
ReconciliationReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], ReconciliationReportService);
export { ReconciliationReportService };
//# sourceMappingURL=reconciliation-report.service.js.map