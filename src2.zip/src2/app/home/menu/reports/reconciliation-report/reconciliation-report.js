export class ReconciliationReport {
    constructor() {
        this.isSingleOrderIDClick = false;
        this.isSearchPanelClick = false;
        this.isNoRecordAfterSearch = true;
        this.timePanel = false;
        this.actionPanel = false;
        this.isExportClick = false;
        this.isSelActionClick = false;
        this.isSearchByClick = false;
        this.closeButton = false;
        this.isSearchClickDropdown = true;
        this.isSearchFound = false;
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            dateLimit: {
                days: 30
            },
            maxDate: new Date(),
        };
        this.isSearchClickDropdown = true;
        this.status.push({ label: 'Active', value: 'ACTI' });
        this.status.push({ label: 'Inactive', value: 'INAC' });
        this.status.push({ label: 'Expired', value: 'EXPD' });
        this.status.push({ label: 'Cancelled', value: 'CANC' });
        this.searchBy = [];
        this.searchBy.push({ label: 'Search by', value: null });
        this.searchBy.push({ label: 'Order #', value: 'orderNo' });
        this.searchBy.push({ label: 'CCAvenue Ref. #', value: 'trackingId' });
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=reconciliation-report.js.map