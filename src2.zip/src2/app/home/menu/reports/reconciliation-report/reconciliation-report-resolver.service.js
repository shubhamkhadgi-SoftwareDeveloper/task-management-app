import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Router } from '@angular/router';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ReconciliationReportReq } from './reconciliation-report-req';
import { ReconciliationReportService } from './reconciliation-report.service';
let ReconciliationReportResolverService = class ReconciliationReportResolverService {
    constructor(sReconciliationReportService, sRouter, pMerchInfoService) {
        this.sReconciliationReportService = sReconciliationReportService;
        this.sRouter = sRouter;
        this.pMerchInfoService = pMerchInfoService;
    }
    resolve(route, state) {
        let mReconciliationReportReq = new ReconciliationReportReq();
        mReconciliationReportReq.searchMerchantArr = ['' + this.pMerchInfoService.getRegId()];
        return this.sReconciliationReportService.fetchReconciliationReport(mReconciliationReportReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
ReconciliationReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ReconciliationReportService,
        Router,
        MerchInfoService])
], ReconciliationReportResolverService);
export { ReconciliationReportResolverService };
//# sourceMappingURL=reconciliation-report-resolver.service.js.map