import * as tslib_1 from "tslib";
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ReconciliationReport } from './reconciliation-report';
import { ReconciliationReportService } from './reconciliation-report.service';
import { ReconciliationReportReq } from './reconciliation-report-req';
import { ReconciliationReportProcEntity } from '../../../../proc-entities/reconciliation-report-proc-entity';
import { CustomValidator } from '../../../../custom-validator/custom-validator';
import { Transactions } from '../../transactions/transactions/transactions.class';
import { TransactionDetailsReq } from '../../transactions/transactions/transactionDetails.req';
import { TransactionWrapperRes } from '../../transactions/transactions/transactionWrapper.res';
import { TransactionsService } from '../../transactions/transactions/transactions.service';
import { TitleService } from './../../../../common-services/title.service';
let ReconciliationReportComponent = class ReconciliationReportComponent {
    constructor(pTransactionsService, cdr, pDatePipe, pFormBuilder, pModalService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sErrorHandler, sReconciliationReportService, sTitleService) {
        this.pTransactionsService = pTransactionsService;
        this.cdr = cdr;
        this.pDatePipe = pDatePipe;
        this.pFormBuilder = pFormBuilder;
        this.pModalService = pModalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sErrorHandler = sErrorHandler;
        this.sReconciliationReportService = sReconciliationReportService;
        this.sTitleService = sTitleService;
        this.cardNumber = null;
        this.orderTax = -1.00;
        this.landingPageMsg = null;
        this.cReconciliationReportProcEntity = [];
        this.cSearchFlag = false;
        this.isTransactionDetailClick = false;
        this.cReconciliationReport = new ReconciliationReport();
        this.cReconciliationReportReq = new ReconciliationReportReq();
        this.cReconciliationReportDetail = new ReconciliationReportProcEntity();
        this.cTransactions = new Transactions();
        this.cTransactionDetailsReq = new TransactionDetailsReq();
        this.cTransactionWrapperRes = new TransactionWrapperRes();
        this.sTitleService.setTitle(this.sTitleService.ReconciliationReport);
    }
    ngOnInit() {
        this.createForm();
        this.mForm.controls['searchByValue'].disable();
        this.datebefore = new Date();
        this.datebefore.setDate(this.datebefore.getDate() - 1);
        this.toDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.fromDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.cReconciliationReport.fromToDate = this.toDate + '-' + this.fromDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cReconciliationReport.pageTotalCount = mCommonResponse.data.pageTotalCount;
                    this.cReconciliationReportProcEntity = mCommonResponse.data.ReconciliationReport;
                }
                else {
                    console.log(mCommonResponse.messageDesc);
                    this.landingPageMsg = 'No records found.';
                }
            }
            else {
                this.landingPageMsg = 'No records found.';
                console.log(mCommonResponse.messageDesc);
            }
        });
    }
    //***********************************************Server Call Event*******************************************//
    fetchReconciliationReportSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cReconciliationReport.pageTotalCount = mCommonResponse.data['pageTotalCount'];
                this.cReconciliationReportProcEntity = mCommonResponse.data['ReconciliationReport'];
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cReconciliationReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchReconciliation(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchReconciliation(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No Record Found';
            this.onFailFetchReconciliation(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchReconciliation(pResMsg) {
        console.log(pResMsg);
        this.landingPageMsg = 'No Record Found';
        this.cReconciliationReport.pageTotalCount = null;
        this.cReconciliationReportProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cReconciliationReport.isSearchPanelClick = false;
        }
    }
    onPageChange(event) {
        this.cReconciliationReportReq.searchPageSize = event.cPageSize;
        this.cReconciliationReportReq.searchPageNo = event.cPageNo;
        this.cSearchFlag = false;
        this.onSearchClick();
    }
    //***********************************************Button Click Event*******************************************//
    onExportClick() {
        this.cReconciliationReport.isSearchPanelClick = false;
        this.cReconciliationReport.isExportClick = !this.cReconciliationReport.isExportClick;
    }
    onExportExcelClick() {
        if (this.cReconciliationReportReq.searchMerchantArr.length <= 0)
            this.cReconciliationReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
        this.cReconciliationReport.isExportClick = !this.cReconciliationReport.isExportClick;
        this.sReconciliationReportService.exportReconciliationReport(this.cReconciliationReportReq)
            .subscribe(pResponse => {
        }, error => { console.log('error'); });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.cSearchFlag) {
                this.cReconciliationReportReq.searchPageNo = 1;
            }
            if (this.cReconciliationReportReq.searchMerchantArr.length < 1)
                this.cReconciliationReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
            this.sReconciliationReportService.fetchReconciliationReport(this.cReconciliationReportReq)
                .subscribe(pResponse => { this.fetchReconciliationReportSuccess(pResponse); }, error => { console.log('error'); });
            this.cSearchFlag = true;
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchByClick() {
        this.cReconciliationReport.isSearchByClick = !this.cReconciliationReport.isSearchByClick;
    }
    onDropdownCloseClick() {
        this.cReconciliationReport.isSearchByClick = false;
    }
    onSearchButtonClick() {
        this.cReconciliationReport.isSearchPanelClick = false;
        this.cReconciliationReportReq.searchPageNo = 1;
        this.onSearchClick();
    }
    onSearchByOptionClick(option) {
        this.cReconciliationReport.isSearchByClick = !this.cReconciliationReport.isSearchByClick;
        this.cReconciliationReport.searchByLabel = option.label;
        this.cReconciliationReportReq.searchBy = option.value;
        console.log(this.cReconciliationReportReq.searchBy);
        if (option.label == 'Search by') {
            this.cReconciliationReport.isSearchClickDropdown = true;
        }
        else {
            this.cReconciliationReport.isSearchClickDropdown = false;
        }
        if (this.cReconciliationReportReq.searchBy == 'trackingId') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.numbersOnly, Validators.required]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else if (this.cReconciliationReportReq.searchBy == 'orderNo') {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].enable();
            this.mForm.controls['searchByValue'].dirty;
            this.mForm.controls['searchByValue'].markAsTouched({ onlySelf: true });
            this.mForm.controls['searchByValue'].setValidators([CustomValidator.letterAndNumberOnly, Validators.required]);
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        else {
            this.mForm.controls['searchByValue'].setValue(null);
            this.mForm.controls['searchByValue'].clearValidators();
            this.mForm.controls['searchByValue'].disable();
            this.mForm.controls['searchByValue'].updateValueAndValidity();
        }
        // console.log(option.label);
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            searchMerchantArr: [''],
            searchSubAccId: [''],
            fromToDate: ['', [Validators.required]]
        });
    }
    onBackClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cReconciliationReport.isSearchPanelClick = false;
        }
        this.isTransactionDetailClick = false;
        this.sResponsiveService.closeDetails();
    }
    onSearchPanelClick() {
        this.cReconciliationReport.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cReconciliationReport.isSearchPanelClick = !this.cReconciliationReport.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cReconciliationReport.isSearchPanelClick = false;
            this.cReconciliationReport.fromToDate = '';
            this.cReconciliationReportReq.searchBy = null;
            this.cReconciliationReportReq.searchFromDate = null;
            this.cReconciliationReport.fromToDate = null;
            this.mForm.controls['fromToDate'].clearValidators();
            this.mForm.controls['fromToDate'].updateValueAndValidity();
            this.cReconciliationReportReq.searchToDate = null;
            this.cReconciliationReportReq.searchSubAccId = null;
            this.cReconciliationReport = new ReconciliationReport();
            this.cReconciliationReportReq = new ReconciliationReportReq();
            this.mForm.controls['searchByValue'].disable();
            this.onSearchClick();
            this.datebefore = new Date();
            this.datebefore.setDate(this.datebefore.getDate() - 1);
            this.toDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.fromDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.cReconciliationReport.fromToDate = this.toDate + '-' + this.fromDate;
        }
    }
    onSingleOrderIDClick(pTrackingId) {
        this.cTransactionDetailsReq.trackingId = pTrackingId;
        this.pTransactionsService.fetchTransDetailsList(this.cTransactionDetailsReq)
            .subscribe(pResponse => {
            window.scrollTo(0, 0);
            this.fetchTransactionDetailsSuccess(pResponse);
        }, error => { console.log(this.sErrorMessagesService.errorResponse); });
    }
    fetchTransactionDetailsSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cTransactionWrapperRes = pResponse.data;
            if (this.sCheck.isNotNullObject(this.cTransactionWrapperRes) && this.sCheck.isNotNullObject(this.cTransactionWrapperRes.transactionDetailsProcEntity)) {
                this.isTransactionDetailClick = true;
            }
            if (this.isTransactionDetailClick) {
                this.sResponsiveService.openDetails();
            }
        }
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cReconciliationReportReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cReconciliationReportReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cReconciliationReport.fromToDate = this.cReconciliationReportReq.searchFromDate + ' - ' + this.cReconciliationReportReq.searchToDate;
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cReconciliationReport.isExportClick = false;
    }
};
ReconciliationReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-reconciliation-report',
        templateUrl: './reconciliation-report.component.html',
        styleUrls: ['./reconciliation-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [TransactionsService,
        ChangeDetectorRef,
        DatePipe,
        FormBuilder,
        BsModalService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        ErrorHandlerService,
        ReconciliationReportService,
        TitleService])
], ReconciliationReportComponent);
export { ReconciliationReportComponent };
//# sourceMappingURL=reconciliation-report.component.js.map