import { TestBed, inject } from '@angular/core/testing';
import { ReconciliationReportService } from './reconciliation-report.service';
describe('ReconciliationReportService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ReconciliationReportService]
        });
    });
    it('should be created', inject([ReconciliationReportService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=reconciliation-report.service.spec.js.map