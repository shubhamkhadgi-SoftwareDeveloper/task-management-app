export class ReconciliationReportReq {
    constructor() {
        this.searchSubAccId = [];
        this.searchMerchantArr = [];
        this.searchPageSize = 25;
        this.searchPageNo = 1;
    }
}
//# sourceMappingURL=reconciliation-report-req.js.map