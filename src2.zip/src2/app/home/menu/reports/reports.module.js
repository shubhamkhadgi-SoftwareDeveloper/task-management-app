import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonAndThirdPartyModule } from '../../../common-modules/common-and-third-party.module';
import { ReportsRoutingModule, ReportsRoutedComponents } from './reports.routing';
import { ReconciliationReportComponent } from './reconciliation-report/reconciliation-report.component';
import { CCAvenueServiceInvoiceComponent } from './ccavenue-service-invoice/ccavenue-service-invoice.component';
import { UnsettledTransactionReportComponent } from './unsettled-transaction-report/unsettled-transaction-report.component';
import { InvalidRequestReportComponent } from './invalid-request-report/invalid-request-report.component';
import { RefundAnalysisReportComponent } from './refund-analysis-report/refund-analysis-report.component';
import { SalesReportbyPaymentTypeComponent } from './sales-reportby-payment-type/sales-reportby-payment-type.component';
import { RetriedTransactionReportComponent } from './retried-transaction-report/retried-transaction-report.component';
import { UserAuditLogsComponent } from './user-audit-logs/user-audit-logs.component';
import { AbortedTransactionReportComponent } from './aborted-transaction-report/aborted-transaction-report.component';
import { SubAccountReportComponent } from './sub-account-report/sub-account-report.component';
import { FailureAnalysisReportComponent } from './failure-analysis-report/failure-analysis-report.component';
import { PayoutSummaryComponent } from './payout-summary/payout-summary.component';
import { PayoutSummarySalesComponent } from './payout-summary/payout-summary-sales/payout-summary-sales.component';
import { PayoutSummaryRefundsComponent } from './payout-summary/payout-summary-refunds/payout-summary-refunds.component';
import { PayoutSummaryChargebackComponent } from './payout-summary/payout-summary-chargeback/payout-summary-chargeback.component';
import { GatewayPerformanceReportComponent } from './gateway-performance-report/gateway-performance-report.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { InitiatedRefundAnalysisReportComponent } from './refund-analysis-report/initiated-refund-analysis-report/initiated-refund-analysis-report.component';
import { FailedRefundAnalysisReportComponent } from './refund-analysis-report/failed-refund-analysis-report/failed-refund-analysis-report.component';
import { FailureAnalysisDetailsComponent } from './failure-analysis-report/failure-analysis-details/failure-analysis-details.component';
import { PendingRefundAnalysisReportComponent } from './refund-analysis-report/pending-refund-analysis-report/pending-refund-analysis-report.component';
import { SuccessfulRefundAnalysisReportComponent } from './refund-analysis-report/successful-refund-analysis-report/successful-refund-analysis-report.component';
import { TransactionsModule } from '../transactions/transactions.module';
let ReportsModule = class ReportsModule {
};
ReportsModule = tslib_1.__decorate([
    NgModule({
        imports: [
            ReportsRoutingModule,
            CommonAndThirdPartyModule,
            TransactionsModule
        ],
        declarations: [ReportsRoutedComponents, ReconciliationReportComponent, CCAvenueServiceInvoiceComponent,
            UnsettledTransactionReportComponent, InvalidRequestReportComponent, RefundAnalysisReportComponent,
            SalesReportbyPaymentTypeComponent, RetriedTransactionReportComponent, UserAuditLogsComponent,
            AbortedTransactionReportComponent, SubAccountReportComponent, FailureAnalysisReportComponent,
            FailureAnalysisDetailsComponent, PayoutSummaryComponent, PayoutSummarySalesComponent,
            PayoutSummaryRefundsComponent, PayoutSummaryChargebackComponent, GatewayPerformanceReportComponent,
            SalesReportComponent, InitiatedRefundAnalysisReportComponent, FailedRefundAnalysisReportComponent,
            PendingRefundAnalysisReportComponent, SuccessfulRefundAnalysisReportComponent]
    })
], ReportsModule);
export { ReportsModule };
//# sourceMappingURL=reports.module.js.map