export class ServiceInvoiceReportResponse {
}
//# sourceMappingURL=ServiceInvoiceReportResponseDTO.js.map