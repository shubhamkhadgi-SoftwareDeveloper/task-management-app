import { TestBed, inject } from '@angular/core/testing';
import { CCAvenueServiceInvoiceService } from './ccavenue-service-invoice.service';
describe('CCAvenueServiceInvoiceService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CCAvenueServiceInvoiceService]
        });
    });
    it('should be created', inject([CCAvenueServiceInvoiceService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=ccavenue-service-invoice.service.spec.js.map