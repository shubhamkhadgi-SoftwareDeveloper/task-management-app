export class CCAVSuccessFull {
    constructor() {
        this.isAllSISuccessCheck = false;
        this.isSelectActionClick = false;
        this.isSearchPanelClick = false;
        this.isSearchByClick = false;
        this.isExportClick = false;
        this.isOccurredCountClick = false;
        this.landingPageMsg = "No CCAvenue service invoices have been raised yet!";
        this.selectedSI = [];
        this.isInv = false;
        this.isInvIDClick = false;
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            // timePicker: true,
            //timePicker12Hour: true,
            maxDate: new Date(),
        };
        this.maxSearchDateTo = new Date();
        this.fromToDate = '';
        this.currDate = new Date();
    }
}
//# sourceMappingURL=CCAVServiceSuccessFull.class.js.map