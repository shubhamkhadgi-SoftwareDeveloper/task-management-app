import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { ActivatedRoute } from '@angular/router';
import { PrivilegeService } from '../../../../common-services/privilege.service';
import { ConditionalCheckService } from './../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { PdfPrintService } from '../../../../common-services/pdf-print.service';
import { MerchInfoService } from "../../../../common-services/merch-info/merch-info.service";
import { CCAvenueService } from "./CCAvenueService-report.service";
import { CCAVServiceReqDto } from "./CCAVService.req";
import { CCAVServiceResDto } from "./CCAVService.res";
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { CCAVSuccessFull } from "./CCAVServiceSuccessFull.class";
import { ServiceInvoiceReportResponse } from './ServiceInvoiceReportResponseDTO';
import { TitleService } from './../../../../common-services/title.service';
let CCAvenueServiceInvoiceComponent = class CCAvenueServiceInvoiceComponent {
    constructor(pCCAvenueService, pDatePipe, cdr, modalService, pMerchInfoService, pModalService, pFormBuilder, sResponsiveService, sCheck, sErrorHandler, sErrorMessagesService, sAlertMessageService, sLandingPageMsgService, sActivatedRoute, sPrivilegeService, pPdfPrintService, sTitleService) {
        this.pCCAvenueService = pCCAvenueService;
        this.pDatePipe = pDatePipe;
        this.cdr = cdr;
        this.modalService = modalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pModalService = pModalService;
        this.pFormBuilder = pFormBuilder;
        this.sResponsiveService = sResponsiveService;
        this.sCheck = sCheck;
        this.sErrorHandler = sErrorHandler;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sAlertMessageService = sAlertMessageService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sPrivilegeService = sPrivilegeService;
        this.pPdfPrintService = pPdfPrintService;
        this.sTitleService = sTitleService;
        this.checkStr = true;
        this.cServiceInvoiceReportResponseArr = [];
        this.cServiceInvoiceReportResponseArr2 = [];
        this.cIsWritePrivilege = false;
        this.pageCount = 0;
        this.isInvIdClick = false;
        this.isSearchByClick = false;
        this.cCCAVServiceReqDto = new CCAVServiceReqDto();
        this.cCCAVServiceResDtoError = new CCAVServiceResDto();
        this.cCCAVServiceResDto1 = new CCAVServiceResDto();
        this.cCCAVSuccessFull = new CCAVSuccessFull();
        this.cServiceInvoiceReportResponse = new ServiceInvoiceReportResponse();
        this.sTitleService.setTitle(this.sTitleService.CCAvenueServiceInvoice);
    }
    ngOnInit() {
        this.createForm();
        this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse)) {
                    if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                        this.cCCAVSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                        if (this.sCheck.isNotNullList(mCommonResponse.data['sCCAVServiceProcEntity'])) {
                            this.cServiceInvoiceReportResponseArr = mCommonResponse.data['sCCAVServiceProcEntity'];
                            this.sResponsiveService.closeSearch();
                            this.pageCount = mCommonResponse.data['pageTotalCount'];
                            this.sResponsiveService.closeSearch();
                        }
                    }
                    else {
                        this.cServiceInvoiceReportResponseArr = null;
                        this.landingPageMsg = "No CCAvenue Service Invoice Report were found!";
                        this.sResponsiveService.closeSearch();
                    }
                }
            }
        });
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchByValue: [''],
            fromToDate: ['', [Validators.required]],
            searchDisputeReasonArr: [''],
            searchDisputeStatusArr: [''],
            subAccountIdList: [''],
        });
    }
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
    fetchCCAV() {
        this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
        this.pCCAvenueService.fetchAllCCAvenueServiceInvoice(this.cCCAVServiceReqDto)
            .subscribe(rResponse => this.fetchCCAVService(rResponse), error => { console.log('error fetch'); });
    }
    fetchCCAVService(pResponse) {
        let mCommonResponse = new CommonResponse(pResponse);
        if (this.sCheck.isNotNullObject(mCommonResponse)) {
            if (this.sCheck.isNotNullObject(mCommonResponse)) {
                if (this.sCheck.isNotNullObject(mCommonResponse.data)) {
                    this.cCCAVSuccessFull.totalCount = mCommonResponse.data['pageTotalCount'];
                    if (this.sCheck.isNotNullList(mCommonResponse.data['sCCAVServiceProcEntity'])) {
                        this.cServiceInvoiceReportResponseArr = mCommonResponse.data['sCCAVServiceProcEntity'];
                        this.sResponsiveService.closeSearch();
                        this.pageCount = mCommonResponse.data['pageTotalCount'];
                        this.sResponsiveService.closeSearch();
                    }
                }
                else {
                    this.cServiceInvoiceReportResponseArr = null;
                    this.landingPageMsg = "No CCAvenue Service Invoice Report were found!";
                    this.sResponsiveService.closeSearch();
                }
            }
        }
        this.cCCAVSuccessFull.selectedSI = [];
        this.cCCAVSuccessFull.isSelectActionClick = false;
    }
    onSearchPanelClick() {
        this.sResponsiveService.openSearch();
    }
    onCancelClick() {
        this.cCCAVServiceReqDto = null;
        this.cCCAVServiceReqDto = new CCAVServiceReqDto();
        this.cCCAVServiceReqDto.regId = this.pMerchInfoService.getRegId();
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cCCAVSuccessFull.isSearchPanelClick = false;
            this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
        }
        if (this.fromDate != null) {
            this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
        }
        else {
            this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
        }
        this.cCCAVSuccessFull = new CCAVSuccessFull();
        this.fetchCCAV();
        this.sResponsiveService.closeSearch();
    }
    onSearchByClick() {
        this.cCCAVSuccessFull.isSearchByClick = !this.cCCAVSuccessFull.isSearchByClick;
    }
    onSearchByOptionClick(pOption) {
        this.cCCAVSuccessFull.isSearchByClick = !this.cCCAVSuccessFull.isSearchByClick;
        this.cCCAVServiceReqDto.searchBy = pOption.value;
        this.cCCAVSuccessFull.searchByLabel = pOption.label;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cCCAVServiceReqDto.fromDate = value.start.format("DD-MM-YYYY");
        this.cCCAVServiceReqDto.toDate = value.end.format("DD-MM-YYYY");
        this.fromDate = value.start.format("DD-MM-YYYY");
        this.toDate = value.end.format("DD-MM-YYYY");
        this.cCCAVSuccessFull.fromToDate = this.cCCAVServiceReqDto.fromDate + ' - ' + this.cCCAVServiceReqDto.toDate;
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            this.pCCAvenueService.fetchAllCCAvenueServiceInvoice(this.cCCAVServiceReqDto)
                .subscribe(rResponse => this.fetchCCAVService(rResponse), error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    onPageChange(event) {
        this.cCCAVServiceReqDto.searchPageSize = event.cPageSize;
        this.cCCAVServiceReqDto.pageNumber = event.cPageNo;
        this.cCCAVSuccessFull.selectedSI = [];
        this.cCCAVSuccessFull.isAllSISuccessCheck = false;
        this.onSearchClick();
    }
    onBackClick() {
        this.cCCAVSuccessFull.isInvIDClick = false;
        this.sResponsiveService.closeSearch();
    }
    onInvIdClick(pInvId) {
        if (pInvId != null) {
            this.cInvId = pInvId;
            this.cCCAVServiceReqDto.searchByInvoiceId = this.cInvId;
            this.pCCAvenueService.fetchCCAvenueServiceInvoiceById(this.cCCAVServiceReqDto)
                .subscribe(pResponse => this.fetchCCAVinvSuccess(pResponse), error => { console.log('error'); });
        }
    }
    fetchCCAVinvSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            this.cCCAVServiceResDto1 = pResponse.data;
            this.cServiceInvoiceReportResponseArr2 = pResponse.data['cServiceInvoiceReportResponse'];
            if (this.sCheck.isNotNullObject(this.cServiceInvoiceReportResponseArr2)) {
                this.cCCAVSuccessFull.isInvIDClick = true;
                this.cCCAVSuccessFull.isInv = true;
            }
        }
    }
    onPrintClick() {
        this.cCCAVServiceReqDto.searchByInvoiceId = this.cInvId;
        this.pCCAvenueService.printCCAVServiceInvoice(this.cCCAVServiceReqDto)
            .subscribe(pResponse => this.printInvSuccess(pResponse), error => { console.log('error'); });
    }
    printInvSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess && this.sCheck.isNotNullObject(mCommonResponse.data)) {
                this.pPdfPrintService.print(mCommonResponse.data);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
    onSendMailClick() {
        this.cCCAVServiceReqDto.searchByInvoiceId = this.cInvId;
        this.pCCAvenueService.sendCCAVServiceInvoice(this.cCCAVServiceReqDto)
            .subscribe(pResponse => this.sendMailSuccess(pResponse), error => { console.log('error'); });
    }
    sendMailSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else if (mCommonResponse.isFail) {
                this.sAlertMessageService.popupAlertMsg(mCommonResponse.messageDesc);
            }
            else {
                this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.sAlertMessageService.popupAlertMsg(this.sErrorMessagesService.responseNull);
        }
    }
};
CCAvenueServiceInvoiceComponent = tslib_1.__decorate([
    Component({
        selector: 'app-ccavenue-service-invoice',
        templateUrl: './ccavenue-service-invoice.component.html',
        styleUrls: ['./ccavenue-service-invoice.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [CCAvenueService,
        DatePipe,
        ChangeDetectorRef,
        BsModalService,
        MerchInfoService,
        BsModalService,
        FormBuilder,
        ResponsiveService,
        ConditionalCheckService,
        ErrorHandlerService,
        ErrorMessagesService,
        AlertMessageService,
        LandingPageMsgService,
        ActivatedRoute,
        PrivilegeService,
        PdfPrintService,
        TitleService])
], CCAvenueServiceInvoiceComponent);
export { CCAvenueServiceInvoiceComponent };
//# sourceMappingURL=ccavenue-service-invoice.component.js.map