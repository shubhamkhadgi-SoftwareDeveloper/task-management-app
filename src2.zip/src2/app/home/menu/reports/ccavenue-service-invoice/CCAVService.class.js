import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let CCAVService = class CCAVService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cFetchServiceDetailsById = 'getServiceInvoiceListById';
    }
    fetchCCAVDetail(pCCAVServiceReq) {
        return this.pApiRequestService.httpPostRequest(pCCAVServiceReq, this.cFetchServiceDetailsById);
    }
};
CCAVService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], CCAVService);
export { CCAVService };
//# sourceMappingURL=CCAVService.class.js.map