import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { Injectable } from '@angular/core';
import { CCAVServiceReqDto } from './CCAVService.req';
import { CCAvenueService } from './CCAvenueService-report.service';
let CCAvenueServiceResolverService = class CCAvenueServiceResolverService {
    constructor(cCCAvenueService) {
        this.cCCAvenueService = cCCAvenueService;
    }
    resolve(route, state) {
        let mCCAVServiceReqDto = new CCAVServiceReqDto();
        return this.cCCAvenueService.fetchAllCCAvenueServiceInvoice(mCCAVServiceReqDto).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
CCAvenueServiceResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [CCAvenueService])
], CCAvenueServiceResolverService);
export { CCAvenueServiceResolverService };
//# sourceMappingURL=CCAvenueService-report.resolver.service.js.map