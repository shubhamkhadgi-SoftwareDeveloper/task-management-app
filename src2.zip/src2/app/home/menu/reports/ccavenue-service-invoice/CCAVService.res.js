export class CCAVServiceResDto {
    constructor() {
        // this.cServiceInvoiceReportResponse = new ServiceInvoiceReportResponse();
    }
}
//# sourceMappingURL=CCAVService.res.js.map