import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let CCAvenueService = class CCAvenueService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cCcavenueServiceInvoiceBaseUrl = 'ccavenueServiceInvoice/';
        this.cGetAllCCAvenueServiceUrl = this.cCcavenueServiceInvoiceBaseUrl + 'getServiceInvoiceList';
        this.cGetServiceInvoiceListByIdUrl = this.cCcavenueServiceInvoiceBaseUrl + 'getServiceInvoiceListById';
        this.cSendInvMailUrl = this.cCcavenueServiceInvoiceBaseUrl + 'sendInvMail';
        this.cPrintCCAVInvoiceUrl = this.cCcavenueServiceInvoiceBaseUrl + 'printCCAVInvoice';
    }
    fetchAllCCAvenueServiceInvoice(pCCAVServiceReqDto) {
        return this.pApiRequestService.httpPostRequest(pCCAVServiceReqDto, this.cGetAllCCAvenueServiceUrl);
    }
    fetchCCAvenueServiceInvoiceById(pCCAVServiceReqDto) {
        return this.pApiRequestService.httpPostRequest(pCCAVServiceReqDto, this.cGetServiceInvoiceListByIdUrl);
    }
    sendCCAVServiceInvoice(pCCAVServiceReqDto) {
        return this.pApiRequestService.httpPostRequest(pCCAVServiceReqDto, this.cSendInvMailUrl);
    }
    printCCAVServiceInvoice(pCCAVServiceReqDto) {
        return this.pApiRequestService.httpPostRequest(pCCAVServiceReqDto, this.cPrintCCAVInvoiceUrl);
    }
};
CCAvenueService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], CCAvenueService);
export { CCAvenueService };
//# sourceMappingURL=CCAvenueService-report.service.js.map