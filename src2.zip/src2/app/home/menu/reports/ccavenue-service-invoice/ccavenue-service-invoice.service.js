import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
let CCAvenueServiceInvoiceService = class CCAvenueServiceInvoiceService {
    constructor() { }
};
CCAvenueServiceInvoiceService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [])
], CCAvenueServiceInvoiceService);
export { CCAvenueServiceInvoiceService };
//# sourceMappingURL=ccavenue-service-invoice.service.js.map