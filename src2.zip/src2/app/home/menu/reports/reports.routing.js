import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DirectBankSettlementsComponent } from './direct-bank-settlements/direct-bank-settlements.component';
import { UnsettledTransactionReportComponent } from './unsettled-transaction-report/unsettled-transaction-report.component';
import { ReconciliationReportComponent } from './reconciliation-report/reconciliation-report.component';
import { CCAvenueServiceInvoiceComponent } from './ccavenue-service-invoice/ccavenue-service-invoice.component';
import { InvalidRequestReportComponent } from './invalid-request-report/invalid-request-report.component';
import { AbortedTransactionReportComponent } from './aborted-transaction-report/aborted-transaction-report.component';
import { RefundAnalysisReportComponent } from './refund-analysis-report/refund-analysis-report.component';
import { InitiatedRefundAnalysisReportComponent } from './refund-analysis-report/initiated-refund-analysis-report/initiated-refund-analysis-report.component';
import { FailureAnalysisDetailsComponent } from './failure-analysis-report/failure-analysis-details/failure-analysis-details.component';
import { SuccessfulRefundAnalysisReportComponent } from './refund-analysis-report/successful-refund-analysis-report/successful-refund-analysis-report.component';
import { PendingRefundAnalysisReportComponent } from './refund-analysis-report/pending-refund-analysis-report/pending-refund-analysis-report.component';
import { FailedRefundAnalysisReportComponent } from './refund-analysis-report/failed-refund-analysis-report/failed-refund-analysis-report.component';
import { UserAuditLogsComponent } from './user-audit-logs/user-audit-logs.component';
import { RetriedTransactionReportComponent } from './retried-transaction-report/retried-transaction-report.component';
import { SalesReportbyPaymentTypeComponent } from './sales-reportby-payment-type/sales-reportby-payment-type.component';
import { FailureAnalysisReportComponent } from './failure-analysis-report/failure-analysis-report.component';
import { SubAccountReportComponent } from './sub-account-report/sub-account-report.component';
import { PayoutSummaryComponent } from './payout-summary/payout-summary.component';
import { SalesReportComponent } from './sales-report/sales-report.component';
import { PayoutSummaryRefundsComponent } from './payout-summary/payout-summary-refunds/payout-summary-refunds.component';
import { PayoutSummaryChargebackComponent } from './payout-summary/payout-summary-chargeback/payout-summary-chargeback.component';
import { PayoutSummarySalesComponent } from './payout-summary/payout-summary-sales/payout-summary-sales.component';
import { GatewayPerformanceReportComponent } from './gateway-performance-report/gateway-performance-report.component';
//Resolver - services
import { GatePerformanceResolverService } from './gateway-performance-report/gateway-performance-resolver.service';
import { DirectBankSettlementsResolverService } from './direct-bank-settlements/direct-bank-settlements-resolver-service';
import { ReconciliationReportResolverService } from './reconciliation-report/reconciliation-report-resolver.service';
import { PayoutSummaryResolverService } from './payout-summary/payout-summary-resolver.service';
import { PayoutSummarySalesResolverService } from './payout-summary/payout-summary-sales/payout-summary-sales-resolver.service';
import { PayoutSummaryRefundsResolverService } from './payout-summary/payout-summary-refunds/payout-summary-refunds-resolver.service';
import { PayoutSummaryChargebackResolverService } from './payout-summary/payout-summary-chargeback/payout-summary-chargeback-resolver.service';
import { RetriedTransactionReportResolverService } from './retried-transaction-report/retried-transaction-report-resolver.service';
import { SalesReportResolverService } from './sales-report/sales-report-resolver.service';
import { UnsettledTransactionReportResolverService } from './unsettled-transaction-report/unsettled-transaction-report-resolver-service';
import { SalesReportbyPaymentTypeResolverService } from './sales-reportby-payment-type/sales-reportby-payment-type-resolver.service';
import { RefundAnalysisReportResolverService } from './refund-analysis-report/refund-analysis-report-resolver.service';
import { InitiatedRefundAnalysisReportResolverService } from './refund-analysis-report/initiated-refund-analysis-report/initiated-refund-analysis-report-resolver.service';
import { FailureRefundAnalysisReportResolverService } from './failure-analysis-report/failure-analysis-details/failure-analysis-details.service';
import { SuccessfulRefundAnalysisReportResolverService } from './refund-analysis-report/successful-refund-analysis-report/successful-refund-analysis-report-resolver.service';
import { PendingRefundAnalysisReportResolverService } from './refund-analysis-report/pending-refund-analysis-report/pending-refund-analysis-report-resolver.service';
import { FailedRefundAnalysisReportResolverService } from './refund-analysis-report/failed-refund-analysis-report/failed-refund-analysis-report-resolver.service';
import { UserAuditLogsResolverService } from './user-audit-logs/user-audit-logs-resolver.service';
//API - services
import { DirectBankSettlementsService } from './direct-bank-settlements/direct-bank-settlements.service';
import { ReconciliationReportService } from './reconciliation-report/reconciliation-report.service';
import { CCAvenueServiceInvoiceService } from './ccavenue-service-invoice/ccavenue-service-invoice.service';
import { UnsettledTransactionReportService } from './unsettled-transaction-report/unsettled-transaction-report.service';
import { InvalidRequestReportService } from './invalid-request-report/invalid-request-report.service';
/*import { AbortedTransactionReportService } from './aborted-transaction-report/aborted-transaction-report.service';*/
import { RefundAnalysisReportService } from './refund-analysis-report/refund-analysis-report.service';
import { UserAuditLogsService } from './user-audit-logs/user-audit-logs.service';
import { RetriedTransactionReportService } from './retried-transaction-report/retried-transaction-report.service';
import { SalesReportbyPaymentTypeService } from './sales-reportby-payment-type/sales-reportby-payment-type.service';
import { PayoutSummaryService } from './payout-summary/payout-summary.service';
import { PayoutSummarySalesService } from './payout-summary/payout-summary-sales/payout-summary-sales.service';
import { PayoutSummaryRefundsService } from './payout-summary/payout-summary-refunds/payout-summary-refunds.service';
import { PayoutSummaryChargebackService } from './payout-summary/payout-summary-chargeback/payout-summary-chargeback.service';
import { FailureAnalysisReportService } from './failure-analysis-report/failure-analysis-report.service';
import { SalesReportService } from './sales-report/sales-report.service';
import { GatewayPerformanceReportService } from './gateway-performance-report/gateway-performance-report.service';
import { AbortedTransationResolverService } from './aborted-transaction-report/aborted-transaction-resolver.service';
import { AbortedTransationService } from './aborted-transaction-report/aborted-transation-report.service';
import { InvalidRequestResolverService } from './invalid-request-report/InvalidRequest-report.resolver.service';
import { InvalidRequestService } from './invalid-request-report/InvalidRequest-report.service';
import { CCAvenueServiceResolverService } from './ccavenue-service-invoice/CCAvenueService-report.resolver.service';
import { CCAvenueService } from './ccavenue-service-invoice/CCAvenueService-report.service';
import { SubAccountResolverService } from './sub-account-report/SubAccount-report.resolver.service';
import { SubAccountService } from './sub-account-report/SubAccount-report.service';
import { FailureAnalysisResolverService } from './failure-analysis-report/FailureAnalysis-report.resolver.service';
const routes = [
    { path: 'unsettledTransactionReport', component: UnsettledTransactionReportComponent, resolve: { commonResponse: UnsettledTransactionReportResolverService } },
    { path: 'payoutSummary', component: PayoutSummaryComponent, resolve: { commonResponse: PayoutSummaryResolverService } },
    { path: 'payoutSummary/payoutSummarySales', component: PayoutSummarySalesComponent, resolve: { commonResponse: PayoutSummarySalesResolverService } },
    { path: 'payoutSummary/payoutSummaryRefunds', component: PayoutSummaryRefundsComponent, resolve: { commonResponse: PayoutSummaryRefundsResolverService } },
    { path: 'payoutSummary/payoutSummaryChargeback', component: PayoutSummaryChargebackComponent, resolve: { commonResponse: PayoutSummaryChargebackResolverService } },
    { path: 'salesReport', component: SalesReportComponent, resolve: { commonResponse: SalesReportResolverService } },
    { path: 'salesReportbyPaymentType', component: SalesReportbyPaymentTypeComponent, resolve: { commonResponse: SalesReportbyPaymentTypeResolverService } },
    { path: 'directBankSettlements', component: DirectBankSettlementsComponent, resolve: { commonResponse: DirectBankSettlementsResolverService } },
    { path: 'reconciliationReport', component: ReconciliationReportComponent, resolve: { commonResponse: ReconciliationReportResolverService } },
    { path: 'abortedTransactionReport', component: AbortedTransactionReportComponent, resolve: { commonResponse: AbortedTransationResolverService } },
    { path: 'ccavenueServiceInvoice', component: CCAvenueServiceInvoiceComponent, resolve: { commonResponse: CCAvenueServiceResolverService } },
    { path: 'invalidRequestReport', component: InvalidRequestReportComponent, resolve: { commonResponse: InvalidRequestResolverService } },
    { path: 'failureAnalysisReport', component: FailureAnalysisReportComponent, resolve: { commonResponse: FailureAnalysisResolverService } },
    { path: 'failureAnalysisReport/FailureAnalysisReportDetails', component: FailureAnalysisDetailsComponent, resolve: { commonResponse: FailureRefundAnalysisReportResolverService } },
    { path: 'refundAnalysisReport', component: RefundAnalysisReportComponent, resolve: { commonResponse: RefundAnalysisReportResolverService } },
    { path: 'refundAnalysisReport/InitiatedRefundAnalysisReport', component: InitiatedRefundAnalysisReportComponent, resolve: { commonResponse: InitiatedRefundAnalysisReportResolverService } },
    { path: 'refundAnalysisReport/SuccessfulRefundAnalysisReport', component: SuccessfulRefundAnalysisReportComponent, resolve: { commonResponse: SuccessfulRefundAnalysisReportResolverService } },
    { path: 'refundAnalysisReport/PendingRefundAnalysisReport', component: PendingRefundAnalysisReportComponent, resolve: { commonResponse: PendingRefundAnalysisReportResolverService } },
    { path: 'refundAnalysisReport/FailedRefundAnalysisReport', component: FailedRefundAnalysisReportComponent, resolve: { commonResponse: FailedRefundAnalysisReportResolverService } },
    { path: 'userAuditLogs', component: UserAuditLogsComponent, resolve: { commonResponse: UserAuditLogsResolverService } },
    { path: 'gatewayPerformanceReport', component: GatewayPerformanceReportComponent, resolve: { commonResponse: GatePerformanceResolverService } },
    { path: 'retriedTransactionReport', component: RetriedTransactionReportComponent, resolve: { commonResponse: RetriedTransactionReportResolverService } },
    { path: 'subAccountReport', component: SubAccountReportComponent, resolve: { commonResponse: SubAccountResolverService } },
    { path: '', redirectTo: 'directBankSettlements', pathMatch: 'full' },
    { path: '**', component: DirectBankSettlementsComponent }
];
let ReportsRoutingModule = class ReportsRoutingModule {
};
ReportsRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule],
        providers: [RetriedTransactionReportService, RetriedTransactionReportResolverService,
            PayoutSummaryChargebackService, GatewayPerformanceReportService,
            SalesReportService, SalesReportResolverService,
            PayoutSummarySalesService, PayoutSummaryRefundsService, PayoutSummaryRefundsResolverService, PayoutSummaryChargebackResolverService, PayoutSummarySalesResolverService, PayoutSummaryService, PayoutSummaryResolverService,
            SalesReportbyPaymentTypeService, SalesReportbyPaymentTypeResolverService,
            UnsettledTransactionReportService,
            InvalidRequestReportService,
            DirectBankSettlementsResolverService, DirectBankSettlementsService,
            CCAvenueServiceInvoiceService,
            ReconciliationReportService, ReconciliationReportResolverService,
            /* AbortedTransactionReportService,*/
            FailureAnalysisReportService, FailureRefundAnalysisReportResolverService,
            RefundAnalysisReportService, RefundAnalysisReportResolverService, InitiatedRefundAnalysisReportResolverService, SuccessfulRefundAnalysisReportResolverService, PendingRefundAnalysisReportResolverService, FailedRefundAnalysisReportResolverService,
            UserAuditLogsService, UserAuditLogsResolverService,
            UnsettledTransactionReportResolverService,
            GatewayPerformanceReportService, GatePerformanceResolverService,
            AbortedTransationService, AbortedTransationResolverService,
            InvalidRequestService, InvalidRequestResolverService,
            CCAvenueService, CCAvenueServiceResolverService,
            SubAccountService, SubAccountResolverService,
            /*FailureAnalysisService,*/ FailureAnalysisResolverService
        ]
    })
], ReportsRoutingModule);
export { ReportsRoutingModule };
export const ReportsRoutedComponents = [
    GatewayPerformanceReportComponent,
    SalesReportComponent,
    PayoutSummaryComponent,
    FailureAnalysisReportComponent,
    SubAccountReportComponent,
    SalesReportbyPaymentTypeComponent,
    RetriedTransactionReportComponent,
    UnsettledTransactionReportComponent,
    InvalidRequestReportComponent,
    DirectBankSettlementsComponent,
    ReconciliationReportComponent,
    AbortedTransactionReportComponent,
    CCAvenueServiceInvoiceComponent,
    RefundAnalysisReportComponent,
    UserAuditLogsComponent
];
//# sourceMappingURL=reports.routing.js.map