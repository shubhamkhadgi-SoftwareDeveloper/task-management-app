export class SalesReportReq {
    constructor() {
        this.searchMerchantArr = [];
    }
}
//# sourceMappingURL=sales-report-req.js.map