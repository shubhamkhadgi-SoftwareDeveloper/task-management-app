import * as tslib_1 from "tslib";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { SalesReportReq } from './sales-report-req';
import { SalesReport } from './sales-report';
import { SalesReportService } from './sales-report.service';
let SalesReportResolverService = class SalesReportResolverService {
    constructor(pDatePipe, cSalesReportService) {
        this.pDatePipe = pDatePipe;
        this.cSalesReportService = cSalesReportService;
        this.toPayDate = '';
        this.cSalesReport = new SalesReport();
    }
    resolve(route, state) {
        let mSalesReportReq = new SalesReportReq();
        this.datebefore = new Date();
        mSalesReportReq.searchFromDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        mSalesReportReq.searchToDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.cSalesReport.fromToDate = mSalesReportReq.searchFromDate + '-' + mSalesReportReq.searchFromDate;
        return this.cSalesReportService.fetchSalesReport(mSalesReportReq).take(1).map(pCommonResponse => {
            if (pCommonResponse) {
                return pCommonResponse;
            }
            else {
                return null;
            }
        });
    }
};
SalesReportResolverService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [DatePipe,
        SalesReportService])
], SalesReportResolverService);
export { SalesReportResolverService };
//# sourceMappingURL=sales-report-resolver.service.js.map