export class SalesReportWrapper {
    constructor() {
        this.chartArea = [];
        this.chartArea = [];
    }
}
//# sourceMappingURL=sales-report-wrapper.js.map