import * as tslib_1 from "tslib";
import { SalesReportReq } from './sales-report-req';
import { SalesReport } from './sales-report';
import { SalesReportService } from './sales-report.service';
import { DatePipe } from '@angular/common';
import { Component, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { MerchInfoService } from '../../../../common-services/merch-info/merch-info.service';
import { ConditionalCheckService } from '../../../../common-services/conditional-check.service';
import { AlertMessageService } from '../../../../common-services/alert-message.service';
import { ErrorMessagesService } from '../../../../common-services/error-messages.service';
import { ResponsiveService } from '../../../../common-services/responsive.service';
import { LandingPageMsgService } from './../../../../common-services/landing-page-msg.service';
import { CommonResponse } from '../../../../common-response/common-response.res';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ErrorHandlerService } from '../../../../common-services/error-handler.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TitleService } from './../../../../common-services/title.service';
let SalesReportComponent = class SalesReportComponent {
    constructor(pDatePipe, cdr, pFormBuilder, sErrorHandler, pModalService, pMerchInfoService, pLocation, sCheck, sAlertMessageService, sErrorMessagesService, sResponsiveService, sLandingPageMsgService, sActivatedRoute, sSalesReportService, sTitleService) {
        this.pDatePipe = pDatePipe;
        this.cdr = cdr;
        this.pFormBuilder = pFormBuilder;
        this.sErrorHandler = sErrorHandler;
        this.pModalService = pModalService;
        this.pMerchInfoService = pMerchInfoService;
        this.pLocation = pLocation;
        this.sCheck = sCheck;
        this.sAlertMessageService = sAlertMessageService;
        this.sErrorMessagesService = sErrorMessagesService;
        this.sResponsiveService = sResponsiveService;
        this.sLandingPageMsgService = sLandingPageMsgService;
        this.sActivatedRoute = sActivatedRoute;
        this.sSalesReportService = sSalesReportService;
        this.sTitleService = sTitleService;
        this.landingPageMsg = null;
        this.data = [];
        this.toPayDate = '';
        this.k = 0;
        this.chartArea = [];
        for (var i = 0; i < 48; i++) {
            this.chartArea[i] = [];
        }
        this.cSalesReportProcEntity = [];
        this.cSalesReportReq = new SalesReportReq();
        this.cSalesReport = new SalesReport();
        this.sTitleService.setTitle(this.sTitleService.SalesReport);
    }
    ngOnInit() {
        this.createForm();
        this.datebefore = new Date();
        this.cSalesReportReq.searchFromDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.cSalesReportReq.searchToDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
        this.cSalesReport.fromToDate = this.cSalesReportReq.searchFromDate + '-' + this.cSalesReportReq.searchFromDate;
        this.sActivatedRoute.data
            .subscribe((data) => {
            let mCommonResponse = new CommonResponse(data.commonResponse);
            if (mCommonResponse.isSuccess) {
                if (!this.sCheck.isNotNullList(mCommonResponse.data)) {
                    this.cSalesReportProcEntity = mCommonResponse.data.SalesReport;
                    this.pieChartCalculation();
                }
                else {
                    this.cSalesReportProcEntity = null;
                    console.log(mCommonResponse.messageDesc);
                    this.landingPageMsg = 'No records found';
                }
            }
            else {
                this.cSalesReportProcEntity = null;
                this.landingPageMsg = 'No records found';
                console.log(mCommonResponse.messageDesc);
            }
        });
    }
    pieChartCalculation() {
        let totalAmount = 0;
        let currency;
        for (var i = 0; i < this.cSalesReportProcEntity.length; i++) {
            totalAmount = this.cSalesReportProcEntity[i].refundsAmt + this.cSalesReportProcEntity[i].salesAmt;
            if (this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].refundsAmt) && this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].salesAmt)) {
                currency = this.cSalesReportProcEntity[i].curr;
                this.chartArea[i][0] = { label: "Refunded",
                    value: [((this.cSalesReportProcEntity[i].refundsAmt / (this.cSalesReportProcEntity[i].refundsAmt + this.cSalesReportProcEntity[i].salesAmt)) * 100).toFixed(2)],
                    color: "#526382" };
                this.chartArea[i][1] = { label: "Sales",
                    value: [((this.cSalesReportProcEntity[i].salesAmt / (this.cSalesReportProcEntity[i].refundsAmt + this.cSalesReportProcEntity[i].salesAmt)) * 100).toFixed(2)],
                    color: "#64d691" };
            }
            else if (!(this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].refundsAmt)) && this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].salesAmt)) {
                currency = this.cSalesReportProcEntity[i].curr;
                this.chartArea[i][0] = {
                    label: "Sales",
                    value: [((this.cSalesReportProcEntity[i].salesAmt / (this.cSalesReportProcEntity[i].refundsAmt + this.cSalesReportProcEntity[i].salesAmt)) * 100).toFixed(2)],
                    color: "#64d691"
                };
            }
            else if (this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].refundsAmt) && !this.sCheck.isNotNullNumber(this.cSalesReportProcEntity[i].salesAmt)) {
                currency = this.cSalesReportProcEntity[i].curr;
                this.chartArea[i][0] = { label: "Refunded",
                    value: [((this.cSalesReportProcEntity[i].refundsAmt / (this.cSalesReportProcEntity[i].refundsAmt + this.cSalesReportProcEntity[i].salesAmt)) * 100).toFixed(2)],
                    color: "#526382" };
            }
            this.chartDonutOptions = { formatter: function (y, data) {
                    return y + '%';
                }, resize: true,
            };
        }
        this.options = {
            legend: {
                display: false
            },
            tooltips: {
                callbacks: {
                    title: function (tooltipItem, data) {
                        return data['labels'][tooltipItem[0]['index']];
                    },
                    label: function (tooltipItem, data) {
                        return data['datasets'][0]['data'][tooltipItem['index']] + '%';
                    },
                }
            }
        };
    }
    //***********************************************Button Click Event*******************************************//
    onDropdownCloseClick() {
        this.cSalesReport.isSearchByClick = false;
    }
    createForm() {
        this.mForm = this.pFormBuilder.group({
            searchMerchantArr: [''],
            searchSubAccId: [''],
            fromToDate: ['', [Validators.required]],
            currency: ['']
        });
    }
    onSearchClick() {
        if (this.mForm.valid) {
            if (this.cSalesReportReq.searchMerchantArr.length < 1)
                this.cSalesReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
            this.sSalesReportService.fetchSalesReport(this.cSalesReportReq)
                .subscribe(pResponse => { this.fetchSalesReportSuccess(pResponse); }, error => { console.log('error'); });
        }
        else {
            this.validateAllFields(this.mForm);
        }
    }
    validateAllFields(pFormGroup) {
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    onSearchPanelClick() {
        this.cSalesReport.isExportClick = false;
        if (!this.sResponsiveService.isSearchResponsive()) {
            this.cSalesReport.isSearchPanelClick = !this.cSalesReport.isSearchPanelClick;
        }
    }
    onCancelPanelClick() {
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSalesReport.isSearchPanelClick = false;
            this.cSalesReportReq = null;
            this.cSalesReportReq = new SalesReportReq();
            this.cSalesReport.calOptions = {
                autoApply: true,
                autoUpdateInput: false,
                locale: { format: 'DD-MM-YYYY' },
                alwaysShowCalendars: false,
                "applyClass": "btn-theme",
                "cancelClass": "btn-blank",
                dateLimit: {
                    days: 30
                },
                maxDate: new Date(),
            };
            this.datebefore = new Date();
            this.cSalesReportReq.searchFromDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.cSalesReportReq.searchToDate = this.pDatePipe.transform(this.datebefore, 'dd-MM-yyyy');
            this.cSalesReport.fromToDate = '';
            this.mForm.controls['fromToDate'].clearValidators();
            this.mForm.controls['fromToDate'].updateValueAndValidity();
            this.onSearchClick();
        }
    }
    onExportExcelClick() {
        if (this.cSalesReportReq.searchMerchantArr.length <= 0)
            this.cSalesReportReq.searchMerchantArr = ["" + this.pMerchInfoService.getRegId()];
        this.cSalesReport.isExportClick = !this.cSalesReport.isExportClick;
        this.sSalesReportService.exportSalesReport(this.cSalesReportReq)
            .subscribe(pResponse => {
        }, error => { console.log('error in onExportExcelClick'); });
    }
    onExportClick() {
        this.cSalesReport.isSearchPanelClick = false;
        this.cSalesReport.isExportClick = !this.cSalesReport.isExportClick;
    }
    //***********************************************Select Event*******************************************//
    selectedDate(value) {
        this.cSalesReportReq.searchFromDate = value.start.format("DD-MM-YYYY");
        this.cSalesReportReq.searchToDate = value.end.format("DD-MM-YYYY");
        this.cSalesReport.fromToDate = this.cSalesReportReq.searchFromDate + ' - ' + this.cSalesReportReq.searchToDate;
    }
    //***********************************************Server Call Event*******************************************//
    fetchSalesReportSuccess(pResponse) {
        if (this.sCheck.isNotNullObject(pResponse)) {
            let mCommonResponse = new CommonResponse(pResponse);
            if (mCommonResponse.isSuccess) {
                this.cSalesReportProcEntity = mCommonResponse.data['SalesReport'];
                this.pieChartCalculation();
                if (!this.sResponsiveService.isCancelResponsive()) {
                    this.cSalesReport.isSearchPanelClick = false;
                }
            }
            else if (mCommonResponse.isFail) {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchSalesReport(mCommonResponse.messageDesc);
            }
            else {
                this.landingPageMsg = 'No Record Found';
                this.onFailFetchSalesReport(this.sErrorMessagesService.responseNull);
            }
        }
        else {
            this.landingPageMsg = 'No Record Found';
            this.onFailFetchSalesReport(this.sErrorMessagesService.responseNull);
        }
    }
    onFailFetchSalesReport(pResMsg) {
        console.log(pResMsg);
        this.landingPageMsg = 'No Record Found';
        this.cSalesReport.pageTotalCount = null;
        this.cSalesReportProcEntity = null;
        if (!this.sResponsiveService.isCancelResponsive()) {
            this.cSalesReport.isSearchPanelClick = false;
        }
    }
    //***********************************************Mouse Event*******************************************//
    //Export Panel
    mouseleaveExportEvent() {
        this.cSalesReport.isExportClick = false;
    }
    //***********************************************Life Hooks Event*******************************************//
    ngAfterViewChecked() {
        this.cdr.detectChanges();
    }
};
SalesReportComponent = tslib_1.__decorate([
    Component({
        selector: 'app-sales-report',
        templateUrl: './sales-report.component.html',
        styleUrls: ['./sales-report.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [DatePipe,
        ChangeDetectorRef,
        FormBuilder,
        ErrorHandlerService,
        BsModalService,
        MerchInfoService,
        Location,
        ConditionalCheckService,
        AlertMessageService,
        ErrorMessagesService,
        ResponsiveService,
        LandingPageMsgService,
        ActivatedRoute,
        SalesReportService,
        TitleService])
], SalesReportComponent);
export { SalesReportComponent };
//# sourceMappingURL=sales-report.component.js.map