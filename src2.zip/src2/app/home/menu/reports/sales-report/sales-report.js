export class SalesReport {
    constructor() {
        this.isSearchPanelClick = false;
        this.isNoRecordAfterSearch = true;
        this.isExportClick = false;
        this.isSearchByClick = false;
        this.status = [];
        this.calOptions = {
            autoApply: true,
            autoUpdateInput: false,
            locale: { format: 'DD-MM-YYYY' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            dateLimit: {
                days: 30
            },
            maxDate: new Date(),
        };
        this.searchBy = [];
        this.maxSearchDateTo = new Date();
        this.searchByLabel = 'Search By';
        this.fromToDate = '';
        this.fromDate = '';
        this.toDate = '';
    }
}
//# sourceMappingURL=sales-report.js.map