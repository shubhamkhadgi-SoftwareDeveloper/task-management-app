import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { ApiRequestService } from '../../../../common-services/api-request.service';
let SalesReportService = class SalesReportService {
    constructor(pApiRequestService) {
        this.pApiRequestService = pApiRequestService;
        this.cBaseUrl = 'salesReport/';
        this.cfetchSalesReportUrl = this.cBaseUrl + 'fetchSalesReport';
        this.cexportSalesReportUrl = this.cBaseUrl + 'exportSalesReport';
    }
    fetchSalesReport(pSalesReportReq) {
        return this.pApiRequestService.httpPostRequest(pSalesReportReq, this.cfetchSalesReportUrl);
    }
    exportSalesReport(pSalesReportReq) {
        return this.pApiRequestService.exportFileRequest(pSalesReportReq, this.cexportSalesReportUrl, "SalesReport.xlsx");
    }
};
SalesReportService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [ApiRequestService])
], SalesReportService);
export { SalesReportService };
//# sourceMappingURL=sales-report.service.js.map