import { TestBed, inject } from '@angular/core/testing';
import { SalesReportResolverService } from './sales-report-resolver.service';
describe('SalesReportResolverService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SalesReportResolverService]
        });
    });
    it('should be created', inject([SalesReportResolverService], (service) => {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=sales-report-resolver.service.spec.js.map