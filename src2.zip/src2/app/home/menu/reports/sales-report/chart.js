export class Chart {
}
//# sourceMappingURL=chart.js.map