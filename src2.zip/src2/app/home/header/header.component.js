import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import * as screenfull from 'screenfull';
import { AlertMessageService } from '../../common-services/alert-message.service';
import { CurrentLoginMerchantService } from '../../common-services/current-login-merchant.service';
let HeaderComponent = class HeaderComponent {
    constructor(pRouter, sAlertMessageService, sCurrentLoginMerchantService) {
        this.pRouter = pRouter;
        this.sAlertMessageService = sAlertMessageService;
        this.sCurrentLoginMerchantService = sCurrentLoginMerchantService;
        this.menuMinMaxEvent = new EventEmitter();
        this.cMerchName = '';
        this.cMerchantId = '';
        this.cMerchantEmail = '';
        this.cMerchNameInitial = '';
        this.cAdminMenuList = JSON.parse(sessionStorage.getItem('adminMenuList'));
        this.cMenuList = JSON.parse(sessionStorage.getItem('menuList'));
    }
    ngOnInit() {
        this.cMerchName = this.sCurrentLoginMerchantService.userName;
        this.cMerchantId = this.sCurrentLoginMerchantService.regId;
        this.cMerchantEmail = this.sCurrentLoginMerchantService.userEmail;
        this.cIsManageAccountClick = false;
        this.cMerchNameInitial = this.cMerchName.slice(0, 1);
    }
    onMaxMinViewClick() {
        this.cIsMinView = !this.cIsMinView;
        this.menuMinMaxEvent.emit(this.cIsMinView);
    }
    onFullScreenClick() {
        if (screenfull.enabled) {
            screenfull.toggle();
        }
    }
    onManageAccountClick() {
        this.cIsManageAccountClick = !this.cIsManageAccountClick;
    }
    onLogOutClick() {
        sessionStorage.clear();
        localStorage.clear();
        location.reload();
        this.pRouter.navigate(['login/login']);
    }
    getResellerImgUrl() {
        return 'url(assets/images/reseller-logo/' + this.sCurrentLoginMerchantService.resellerCode + '-logo.png)';
    }
};
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], HeaderComponent.prototype, "menuMinMaxEvent", void 0);
tslib_1.__decorate([
    Input('isMinView'),
    tslib_1.__metadata("design:type", Boolean)
], HeaderComponent.prototype, "cIsMinView", void 0);
tslib_1.__decorate([
    Input('menuName'),
    tslib_1.__metadata("design:type", String)
], HeaderComponent.prototype, "cMenuName", void 0);
HeaderComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-header',
        templateUrl: './header.component.html',
        styleUrls: ['./header.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [Router,
        AlertMessageService,
        CurrentLoginMerchantService])
], HeaderComponent);
export { HeaderComponent };
//# sourceMappingURL=header.component.js.map