import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { SlimLoadingBarModule } from 'ng2-slim-loading-bar';
import { CommonAndThirdPartyModule } from '../common-modules/common-and-third-party.module';
import { HomeRoutingModule, HomeRoutedComponents } from './home.routing';
import { TransactionsModule } from './menu/transactions/transactions.module';
import { InvoiceModule } from './menu/invoice/invoice.module';
import { ApiRequestService } from '../common-services/api-request.service';
import { MerchInfoService } from '../common-services/merch-info/merch-info.service';
import { DashboardComponent } from './menu/dashboard/dashboard.component';
import { ModalModule } from 'ngx-bootstrap';
import { GstDetailsComponent } from './menu/dashboard/gst-details/gst-details.component';
import { CustomerComponent } from './menu/customer/customer.component';
import { SettingsModule } from './menu/settings/settings.module';
import { CopyPasteControlModule } from 'app/common-modules/copy-paste-control.module';
let HomeModule = class HomeModule {
};
HomeModule = tslib_1.__decorate([
    NgModule({
        declarations: [
            HomeRoutedComponents,
            DashboardComponent,
            GstDetailsComponent,
            CustomerComponent,
        ],
        entryComponents: [GstDetailsComponent],
        imports: [
            SlimLoadingBarModule.forRoot(),
            CommonAndThirdPartyModule,
            HomeRoutingModule,
            TransactionsModule,
            InvoiceModule,
            ModalModule.forRoot(),
            SettingsModule,
            CopyPasteControlModule,
        ],
        exports: [SlimLoadingBarModule],
        providers: [
            //API request http service
            ApiRequestService,
            //Merchant common information service
            MerchInfoService
        ]
    })
], HomeModule);
export { HomeModule };
//# sourceMappingURL=home.module.js.map