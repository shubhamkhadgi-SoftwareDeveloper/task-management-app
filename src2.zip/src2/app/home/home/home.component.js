import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
let HomeComponent = class HomeComponent {
    constructor() {
        this.cIsMinView = false;
    }
    ngOnInit() {
    }
    onMenuMinMaxChange(event) {
        this.cIsMinView = event;
    }
    onMenuNameChange(event) {
        this.cMenuName = event;
    }
};
HomeComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-home',
        templateUrl: './home.component.html',
        styleUrls: ['./home.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [])
], HomeComponent);
export { HomeComponent };
//# sourceMappingURL=home.component.js.map