export class CommonResponse {
    constructor(pObj) {
        if (pObj != undefined && pObj != null) {
            Object.assign(this, pObj);
        }
    }
    get isSuccess() {
        return (this.code === CustomResponseCode.SUCCESS && this.message === CustomResponseMessage.SUCCESS);
    }
    get isValidationFail() {
        return (this.code === CustomResponseCode.FAIL && this.message === CustomResponseMessage.VALIDATION_FAIL);
    }
    get isFail() {
        return (this.code === CustomResponseCode.FAIL && this.message === CustomResponseMessage.ERROR);
    }
}
export class CustomResponseCode {
}
CustomResponseCode.SUCCESS = 0;
CustomResponseCode.FAIL = -1;
export class CustomResponseMessage {
}
CustomResponseMessage.SUCCESS = "Success";
CustomResponseMessage.ERROR = "Error";
CustomResponseMessage.INVALID_FORMAT = "Invalid request format";
CustomResponseMessage.VALIDATION_FAIL = "ValidationFail";
//# sourceMappingURL=common-response.res.js.map