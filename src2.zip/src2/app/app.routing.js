import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
const routes = [
    {
        path: 'login',
        loadChildren: () => import('app/login/login.module').then(m => m.LoginModule)
    },
    {
        path: 'home',
        loadChildren: () => import('app/home/home.module').then(m => m.HomeModule),
    },
    {
        path: 'resources',
        loadChildren: () => import('app/resources/resources.module').then(m => m.ResourcesModule),
    },
    { path: '', redirectTo: 'login/login', pathMatch: 'full' },
    { path: '**', component: LoginComponent }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib_1.__decorate([
    NgModule({
        imports: [RouterModule.forRoot(routes)],
        exports: [RouterModule]
    })
], AppRoutingModule);
export { AppRoutingModule };
//export const AppRoutedComponents = [LoginComponent];
//# sourceMappingURL=app.routing.js.map