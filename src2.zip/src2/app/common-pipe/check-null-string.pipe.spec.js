import { CheckNullStringPipe } from './check-null-string.pipe';
describe('CheckNullStringPipe', () => {
    it('create an instance', () => {
        const pipe = new CheckNullStringPipe();
        expect(pipe).toBeTruthy();
    });
});
//# sourceMappingURL=check-null-string.pipe.spec.js.map