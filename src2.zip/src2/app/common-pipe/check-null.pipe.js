import * as tslib_1 from "tslib";
import { Pipe } from '@angular/core';
let CheckNullPipe = class CheckNullPipe {
    transform(value) {
        if (value == null || value === null || value == undefined || value === undefined) {
            return '-';
        }
        else {
            return value;
        }
    }
};
CheckNullPipe = tslib_1.__decorate([
    Pipe({
        name: 'checkNull'
    })
], CheckNullPipe);
export { CheckNullPipe };
//# sourceMappingURL=check-null.pipe.js.map