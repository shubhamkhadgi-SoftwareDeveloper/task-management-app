import * as tslib_1 from "tslib";
import { Pipe } from '@angular/core';
import * as moment from 'moment';
let DatexPipe = class DatexPipe {
    transform(value, format = "") {
        // Try and parse the passed value.
        var momentDate = moment(value);
        // If moment didn't understand the value, return it unformatted.
        if (!momentDate.isValid())
            return value;
        // Otherwise, return the date formatted as requested.
        return momentDate.format(format);
    }
};
DatexPipe = tslib_1.__decorate([
    Pipe({
        name: 'datex'
    })
], DatexPipe);
export { DatexPipe };
//# sourceMappingURL=datex.pipe.js.map