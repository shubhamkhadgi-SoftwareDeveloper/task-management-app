import { MapKeyPipe } from './map-key.pipe';
describe('MapKeyPipe', () => {
    it('create an instance', () => {
        const pipe = new MapKeyPipe();
        expect(pipe).toBeTruthy();
    });
});
//# sourceMappingURL=map-key.pipe.spec.js.map