import * as tslib_1 from "tslib";
import { Pipe } from '@angular/core';
let CheckNullNumberPipe = class CheckNullNumberPipe {
    transform(value) {
        if (value == null || value === null || value == undefined || value === undefined) {
            return '-';
        }
        else {
            if (value == 0 || value === 0) {
                return '-';
            }
            return value;
        }
    }
};
CheckNullNumberPipe = tslib_1.__decorate([
    Pipe({
        name: 'checkNullNumber'
    })
], CheckNullNumberPipe);
export { CheckNullNumberPipe };
//# sourceMappingURL=check-null-number.pipe.js.map