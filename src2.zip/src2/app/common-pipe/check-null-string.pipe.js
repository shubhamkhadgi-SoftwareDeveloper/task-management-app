import * as tslib_1 from "tslib";
import { Pipe } from '@angular/core';
let CheckNullStringPipe = class CheckNullStringPipe {
    transform(value) {
        if (value == null || value === null || value == undefined || value === undefined) {
            return '-';
        }
        else {
            if (value.trim() == '' || value.trim() === '') {
                return '-';
            }
            else {
                return value.trim();
            }
        }
    }
};
CheckNullStringPipe = tslib_1.__decorate([
    Pipe({
        name: 'checkNullString'
    })
], CheckNullStringPipe);
export { CheckNullStringPipe };
//# sourceMappingURL=check-null-string.pipe.js.map