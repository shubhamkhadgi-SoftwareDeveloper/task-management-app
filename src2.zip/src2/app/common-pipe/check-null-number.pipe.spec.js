import { CheckNullNumberPipe } from './check-null-number.pipe';
describe('CheckNullNumberPipe', () => {
    it('create an instance', () => {
        const pipe = new CheckNullNumberPipe();
        expect(pipe).toBeTruthy();
    });
});
//# sourceMappingURL=check-null-number.pipe.spec.js.map