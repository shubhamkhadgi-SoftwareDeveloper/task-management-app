import * as tslib_1 from "tslib";
import { Pipe } from '@angular/core';
let MapKeyPipe = class MapKeyPipe {
    transform(value, args = null) {
        return Object.keys(value); //.map(key => value[key]);
    }
};
MapKeyPipe = tslib_1.__decorate([
    Pipe({
        name: 'mapKey'
    })
], MapKeyPipe);
export { MapKeyPipe };
//# sourceMappingURL=map-key.pipe.js.map