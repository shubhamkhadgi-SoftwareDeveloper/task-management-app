export class DynamicEventParamEntity {
}
//# sourceMappingURL=dynamic-event-param-entity.js.map