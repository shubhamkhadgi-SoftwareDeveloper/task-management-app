export class PaymentOption {
}
//# sourceMappingURL=paymentOption.js.map