export class SettlementBankDetailResultEntity {
}
//# sourceMappingURL=settlement-bank-detail-result-entity.js.map