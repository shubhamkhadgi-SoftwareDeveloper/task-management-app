export class ActivationEMIOptionsResultEntity {
}
//# sourceMappingURL=activation-emi-options-result-entity.js.map