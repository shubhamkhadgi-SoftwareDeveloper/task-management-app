export class ActivationCurrencySelResultEntity {
}
//# sourceMappingURL=activation-currency-sel-result-entity.js.map