export class GatewayCard {
}
//# sourceMappingURL=gateway-card.js.map