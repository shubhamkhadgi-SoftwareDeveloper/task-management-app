export class BillPaymentEntity {
}
//# sourceMappingURL=bill-payment-entity.js.map