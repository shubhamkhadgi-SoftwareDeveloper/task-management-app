export class RegistrationEntity {
}
//# sourceMappingURL=registration-entity.js.map