export class MerchantURL {
}
//# sourceMappingURL=merchant-url.js.map