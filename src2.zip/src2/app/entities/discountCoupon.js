import { DiscountCouponId } from './discountCouponId';
export class DiscountCoupon {
    constructor() {
        this.discountCouponId = new DiscountCouponId();
    }
}
//# sourceMappingURL=discountCoupon.js.map