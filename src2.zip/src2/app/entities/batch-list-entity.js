export class BatchListEntity {
}
//# sourceMappingURL=batch-list-entity.js.map