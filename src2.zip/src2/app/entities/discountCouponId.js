export class DiscountCouponId {
}
//# sourceMappingURL=discountCouponId.js.map