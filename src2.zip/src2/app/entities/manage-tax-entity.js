export class ManageTax {
}
//# sourceMappingURL=manage-tax-entity.js.map