export class MertranVelocityCheck {
}
//# sourceMappingURL=mertran-velocity-check.js.map