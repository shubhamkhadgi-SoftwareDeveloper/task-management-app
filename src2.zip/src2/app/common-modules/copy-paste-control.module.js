import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { BlockCopyPasteDirective } from '../common-directive/block-copy-paste.directive';
import { NumberDirective } from '../common-directive/number-only.directive';
let CopyPasteControlModule = class CopyPasteControlModule {
};
CopyPasteControlModule = tslib_1.__decorate([
    NgModule({
        declarations: [
            BlockCopyPasteDirective, NumberDirective
        ],
        imports: [],
        exports: [BlockCopyPasteDirective, NumberDirective],
        providers: [
            ,
            //API request http service
        ]
    })
], CopyPasteControlModule);
export { CopyPasteControlModule };
//# sourceMappingURL=copy-paste-control.module.js.map