import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
//Third-part modules
import { CheckboxModule, MultiSelectModule, InputSwitchModule, DropdownModule, CalendarModule, RadioButtonModule, EditorModule, ChartModule } from 'primeng/primeng';
import { Daterangepicker } from 'ng2-daterangepicker';
//import { QuillEditorModule } from 'ngx-quill-editor';
import { NgxDnDModule } from '@swimlane/ngx-dnd';
import { ModalModule } from 'ngx-bootstrap';
import { NgxMessagesModule } from 'ngx-messages';
import { TagInputModule } from 'ngx-chips';
import { FacebookModule } from 'ngx-facebook';
import { ChartsModule } from 'ng2-charts';
import { NgxQRCodeModule } from 'ngx-qrcode2';
//ClipboardModule
import { ClipboardModule } from 'ngx-clipboard';
//Common-component
import { PaginatorComponent } from "../common-components/paginator/paginator.component";
//import { SlimScroll } from 'angular-io-slimscroll';
import { LandingPageComponent } from '../common-components/landing-page/landing-page.component';
import { ServerErrorLandingPageComponent } from '../common-components/server-error-landing-page/server-error-landing-page.component';
//Common-pipe
import { CheckNullPipe } from "../common-pipe/check-null.pipe";
import { CheckNullStringPipe } from "../common-pipe/check-null-string.pipe";
import { CheckNullNumberPipe } from "../common-pipe/check-null-number.pipe";
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { MapKeyPipe } from '../common-pipe/map-key.pipe';
import { DatexPipe } from '../common-pipe/datex.pipe';
/*import { Ng2UtilsModule } from 'ng2-utils';*/
import { ShareButtonsModule } from 'ngx-sharebuttons';
import { MorrisJsModule } from 'angular-morris-js';
import { NgSelectModule } from '@ng-select/ng-select';
import { StickyModule } from 'ng2-sticky-kit';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MultiselectDropdownComponent } from 'app/common-components/multiselect-dropdown/multiselect-dropdown.component';
// import { NgScrollbarModule } from 'ngx-scrollbar';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
let CommonAndThirdPartyModule = class CommonAndThirdPartyModule {
};
CommonAndThirdPartyModule = tslib_1.__decorate([
    NgModule({
        imports: [
            //General angular Module
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            HttpClientModule,
            //Prime Faces module
            CheckboxModule,
            MultiSelectModule,
            InputSwitchModule,
            DropdownModule,
            CalendarModule,
            RadioButtonModule,
            EditorModule,
            ChartModule,
            //Daterangepicker
            Daterangepicker,
            //editor
            //    QuillEditorModule,
            //Dragdrop
            NgxDnDModule,
            //Module pop-up
            ModalModule.forRoot(),
            //Error message handling
            NgxMessagesModule.configure({ showErrorsOnlyIfInputDirty: false }),
            //Tag Input
            TagInputModule,
            //Group by MultiSelect
            AngularMultiSelectModule,
            //Facebook API
            FacebookModule.forRoot(),
            //ORCode
            NgxQRCodeModule,
            //CopyToClipbord
            ClipboardModule,
            //Chart
            ChartsModule,
            MorrisJsModule,
            NgSelectModule,
            StickyModule,
            NgMultiSelectDropDownModule.forRoot(),
            ShareButtonsModule.forRoot(),
            // NgScrollbarModule,
            NgbModule
        ],
        exports: [
            //General angular Module
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
            HttpClientModule,
            //Prime Faces module
            CheckboxModule,
            MultiSelectModule,
            InputSwitchModule,
            DropdownModule,
            CalendarModule,
            RadioButtonModule,
            EditorModule,
            //Daterangepicker
            Daterangepicker,
            ChartModule,
            //edior
            //    QuillEditorModule,
            //Dragdrop
            NgxDnDModule,
            //Module pop-up
            ModalModule,
            //Error message handling
            NgxMessagesModule,
            //Tag Input
            TagInputModule,
            //common component
            PaginatorComponent,
            MultiselectDropdownComponent,
            // SlimScroll,
            LandingPageComponent,
            ServerErrorLandingPageComponent,
            //common-pipe
            CheckNullPipe,
            CheckNullStringPipe,
            CheckNullNumberPipe,
            MapKeyPipe,
            DatexPipe,
            //Group by MultiSelect
            AngularMultiSelectModule,
            //ORCode
            NgxQRCodeModule,
            //CopyToClipbord
            ClipboardModule,
            //Chart
            ChartsModule,
            MorrisJsModule,
            NgSelectModule,
            StickyModule,
            NgMultiSelectDropDownModule,
            ShareButtonsModule,
            // NgScrollbarModule,
            NgbModule
        ],
        declarations: [
            PaginatorComponent,
            /*SlimScroll,*/
            CheckNullPipe,
            CheckNullStringPipe,
            CheckNullNumberPipe,
            MapKeyPipe,
            DatexPipe,
            LandingPageComponent,
            ServerErrorLandingPageComponent,
            MultiselectDropdownComponent
        ]
    })
], CommonAndThirdPartyModule);
export { CommonAndThirdPartyModule };
//# sourceMappingURL=common-and-third-party.module.js.map