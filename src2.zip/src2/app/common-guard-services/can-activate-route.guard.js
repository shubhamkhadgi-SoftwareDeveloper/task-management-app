import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
let CanActivateRouteGuard = class CanActivateRouteGuard {
    constructor(sRouter) {
        this.sRouter = sRouter;
    }
    canActivate(next, state) {
        if (localStorage.getItem("sessionStorage") && !sessionStorage.getItem("regId")) {
            var data = JSON.parse(localStorage.getItem("sessionStorage"));
            for (var key in data) {
                sessionStorage.setItem(key, data[key]);
            }
            return true;
        }
        else if (sessionStorage.getItem("regId")) {
            return true;
        }
        else {
            this.sRouter.navigate(['login/login']);
        }
    }
};
CanActivateRouteGuard = tslib_1.__decorate([
    Injectable(),
    tslib_1.__metadata("design:paramtypes", [Router])
], CanActivateRouteGuard);
export { CanActivateRouteGuard };
//# sourceMappingURL=can-activate-route.guard.js.map