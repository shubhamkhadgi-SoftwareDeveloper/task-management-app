import { TestBed, inject } from '@angular/core/testing';
import { CanActivateRouteGuard } from './can-activate-route.guard';
describe('CanActivateRouteGuard', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CanActivateRouteGuard]
        });
    });
    it('should ...', inject([CanActivateRouteGuard], (guard) => {
        expect(guard).toBeTruthy();
    }));
});
//# sourceMappingURL=can-activate-route.guard.spec.js.map