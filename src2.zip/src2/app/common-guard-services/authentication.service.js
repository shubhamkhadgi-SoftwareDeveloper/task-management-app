import * as tslib_1 from "tslib";
import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
let AuthenticationService = class AuthenticationService {
    constructor(http, pApiEndpoint) {
        this.http = http;
        this.pApiEndpoint = pApiEndpoint;
        this.cCheckAuthenticateMerchantUrl = 'checkAuthenticateMerchant';
    }
    checkAuthenticateMerchant(pInvoiceSearchReq) {
        let mHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
        mHeaders.append('accessToken', 'myName');
        let mOptions = { headers: mHeaders };
        return this.http.post(this.pApiEndpoint + 'checkAuthenticateMerchant', pInvoiceSearchReq, mOptions)
            .toPromise()
            .then(res => { console.log(JSON.stringify(res)); })
            .catch(error => { console.log(JSON.stringify(error)); });
    }
};
AuthenticationService = tslib_1.__decorate([
    Injectable(),
    tslib_1.__param(1, Inject('APP_CONFIG')),
    tslib_1.__metadata("design:paramtypes", [HttpClient, String])
], AuthenticationService);
export { AuthenticationService };
//# sourceMappingURL=authentication.service.js.map