import { FormGroup, FormControl } from '@angular/forms';
import * as $ from 'jquery';
export class CustomValidator {
    static validateAllFields(pFormGroup) {
        this.focusOnFirstInvalidField(pFormGroup);
        Object.keys(pFormGroup.controls).forEach(field => {
            const control = pFormGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            }
            else if (control instanceof FormGroup) {
                this.validateAllFields(control);
            }
        });
    }
    static focusOnFirstInvalidField(pForm) {
        let control;
        Object.keys(pForm.controls).reverse().forEach((field) => {
            if (pForm.get(field).invalid) {
                control = pForm.get(field);
                control.markAsDirty();
            }
        });
        if (control) {
            let el = $('.ng-invalid:not(form):first');
            $('html,body').animate({ scrollTop: (el.offset().top - 100) }, 'slow', () => {
                el.focus();
            });
        }
    }
    static getFormValidationErrors(pForm) {
        Object.keys(pForm.controls).forEach(key => {
            const controlErrors = pForm.get(key).errors;
            if (controlErrors != null) {
                Object.keys(controlErrors).forEach(keyError => {
                    console.log('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
                });
            }
        });
    }
    //*******************************   Common Validators  ************************************************// 
    static numbersOnly(control) {
        const mRegExp = /^[0-9]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'numbersOnly': true };
    }
    static onlyNumbersAndDot(control) {
        const reg_exp = /^((\d)*(\.)?\d{1,2})$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'onlyNumbersAndDot': true };
    }
    static lettersOnly(control) {
        const mRegExp = /^[a-zA-Z]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'lettersOnly': true };
    }
    static letterAndSpaceOnly(control) {
        const mRegExp = /^[a-zA-Z\s]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'letterAndSpaceOnly': true };
    }
    static letterAndNumberOnly(control) {
        const mRegExp = /^[a-zA-Z0-9]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'letterAndNumberOnly': true };
    }
    static letterSpaceAndDotOnly(control) {
        const mRegExp = /^[a-zA-Z\s\.]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'letterSpaceAndDotOnly': true };
    }
    static firstName(control) {
        const mRegExp = /^[a-zA-Z\s]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'firstName': true };
    }
    static lastName(control) {
        const mRegExp = /^([a-zA-Z\s]*('?)[a-zA-Z\s]*)$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'lastName': true };
    }
    static fullName(control) {
        const mRegExp = /^([a-zA-Z\s\.]+('?)[a-zA-Z\s\.]*)$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'fullName': true };
    }
    static email(control) {
        const mRegExp = /^[\s]*([a-zA-Z0-9]+[\-\._]?)+[a-zA-Z0-9]+@{1}[a-zA-Z\d]+[a-zA-Z\d_\-]+(\.[a-zA-Z_\\-]+)+[\s]*$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'email': true };
    }
    static isBeginSpecialChar(control) {
        const mRegExp = /^[a-zA-Z0-9\s]/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isBeginSpecialChar': true };
    }
    static isEndSpecialChar(control) {
        const mRegExp = /[a-zA-Z0-9\s]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialChar': true };
    }
    static isBeginSpecialCharEmailSub(control) {
        const mRegExp = /^[a-zA-Z0-9\s\{]/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isBeginSpecialCharEmailSub': true };
    }
    static isEndSpecialCharEmailSub(control) {
        const mRegExp = /[a-zA-Z0-9.\s\}]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharEmailSub': true };
    }
    static isBeginSpecialCharDesc(control) {
        const mRegExp = /^[a-zA-Z0-9\s\<]/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isBeginSpecialCharDesc': true };
    }
    static isEndSpecialCharDesc(control) {
        const mRegExp = /[a-zA-Z0-9\s\>\)\.\:]$/;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharDesc': true };
    }
    static isConsecuSpecialCharDesc(control) {
        const mRegExp = /^(?:(?!(\*|\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isConsecuSpecialCharDesc': true };
    }
    static isEndSpecialCharUrl(control) {
        const mRegExp = /[a-zA-Z0-9\s\/]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharUrl': true };
    }
    static isConsecuSpecialCharUrl(control) {
        const mRegExp = /^(http|https):\/\/(?:(?!(--|\.\.|::|\/\/)).[\n]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isConsecuSpecialCharUrl': true };
    }
    static customURL(control) {
        const mRegExp = /^(http|https):\/\/[a-zA-Z0-9]+[a-zA-Z0-9\/:\-\_]+\.+[a-zA-Z0-9\/:\.\-\_]+[a-zA-Z0-9\/:\-\_]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customURL': true };
    }
    static isEndSpecialCharForAddr(control) {
        const mRegExp = /[a-zA-Z0-9\.\)\n\s]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharForAddr': true };
    }
    static isConsecuSpecialChar(control) {
        const mRegExp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\/\/|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isConsecuSpecialChar': true };
    }
    static loginId(control) {
        const mRegExp = /^([A-Za-z0-9\.\_!$\-])+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'loginId': true };
    }
    static password(control) {
        const mRegExp = /^([A-Za-z0-9\[\_,!@#$&%^\~\:\-\+=\]\(\)\s\{\}\?])+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'password': true };
    }
    static passwordMin(control) {
        const mRegExp = /(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\[\_,!@#$&%^\~\:\-\+=\]\(\)\s\{\}\?])/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'passwordMin': true };
    }
    static isConsecuSpecialCharPassword(control) {
        const mRegExp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\/\/|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\~\~|\+\+|==|\?\?|\:\:|\s\s|\]\]|\[\[|\}\}|\{\{)).[\n]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isConsecuSpecialCharPassword': true };
    }
    static textArea(control) {
        const mRegExp = /^[0-9a-zA-Z\s\(\)\#\.,\-\n]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'textArea': true };
    }
    static disputeMessages(control) {
        const mRegExp = /^[0-9a-zA-Z\s\(\)\.\-&\n]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'disputeMessages': true };
    }
    static termsCondition(control) {
        const mRegExp = /^[0-9a-zA-Z\s\(\)\#\.,\-&\n]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'termsCondition': true };
    }
    static termsConditionInv(control) {
        const mRegExp = /^[0-9a-zA-Z\s\(\)\#@\.,_\-&\n\/:]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'termsConditionInv': true };
    }
    static address(control) {
        const mRegExp = /^([0-9a-zA-Z \(\)\s#\.]+|[#,-]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'address': true };
    }
    static customAddress(control) {
        const mRegExp = /^[0-9a-zA-Z\s\'\/#,.\-(\)]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customAddress': true };
    }
    static city(control) {
        const mRegExp = /^[0-9a-zA-Z\s,\-\.]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'city': true };
    }
    static orderid(control) {
        const mRegExp = /^[a-zA-Z0-9\-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'orderid': true };
    }
    static isBeginSpecialCharfororderid(control) {
        const mRegExp = /^[a-zA-Z\s]/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isBeginSpecialCharfororderid': true };
    }
    static zipCode(control) {
        const mRegExp = /^[0-9a-zA-Z\s-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'zipCode': true };
    }
    static linkName(control) {
        const mRegExp = /^[0-9a-zA-Z\-\s\.]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'linkName': true };
    }
    static state(control) {
        const mRegExp = /^([a-zA-Z\-\s\.])+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'state': true };
    }
    static country(control) {
        const mRegExp = /^([a-zA-Z\s()\.,])+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'country': true };
    }
    static customPANCard(control) {
        const mRegExp = /^(([a-zA-Z]{5})+([0-9]{4})+([a-zA-Z]{1}))+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customPANCard': true };
    }
    static customSaleTaxNo(control) {
        const mRegExp = /^[0-9a-zA-Z-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customSaleTaxNo': true };
    }
    static customServiceTaxNo(control) {
        const mRegExp = /([0-9].*[A-Za-z])|([A-Za-z].*[0-9])+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customServiceTaxNo': true };
    }
    //******************************* End Common Validators ***********************************************//
    //****************************  Start Gateway Validators *********************************************//
    static webStoreName(control) {
        const mRegExp = /^[a-zA-Z0-9\s\-\&]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'webStoreName': true };
    }
    static customerCareMailSignature(control) {
        const mRegExp = /^[a-zA-Z0-9\s_.,+\/\-\&\>\<\/\:\@\""\=\?\*\(\)]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customerCareMailSignature': true };
    }
    //*****************************  End Gateway Validators **********************************************//
    //********************************* Start Validators **************************************************//
    static amount(control) {
        const mRegExp = /^((\d)*(\.)?(\d)+)$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'amount': true };
    }
    static invoiceMerRefNum(control) {
        const mRegExp = /^([0-9a-zA-Z]+|[_,-]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'invoiceMerRefNum': true };
    }
    static recurringMerRefNum(control) {
        const mRegExp = /^([0-9a-zA-Z\s]+|[_,-]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'recurringMerRefNum': true };
    }
    static legalEntity(control) {
        const mRegExp = /^[0-9a-zA-Z\s\(\).&-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'legalEntity': true };
    }
    static NumbersAndDot(control) {
        const mRegExp = /^[0-9 .]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'NumbersAndDot': true };
    }
    static emailSub(control) {
        const mRegExp = /^[a-zA-Z0-9\s._-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'emailSub': true };
    }
    static smsContent(control) {
        const mRegExp = /^[a-zA-Z0-9\#\s._-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'smsContent': true };
    }
    static invoiceEmailSub(control) {
        const mRegExp = /^[a-zA-Z0-9\s}%{._-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'invoiceEmailSub': true };
    }
    static isEndSpecialCharForSms(control) {
        const mRegExp = /[a-zA-Z0-9\s.]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharForSms': true };
    }
    static dueDate(control) {
        const mRegExp = /^[0-9 -]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'dueDate': true };
    }
    static frequency(control) {
        const mRegExp = /^[a-zA-Z -]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'frequency': true };
    }
    static isConsecuSpecialCharInvoice(control) {
        const mRegExp = /^(?:(?!(\/\*|\*\/|@@|--|__|!!|\^\^|##|\$\$|%%|&&|\.\.|\(\(|\)\)|,,|\|\|)).[\n]*)+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isConsecuSpecialCharInvoice': true };
    }
    //********************************** End Invoice ***************************************************//
    //******************************* Marketing Coupans ************************************************//
    static couponName(control) {
        const mRegExp = /^[a-zA-Z0-9\s_-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'couponName': true };
    }
    //***************************** End Marketing Coupens **********************************************//
    //****************************** Marketing Promotion ***********************************************//
    static promotionName(control) {
        const mRegExp = /^[a-zA-Z0-9\s_-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'promotionName': true };
    }
    //Google Analytics Code
    static gaCode(control) {
        const mRegExp = /^UA-\d{1,10}\-\d{1,2}$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'gaCode': true };
    }
    static promotionDescription(control) {
        const mRegExp = /^[a-zA-Z0-9\s\(\)_.-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'promotionDescription': true };
    }
    static promotionBins(control) {
        const mRegExp = /^\d{6}(?:[,]\d{6})*\s*$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'promotionBins': true };
    }
    static isEndSpecialCharPromotionBins(control) {
        const mRegExp = /[a-zA-Z0-9\s]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharPromotionBins': true };
    }
    //**************************** End Marketing Promotion *********************************************//
    //****************************** Product Management*************************************************//
    static productName(control) {
        const mRegExp = /^[a-zA-Z0-9\s_+\/\-\&]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'productName': true };
    }
    static productDesc(control) {
        const mRegExp = /^[a-zA-Z0-9\s_.,+\/\-\&\>\<\/\:\@\""\=\?\''\*\;\(\)]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'productDesc': true };
    }
    static productPrice(control) {
        const mRegExp = /^\d*\.?\d*(\d*\|\d*\.?\d*)*$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'productPrice': true };
    }
    static productcurrencyPrice(control) {
        const mRegExp = /^[0-9 .]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'productcurrencyPrice': true };
    }
    static optionValue(control) {
        const mRegExp = /^[a-zA-Z0-9\s+-.,]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'optionValue': true };
    }
    static productSku(control) {
        const mRegExp = /^[a-zA-Z0-9_-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'productSku': true };
    }
    //***************************** Start Pending Orders ************************************************//
    //Delivery Notes
    static notes(control) {
        const mRegExp = /^[a-zA-Z\d\s\.-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'notes': true };
    }
    static isEndSpecialCharForNotes(control) {
        const mRegExp = /[a-zA-Z0-9\.]$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'isEndSpecialCharForNotes': true };
    }
    static letterSpaceDotAndApostropheOnly(control) {
        let reg_exp = /^([a-zA-Z\ \\.]*('?)[a-zA-Z\ \\.]*)$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'letterSpaceDotAndApostropheOnly': true };
    }
    static letterSpaceDotAndHyphenOnly(control) {
        let reg_exp = /^[a-zA-Z\ \-\.]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'letterSpaceDotAndHyphenOnly': true };
    }
    static billAddress(control) {
        let reg_exp = /^[0-9a-zA-Z\ \\(\\)\\#\\.,\-\\&]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'billAddress': true };
    }
    static zip(control) {
        let reg_exp = /^[0-9a-zA-Z\ -]+$/;
        if (!control.value) {
            return null;
        }
        return reg_exp.test(control.value) ? null : { 'zip': true };
    }
    //***************************** End Pending Orders *************************************************//
    //for collection
    //Country
    static collectionTitle(control) {
        const mRegExp = /^[a-zA-Z0-9\s()\.,\&]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'collectionTitle': true };
    }
    static letterNumberAndSpaceOnly(control) {
        const mRegExp = /^[a-zA-Z0-9\s]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'letterNumberAndSpaceOnly': true };
    }
    //******************************** Store Settings **************************************************//
    static storeNameTitle(control) {
        const mRegExp = /^[0-9a-zA-Z\s\'\-\.]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'storeNameTitle': true };
    }
    static ccavenuedomain(control) {
        const mRegExp = /^[0-9a-zA-Z\-]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'ccavenuedomain': true };
    }
    static customedomain(control) {
        const mRegExp = /^[0-9a-zA-Z\-\.]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'customedomain': true };
    }
    //****************************** End Store Settings ************************************************//
    static colorCode(control) {
        const mRegExp = /^(#[0-9a-fA-F]{6})+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'colorCode': true };
    }
    static altTag(control) {
        const mRegExp = /^[\w!#\$%&\'\"\/\-\(\)\s\.,@]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'altTag': true };
    }
    static storePageUrl(control) {
        const mRegExp = /^[a-zA-Z0-9\.\-_\/]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'storePageUrl': true };
    }
    static ipAddress(control) {
        const mRegExp = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'ipAddress': true };
    }
    static gstNo(control) {
        const mRegExp = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
        if (control.value == undefined || control.value == null || control.value == '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'gstNo': true };
    }
    static batchFileName(control) {
        const mRegExp = /^[a-zA-Z0-9\.\s_+\/\-\&]+$/i;
        if (control.value == undefined || control.value == null || control.value === '') {
            return null;
        }
        return mRegExp.test(control.value) ? null : { 'batchFileName': true };
    }
}
//# sourceMappingURL=custom-validator.js.map