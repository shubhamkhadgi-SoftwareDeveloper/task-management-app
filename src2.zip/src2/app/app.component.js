import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import { DaterangepickerConfig } from 'ng2-daterangepicker';
let AppComponent = class AppComponent {
    constructor(sRouter, daterangepickerOptions) {
        this.sRouter = sRouter;
        this.daterangepickerOptions = daterangepickerOptions;
        this.daterangepickerOptions.skipCSS = true;
    }
    ngOnInit() {
        //this.sRouter.navigate(['login/login']);
        this.sRouter.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                return;
            }
            window.scrollTo(0, 0);
        });
    }
};
AppComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-root',
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css'],
        preserveWhitespaces: true,
    }),
    tslib_1.__metadata("design:paramtypes", [Router,
        DaterangepickerConfig])
], AppComponent);
export { AppComponent };
//# sourceMappingURL=app.component.js.map