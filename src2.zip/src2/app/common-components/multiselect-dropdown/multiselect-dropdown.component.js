var MultiselectDropdownComponent_1;
import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
let MultiselectDropdownComponent = MultiselectDropdownComponent_1 = class MultiselectDropdownComponent {
    constructor() {
        this.valueSelected = new EventEmitter();
        this.valueDeSelected = new EventEmitter();
        this.selectedItemsLabels = [];
        this.selectedItemsValues = [];
        this.onChange = (e) => {
            console.log("called 33333", e);
        };
        this.onTouched = () => { };
    }
    ngOnInit() {
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    writeValue(value) {
        // if (value) {
        //   this.value = value;
        // }
    }
    onSelect(item, multiselectDropdown, data) {
        if (this.cLimit) {
            this.onSelectWithLimit(item, multiselectDropdown);
        }
        else {
            this.onSelectWithoutLimit(item, multiselectDropdown, data);
        }
    }
    onSelectWithLimit(item, multiselectDropdown) {
        this.selectedItemsLabels.push(item);
        if (this.selectedItemsLabels.length == 1) {
            multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels[0].name + '</span>';
        }
        else {
            multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels.length + ' items selected' + '</span>';
        }
    }
    onSelectWithoutLimit(item, multiselectDropdown, data) {
        let cCardFlag = false;
        this.selectedItemsLabels.push(item[this.cTextField]);
        multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels.toString() + '</span>';
        data.forEach(element => {
            if (element.hasOwnProperty('itemName')) {
                cCardFlag = true;
                if (element.id === item[this.cIdField]) {
                    this.selectedItemsValues.push(element);
                }
            }
        });
        if (!cCardFlag) {
            this.selectedItemsValues.push(item);
        }
        this.valueSelected.emit(this.selectedItemsValues);
    }
    onDeselect(deselectItemId, multiselectDropdown) {
        if (this.cLimit) {
            this.onDeselectWithLimit(deselectItemId, multiselectDropdown);
        }
        else {
            this.onDeselectWithoutLimit(deselectItemId, multiselectDropdown);
        }
    }
    onDeselectWithLimit(deselectItemId, multiselectDropdown) {
        this.selectedItemsLabels.forEach((item, index) => {
            if (item.id === deselectItemId.id) {
                this.selectedItemsLabels.splice(index, 1);
                if (this.selectedItemsLabels.length === 1) {
                    multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels[0].name + '</span>';
                }
                else {
                    multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.cPlaceholder + '</span>';
                }
            }
        });
    }
    onDeselectWithoutLimit(deselectItemId, multiselectDropdown) {
        this.selectedItemsLabels.forEach((label, index) => {
            if (label === deselectItemId[this.cTextField]) {
                this.selectedItemsLabels.splice(index, 1);
                multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels.toString() + '</span>';
            }
        });
        this.selectedItemsValues.forEach((item, index) => {
            if (item[this.cIdField] === deselectItemId[this.cIdField]) {
                this.selectedItemsValues.splice(index, 1);
            }
        });
        if (this.selectedItemsLabels.length === 0) {
            multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.cPlaceholder + '</span>';
        }
        this.valueSelected.emit(this.selectedItemsValues);
    }
    onSelectAll(event, multiselectDropdown) {
        const data = event;
        data.forEach(item => {
            this.selectedItemsLabels.push(item.name);
        });
        multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.selectedItemsLabels.toString() + '</span>';
    }
    onDeSelectAll(event, multiselectDropdown) {
        this.selectedItemsLabels = [];
        multiselectDropdown.cdr._view.component.cdr._view.nodes[2].renderElement.childNodes[0].innerHTML = '<span>' + this.cPlaceholder + '</span>';
    }
};
tslib_1.__decorate([
    Input('placeholder'),
    tslib_1.__metadata("design:type", String)
], MultiselectDropdownComponent.prototype, "cPlaceholder", void 0);
tslib_1.__decorate([
    Input('idField'),
    tslib_1.__metadata("design:type", String)
], MultiselectDropdownComponent.prototype, "cIdField", void 0);
tslib_1.__decorate([
    Input('textField'),
    tslib_1.__metadata("design:type", String)
], MultiselectDropdownComponent.prototype, "cTextField", void 0);
tslib_1.__decorate([
    Input('data'),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "cData", void 0);
tslib_1.__decorate([
    Input('settings'),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "cSettings", void 0);
tslib_1.__decorate([
    Input('limit'),
    tslib_1.__metadata("design:type", Boolean)
], MultiselectDropdownComponent.prototype, "cLimit", void 0);
tslib_1.__decorate([
    Input('formName'),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "cFormControlName", void 0);
tslib_1.__decorate([
    Input('selectedItems'),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "cSelectedItems", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "valueSelected", void 0);
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], MultiselectDropdownComponent.prototype, "valueDeSelected", void 0);
MultiselectDropdownComponent = MultiselectDropdownComponent_1 = tslib_1.__decorate([
    Component({
        selector: 'cc-multiselect-dropdown',
        templateUrl: './multiselect-dropdown.component.html',
        styleUrls: ['./multiselect-dropdown.component.css'],
        providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => MultiselectDropdownComponent_1),
                multi: true
            }
        ]
    }),
    tslib_1.__metadata("design:paramtypes", [])
], MultiselectDropdownComponent);
export { MultiselectDropdownComponent };
//# sourceMappingURL=multiselect-dropdown.component.js.map