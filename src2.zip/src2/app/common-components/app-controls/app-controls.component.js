import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
let AppControlsComponent = class AppControlsComponent {
    constructor(modalService) {
        this.modalService = modalService;
        //DatePicker
        this.daterange = {};
        this.options = {
            locale: { format: 'DD-MM-YYYY HH:mm' },
            alwaysShowCalendars: false,
            "applyClass": "btn-theme",
            "cancelClass": "btn-blank",
            timePicker: true,
            singleDatePicker: false,
            showDropdowns: false,
        };
        //checkbox
        this.selectedValues = [];
        //switch Btn
        this.switchValue = 'Y';
        this.cities = [];
        this.cities.push({ label: 'New York', value: 'New York' });
        this.cities.push({ label: 'Rome', value: 'Rome' });
        this.cities.push({ label: 'London', value: 'London' });
        this.cities.push({ label: 'Istanbul', value: 'Istanbul' });
        this.cities.push({ label: 'Paris', value: 'Paris' });
    }
    ngOnInit() {
    }
    selectedDate(value, datepicker) {
        // this is the date the iser selected
        console.log(value);
        // any object can be passed to the selected event and it will be passed back here
        datepicker.start = value.start;
        datepicker.end = value.end;
        // or manupulat your own internal property
        this.daterange.start = value.start;
        this.daterange.end = value.end;
        this.daterange.label = value.label;
    }
    openModal(template) {
        this.modalRef = this.modalService.show(template);
    }
    onSwitchChange(event, switchValue) {
        if (event.target.checked) {
            this[switchValue] = 'Y';
        }
        else {
            this[switchValue] = 'N';
        }
    }
};
AppControlsComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-app-controls',
        templateUrl: './app-controls.component.html',
        styleUrls: ['./app-controls.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [BsModalService])
], AppControlsComponent);
export { AppControlsComponent };
//# sourceMappingURL=app-controls.component.js.map