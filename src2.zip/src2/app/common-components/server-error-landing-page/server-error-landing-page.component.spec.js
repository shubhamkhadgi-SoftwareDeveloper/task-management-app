import { async, TestBed } from '@angular/core/testing';
import { ServerErrorLandingPageComponent } from './server-error-landing-page.component';
describe('ServerErrorLandingPageComponent', () => {
    let component;
    let fixture;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ServerErrorLandingPageComponent]
        })
            .compileComponents();
    }));
    beforeEach(() => {
        fixture = TestBed.createComponent(ServerErrorLandingPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=server-error-landing-page.component.spec.js.map