import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LandingPageMsgService } from '../../common-services/landing-page-msg.service';
let ServerErrorLandingPageComponent = class ServerErrorLandingPageComponent {
    constructor(sRoute, sLandingPageMsg) {
        this.sRoute = sRoute;
        this.sLandingPageMsg = sLandingPageMsg;
    }
    ngOnInit() {
        this.sRoute.params.subscribe(params => {
            let mErrorCode = params['errorCode'];
            if (mErrorCode != undefined && mErrorCode != null) {
                console.log('errorCode-->' + mErrorCode);
                if (mErrorCode == 400) {
                    this.setError400();
                }
                else if (mErrorCode == 401) {
                    this.setError401();
                }
                else if (mErrorCode == 403) {
                    this.setError403();
                }
                else if (mErrorCode == 404) {
                    this.setError404();
                }
                else if (mErrorCode == 500) {
                    this.setError500();
                }
                else if (mErrorCode == 502) {
                    this.setError502();
                }
                else if (mErrorCode == 503) {
                    this.setError503();
                }
                else if (mErrorCode == 504) {
                    this.setError504();
                }
            }
        });
    }
    //Bad Request 
    setError400() {
        this.cErrorCode = 400;
        this.cErrorDec = 'Bad Request';
        this.cErrorMsg = 'Sorry ! We could not understand your request';
        this.cErrorClass = 'error-bad-request-400';
    }
    //token-expired
    setError401() {
        this.cErrorCode = 401;
        this.cErrorDec = 'Unauthorized';
        this.cErrorMsg = 'Oops! Permission to view this page is denied';
        this.cErrorClass = 'error-token-expired';
    }
    //forbidden
    setError403() {
        this.cErrorCode = 403;
        this.cErrorDec = 'Forbidden';
        this.cErrorMsg = 'Oops! Access to this page is forbidden';
        this.cErrorClass = 'error-forbidden-403';
    }
    setError404() {
        this.cErrorCode = 404;
        this.cErrorDec = 'Not Found';
        this.cErrorMsg = 'Oops! Looks like this page does not exist';
        this.cErrorClass = 'error-page-not-found-404';
    }
    setError500() {
        this.cErrorCode = 500;
        this.cErrorDec = 'Internal Server Error';
        this.cErrorMsg = 'Aah! Something seems to have gone wrong! Refresh this page or try again later';
        this.cErrorClass = 'error-internal-server-error-500';
    }
    setError502() {
        this.cErrorCode = 502;
        this.cErrorDec = 'Bad Gateway';
        this.cErrorMsg = 'Sorry! We have received an incomplete or invalid response';
        this.cErrorClass = 'error-internal-server-error-500';
    }
    setError503() {
        this.cErrorCode = 503;
        this.cErrorDec = 'Service Unavailable';
        this.cErrorMsg = 'Sorry! We are temporarily unable to service your request. Please try again later';
        this.cErrorClass = 'error-server-unavailable-503';
    }
    setError504() {
        this.cErrorCode = 504;
        this.cErrorDec = 'Gateway Timeout';
        this.cErrorMsg = 'Oops! Looks like its taking longer than we anticipated. Please try again later';
        this.cErrorClass = 'error-gateway-timeout-504';
    }
};
ServerErrorLandingPageComponent = tslib_1.__decorate([
    Component({
        selector: 'app-server-error-landing-page',
        templateUrl: './server-error-landing-page.component.html',
        styleUrls: ['./server-error-landing-page.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [ActivatedRoute,
        LandingPageMsgService])
], ServerErrorLandingPageComponent);
export { ServerErrorLandingPageComponent };
//# sourceMappingURL=server-error-landing-page.component.js.map