import * as tslib_1 from "tslib";
import { Component, Input, Output, EventEmitter } from '@angular/core';
let PaginatorComponent = class PaginatorComponent {
    //    public cRecordFrom: number;
    //    public cRecordTo: number;
    constructor() {
        this.pagingEvent = new EventEmitter();
        this.cPageNoList = [];
        this.cPageNo = 1;
        this.cGoToPageNo = 1;
        this.calTotalPages();
    }
    ngOnChanges() {
        this.calTotalPages();
        this.calPagNoList(this.cPageNo);
    }
    ngOnInit() {
        this.calPagNoList(this.cPageNo);
    }
    calPagNoList(pPageNo) {
        if (!this.cPageNoList.includes(this.cPageNo))
            if (pPageNo !== this.cTotalPages) {
                this.cPageNoList = [];
                for (let i = 1; i <= (this.cTotalPages > this.cDispalyPages ? this.cDispalyPages : this.cTotalPages); i++) {
                    this.cPageNoList.push(i);
                }
            }
        if (pPageNo === this.cTotalPages) {
            this.cPageNoList = [];
            for (let i = this.cTotalPages; i > (this.cTotalPages > this.cDispalyPages ? this.cTotalPages - this.cDispalyPages : this.cTotalPages); i--) {
                this.cPageNoList.unshift(i);
            }
        }
    }
    calTotalPages() {
        this.cTotalPages = this.cTotalRecord / this.cPageSize;
        this.cTotalPages = Math.floor(this.cTotalPages);
        if ((this.cTotalRecord % this.cPageSize) > 0) {
            this.cTotalPages++;
        }
        //        this.cPageNoList = [];
        //        
        //        for (let i: number = 1; i <= (this.cTotalPages > this.cDispalyPages ? this.cDispalyPages : this.cTotalPages); i++) {
        //            this.cPageNoList.push(i);
        //        }
        //        this.cPageNo=1;
        if (this.cTotalRecord > 0) {
            this.recordToFrom();
        }
        else {
            this.cRecordFrom = 0;
            this.cRecordTo = 0;
        }
    }
    onGoToPageNoClick() {
        if (this.cGoToPageNo >= 1 && this.cGoToPageNo <= this.cTotalPages) {
            this.cPageNo = this.cGoToPageNo;
            let mDispalyPagesNo = this.cPageNoList.length;
            this.cPageNoList = [];
            if (this.cPageNo > mDispalyPagesNo) {
                for (let i = (this.cPageNo - mDispalyPagesNo + 1); i <= this.cPageNo; i++) {
                    this.cPageNoList.push(i);
                }
            }
            else {
                for (let i = 1; i <= mDispalyPagesNo; i++) {
                    this.cPageNoList.push(i);
                }
            }
            this.recordToFrom();
            this.pagingEvent.emit(this);
        }
    }
    onPageSizeSelect() {
        this.cPageNo = 1;
        this.calTotalPages();
        this.calPagNoList(this.cPageNo);
        this.pagingEvent.emit(this);
    }
    onNextClick() {
        if (this.cPageNo < this.cTotalPages) {
            this.cPageNo++;
            if (this.cPageNo > this.cPageNoList.length && this.cPageNo > this.cPageNoList[this.cPageNoList.length - 1]) {
                this.arrayIncrement();
            }
            this.recordToFrom();
            this.pagingEvent.emit(this);
        }
    }
    onNext5Click() {
        this.cPageNo = this.cTotalPages;
        this.calPagNoList(this.cPageNo);
        this.recordToFrom();
        this.pagingEvent.emit(this);
    }
    onPreviousClick() {
        if (this.cPageNo > 1) {
            this.cPageNo--;
            if (this.cPageNo >= 1 && this.cPageNo < this.cPageNoList[0]) {
                this.arrayDecrement();
            }
            this.recordToFrom();
            this.pagingEvent.emit(this);
        }
    }
    onPrevious5Click() {
        this.cPageNo = 1;
        this.calPagNoList(this.cPageNo);
        this.recordToFrom();
        this.pagingEvent.emit(this);
    }
    onPageNoClick(pPageNo) {
        this.cPageNo = pPageNo;
        this.recordToFrom();
        this.pagingEvent.emit(this);
    }
    arrayIncrement() {
        this.cPageNoList.shift();
        this.cPageNoList.push(this.cPageNoList[this.cPageNoList.length - 1] + 1);
    }
    arrayDecrement() {
        this.cPageNoList.splice(this.cPageNoList.length - 1, 1);
        this.cPageNoList.unshift(this.cPageNoList[0] - 1);
    }
    arrayDecrement5() {
        this.cPageNoList.splice(this.cPageNoList.length - 1, 5);
        this.cPageNoList.unshift(this.cPageNoList[0] - 5);
    }
    recordToFrom() {
        let mDeca = (this.cPageNo * this.cPageSize) - this.cPageSize;
        this.cRecordFrom = mDeca + 1;
        if (this.cTotalPages == this.cPageNo) {
            if (this.cTotalRecord == this.cPageSize) {
                this.cRecordTo = this.cTotalRecord;
            }
            else {
                //this.cRecordTo = mDeca + (this.cTotalRecord % this.cPageSize);
                this.cRecordTo = +mDeca + +((this.cTotalRecord % this.cPageSize) == 0 ? this.cPageSize : (this.cTotalRecord % this.cPageSize));
            }
        }
        else {
            this.cRecordTo = +mDeca + +this.cPageSize;
        }
    }
};
tslib_1.__decorate([
    Output(),
    tslib_1.__metadata("design:type", Object)
], PaginatorComponent.prototype, "pagingEvent", void 0);
tslib_1.__decorate([
    Input('updown'),
    tslib_1.__metadata("design:type", String)
], PaginatorComponent.prototype, "cUpDown", void 0);
tslib_1.__decorate([
    Input('totalRecord'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cTotalRecord", void 0);
tslib_1.__decorate([
    Input('pageSize'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cPageSize", void 0);
tslib_1.__decorate([
    Input('pageSizeOption'),
    tslib_1.__metadata("design:type", Array)
], PaginatorComponent.prototype, "cPageSizeOption", void 0);
tslib_1.__decorate([
    Input('dispalyPages'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cDispalyPages", void 0);
tslib_1.__decorate([
    Input('showLabel'),
    tslib_1.__metadata("design:type", String)
], PaginatorComponent.prototype, "cShowLabel", void 0);
tslib_1.__decorate([
    Input('recordFrom'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cRecordFrom", void 0);
tslib_1.__decorate([
    Input('recordTo'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cRecordTo", void 0);
tslib_1.__decorate([
    Input('pageNo'),
    tslib_1.__metadata("design:type", Number)
], PaginatorComponent.prototype, "cPageNo", void 0);
PaginatorComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-paginator',
        templateUrl: './paginator.component.html',
        styleUrls: ['./paginator.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [])
], PaginatorComponent);
export { PaginatorComponent };
//# sourceMappingURL=paginator.component.js.map