import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
let LandingPageComponent = class LandingPageComponent {
    constructor() { }
    ngOnInit() {
    }
};
tslib_1.__decorate([
    Input('moduleClass'),
    tslib_1.__metadata("design:type", String)
], LandingPageComponent.prototype, "moduleClass", void 0);
tslib_1.__decorate([
    Input('message'),
    tslib_1.__metadata("design:type", String)
], LandingPageComponent.prototype, "message", void 0);
LandingPageComponent = tslib_1.__decorate([
    Component({
        selector: 'cc-landing-page',
        templateUrl: './landing-page.component.html',
        styleUrls: ['./landing-page.component.css']
    }),
    tslib_1.__metadata("design:paramtypes", [])
], LandingPageComponent);
export { LandingPageComponent };
//# sourceMappingURL=landing-page.component.js.map